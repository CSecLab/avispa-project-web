% a datalog problem resolver. It outputs all the solutions
% of the problem.
%Usage : 
%initialization([List_of_Datalog_Rules]).
%datalog.
%In the list, each datalog rule :  
%      R_i <- S_(i,1),...,S_(i,k_i)
%is given as :
%      datalogrule(R_i,(S_(i,1),(...,S_(i,k_i))))

%for example :
 
%initialization([datalogrule(crypt(pk(X1),pk(X3)),(pk(X3),pk(X1))),
%    datalogrule(pk(ni),true)]).
   


% Preliminary definition -- needed by gprolog

:- op(999,xf,'inv').

:- dynamic(datalogrule/2).



not_member(_,[]) :- true.
not_member(X,[T|Tail]) :- X=T -> fail; not_member(X,Tail).

% this function explores all the possibilities, including the 'don't touch'.
% (hence the last rule). It also carries a trace of the proof done using
% the other datalogrules.


 
trace(true,[],_) :-
 	true.
 
trace((A,B),Proof,AlreadyUsed) :-
	trace(A,ProofA,AlreadyUsed),
	trace(B,ProofB,AlreadyUsed),
	append(ProofA,ProofB,Proof).
trace(A,Proof,AlreadyUsed) :-
	datalogrule(A,B),
	not_member(datalogrule(A,B),AlreadyUsed),
	trace(B,Proof,[datalogrule(A,B) | AlreadyUsed]).
trace(Proof,[Proof],_) :- 
	Proof \== true, 
	Proof \= (_,_), 
	true.

 
%
% the meaning is contained in the name. It should later change to
% the actual output rule. It will then be possible to write directly from
% C.
%


not_empty(List) :-
	List \== [].


give_output_list([Head | Tail],Output,Separator) :-
	not_empty(Tail) ->
	  give_output(Head,Head1),
	  append(Head1,[Separator],Head_out),
	  give_output_list(Tail,Tail_out,Separator),
	  append(Head_out,Tail_out,Output);
	give_output(Head,Output).
	




convert(Functor,List) :-
	Functor == '.' -> 
	     List = [] ;
	write_term_to_chars(
        	            List,
			    Functor,
			    [namevars(true),portrayed(true)]
			).

 
give_output(Term,[]) :- Term == [] -> true; fail.
give_output(Term,Output) :-
%
% if Term is a variable, remove the leading '_' and
% replace it with x
%
	var(Term) ->
	  write_term_to_chars(Tmp,Term,[namevars(true),portrayed(true)]),
	  Tmp = [_ |Tail],
	  Output = ['x' |Tail];
%
% if Term is a constant, just write it
%
        functor(Term,X,0) -> 
	  not_empty(X),
	  write_term_to_chars(Output,
	                      Term,
			      [namevars(true),portrayed(true)]);
%
% This is the part that handles the format of the output.
% Currently, the output is given as an IF rule with the opi
% missing.
%
	functor(Term,'datalogrule',2) ->
	  Term =.. ['datalogrule',Left,Right],
	  give_output(Left,ResLeft),
	  give_output(Right,ResRight),
	  append(ResLeft,[' ','=','>'],Left1),
	  append(ResRight,Left1,Output);
%
% if Term is a private key, output the ' instead of prim
%
        functor(Term,'prim',1) ->
          Term =.. ['prim',X],
	  give_output(X,Res),
	  append(Res,['\''],Output);
%
% if it is a list
%
        functor(Term,'.',2) ->
	  not_empty(Term),
	  give_output_list(Term,Output,' ');
%
% if Term as some arguments, write them...
%
	Term =.. [Function | Arg] ->
	  convert(Function,Head1),
	  give_output_list(Arg,Res1,' '),
	  append(Head1,[' '],Head),
	  append(Res1,[' '],Res),
	  append(Res,Head,Output).

%
% the printing functions
%



print_line([]) :-
	nl.
print_line([Head|Tail]) :-
	put_char(user_output,Head),
	print_line(Tail).

print_clause(datalogrule(G,H)) :- 
	give_output(datalogrule(G,H),Output),
	print_line(Output).

    
%
% initialisation functions :
% in this part, we put the datalog rules to be studied
%



assertall([]) :- true. 
assertall([First |Other]) :- 
	assertz(First),  
	assertall(Other). 


initialization(X) :- 
	assertall(X). 


% 
% and now, the function that prints all possibilities
% (hence the fail, so we do not stop after the first solution)
%

datalog :-
	datalogrule(A,B), 
	trace(B,Proof,[datalogrule(A,B)]), 
	print_clause(datalogrule(A,Proof)), fail.


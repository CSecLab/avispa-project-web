/*********************************************************************
; Copyright 1992-97, The University of Iowa (UI).  All rights reserved. 
; By using this software the USER indicates that he or she has read, 
; understood and will comply with the following:
;
; --- UI hereby grants USER nonexclusive permission to use, copy and/or
; modify this software for internal, noncommercial, research purposes only.
; Any distribution, including commercial sale or license, of this software,
; copies of the software, its associated documentation and/or modifications
; of either is strictly prohibited without the prior consent of UI.  Title
; to copyright to this software and its associated documentation shall at
; all times remain with UI.  Appropriate copyright notice shall be placed
; on all software copies, and a complete copy of this notice shall be
; included in all copies of the associated documentation.  No right is
; granted to use in advertising, publicity or otherwise any trademark,
; service mark, or the name of UI.  Software and/or its associated
; documentation identified as "confidential," if any, will be protected
; from unauthorized use/disclosure with the same degree of care USER
; regularly employs to safeguard its own such information.
;
; --- This software and any associated documentation is provided "as is," and
; UI MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
; THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
; USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL
; NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL
; PROPERTY RIGHTS OF A THIRD PARTY.  UI, the University of Iowa,
; its Regents, officers, and employees shall not be liable under any
; circumstances for any direct, indirect, special, incidental, or
; consequential damages with respect to any claim by USER or any third
; party on account of or arising from the use, or inability to use, this
; software or its associated documentation, even if UI has been advised
; of the possibility of those damages.
*********************************************************************/
#define IN_MAIN
#include "main.h"

/* Message Types */
#define MAX_MSIZE 2000 /* Maximum size of a message */

/* Global variables */
char *fname_out = NULL;

FILE *command_line_check ();

/*************
 *
 *   main()
 *
 *************/

main(argc, argv)
     int argc;
     char **argv;
{
  FILE *fin;
  FILE *efile;
  int res;

  if ( argc == 1 ) print_menu();

  fin = command_line_check( argc, argv, &efile );

  if (DATA == 1)
    list_init_once_forall();
  else
    trie_init_once_forall();

  if (!Stop) {
    read_one_problem(1, efile, argc, argv);
    res = sato(fin); 
    if (efile != NULL || res == 2) read_one_problem(0, efile, argc, argv);
    if (OUTPUT < 2) print_command(Sato_fp, 1, argc, argv);
  }
}

void p_banner(argc, argv)
     int argc;
     char *argv[];
{

  char host[64];

  if (gethostname(host, 64) != 0) str_copy("???", host);
  printf("------- SATO 3.0 on %s ------\n", host);
  print_command(stdout, 0, argc, argv);
  printf("\n");
}  /* print_banner */

void print_menu()
{
  printf("Usage: sato [<Options>] <Input_file>\n\n");
  printf("Options are:\n");
  printf("   -f       : use the input format suggested by DIMACS\n");
  printf("   -p       : preprocess (sort) input clauses\n");
  printf("   -o<n>    : print out clauses (0 <= n <= 3)\n");
  printf("   -g<n>    : set the length of created clauses to be saved\n");
  printf("   -h<n>    : set the maximal number of hours to be run\n");
  printf("   -m<n>    : set the number of expected models (default: 1)\n");
#ifdef MORETRACE
  printf("   -t<n>    : set the trace level (2-4: search; 5-8: build; 9: all)\n");
#else
  printf("   -t<n>    : set the trace level (0 or 1)\n");
#endif
/*
  printf("   -s<n>    : select an atom in clauses for branching:\n");
  printf("               n = 0: the atom with the minimal index;\n");
  printf("               n = 1: an atom in a shortest positive clause (default);\n");
  printf("               n = 2: a variant of n = 1;\n");
  printf("               n = 3: an atom with most occurrences;\n");
  printf("               n = 4: an atom with most occurrences in all/binary clauses;\n");
  printf("               n = 5: an atom with most Jeroslow-Wang weight.\n");
  printf("   -b<n>    : set the base number for splitting jobs (default: 0)\n");
*/
  printf("   -e fname : give the file name of unfinished jobs\n");
#ifdef BENCHMARK
  printf("   -A<n>    : Random k-sat problems (-K<k>, n atoms, -C<c> clauses)\n");
  printf("   -P<n>    : Pigeonhole problems (n holes, n+1 pigeons)\n");
  printf("   -Q<n>    : Queen problems (n queens on n by n board)\n");
  printf("   -R<n>    : Ramsey numbers r(p, q) = n with -P<p> and -Q<q>\n");
  printf("   -G<n>    : Quasigroup problems: QGm(n), m from -Q<m>\n");
  printf("   -B<n>    : Cyclic method for quasigroups QGm(h^g, i), where:\n");
  printf("   -C<n>    :   n=hg+k, m from -Q<m>, h from -H<h>, i from -I<i>\n");
  printf("   -K<k>    : k-PMD(h^g, i) problems, h, g, i, as above\n");
  printf("   -O<k>    : k-MOLS(h^g, i) problems, h, g, i, as above\n");
#endif
  printf("   \n");
  printf("Input_file is either `-' (denotes the standard input) or a \n");
  printf("    file name. The default input consists of a list of clauses, each\n");
  printf("    of which is a list of nonzero integers surrounded by parentheses.\n");
  printf("    When -p is not set, it is more efficient if the integers in\n");
  printf("    each clause are in nondecreasing order of their absolute values.\n");
  printf("    Tautologies and duplicated literals are always removed.\n");
  printf("    E.g., (1 1 -2 -4) is the same as (1 -2 -4).\n");
  printf("    If the option `-f' is set, the DIMACS format will be used.\n");
  printf("\n");

  exit ( 0 );
}

FILE *open_fname_out (mode)
     char *mode;
{
  FILE *fout;

  if (fname_out == NULL) 
    fname_out = (char *) strdup("unfinish.jobs");
  else if (mode[0] == 'w') {
    char s[100];
    sprintf(s, "mv %s %s~", fname_out, fname_out);
    system (s);
  }
  fout = fopen(fname_out, mode);
  if (fout == NULL) fout = stdout;
  return (fout);
}

void read_one_problem (flag, efile, argc, argv)
     int flag;
     FILE *efile;
     int argc;
     char *argv[];
{
  static int msgout[MAX_MSIZE];
  int MSIZE, i;

  if (flag) {
    int sign_arr [MAX_ATOM];
    int cl_arr [MAX_ATOM];
    int total, ch, j;
    int old_format;

    OLDV = j = 0;
    for (i = 1; i <= Max_atom; i++) Value[i] = DC;
    msgout[0] = 2;
    msgout[1] = 0;

    if (efile == NULL) return;
    ch = getc ( efile );  
    while (ch != EOF && (ch != '(' || (ch = getc ( efile )) != '(')) {
      skip_chars_until( efile, '\n' ); 
      ch = getc ( efile );                /* skip it */
    }

    /* read the extra unit clauses */
    if (ch != EOF) {
      old_format = FORMAT;
      FORMAT = 1;
      total = read_one_clause( efile, cl_arr, sign_arr, &j, NULL );
      FORMAT = old_format;
      MSIZE = 1;

      if (total > 0) {
	reverse(cl_arr, total);
	printf("One set of extra unit clauses is read:\n    ");
	print_clause(cl_arr, sign_arr, total);

	for (i = 0; i < total; i++) {
	  ch = cl_arr[i];
	  Value[ch] = sign_arr[ch];
	  msgout[MSIZE++] = (sign_arr[ch])? ch : -ch;
	}
      }
	
      /* read in the old values */
      ch = getc ( efile );  
      while ( ch != EOF && ch != '(') ch = getc ( efile );  
      if (ch != EOF) {
	total = read_guide_path( efile, Old_value, Old_choice );
	if (total > 1) {
	  printf("\nA guiding path is read:\n    ");
	  print_read_guide_path(Old_value, Old_choice, total);
	  reverse(Old_value, total);
	  reverse(Old_choice, total);
	  i = total;
	  while (i-- && OLDV == 0) {
	    if (Old_choice[i] == FF) {
	      if (Old_value[i] > 0) {
		Value[Old_value[i]] = TT;
	      } else {
		Value[-Old_value[i]] = FF;
	      }
	      msgout[MSIZE++] = Old_value[i];
	    } else {
	      OLDV = i+1;
	    }
	  }
	}
      }
      
      printf("\n");

      msgout[0] = MSIZE;
    }

  } else {

    FILE *fout;

    fout = open_fname_out("w");
    fprintf(fout, "Unfinished job is:\n((");

    MSIZE = msgout[0];
    if (MSIZE > 1)
      for (i = 1; i < MSIZE; i++) fprintf(fout, " %d", msgout[i]);
    else 
      fprintf(fout, " 0");

    fprintf(fout, " ) ");
    output_guide_path(fout);
    fprintf(fout, ")\n");

    if (efile != NULL) save_untouched(efile, fout);
    fclose(fout);
    append_cmd_line(argc, argv);
  }
}

void save_untouched (efile, fout)
     FILE *efile, *fout;
{
  int i;

  while ((i = getc ( efile )) != EOF && i != '(' && i != 'T')
    skip_chars_until( efile, '\n' ); 
  if (i != EOF) {
    fprintf(fout, "Untouched jobs:\n"); putc( i, fout );
    while ((i = getc( efile )) != EOF) putc( i, fout );
  }
}

void append_cmd_line(argc, argv)
     int argc;
     char *argv[];
{
  FILE *fout;

  fout = fopen(fname_out, "a");
  if (OUTPUT < 2) print_command(fout, 1, argc, argv);
  fclose(fout);
}

void print_command (fout, flag, argc, argv)
     FILE *fout; int flag, argc; char *argv[];
{
  int i;
  fprintf(fout, "The job \"%s", argv[0]);
  for (i = 1; i < argc; i++) fprintf(fout, " %s", argv[i]);
  if (flag)
    fprintf(fout, "\" ended at %s", get_time());
  else 
    fprintf(fout, "\" started at %s", get_time());
}

FILE *command_line_check (argc, argv, efile)
     int argc;
     char **argv;
     FILE **efile;
{
  int i, temp;
  FILE *fin;

  /* Default */
  *efile = fin = NULL;

  Memory_count = 0;
  Max_atom = MAX_ATOM-1;
  Max_clause = 100000;
  Printed_clause = 0;
  Lookahead_level = MAX_SHORT;

#ifdef PRIVATE
  GRASP = 0;
  DATA = 3;
  FORMAT = 1;
#else
  GRASP = 20;
  DATA = 2;
  FORMAT = 0;
#endif 

  Stop = 0;
  CREATE = 0;
  TRACE = 1;
  MODEL = 1;
  SELECT = 0;
  PREP = 1;
  LINE = 20;
  JUMP = 1;
  OUTPUT = 0;
  OLDV = 0;
  HOURS = 23; /* default: 23 hours */
  CHOICE1 = FF;
  CHOICE2 = TT;
  IDEMPOTENT = 1;

#ifdef BENCHMARK
  FLAG = 0;
  RAMSEY = 0;
  NHOLE = 0;
  QGROUP = 0;
  PIGEON = 0;
  QUEEN = 0;
  INCOMPLETE = 0;
  CYCLIC = 0;
  RESTRICT = 0;
  SQUARE2 = 0;
#endif

  for(i = 1; i < argc; i++) 
    if (argv[i][0] == '-')  {
      temp = str_int(argv[i], 2);

      if (argv[i][1] == 'c') {
	CREATE = temp;
      } else if (argv[i][1] == 'd') {
	DATA = temp;
 	if (DATA != 2) GRASP = 0;
      } else if (argv[i][1] == 'e') {
	i++;
	fname_out = (char *) strdup(argv[i]);
	if ((*efile = fopen (fname_out, "r")) == NULL) 
	  fprintf(stderr, "%s ignores invalid parameter : %s\n",
		  argv [0], fname_out );
      } else if (argv[i][1] == 'f') {
	FORMAT = temp;
      } else if (argv[i][1] == 'g') {
	GRASP = temp;
	if (GRASP) DATA = 2;
      } else if (argv[i][1] == 'h') {
	HOURS = temp;
      } else if (argv[i][1] == 'j') {
	JUMP = temp;

#ifdef BENCHMARK
      } else if (argv[i][1] == 'a') {
	set_addk(temp);
      } else if (argv[i][1] == 'i') {
	open_input_sqs(argv[++i]);
      } else if (argv[i][1] == 'k') {
	set_k_flag(temp);
      } else if (argv[i][1] == 'r') {
	RESTRICT = temp;
#endif

      } else if (argv[i][1] == 'l') {
	LINE = temp;
      } else if (argv[i][1] == 'm') {
	MODEL = temp;
      } else if (argv[i][1] == 'o') {
	/* OUTPUT = 3+2: print every clause in dimacs format 
	   OUTPUT = 2+2: print nontrivial clause in lisp format */
	/* OUTPUT = 1+2: print every clause in lisp format 
	   OUTPUT = 0+2: print nontrival clause in lisp format */
	OUTPUT = temp+2;
      } else if (argv[i][1] == 'p') {
	if (temp == 1) IDEMPOTENT = 0;
	else if (temp == 0) PREP = 0;
	else IDEMPOTENT = temp;
      } else if (argv[i][1] == 's') {
	SELECT = temp;
      } else if (argv[i][1] == 't') {
	TRACE = temp;
	if (!OUTPUT && TRACE > 5) OUTPUT = 1;
      } else if (argv[i][1] == 'v') {
	CHOICE1 = TT;
	CHOICE2 = FF;
#ifdef BENCHMARK
      } else if (argv[i][1] == 'A') {
	RANDOM = temp;
      } else if (argv[i][1] == 'B') {
	QGROUP = temp;
	CYCLIC = 'B';
      } else if (argv[i][1] == 'C') {
	QGROUP = temp;
	CYCLIC = 'C';
      } else if (argv[i][1] == 'D') {
	QGROUP = temp;
	set_double_cl(1); 
      } else if (argv[i][1] == 'G') {
	QGROUP = temp;
      } else if (argv[i][1] == 'H') {
	RAMSEY = temp;
      } else if (argv[i][1] == 'I') {
	INCOMPLETE = temp;
      } else if (argv[i][1] == 'K') {
	PMD = temp;
	if (PMD > 20) { PMD -= 20; IDEMPOTENT = 3; }
	if (PMD > 10) { PMD -= 10; IDEMPOTENT = 2; }
      } else if (argv[i][1] == 'M') {
	CYCLIC = temp;
      } else if (argv[i][1] == 'N') {
	set_num_of_hole(temp);
      } else if (argv[i][1] == 'O') {
	OARRAY = temp;
      } else if (argv[i][1] == 'P') {
	PIGEON = temp;
      } else if (argv[i][1] == 'Q') {
	QUEEN = temp;
      } else if (argv[i][1] == 'R') {
	RAMSEY = temp;
#endif

      } else if (argv[i][1] == '\0' && (i+1 == argc)) {
	fin = stdin;
      } else {
	fprintf(stderr, "%s ignores invalid parameter : %s\n",
		argv[0], argv[i] );
      }
    } else if (i+1 < argc) {
      fprintf ( stderr, "%s ignores invalid parameter : %s\n",
	       argv [0], argv [i] );
    }

  if (OUTPUT < 2) {
    p_banner(argc, argv);
    if (fname_out != NULL) 
      printf( "File \"%s\" is open for the extra clauses.\n", fname_out );
  } else {
    printf("c ");
    print_command(stdout, 0, argc, argv);
  }

#ifdef BENCHMARK
  if (QGROUP > 0 || RAMSEY > 0 || PIGEON > 0 || QUEEN > 0) {
    fin = NULL; PREP = 0;
  } else 
#endif

  if (fin != stdin && ((fin = fopen ( argv [argc-1], "r" ) ) == NULL)) {
    fprintf ( stderr, "%s can't open file : %s\n",
	      argv [0], argv [argc-1] );
    Stop = 1;
  } else if (OUTPUT < 2) {
    printf( "Input file \"%s\" is open.\n", argv [argc-1] );

    if (FORMAT == 0) {
      /* fix Max_atom and Max_clause if possible */
      int ch;
      printf( "Reading clauses in DIMACS's format.\n");
      ch = getc ( fin );  
      while (ch != 'p') {
	skip_chars_until( fin, '\n' ); 
	ch = getc ( fin );  
	if (ch == EOF) { printf("The file is empty.\n"); exit(0); }
	if (ch == 'p' &&
	    getc(fin) == ' ' &&
	    getc(fin) == 'c' &&
	    getc(fin) == 'n' &&
	    getc(fin) == 'f' ) {
	  fscanf(fin, "%d", &Max_atom);
	  fscanf(fin, "%d", &Max_clause);
	  printf("Max_atom = %d, Max_clause = %d\n", Max_atom, Max_clause);
	  ch = 'p';
	}
      }
    }
  }

#ifdef BENCHMARK
  /* some initiation following the parameters */
  if (RANDOM) {
    random_ksat_init(RANDOM, QGROUP, PMD);
  } else if (PMD > 0) {
    init_pmd();
  } else if (OARRAY > 0) {
    init_oarray();
  } else if (QGROUP > 0) {
    init_qgroups();
  } else if (RAMSEY > 0) 
    Max_atom = (RAMSEY-1) * RAMSEY / 2;
  else if (QUEEN > 0)
    Max_atom = QUEEN * QUEEN;
  else if (PIGEON > 0)
    Max_atom = PIGEON * (PIGEON+1);

  if (Max_atom >= MAX_ATOM) {
    fprintf(stderr, "Max_atom(=%d) >= MAX_ATOM(=%d) (check sato.h).\n",
	       Max_atom, MAX_ATOM);
    Stop = 1;
  }
#endif

  return fin;
}

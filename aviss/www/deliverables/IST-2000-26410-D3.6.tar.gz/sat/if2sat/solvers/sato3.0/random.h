#include <limits.h>

/* A good random number generator. */
#define IM1   2147483563
#define IM2   2147483399
#define AM    (1.0/IM1)
#define IMM1  (IM1-1)
#define IA1   40014
#define IA2   40692
#define IQ1   53668
#define IQ2   52774
#define IR1   12211
#define IR2   3791
#define NTAB  32
#define NDIV  (1+IMM1/NTAB)
#define EPS   1.2e-7
#define RNMX  (1.0-EPS)

long random_seed;
void reset_seed();
double good_random();

#define TISET_NOVALUE -99

typedef struct {
  long *dense_array;    /* The index in sparse_array, i.e., the element */
  long *sparse_array;   /* The index in dense_array, or TISET_NOVALUE */
  long length;          /* The actual number of elements in the set */
  long limit;           /* The elements can range from 0 to limit - 1 */
} time_index_set_object, *time_index_set;

/* Returns a long integer in the range [0, x-1]. */
#define random_long(x) ((long)(good_random() * (double)(x)))

/* Generate an instance of a random K-SAT problem. */
void random_ksat();

/* For ensuring that no clause contains more than one literal
   associated with the same proposition. */
static time_index_set existing_props;

/* Macros and function prototypes. */
static int ksat_make_mitchell();

time_index_set tiset_emptyset();

#define tiset_cardinality(x) ((x)->length)

#define tiset_size(x) ((x)->limit)

#define tiset_isempty(x) ((x)->length == 0)

#define tiset_notempty(x) ((x)->length)

#define tiset_members(x) ((x)->dense_array)

#define tiset_member(x,y) ((x)->sparse_array[(y)] != TISET_NOVALUE)

#define tiset_nonmember(x,y) ((x)->sparse_array[(y)] == TISET_NOVALUE)

/* This will cause a segmentation fault if the set is empty. */
#define tiset_choose(x) ((x)->dense_array[random_long((x)->length)])

void tiset_adjoin();

/* Assumption:  elt is not already in the set. */

#define tiset_unsafe_adjoin( TISET, ELT ) do { \
    (TISET)->sparse_array[(ELT)] = (TISET)->length; \
    (TISET)->dense_array[(TISET)->length] = (ELT); \
    (TISET)->length++; \
  } while( 0 )

void tiset_delete_all();

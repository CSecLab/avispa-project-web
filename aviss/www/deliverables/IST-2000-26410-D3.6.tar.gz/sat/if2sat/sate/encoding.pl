:- use_module(library(terms)).
% :- ensure_loaded(operators).
% :- ensure_loaded(instantiators).

:- dynamic numof/2.
:- dynamic table_explanatory_frame_axiom/3.
:- dynamic table_conflict_exclusion_axiom/1.
:- dynamic well_formed_action/1.

%:- dynamic not_well_formed_action/1.

:- dynamic fluent_counter/1.
:- dynamic action_counter/1.

:- dynamic conflict_actions/1.

:- dynamic ax/4.

print_wff(true) :- !.
print_wff(W) :- format('~w\n',[W]).
print_clause([true]) :- !.
print_clause(Ls) :- 
	print_literals(Ls),
	write('0\n'),
	flush_output,
	increment_clause_counter.
print_dimacs_header(N,C) :-
	format('p cnf ~w ~w\n',[N,C]).

print_axiom(ax(_,_,_,true)) :- !.
print_axiom(ax(C,I,I1,AX)) :-
	AX\=true,
	T=ax(C,I,I1,AX),
	numbervars(T,8,_),
	write_term(T,[numbervars(true)]),
	write('.'),nl.
%	format('ax(~w,~w,~w,~w).\n',[C,I,I1,AX]).

print_literals([]).
print_literals([L|Ls]) :-
	print_literal(L), write(' '),
	print_literals(Ls).

print_literal(false) :- !.
print_literal(~A) :- !, write('-'), print_atom(A).
print_literal(A) :- print_atom(A).

sate_term_hash(A,H) :-
	format_to_chars('~w',[A],CHARS),
	atom_codes(H,CHARS).

% print_atom(_:A) :-
% 	static(A),!,
% 	sate_term_hash(A,H),
% 	(
% 	  numof(H,N)
% 	;
% 	  retract(value(curnum,N)),
% 	  assert(numof(H,N)),
% 	  N1 is N+1,
% 	  assert(value(curnum,N1))
% 	),
% 	write(N).

% print_atom(I:i(na)) :-
% 	!,
% 	trace,
% 	sate_term_hash(i(na),H),
% 	(
% 	  numof(H,OFFSET),
% 	  N is OFFSET + I, !
% 	;
% 	  value(steps,S),
% 	  retract(value(curnum,N)),
% 	  assert(numof(H,N)),
% 	  N1 is N + S + 1,
% 	  assert(value(curnum,N1))
% 	),
% 	write(N).

print_atom(I:P) :-
	sate_term_hash(P,H),
	(
	  numof(H,OFFSET),
	  N is OFFSET + I, !
	;
	  value(steps,S),
	  retract(value(curnum,N)),
	  assert(numof(H,N)),
	  N1 is N + S + 1,
	  assert(value(curnum,N1))
	),
	write(N).
% % [LC]:
% % we need to distinguish between fluents (0 to S)
% % and actions (0 to S-1). Since we check only the
% % highest functional symbol, then we have to add
% % (TODO) a check in the predicate check_problem.
% print_atom(I:P) :-
% 	sate_term_hash(P,H),
% 	(
% 	  numof(H,OFFSET),
% 	  N is OFFSET + I, !
% 	;
% 	  value(steps,S),
% 	  retract(value(curnum,N)),
% 	  assert(numof(H,N)),
% 	  P=..[SF|_],
% 	  ( (constant(A,action),A=..[SF|_]) ->
% 	      OFFSET = S;
% 	      OFFSET = S + 1
% 	  ),
% 	  N1 is N+OFFSET,
% 	  assert(value(curnum,N1))
% 	),
% 	write(N).

print_encoding_axioms(initial_fact) :-
	encoder_initialization, % ~ 300 msec
	encode_axiom(initial_fact,ax(C,I,I1,W1)),
	simplify(W1,W2),
	print_axiom(ax(C,I,I1,W2)),
	flush_output,
	fail.
print_encoding_axioms(AxType) :-
	AxType\=initial_fact,
	encode_axiom(AxType,ax(C,I,I1,W1)),
	simplify(W1,W2),
	print_axiom(ax(C,I,I1,W2)),
	flush_output,	
	fail.
print_encoding_axioms(_).


%-----------------------------------------------------------------------
%        BEGIN: AXIOMS ENCODING
%

encode_axiom(initial_fact,ax(true,0,_,W)) :-
	predicate(fluent,P),
	facts(Fs),
	( member(P,Fs) ->
	    W=(0:P) ;
	    W=(~0:P) ).

encode_axiom(goal,ax(value(steps,N),_,N,W)) :-
%	value(steps,N),
	goals_axiom(N),
	collect_disjuncts_goal(goal_disjunct,W),
	% [LC]: Trick for leaving N as variable
	%       associated with the index of each
	%       predicate in the goals. 
	associate_variable_with_wff(N,W).

% Version ape axioms 1.0
encode_axiom(ape_axiom,ax(C,I,I1,W)) :-
	value(well_formed_actions_preprocessing,on),
	well_formed_action(Op),
	action(Op,_,Pre,Add,Del),	
	ape_axiom(C,I,I1,Op,Pre,Add,Del,W).
encode_axiom(ape_axiom,ax(C,I,I1,W)) :-
	value(well_formed_actions_preprocessing,off),
	action(Op,Cond,Pre,Add,Del),
	predicate(action,Op),
	call(Cond),
	(is_well_formed(action,Op) ->
	    ape_axiom(C,I,I1,Op,Pre,Add,Del,W)
	;
	    (
	      C=true,
	      W = ~(I:Op)
	    ;
	      value(steps,_),
	      C=value(steps,I1),
	      W = ~(I1:Op)
	    )
	).
% encode_axiom(ape_axiom,ax(true,I,_,~(I:Op))) :-
% 	action(Op,Cond,_,_,_),
% 	predicate(action,Op),
% 	call(Cond),	
% 	\+is_well_formed(action,Op).
% encode_axiom(ape_axiom,ax(value(steps,S),_,S,~(S:Op))) :-
% 	action(Op,Cond,Pre,Add,Del),
% 	predicate(action,Op),
% 	call(Cond),
% 	value(steps,_),
% 	\+is_well_formed(action,Op).

% Version 1.0 and 1.1 of the explanatory axioms
encode_axiom(explanatory_frame_axiom,ax(true,I,I1,W)) :-
	predicate(fluent,P),
	\+invariant(~P),
	(static(P) ->
	    (
	      W=((~I:P & I1:P)=>false)
	    ;
	      W=((I:P & ~I1:P)=>false)
	    )
	;
	    (monotone(P) ->
		(
		  explanatory_frame_axiom(P,I,I1,(~I:P & I1:P)=>ActAdd),
		  W=((~I:P & I1:P)=>ActAdd)
		;
		  W=((I:P & ~I1:P)=>false)
		)
	    ;
% [LC]: The following instructions decrease the number
%	of clauses, but they increase the space and the
%	time needed.
%	\+value(explanatory_fluent_done,P),		
%	assertz(value(explanatory_fluent_done,P)),
	    explanatory_frame_axiom(P,I,I1,W)
	    )
	).
	    
encode_axiom(classical_frame_axiom,ax(true,I,I1,I:Op=>(I:P<=>I1:P))) :-
	action(Op,Cond,_,Add,Del),
	predicate(action,Op),
	call(Cond),
	predicate(fluent,P),
	\+member(P,Add),
	\+member(P,Del).

encode_axiom(at_least_one_axiom,ax(true,I,_,W)) :-
	at_least_one_action_axiom(I,W).

encode_axiom(complete_exclusion_axiom,ax(true,I,_,~(I:Op1 & I:Op2))) :- 
	action(Op1,Cond1,_,_,_),
	action(Op2,Cond2,_,_,_),
	( Op1@<Op2 -> true; \+ \+ (Op1=Op2)),  % early pruning
	predicate(action,Op1),
	call(Cond1),
	predicate(action,Op2),
	call(Cond2),
	Op1@<Op2.

% Version 1.1
encode_axiom(conflict_exclusion_axiom,ax(true,I,_,~(I:Op1 & I:Op2))) :-
	value(well_formed_actions_preprocessing,on),
	well_formed_action(Op1),
	action(Op1,_,Pre1,_,Del1),
	Op1=..[Act1|_],
	table_conflict_exclusion_axiom(Act1-Acts),
	member(Act2,Acts),
	action(Op2,_,Pre2,_,Del2),
	Op2 =..[Act2|_],
	well_formed_action(Op2),
	Op1@<Op2,
	check_conflict_acts(Pre1,Del1,Pre2,Del2).
encode_axiom(conflict_exclusion_axiom,ax(true,I,_,~(I:Op1 & I:Op2))) :-
	\+value(well_formed_actions_preprocessing,on),
	action(Op1,Cond1,Pre1,_,Del1),
	Op1=..[Act1|_],
	table_conflict_exclusion_axiom(Act1-Acts),
	member(Act2,Acts),
	action(Op2,Cond2,Pre2,_,Del2),
	Op2 =..[Act2|_],
	( Op1@<Op2 -> true; \+ \+ (Op1=Op2)),  % early pruning
	predicate(action,Op1),
	call(Cond1),
	predicate(action,Op2),
	call(Cond2),
	Op1@<Op2,
	check_conflict_acts(Pre1,Del1,Pre2,Del2).


% [LC]: Trick for leaving N as variable
%       associated with the index of each
%       predicate in the goals.
associate_variable_with_wffs(_,[]).
associate_variable_with_wffs(N,[W|Ws]) :-
	associate_variable_with_wff(N,W),
	associate_variable_with_wffs(N,Ws).
associate_variable_with_wff(N,N:_) :- !.
associate_variable_with_wff(N,W) :-
	\+is_list(W),
	W=..[_|SubWs],
	associate_variable_with_wffs(N,SubWs).

%
%          END: AXIOMS ENCODING 
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: AXIOMS CONVERSION
%

axioms2sat :-
	print_statistics_axioms2sat_heading,
	axioms2sat(initial_fact),
	axioms2sat(goal),
	value(encoding,AxTypes),
	axioms2sat(AxTypes).

axioms2sat([]).
axioms2sat([AxType|AxTypes]) :-
	axioms2sat(AxType),
	axioms2sat(AxTypes).

% Does not load the axioms file.
axioms2sat(AxType) :-
	\+is_list(AxType),
	open_input_file_axioms(AxType),
	open_output_file(AxType),
	statistics(runtime,_),
	axiom2sat(AxType),
	statistics(runtime,[_,RT]),
	close_output_file(AxType),
	close_input_file_axioms(AxType),
	assert_axioms_translation_time(AxType,RT),
	print_statistics_axioms_translation(AxType).

% % Load the axioms file and then encode them.
% axioms2sat(AxType) :-
% 	\+is_list(AxType),
% 	file_name_axioms(AxType,FN),
% 	load_problems_file(FN),
% 	open_output_file(AxType),
% 	statistics(runtime,_),
% 	axiom2sat(AxType),
% 	statistics(runtime,[_,RT]),
% 	close_output_file(AxType),	
% 	assert_axioms_translation_time(AxType,RT),
% 	print_statistics_axioms_translation(AxType),
% 	retractall(ax(_,_,_,_)).

% axioms2clauses(AxType) :-
% 	file_name_axioms(AxType,FN),
% 	see(FN),
% 	statistics(runtime,_),
% 	axioms2clauses(AxType,read),
% 	statistics(runtime,[_,RT]),
% 	seen,
% 	assert_axioms_translation_time(AxType,RT),
% 	print_statistics_axioms_translation(AxType).
% %	retractall(ax(_,_,_)).

% axioms2clauses(AxType,read) :-
% 	read(T),		% Read a term
% 	(T \== end_of_file ->
% 	    axiom2clause(AxType,T);
% 	    true
% 	).

% axiom2clause(initial_fact,ax(0,_,W)) :-
% 	print_clause(W).
% axiom2clause(goal,ax(_,N,W)) :-
% 	value(steps,N),
% 	print_clause(W).
% axiom2clause(AxType,ax(I,I1,W)) :-
% 	\+member(AxType,[initial_fact,goal]),
% 	value(steps,N),	
% 	value(time,I),
% 	I<N,
% 	I1 is I+1,
% 	print_clause(W),
% 	fail.
% axiom2clause(_).	

% axiom2clause(initial_fact) :-
% 	ax(0,0,W),
% 	print_wff(W),
% 	fail.
% axiom2clause(goal) :-
% 	value(steps,N),
% 	ax(N,N,W),
% 	print_wff(W),
% 	fail.
% axiom2clause(AxType) :-
% 	\+member(AxType,[initial_fact,goal]),
% 	value(steps,N),	
% 	value(time,I),
% 	I<N,
% 	I1 is I+1,
% 	ax(I,I1,W),
% 	print_wff(W),
% 	fail.
% axiom2clause(_).	

axiom2sat(AxType) :-
	((read(Ax),Ax \== end_of_file) ->
	    axiom2sat(AxType,Ax),
	    axiom2sat(AxType)
	;
	    true
	).

axiom2sat(initial_fact,Ax) :-
	Ax=ax(C,0,0,W),
	call(C),
	(value(dimacs,on) ->
	    clause_of(W,W1),
	    print_clause(W1)
	;
	    print_wff(W)
	),
	fail.
axiom2sat(goal,Ax) :-
	value(steps,N),
	Ax=ax(C,N,N,W),
	call(C),
	(value(dimacs,on) ->
	    clause_of(W,W1),
	    print_clause(W1)
	;
	    print_wff(W)
	),
	fail.
axiom2sat(AxType,Ax) :-
	\+member(AxType,[initial_fact,goal]),
	value(steps,N),	
	Ax=ax(C,I,I1,W),
	value(time,I),
	I<N,
	I1 is I+1,
	call(C),
	(value(dimacs,on) ->
	    clause_of(W,W1),
	    print_clause(W1)
	;
	    print_wff(W)
	),
	fail.
axiom2sat(_,_).	

% axiom2sat(initial_fact) :-
% 	ax(C,0,0,W),
% 	call(C),
% 	(value(dimacs,on) ->
% 	    clause_of(W,W1),
% 	    print_clause(W1)
% 	;
% 	    print_wff(W)
% 	),
% 	fail.
% axiom2sat(goal) :-
% 	value(steps,N),
% 	ax(C,N,N,W),
% 	call(C),
% 	(value(dimacs,on) ->
% 	    clause_of(W,W1),
% 	    print_clause(W1)
% 	;
% 	    print_wff(W)
% 	),
% 	fail.
% axiom2sat(AxType) :-
% 	\+member(AxType,[initial_fact,goal]),
% 	value(steps,N),	
% 	ax(C,I,I1,W),
% 	value(time,I),
% 	I<N,
% 	I1 is I+1,
% 	call(C),
% 	(value(dimacs,on) ->
% 	    clause_of(W,W1),
% 	    print_clause(W1)
% 	;
% 	    print_wff(W)
% 	),
% 	fail.
% axiom2sat(_).	

%
%          END: AXIOMS CONVERSION 
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: AXIOMS ENCODING
%

% Old version
print_encoding :-
	encoder_initialization, % ~ 300 msec
	encode(W),
	( value(dimacs,on) ->
	    print_clause(W) ;
	    print_wff(W) ),
	fail.
print_encoding.

encode(W2) :-
	encode(initial_fact,W),
	simplify(W,W1),
	( value(dimacs,on) ->
	    clause_of(W1,W2) ;
	    W2=W1 ).
encode(W2) :-
	print_statistics(goal),
	encode(goal,W),
	simplify(W,W1),
	( value(dimacs,on) ->
	    clause_of(W1,W2) ;
	    W2=W1 ).
encode(W2) :-
	value(steps,N),
	value(encoding,Encoding),
	member(AxType,Encoding),
	print_statistics(AxType),
	encode(AxType,I,I1,W),
	simplify(W,W1),
	( value(dimacs,on) ->
	    clause_of(W1,W2) ;
	    W2=W1 ),
	value(time,I),
	I<N,
	I1 is I+1.
encode(_) :-
	print_statistics(goal),
	fail.

encode(initial_fact,W) :-
	predicate(fluent,P),
	facts(Fs),
	( member(P,Fs) ->
	    W=(0:P) ;
	    W=(~0:P) ).

encode(goal,W) :-
	value(steps,N),
	goals_axiom(N),
	collect_disjuncts_goal(goal_disjunct,W).
	
% % Original Version 
% encode(goal,N:G) :-
% 	value(steps,N),
% 	goal(Gs),
% 	member(G,Gs).

% Version ape axioms 1.0
encode(ape_axiom,I,I1,W) :-
	action(Op,Cond,Pre,Add,Del),
	predicate(action,Op),
	call(Cond),
	ape_axiom(I,I1,Op,Pre,Add,Del,W).
% Version 1.0 and 1.1 of the explanatory axioms
encode(explanatory_frame_axiom,I,I1,W) :-
	predicate(fluent,P),
	\+invariant(~P),
	(static(P) ->
	    (
	      W=((~I:P & I1:P)=>false)
	    ;
	      W=((I:P & ~I1:P)=>false)
	    )
	;
	    (monotone(P) ->
		(
		  explanatory_frame_axiom(P,I,I1,(~I:P & I1:P)=>ActAdd),
		  W=((~I:P & I1:P)=>ActAdd)
		;
		  W=((I:P & ~I1:P)=>false)
		)
	    ;
% [LC]: The following instructions decrease the number
%	of clauses, but they increase the space and the
%	time needed.
%	\+value(explanatory_fluent_done,P),		
%	assertz(value(explanatory_fluent_done,P)),
	    explanatory_frame_axiom(P,I,I1,W)
	    )
	).
encode(classical_frame_axiom,I,I1,I:Op=>(I:P<=>I1:P)) :-
	action(Op,Cond,_,Add,Del),
	predicate(action,Op),
	call(Cond),
	predicate(fluent,P),
	\+member(P,Add),
	\+member(P,Del).
encode(at_least_one_axiom,I,_,W) :-
	at_least_one_action_axiom(I,W).
encode(complete_exclusion_axiom,I,_,~(I:Op1 & I:Op2)) :- 
	action(Op1,Cond1,_,_,_),
	action(Op2,Cond2,_,_,_),
	( Op1@<Op2 -> true; \+ \+ (Op1=Op2)),  % early pruning
	predicate(action,Op1),
	call(Cond1),
	predicate(action,Op2),
	call(Cond2),
	Op1@<Op2.

% Version 1.1
encode(conflict_exclusion_axiom,I,_,~(I:Op1 & I:Op2)) :-
	action(Op1,Cond1,Pre1,_,Del1),
	Op1=..[Act1|_],
	table_conflict_exclusion_axiom(Act1-Acts),
	member(Act2,Acts),
	action(Op2,Cond2,Pre2,_,Del2),
	Op2 =..[Act2|_],
	( Op1@<Op2 -> true; \+ \+ (Op1=Op2)),  % early pruning
	predicate(action,Op1),
	call(Cond1),
	predicate(action,Op2),
	call(Cond2),
	Op1@<Op2,
	check_conflict_acts(Pre1,Del1,Pre2,Del2).

check_conflict_acts(Pre1,Del1,Pre2,Del2) :-
	member(X,Pre1),
	member(X,Del2),
	member(Y,Pre2),
	member(Y,Del1),
% 	% DEBUG 
% 	format(user_output,"\tFluents Conflict: ~w        ~w\n",[X,Y]),
	!.

% % ERROR: IS NOT AN OR
% check_conflict_acts(Pre1,Del1,Pre2,Del2) :-
% 	(
% 	  member(X,Pre1),
% 	  member(X,Del2),
% 	  !
% 	;
% 	  member(X,Pre2),
% 	  member(X,Del1),
% 	  !
% 	).


goals_axiom(N) :-
	goal(C,Gs),
% 	findall(F,
% 		(
% 		  member(G,Gs),
% 		  get_fluents(G, TmpFs),
% 		  member(F,TmpFs)
% 		),
% 		Fs),
% 	predicates(fluent,Fs),
	goal_instantiation(Gs),
	call(C),
	\+value(goal_instance,Gs),
	assertz(value(goal_instance,Gs)),
	goal_axiom(N,Gs,W),
	\+value(goal_disjunct,W),
	assertz(value(goal_disjunct,W)),
	fail.
goals_axiom(_).

goal_axiom(N,[G],(N:G)).
goal_axiom(N,[G|Gs],N:G & (W)) :-
	goal_axiom(N,Gs,W).

goal_instantiation([]) :- !.
goal_instantiation([G|Gs]) :-
	get_fluents(G,Fs),
	predicates(fluent,Fs),
	goal_instantiation(Gs).
	
collect_disjuncts_goal(Type,Disj v Disjs) :-
	retract(value(Type,Disj)), !,
	collect_disjuncts_goal(Type,Disjs).
collect_disjuncts_goal(_,false).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTES:
% If we don't check that P is a fluent we use the
% assumption such that: it does not exist an action
% instance such that contains a term P that is not
% a fluent. (Without the check we improve the
% performance of the ape_axiom of 30%.)
ape_axiom(I,_,Op,Pre,_,_,I:Op=>I:P) :-
	member(P,Pre).
%	predicate(fluent,P).
ape_axiom(I,I1,Op,_,Add,_,I:Op=>I1:P) :- 
	member(P,Add).
%	predicate(fluent,P).	
ape_axiom(I,I1,Op,_,_,Del,I:Op=> ~I1:P) :- 
	member(P,Del).
%	predicate(fluent,P).
% [LC]: since actions range over [0,S-1] then ~S:action
ape_axiom(_,S,Op,_,_,_,~(S:Op)) :- 
	value(steps,S).

% APE AXIOMS WITH CONDITION
ape_axiom(true,I,_,Op,Pre,_,_,I:Op=>I:P) :-
	member(P,Pre).
%	predicate(fluent,P).
ape_axiom(true,I,I1,Op,_,Add,_,I:Op=>I1:P) :- 
	member(P,Add).
%	predicate(fluent,P).	
ape_axiom(true,I,I1,Op,_,_,Del,I:Op=> ~I1:P) :- 
	member(P,Del).
%	predicate(fluent,P).
% [LC]: since actions range over [0,S-1] then ~S:action
ape_axiom(value(steps,S1),_,S1,Op,_,_,_,~(S1:Op)) :-
	value(steps,_).

% % Version explanatory 1.1
% explanatory_frame_axiom(P,_,_,_) :-
% 	table_explanatory_frame_axiom(P,ActAddList,[]),
% 	!,
% 	member(Act,ActAddList),
% 	action(Op,Cond,_,Add,_),
% 	Op=..[Act|_],
% 	predicate(action,Op),
% 	call(Cond),	  	
% 	member(P,Add),
% 	assertz(value(addop,Op)),
% 	fail.
% % Version explanatory 1.1
% explanatory_frame_axiom(P,_,_,_) :-
% 	table_explanatory_frame_axiom(P,[],ActDelList),
% 	!,
% 	member(Act,ActDelList),
% 	action(Op,Cond,_,_,Del),
% 	Op=..[Act|_],
% 	predicate(action,Op),
% 	call(Cond),	  	
% 	member(P,Del),
% 	assertz(value(delop,Op)),
% 	fail.
% Version explanatory 1.1
explanatory_frame_axiom(P,_,_,_) :-
	value(well_formed_actions_preprocessing,on),
	table_explanatory_frame_axiom(P,ActAddList,ActDelList),
%	ActAddList\==[],
%	ActDelList\==[],
	action(Op,_,_,Add,Del),
	Op=..[Act|_],
	(
	  member(Act,ActAddList),
	  well_formed_action(Op),	  
	  member(P,Add),
	  assertz(value(addop,Op));
	  member(Act,ActDelList),
	  well_formed_action(Op),	  	  
	  member(P,Del),
	  assertz(value(delop,Op))
	),
	fail.
explanatory_frame_axiom(P,_,_,_) :-
	value(well_formed_actions_preprocessing,off),	
	table_explanatory_frame_axiom(P,ActAddList,ActDelList),
%	ActAddList\==[],
%	ActDelList\==[],
	action(Op,Cond,_,Add,Del),
	Op=..[Act|_],
	(
	  member(Act,ActAddList),
	  predicate(action,Op),
	  call(Cond),	  	
	  member(P,Add),
	  assertz(value(addop,Op));
	  member(Act,ActDelList),
	  predicate(action,Op),	  
	  call(Cond),	  	
	  member(P,Del),
	  assertz(value(delop,Op))
	),
	fail.
% Version explanatory 1.0 and 1.1
explanatory_frame_axiom(P,I,I1,(~I:P & I1:P)=>AddDisj) :-
	collect_disjuncts(addop,I,AddDisj).
% Version explanatory 1.0 and 1.1
explanatory_frame_axiom(P,I,I1,(I:P & ~I1:P)=>DelDisj) :- 
	collect_disjuncts(delop,I,DelDisj).

% Version explanatory 1.0 and 1.1
collect_disjuncts(Type,I,I:Op v Disj) :-
	retract(value(Type,Op)), !,
	collect_disjuncts(Type,I,Disj).
collect_disjuncts(_,_,false).
	
at_least_one_action_axiom(_,_) :-
	action(Op,Cond,_,_,_),
	predicate(action,Op),
	call(Cond),
	assertz(value(oneact,Op)),
	fail.
at_least_one_action_axiom(I,Disj) :-
	collect_disjuncts(oneact,I,Disj).

%
%          END: AXIOMS ENCODING
%-----------------------------------------------------------------------

reset_atom_db :-
	retractall(numof(_,_)),
	retractall(value(curnum,_)),
	assert(value(curnum,1)).

reset_clause_counter :-
	retractall(value(clause_counter,_)),
	assert(value(clause_counter,0)).
reset_extra_clause_counter :-
	retractall(value(extra_clause_counter,_)),
	assert(value(extra_clause_counter,0)).

increment_clause_counter :-
	retract(value(clause_counter,X)),
	X1 is X+1,
	assert(value(clause_counter,X1)).
increment_extra_clause_counter :-
	retract(value(extra_clause_counter,X)),
	X1 is X+1,
	assert(value(extra_clause_counter,X1)).

atoms_at([],_,[]).
atoms_at([A|As],I,[I:A|IAs]) :-
	atoms_at(As,I,IAs).
	
reset_statistics :-
	retractall(value(tmp_clause_counter,_)),
	assert(value(tmp_clause_counter,0)),
	retractall(value(previous_ax_type,_)),
	assert(value(previous_ax_type,initial_fact)),
	statistics(_,_), !.

assert_axioms_clauses_number(AxType,CC) :-
	atom_concat(AxType,'_axioms_clauses_number',STR),
	retractall(value(STR,_)),
	assert(value(STR,CC)).

retract_axioms_clauses_numbers([]).
retract_axioms_clauses_numbers([AxType|AxTypes]) :-
	retract_axioms_clauses_number(AxType),
	retract_axioms_clauses_numbers(AxTypes).
retract_axioms_clauses_number(AxType) :-
	atom_concat(AxType,'_axioms_clauses_number',STR),
	retractall(value(STR,_)).

get_axioms_clauses_number(AxType,CC) :-
	atom_concat(AxType,'_axioms_clauses_number',STR),
	value(STR,CC).

get_total_axioms_clauses_number(TotCC) :-
	value(encoding,Encoding),
	findall(CC,
		(
		  member(AxType,[initial_fact,goal|Encoding]),
		  get_axioms_clauses_number(AxType,CC)
		),
		CCs),
	sum_list(CCs,TotCC).

	
%% CLAUSIFIER

clause_of(A,C) :-
	clause_of(A,[],C).

clause_of(~(~A),C,CA) :- !, clause_of(A,C,CA).
clause_of(~(A v B),C,CAB) :- !,	clause_of(~A & ~B,C,CAB).
clause_of(~(A & B),C,CAB) :- !,	clause_of(~A v ~B,C,CAB).
clause_of(~(A <=> B),C,CAB) :- !, clause_of(~A <=> B,C,CAB).
clause_of(~(A <~> B),C,CAB) :- !, clause_of((A <=> B),C,CAB).
clause_of(A v B,C,CAB) :- !,
	clause_of(A,C,CA),
	clause_of(B,CA,CAB).
clause_of(A & _,C,CA) :- clause_of(A,C,CA).
clause_of(_ & B,C,CB) :- !, clause_of(B,C,CB).
clause_of(A => B,C,CAB) :- !, clause_of(~A v B,C,CAB).
clause_of(A <=> B,C,CAB) :- clause_of(~A v B,C,CAB).
clause_of(A <=> B,C,CAB) :- !, clause_of(~B v A,C,CAB).
clause_of(A <~> B,C,CAB) :- !, clause_of(~(A <=> B),C,CAB).
clause_of(A,C,[A|C]).

simplify0((false & _),false) :- !.
simplify0((_ & false),false) :- !.
simplify0((true & Q),Q) :- !.
simplify0((Q & true),Q) :- !.
simplify0((true v _),true) :- !.
simplify0((_ v true),true) :- !.
simplify0((false v Q),Q) :- !.
simplify0((Q v false),Q) :- !.
simplify0((~false),true) :- !.
simplify0((~true),false) :- !.
simplify0(_=>true,true) :- !.
simplify0(false=>_,true) :- !.
simplify0(true=>A,A) :- !.
simplify0(A=>false,~A) :- !.
simplify0(A<=>true,A) :- !.
simplify0(true<=>A,A) :- !.
simplify0(A<=>false,~A) :- !.
simplify0(false<=>A,~A) :- !.
simplify0(A<~>true,~A) :- !.
simplify0(true<~>A,~A) :- !.
simplify0(A<~>false,A) :- !.
simplify0(false<~>A,A) :- !.
simplify0(A,A).

simplify((P & Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 & Q1), PQ1).
simplify((P v Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 v Q1), PQ1).
simplify((P <=> Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 <=> Q1), PQ1).
simplify((P => Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 => Q1), PQ1).
simplify((P <~> Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 <~> Q1), PQ1).
simplify((~A),A2) :- !,
	simplify(A,A1),
	simplify0((~A1),A2).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Added
simplify(I:WFF1,WFF2) :- 
	WFF1=..[OP,A1,A2],
	member(OP,[&,v]),!,
	simplify(I:A1,C1),
	simplify(I:A2,C2),
	WFF2=..[OP,C1,C2].
% De Morgan Rules
simplify(I:(~(A1 v A2)),WFF2) :- !,
	simplify(I:(~A1),C1),
	simplify(I:(~A2),C2),
	WFF2=..[&,C1,C2].
simplify(I:(~(A1 & A2)),WFF2) :- !,
	simplify(I:(~A1),C1),
	simplify(I:(~A2),C2),
	WFF2=..[v,C1,C2].
simplify(I:(~(~A)),WFF2) :- !,
	simplify(I:A,WFF2).
simplify(I:(~A),WFF2) :- !,
	simplify(~(I:A),WFF2).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Invariants checking
simplify(_:A,true) :- invariant(A), !.
simplify(_:A,false) :- invariant(~(A)), !.
% Modified (1 OR 2)
% CASE 1
simplify(I:A,T) :-
	invariant(A<=>A1),
%	A1 @< A, !,
	!,
	simplify(I:A1,T).
% % CASE 2
% simplify(I:A,I:A2) :-
% 	invariant(A<=>A1),
% 	A1 @< A, !,
% 	simplify(I:A1,I:A2).
simplify(A,A).

% %% PARSER FOR DIMACS FILES
% %% Used for debugging purposes only (so far).
% parse_dimacs :-
% 	set(dimacs,off),
% 	file_name(dimacs,FN_DIMACS),
% 	see(FN_DIMACS),
% 	read2string(CHs),
% 	seen,
% 	dimacs(CHs,[]).

% dimacs -->
% 	"p cnf ",
% 	pnat(NA),
% 	" ",
% 	pnat(NC),
% 	"\n",
% 	{print(dimacs_problem(NA,NC))},
% 	dimacs_clauses.

% dimacs_clauses -->
% 	dimacs_clause(Pre==>Post), !,
% 	{print(Pre==>Post)},
% 	dimacs_clauses.
% dimacs_clauses --> [].

% dimacs_clause(Pre==>Post) -->
% 	integer(N), " ", !,
% 	dimacs_clause(Pre1==>Post1),
% 	{ N0 is abs(N),
% 	  atomof(N0,A),
% 	  ( N>0 ->
% 	      Pre=Pre1,
% 	      Post=[A|Post1] ;
% 	      Pre=[A|Pre1],
% 	      Post=Post1 ) }.
% dimacs_clause([]==>[]) --> "0\n".

%-----------------------------------------------------------------------
%        BEGIN: ENCODING INITIALIZATION PREDICATEs 
%
encoder_initialization :-
	value(encoding,Encs),
	(member(explanatory_frame_axiom,Encs) ->
	    table(explanatory_frame_axiom)
	;
	    true
	),
	(member(conflict_exclusion_axiom,Encs) ->
	    table(conflict_exclusion_axiom)
	;
	    true
	),
	(value(well_formed_actions_preprocessing,on) ->
	    well_formed_actions_preprocessing
	;
	    true
	),
	!.

retract_encoder_initialization :-
	value(encoding,Encs),
	(member(explanatory_frame_axiom,Encs) ->
	    retractall(table_explanatory_frame_axiom(_,_,_))
	;
	    true
	),
	(member(conflict_exclusion_axiom,Encs) ->
	    retractall(table_conflict_exclusion_axiom(_))
	;
	    true
	),
	(value(well_formed_actions_preprocessing,on) ->
	    retractall(well_formed_action(_))
	;
	    true
	),
	!.
	
%-----------------------------------------------------------------------
%        BEGIN: TABLE
%
table(explanatory_frame_axiom) :-
	partially_instantiated_fluent(F),
	\+table_explanatory_frame_axiom(F,_,_),
	findall(ActAdd,
		(
		  action(Act1,_,_,Add,_),
		  member(F,Add),
		  Act1=..[ActAdd|_]
		),
		TmpActAddList),
	remove_duplicates(TmpActAddList,ActAddList),
	findall(ActDel,
		(
		  action(Act2,_,_,_,Del),
		  member(F,Del),
		  Act2=..[ActDel|_]
		),
		TmpActDelList),
	remove_duplicates(TmpActDelList,ActDelList),
	assert(table_explanatory_frame_axiom(F,ActAddList,ActDelList)),
% 	((ActDelList=[],ActAddList=[]) ->
% 	    format(user_output,"~w:Useless\n",[F]);
% 	    format(user_output,"~w:Useful\n",[F])
% 	),
%	format("~w-~w-~w\n",[F,ActAddList,ActDelList]),
	fail.
table(explanatory_frame_axiom).

% Version 1.1
table(conflict_exclusion_axiom) :-
	action(Op1,C1,Pre1,Add1,Del1),
	Op1=..[Act1|_],
	\+table_conflict_exclusion_axiom(Act1-_),
	findall(Act2,
		( action(Op2,C2,Pre2,Add2,Del2),
		  Op2=..[Act2|_],
		  ( Op1@<Op2 -> true; \+ \+ (Op1=Op2)),  % early pruning  
		  possible_conflict(action(Op1,C1,Pre1,Add1,Del1),action(Op2,C2,Pre2,Add2,Del2))
		),
		Acts),
	assert(table_conflict_exclusion_axiom(Act1-Acts)),
% 	% DEBUG
% 	format(user_output,"Conflict: ~w -> ~w\n",[Act1,Acts]),
	fail.
table(conflict_exclusion_axiom).

%
%          END: TABLE
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: EXPLANATORY FRAME AXIOM PREPROCESSING
%
% Fluent: wk(Sort_WS,Sort_S,Sort_R,_,_,_,Sort_SES)
partially_instantiated_fluent(wk(WS,S,R,_,_,SES)) :-
	value(term_depth_bound,N),
	M is N - 1,
	constant(wk(Sort_WS,Sort_S,Sort_R,_,_,Sort_SES),fluent),
	term(Sort_WS,M,WS),
	term(Sort_S,M,S),
	term(Sort_R,M,R),
	term(Sort_SES,M,SES).
% Fluent: m(Sort_MS,Sort_OS,Sort_R,_)
partially_instantiated_fluent(m(MS,OS,R,_)) :-
	value(term_depth_bound,N),
	M is N - 1,
	constant(m(Sort_MS,Sort_OS,Sort_R,_),fluent),
	term(Sort_MS,M,MS),
	term(Sort_OS,M,OS),
	term(Sort_R,M,R).
% % Fluent: m(Sort_MS,Sort_RS,Sort_OS,Sort_R,_)
% partially_instantiated_fluent(m(MS,RS,OS,R,_)) :-
% 	value(term_depth_bound,N),
% 	M is N - 1,
% 	constant(m(Sort_MS,Sort_RS,Sort_OS,Sort_R,_),fluent),
% 	term(Sort_MS,M,MS),
% 	term(Sort_RS,M,RS),
% 	term(Sort_OS,M,OS),
% 	term(Sort_R,M,R).

%partially_instantiated_fluent(i(_)).

partially_instantiated_fluent(F) :-
	value(term_depth_bound,N),
	constant(FC,fluent),
	FC=..[FF|FSArgs],
%	\+member(FF,[wk,m,i]),
	\+member(FF,[wk,m]),
	tuple(FSArgs,FArgs),
	F=..[FF|FArgs],
	term(fluent,N,F).
%
%          END: EXPLANATORY FRAME AXIOM PREPROCESSING
%-----------------------------------------------------------------------
%-----------------------------------------------------------------------
%        BEGIN: CONFLICT EXCLUSION AXIOM PREPROCESSING
%

possible_conflict(action(_,_,Pre1,_,_),action(_,_,_,_,Del2)) :-
	member(X,Pre1),
	member(X,Del2),
	(value(relax_conflict,on) ->
	    \+is_not_conflict_fluent(X)
	;
	    true
	),!.
possible_conflict(action(_,_,_,_,Del1),action(_,_,Pre2,_,_)) :-
	member(X,Pre2),
	member(X,Del1),
	(value(relax_conflict,on) ->
	    \+is_not_conflict_fluent(X)
	;
	    true
	),!.

%
%          END: CONFLICT EXCLUSION AXIOM PREPROCESSING
%-----------------------------------------------------------------------

% well_formed_actions_preprocessing :-
% 	predicate(action,Op),
% 	is_not_well_formed(action,Op),
% 	\+not_well_formed_action(Op),
% 	assert(not_well_formed_action(Op)),
% 	fail.
% well_formed_actions_preprocessing.
well_formed_actions_preprocessing :-
	predicate(action,Op),
	\+is_not_well_formed(action,Op),
	\+well_formed_action(Op),
	assert(well_formed_action(Op)),
	fail.
well_formed_actions_preprocessing.


%
%          END: ENCODING INITIALIZATION PREDICATEs 
%-----------------------------------------------------------------------

% get_fluents(WFF, Fs) :-
%       Extract the fluents Fs from the formula WFF
get_fluents(WFF, Fs) :- 
	WFF=..[OP,P,Q],
	member(OP,[&,v]),!,
	get_fluents(P,F1s),
	get_fluents(Q,F2s),
	append(F1s,F2s,Fs).
get_fluents((~WFF),Fs) :- !,
	get_fluents(WFF,Fs).
get_fluents(F,[F]) :- !,
	F=..[OP|_],
	\+member(OP,[&,v]).

% count_fluents_and_actions(HashFile,F,A) :-
%       Count the fluents F and the actions A declared 
%       in the hash table file HashFile
count_fluents_and_actions(HashFile,F,A) :-
	assert(fluent_counter(0)),
	assert(action_counter(0)),
	see(HashFile),
	count_fluents_and_actions,
	seen,
	retract(fluent_counter(F)),
	retract(action_counter(A)).
count_fluents_and_actions :-
	((read(T),T\==end_of_file) ->
	    (
	      T=numof(Atom,_),
	      (is_syntactic_fluent(Atom) ->
		  retract(fluent_counter(CurrF)),
		  NextF is CurrF + 1,
		  assert(fluent_counter(NextF)),
		  count_fluents_and_actions
	      ;
		  retract(action_counter(CurrA)),
		  NextA is CurrA + 1,
		  assert(action_counter(NextA)),
		  count_fluents_and_actions
	      )
	    )
	;
	    true
	).
is_syntactic_fluent(m(_,_,_,_)) :- !.
is_syntactic_fluent(wk(_,_,_,_,_,_)) :- !.	
is_syntactic_fluent(i(_)) :- !.
is_syntactic_fluent(not_used(_)) :- !.
is_syntactic_fluent(request(_,_,_,_)) :- !.
is_syntactic_fluent(witness(_,_,_,_)) :- !.
is_syntactic_fluent(secret(_,_)) :- !.
is_syntactic_fluent(give(_,_)) :- !.

% BEGIN OPERATOR SPLITTING
% :- assert((invariant(Action <=> SplittedActions) :-
% 	action(Action,_,_,_,_),
% 	Action=..[Lb|Args],
% 	build_splitted_action(Lb,Args,0,SplittedActions))).
build_splitted_action(Lb,[],_,Lb).
build_splitted_action(Lb,[Arg],N,SplittedAction) :-
	!,
	M is N + 1,
	concat_atom_with_number(Lb,M,LbM),
	SplittedAction=..[LbM,Arg].
build_splitted_action(Lb,[Arg|Args],N,SplittedAction & SplittedActions) :-
	M is N + 1,
	concat_atom_with_number(Lb,M,LbM),
	SplittedAction=..[LbM,Arg],
	build_splitted_action(Lb,Args,M,SplittedActions).
	
concat_atom_with_number(LB,N,LBN) :-
	number(N),
	number_chars(N,CN),
	atom_chars(LB,CLB),
	atom_chars('_',[UNDER]),
	append(CLB,[UNDER|CN],CLBN),
	atom_chars(LBN,CLBN).
% END OPERATOR SPLITTING

%%% DEBUG

print_disjuncts(W1 v W2) :-
	!,
	print_conjuncts(W1),
	write('v'),nl,
	print_disjuncts(W2).
print_disjuncts(W1) :-
	print_conjuncts(W1).

print_conjuncts(W) :-
	!,
	write(W),nl.
prova(RT) :-
	statistics(runtime,[_,_]),
	prova1,
	statistics(runtime,[_,RT]).
prova1:-
	predicate(fluent,_),
	fail.
prova1.



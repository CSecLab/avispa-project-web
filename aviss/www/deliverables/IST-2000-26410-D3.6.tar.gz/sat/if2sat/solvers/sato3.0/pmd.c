/*********************************************************************
; Copyright 1992-97, The University of Iowa (UI).  All rights reserved. 
; By using this software the USER indicates that he or she has read, 
; understood and will comply with the following:
;
; --- UI hereby grants USER nonexclusive permission to use, copy and/or
; modify this software for internal, noncommercial, research purposes only.
; Any distribution, including commercial sale or license, of this software,
; copies of the software, its associated documentation and/or modifications
; of either is strictly prohibited without the prior consent of UI.  Title
; to copyright to this software and its associated documentation shall at
; all times remain with UI.  Appropriate copyright notice shall be placed
; on all software copies, and a complete copy of this notice shall be
; included in all copies of the associated documentation.  No right is
; granted to use in advertising, publicity or otherwise any trademark,
; service mark, or the name of UI.  Software and/or its associated
; documentation identified as "confidential," if any, will be protected
; from unauthorized use/disclosure with the same degree of care USER
; regularly employs to safeguard its own such information.
;
; --- This software and any associated documentation is provided "as is," and
; UI MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
; THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
; USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL
; NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL
; PROPERTY RIGHTS OF A THIRD PARTY.  UI, the University of Iowa,
; its Regents, officers, and employees shall not be liable under any
; circumstances for any direct, indirect, special, incidental, or
; consequential damages with respect to any claim by USER or any third
; party on account of or arising from the use, or inability to use, this
; software or its associated documentation, even if UI has been advised
; of the possibility of those damages.
*********************************************************************/
#include "main.h"

GLOB SATOINT ABG_f[MAX_ABG_SIZE][MAX_ABG_SIZE];
GLOB SATOINT ABG_g[MAX_ABG_SIZE];

/* SIG(x,y,z) means the entry at row x and column y is z */
#define SIG2(i,j,k) ((((((i)-1) * c) + (j)) * m) + (k) + 3)
#define SIG(i,j,k) ((Oarray[i][j] == UNKNOW)? \
		      SIG2(i,j,k) : \
		      (Oarray[i][j] == k)? 1 : 2)
#define set_entry0(i,j,k) if (Oarray[i][j] == UNKNOW) Oarray[i][j] = k; \
                          else if (Oarray[i][j] != k) { bug(8); return 1;} 
#define set_entry(i,j,k) if (insert_cl_1(SIG(i, j, k), 1)) { bug(8); return 1;} \
                         Oarray[i][j] = k; 

/* PHI(k,c1,z) means z is k-apart-covered at column c1 under a */
#define PHI(k,c1,z,a) ((((k) * c + (c1)) * (max_seed) + (z))*Addk + a + rcm)
/* THI(k,r1,z) means z is k-apart-covered at row r1 under a */
#define THI(k,r1,z,a) ((((k) * r + (r1)) * (max_seed) + (z))*Addk + a + rcm + kcm)

/* YOYO(k,x,a,b) means the pair (a,b) appears k-apart in column x */
#define YOYO(k,x,a,b) ((((k) * c + (x)) * (QGROUP) + (a))*(QGROUP) + b + rcm)

#define MULTI PIGEON
#define MAX_ROW 9
#define MAX_COL 50
#define DIFF(x,y) (ABG_f[x][ABG_g[y]])
#define HOLE -2
#define UNKNOW -1

GLOB SATOINT Oarray[MAX_ROW][MAX_COL];
GLOB SATOINT Seed[MAX_ABG_SIZE];
GLOB SATOINT Mext[MAX_ABG_SIZE];
GLOB SATOINT Reps[MAX_ABG_SIZE];
GLOB SATOINT W[MAX_ROW];
GLOB int m, r, c, max_seed, Addk;

int DOUBLE = 0;
int K_apart, rcm, kcm, newaddk;
int remainder[5], num_rem = 0;
int k_flag = 0;
void set_k_flag(k) int k; { k_flag = k; }
int get_k_flag() { return k_flag; }

void init_pmd()
{
  int i;

  m = QGROUP-INCOMPLETE;
  Addk = get_addk();
  newaddk = (CYCLIC > 0 && CYCLIC < 6)? CYCLIC * Addk : Addk;
  gen_abg_table();

  if (k_flag >= 1000) { 
    if (QUEEN == 0) { printf("please set # of blocks by -Q\n"); exit(0); }
    c = QUEEN; 
    K_apart = PMD/2;
    r = PMD;
    num_rem = 0;
    rcm = (r-1) * c * m + 3;
    kcm = max_seed * c * K_apart * Addk + 1;
    Max_atom = SIG2(r-1, c-1, QGROUP-1);
    for (i = 0; i < PMD; i++) W[i] = 1;
    fix_seed_zero();
    MULTI = 1;
    RAMSEY = 1;
    if (TRACE > 8) pmd_print_code(); 
    return; 
  } else if (QUEEN >= 100) {
    K_apart = PMD/2;
    c = QGROUP*(QGROUP-1)/PMD;
    if (QUEEN > 100) c = QUEEN-100;
    r = PMD;
    m = QGROUP;
    rcm = r * c * m + 3;
    Max_atom = YOYO(K_apart-1, c-1, QGROUP-1, QGROUP-1);
    MULTI = 1;
    RAMSEY = 1;
    if (TRACE > 2) pmd_print_code(); 
    return; 
  }

  if (RAMSEY) {
    if (m % RAMSEY != 0) {
      printf("Hole size %d does not divide %d - %d.\n", 
	     RAMSEY, QGROUP, INCOMPLETE);
      exit(0);
    }
    NHOLE = m/RAMSEY;
  } else RAMSEY = 1;

  if ((QGROUP + INCOMPLETE - RAMSEY) < (PMD * INCOMPLETE)) {
    printf("Too many infinitity elements:  %d+%d-%d < %d*%d.\n", 
	   QGROUP, INCOMPLETE, RAMSEY, PMD, INCOMPLETE);
    exit(0);
  }

  if ((QGROUP - INCOMPLETE) % Addk != 0) {
    printf("Additor %d does not divide %d - %d.\n", 
	   Addk, QGROUP, INCOMPLETE);
    exit(0);
  }

  if (MULTI == 0) fix_seed_zero();
  else {

    if (INCOMPLETE % MULTI != 0) {
      printf("Multiplier %d does not divide %d.\n", MULTI, INCOMPLETE);
      exit(0);
    }

    if ((QGROUP - RAMSEY) % MULTI != 0) {
      printf("Multiplier %d does not divide %d - %d.\n", 
	     MULTI, QGROUP-INCOMPLETE, RAMSEY);
      exit(0);
    }

    if (fopen("oa.spe", "r") != NULL) 
      max_seed = read_special_seed();
    else 
      max_seed = fix_seed();

    print_mext_reps();
  }

  for (i = 0; i < PMD; i++) W[i] = 1;

  if (k_flag >= 100 && k_flag < 120) {
    num_rem = 0;
    if (QUEEN == 0) { printf("please set # of blocks by -Q\n"); exit(0); }
    c = QUEEN*Addk/m; 
  } else if ((i = (((QGROUP + INCOMPLETE - RAMSEY)*newaddk/MULTI) % PMD)) != 0) {
    int j;
    printf("Block size %d does not divide %d = (%d + %d - %d)*%d/%d.\n", 
	   PMD, (QGROUP + INCOMPLETE - RAMSEY)*newaddk/MULTI, 
	   QGROUP, INCOMPLETE, RAMSEY, newaddk, MULTI);
    if (k_flag == 0) exit(0);
    if (i % Addk) {
      printf("Additor %d does not divide the remainder %d.\n", 
	     Addk, i);
      exit(0);
    }
    num_rem = i/Addk;
    if (k_flag == 1) fix_remainder(PMD); 
    else if (k_flag < 10) {
      if (k_flag >= PMD) num_rem += PMD;
      printf("Type in %d numbers: ", num_rem);
      i = 0; 
      while (i < num_rem) { scanf("%d", &j); remainder[i++] = j; }
    } 
    c = ((QGROUP + INCOMPLETE - RAMSEY)*newaddk/MULTI - num_rem) / PMD;
  } else {
    num_rem = 0;
    if (k_flag == 1) {
      fix_remainder(PMD);
    } else if (k_flag < 10 && gcd(k_flag, m) == 1) {
      for (i = 0; i < r; i++) W[i] = k_flag;
    } else if (k_flag > 10 && k_flag < 20) {
      int j;
      num_rem = k_flag-10;
      printf("Type in %d numbers: ", num_rem);
      i = 0; 
      while (i < num_rem) { scanf("%d", &j); remainder[i++] = j; }
    }
    c = ((QGROUP + INCOMPLETE - RAMSEY)*newaddk/MULTI - num_rem) / PMD;
  }

  K_apart = PMD/2;
  r = PMD;
  if (IDEMPOTENT == 1) {
    printf("Looking for %d %d-tuples.\n\n", c, PMD);
  } else {
    if (IDEMPOTENT == 3) 
      DOUBLE = (c) >> 1;
    else 
      DOUBLE = (c-Addk*INCOMPLETE/MULTI) >> 1;

    if (Addk != 2 && 2*DOUBLE == c && INCOMPLETE % 2) --DOUBLE;
    c -= (DOUBLE);
    printf("Looking for %d %d-blocks, of which the first %d are doubles.\n",
	   c, PMD, DOUBLE);
  }

  if (r > MAX_ROW) {
    printf("MAX_ROW (%d) is too small (< %d).\n", 
	   MAX_ROW, r);
    exit(0);
  }
  if (c > MAX_COL) {
    printf("MAX_COL (%d) is too small (< %d).\n", 
	   MAX_COL, c);
    exit(0);
  }

  rcm = (r-1) * c * m + 3;
  kcm = max_seed * c * K_apart * Addk + 1;
  Max_atom = THI(K_apart-1, r-1, m-1, Addk-1);

  if (TRACE > 2) pmd_print_code(); 

  if (num_rem) {
    printf("The numbers that should be taken care specially:");
    for (i = 0; i < num_rem; i++) printf(" %d", remainder[i]);
    printf("\n\n");
  }
}

int pmd_fill_remainder(s, seed)
     int s, seed[];
{
  int k, i, j, y, good;
  int w = W[1]-1;

  /*
  printf("Give me the first nubmer to try: ");
  scanf("%d", &j);
  printf("You entered %d, a golden number!\n", j);
  */

  y = 0;
  for (i = 1; i < m; i++) if (seed[i] != HOLE) seed[i] = UNKNOW;
  i = 1;
  while (y < num_rem) {
    while (i < m && seed[i] != UNKNOW) i++;
    if (i >= m) { 
      i = m-1;
      while (i && seed[i] != UNKNOW) i--;
    }
    if (i == 0) return 0;

    good = 1;
    seed[i] = i;
    for (k = PMD/2-1; k >= 0; k--) if (good) {
      j = ((k+1)*i*w) % m;
      if (seed[j] == HOLE) good = 0;
      if (k == 0) {
	printf("j = %d\n", j);
	if (seed[Seed[j]] == -Seed[j]) good = 0;
	else seed[Seed[j]] = -Seed[j];
      }
    }
    if (good) { remainder[y++] = i; i = m-i; }
  }
  return 1;
}

void pmd_clause_init()
{
  int i, j;

  Value[1] = TT;
  Value[2] = FF;
  if (OUTPUT) {
    print_unit_clause(stdout, TT, 1);
    print_unit_clause(stdout, FF, 2);
  }

  for (i = 0; i < r; i++) 
    for (j = 0; j < c; j++)  
      Oarray[i][j] = UNKNOW;
}

int pmd_clauses()
{
  SATOINT cl_arr [ MAX_ATOM ], sign_arr [ MAX_ATOM ];

  pmd_clause_init();

  if (QUEEN >= 100) { return q100_clauses(); }
  if (k_flag >= 1000) { return blocks_clauses(); }

  /*pmd_extra_cls(); */

  /* set the first row */
  if (pmd_unit_cls()) return 1;

  if (LINE >= 1000) {
    if (LINE >= 4000) {
      if (CREATE < 5) pmd_gene_partials();
    } else if ((m % 2 == 0) || (m % 3 == 0)) {
      /* mod 2 or 3 unit blocks or clauses */
      if (LINE >= 2000) {
	if (pmd_mod23_blocks()) return 2;
      } else if (pmd_mod23_cls()) return 1;
    } else {
      printf("%d cannot be divided by 2 or 3\n", m);
      exit(0);
    }
  }

  /* additional constraints on row 2. */
  if (pmd_row2_cls(cl_arr, sign_arr)) return 1;

  if (num_rem && pmd_avoid_nums()) return 1;

  /* difference conditions */
  if (pmd_diff_cls(cl_arr, sign_arr)) return 1;

  /* unique values */
  if (pmd_unique_cls(cl_arr, sign_arr)) return 1;

  /* available values */
  if (pmd_posi_cls(cl_arr, sign_arr)) return 1;

  return 0;
}

int pmd_avoid_nums ()
{
  int i, j, k, u, w, a;

  printf("k_flag = %d, MULTI = %d, r = %d\n", k_flag, MULTI, r);

  if (k_flag == 3 && MULTI == r) 
    for (j = 0; j < num_rem; j++) {
      for (i = 1; i < m; i++) 
	if (((Seed[m]-1)*i) % m == remainder[j]) {
	  printf("replace %d by %d\n", remainder[j], i);
	  remainder[j] = i;
	  i = m;
	}
    }

  if (0 && (num_rem * Addk) > PMD && (m % 2 == 0) && remainder[0] % 2 == 0) {
    num_rem = 1;
    for (k = 1; k <= K_apart; k++) {
      j = (remainder[0] * k) % m;
      printf(">>>>>>>> avoiding %d in %d-apart for even cases ...\n", j, k);
      for (u = 0; u < c; u++) 
	if (insert_cl_1(PHI(k-1, u, Reps[j], 0), FF)) return 1;
      for (u = 0; u < r; u++) 
	if (insert_cl_1(THI(k-1, u, Reps[j], 0), FF)) return 1;
    }

  } else {

    w = 1; 
    for (k = 1; k <= K_apart; k++) {
      w = ((k_flag == 3 && MULTI == r)? 
	   (w*Seed[m]) % m :
	   ((W[k] == 1)? k+1 : W[k]));
      for (i = 0; i < num_rem; i++) {
	/*j = (remainder[i]*(w-1)) % m;*/
	int y;
	int x = remainder[i]; 
	j = x;
	for (y = 2; y < w; y++) j = ABG_f[j][x];

	printf(">>>>>>>> avoiding %d in %d-apart\n", j, k);
	for (u = 0; u < c; u++) 
	  for (a = 0; a < Addk; a++)
	    if (insert_cl_1(PHI(k-1, u, Reps[j], a), FF)) return 1;
	for (u = 0; u < r; u++) 
	  for (a = 0; a < Addk; a++)
	    if (insert_cl_1(THI(k-1, u, Reps[j], a), FF)) return 1;
      }
    }
  }
  return 0;
}


int pmd_unique_cls (cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
     /* every cell has at most one value */
{
  SATOINT x, y, u, v, r1, r2, a, a1, k;
  int k1 = INCOMPLETE/MULTI;
  a1 = c/newaddk-k1;

  for (x = 0; x < r; x++) 
    for (y = 0; y < c; y++) 
      for (u = m-1; u >= 0; u--) 
	for (v = u-1; v >= 0; v--) {
	  /* x * y = u and x * y = v imply u = v. */
	  if (insert_cl_2(SIG(x, y, u), 
			  SIG(x, y, v), 
			  FF, cl_arr, sign_arr)) return 1;
	}

  /* r1 * x = u and r2 * x = v and u-v = 0 imply r1 = r2. */
  for (r1 = 1; r1 < r; r1++) 
    for (r2 = r1-1; r2 >= 0; r2--) 
      for (x = 0; x < c; x++) 
	for (u = 0; u < m; u++)
	  for (v = 0; v < m; v++) {
	    y = DIFF(u, v);
	    if (Seed[y] == HOLE) {
	      if (insert_cl_2(SIG(r1, x, u), 
			      SIG(r2, x, v), 
			      FF, cl_arr, sign_arr)) return 1;
	    }
	  }

  /* 0 * x = 0 * y, x,y >= m, r2 * x = v and r2 * y = u imply v = u. */
  for (x = 0; x < c; x++)
    for (y = x+1; y < c; y++) 
      if (Oarray[0][x] >= m && Oarray[0][x] == Oarray[0][y]) {
	for (r1 = 2; r1 < r; r1++) 
	  for (u = 0; u < m; u++) {
	    if (insert_cl_2(SIG(r1, x, u), 
			    SIG(r1, y, u), 
			    FF, cl_arr, sign_arr)) return 1;
	  }
      }

  for (a = 0; a < newaddk; a++) {

    /* r1 * x = u and r1 * y = u imply x = y. */
    for (r1 = 1; r1 < r; r1++) 
      for (x = 1; x < a1; x++)
	for (y = 0; y < x; y++) 
	  for (u = 1; u < m; u++) {
	    if (insert_cl_2(SIG(r1, x+a*a1, u), 
			    SIG(r1, y+a*a1, u), 
			    FF, cl_arr, sign_arr)) return 1;
	  }
    for (r1 = 2; r1 < r; r1++) 
      for (x = 1; x < k1; x++) 
	for (y = 0; y < x; y++) 
	  for (u = 1; u < m; u++) {
	    if (insert_cl_2(SIG(r1, a1*newaddk+a*k1+x, u), 
			    SIG(r1, a1*newaddk+a*k1+y, u), 
			    FF, cl_arr, sign_arr)) return 1;
	  }

    /* unique covering */
    if (0 < CYCLIC && CYCLIC < 5) {
      return (multi_cover_cls(a, cl_arr, sign_arr));
    } else

    for (k = K_apart-1; k >= 0; k--)
      for (x = 1; x <= max_seed; x++) {
	for (u = 0; u < c; u++) 
	  for (v = u-1; v >= 0; v--) {
	    /* PHI(k, u, x, a) and PHI(k, v, x, a) => u = v */
	    if (insert_cl_2(PHI(k, u, x, a), 
			    PHI(k, v, x, a), 
			    FF, cl_arr, sign_arr)) return 1;
	  }

	for (u = 1; u < r; u++) 
	  for (v = u-1; v >= 0; v--) {
	    /* THI(k, u, x, a) and THI(k, v, x, a) => u = v */
	    if (insert_cl_2(THI(k, u, x, a), 
			    THI(k, v, x, a), 
			    FF, cl_arr, sign_arr)) return 1;
	  }
      }
  }

  return 0;
}

multi_cover_cls (a, cl_arr, sign_arr)
     int a, cl_arr[], sign_arr[];
{
  int k, x, u, v, i, g;
  int comb[5];
  int h = CYCLIC;
  
  for (k = K_apart-1; k >= 0; k--)
    for (x = 1; x <= max_seed; x++) {

      for (u = 0; u <= h; u++) comb[u] = u;
      g = c-1;
      while (comb[0] != g) {
	u = 0;
	for (i = h; i >= 0; i--) {
	  /* PHI(k, u, x, a) and PHI(k, v, x, a) => u = v */
	  v = cl_arr[u++] = PHI(k, comb[i], x, a);
	  sign_arr[v] = FF;
	}
	Clause_num++;
	if (insert_clause ( cl_arr, sign_arr, u)) return 1;

	if ((comb[0] + h) == g)
	  comb[0] = g;
	else 
	  next_combination(h, g, comb);
      }

      for (u = 1; u < r; u++) 
	for (v = u-1; v >= 0; v--) {
	  /* THI(k, u, x, a) and THI(k, v, x, a) => u = v */
	  if (insert_cl_2(THI(k, u, x, a), 
			  THI(k, v, x, a), 
			  FF, cl_arr, sign_arr)) return 1;
	}
    }

  return 0;
}

int pmd_row2_cls (cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
{
  int i, j, k, u, v, a, x;
  k = INCOMPLETE/MULTI;

  if (IDEMPOTENT == 3) {
    k = k/2;
    for (i = DOUBLE-Addk*k; i < DOUBLE; i++) 
      for (j = i+1; j < DOUBLE; j++) 
	for (u = 2; u < m; u++)
	  for (v = u-1; v > 0; v--) {
	    if (insert_cl_2(SIG(2, i, u), 
			    SIG(2, j, v), 
			    FF, cl_arr, sign_arr)) return 1;
	  }
  } else
    for (a = 0; a < Addk; a++) {
      x = c-(Addk-a)*k;
      for (i = 0; i < k; i++) 
	for (j = i+1; j < k; j++) 
	  for (u = 2; u < m; u++)
	    for (v = u-1; v > 0; v--) {
	      if (insert_cl_2(SIG(2, i+x, u), 
			      SIG(2, j+x, v), 
			      FF, cl_arr, sign_arr)) return 1;
	    }
    }

  x = (c/Addk-k)*Addk;
  if (IDEMPOTENT == 3 && Addk == 2 && INCOMPLETE % 2) x--;

  if (k_flag < 100) 
    for (i = 0; i < x; i++)
      for (j = i+1; j < x; j++) 
	for (u = 2; u < m; u++)
	  for (v = u-1; v > 0; v--) {
	    if (insert_cl_2(SIG(1, i, u), 
			    SIG(1, j, v), 
			    FF, cl_arr, sign_arr)) return 1;
	  }
  else {
    x = c-(k_flag % 100);
    for (i = 0; i < x; i++)
      for (j = i+1; j < x; j++) 
	for (u = 2; u < m; u++)
	  for (v = u-1; v > 0; v--) {
	    if (insert_cl_2(SIG(1, i, u), 
			    SIG(1, j, v), 
			    FF, cl_arr, sign_arr)) return 1;
	  }

    for (i = c-(k_flag % 100); i < c; i++)
      for (j = i+1; j < c; j++) 
	for (u = 2; u < m; u++)
	  for (v = u-1; v > 0; v--) {
	    if (insert_cl_2(SIG(1, i, u), 
			    SIG(1, j, v), 
			    FF, cl_arr, sign_arr)) return 1;
	  }
  }

  return 0;
}

int pmd_posi_cls (cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
  /* every cell must have a value */
{
  int i, j, u, v;

  for (i = 0; i < r; i++) 
    for (j = 0; j < c; j++) 
      if (Oarray[i][j] < 0) {
	v = 0;
	for (u = m-1; u >= 0; u--) {
	  cl_arr[v] = SIG(i, j, u);
	  sign_arr[cl_arr[v++]] = 1;
	}
	Clause_num++;
	if (insert_clause ( cl_arr, sign_arr, v) == 1)	return 1;
      }
  return 0;
}

int pmd_diff_cls (cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
{
  int x, y0, y, u, v, r1, r2, k;

  if (IDEMPOTENT == 3 && PMD == 5) {
    k = INCOMPLETE/(MULTI * 2);

    for (y = 0; y < k; y++) {
      x = DOUBLE-k*Addk+y;
      for (u = 1; u < m; u++) {

	if (u % 2 == Oarray[1][x] % 2)
	  /* In <-, 0, c, d, e>, e is odd */
	  if (insert_cl_1(SIG(4, x, u), FF)) return 1;

	/* In <-, 0, c, d, e>, c and d have different oddity. */
	for (v = 1; v < m; v++) if (v % 2 == u % 2) 
	  if (insert_cl_2(SIG(2, x, v), 
			  SIG(3, x, u), 
			  FF, cl_arr, sign_arr)) return 1;

      }
    }
  }
   
  for (k = 0; k < K_apart; k++)
    for (x = 0; x < c; x++) 
      for (u = 0; u < m; u++)
	for (v = 0; v < m; v++) {
	  y0 = DIFF(u, v);
	  for (r1 = 0; r1 < r; r1++) {
	    y = (y0 * W[(r1)? (r-r1) : 0]) % m;
	    r2 = (r1 + 1 + k) % r;
	    if (y && Seed[y] != HOLE) {
	      /* DIFF(u, v) is not in H. */

	      if (x < DOUBLE && Reps[y] == Reps[ABG_g[y]]) {

		/* printf("<%d, %d, %d> vs <%d, %d, %d>\n", r1, x, v, r2, x, u);*/

		if (insert_cl_2(SIG(r1, x, v), 
				SIG(r2, x, u), 
				FF, cl_arr, sign_arr)) return 1;


	      } else {

		if (insert_cl_all_3(SIG(r1, x, v), 
				    SIG(r2, x, u), 
				    PHI(k, x, Reps[y], u%Addk),
				    TT, cl_arr, sign_arr)) return 1;

		if (insert_cl_all_3(SIG(r1, x, v), 
				    SIG(r2, x, u), 
				    THI(k, r1, Reps[y], u%Addk),
				    TT, cl_arr, sign_arr)) return 1;

		if (x < DOUBLE) {
		  if (insert_cl_all_3(SIG(r1, x, v), 
				      SIG(r2, x, u), 
				      PHI(k, x, Reps[ABG_g[y]], v%Addk),
				      TT, cl_arr, sign_arr)) return 1;
		  if (insert_cl_all_3(SIG(r1, x, v), 
				      SIG(r2, x, u), 
				      THI(k, r1, Reps[ABG_g[y]], v%Addk),
				      TT, cl_arr, sign_arr)) return 1;
		}
	      }
	    } 
	  }
	}
  return 0;
}

int pmd_qg0 (cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
     /* QG0 constraints on row2 and row3 */
{
  return (INCOMPLETE/MULTI);
}

int pmd_unit_cls ()
{
  int i, j, k, a,  x;

  k = INCOMPLETE/MULTI;

  if (LINE >= 4000) pmd_read_partial();

  if (IDEMPOTENT == 3) {

    /* in case the number of colums is not even */
    for (a = 0;  a < Addk; a++) {
      if (k % 2 && Addk != 2) {
	set_entry0(0,c-Addk+a,m+k-1);
	set_entry(1,c-Addk+a, a);

	if (c > DOUBLE+1) {
	  set_entry0(0,c-2*Addk+a,0);
	  if (insert_cl_1(SIG(1, c-2*Addk+a, 0), FF)) { bug(8); return 1; }
	  if (NHOLE) for (j = 1; j < m; j++) 
	    if ((Seed[j] == HOLE) && 
		insert_cl_1(SIG(1, c-2*Addk+a, j), FF)) { bug(8); return 1; }
	}
      } else if (c > DOUBLE) {
	set_entry0(0,c-Addk+a,0);
	if (insert_cl_1(SIG(1, c-Addk+a, 0), FF)) { bug(8); return 1; }
	if (NHOLE) for (j = 1; j < m; j++) 
	  if ((Seed[j] == HOLE) && 
	      insert_cl_1(SIG(1, c-Addk+a, j), FF)) { bug(8); return 1; }
      }
    }
    
    k = k/2;
    /* pre-set the places of infinity elements at the first row */
    for (i = DOUBLE-k*Addk; i < DOUBLE; i++) {
      set_entry0(0,i,m);
      set_entry(1,i,0);
    }

    for (i = DOUBLE-k*Addk-1; i >= 0; i--) {
      set_entry0(0,i,0);
      if (insert_cl_1(SIG(1, i, 0), FF)) { bug(8); return 1; }
      if (NHOLE) for (j = 1; j < m; j++) 
	if ((Seed[j] == HOLE) && 
	    insert_cl_1(SIG(1, i, j), FF)) { bug(8); return 1; }
    }

  } else {

    x = c-newaddk*k;
    if (x < 0) x = 0;

    for (a = 0; a < newaddk; a++) {
      int y1;

      if (k*newaddk >= c) {
	y1 = a*k;
	for (i = 0; i < k; i++) {
	  /* pre-set the places of infinity elements at the first row */
	  set_entry0(0,y1+i,m+i);
	  set_entry(1,y1+i,a);
	}
	
      } else {

	y1 = x+a*k;
	for (i = 0; i < k; i++) {
	  /* pre-set the places of infinity elements at the first row */
	  set_entry0(0,y1+i,m+i);
	  set_entry(1,y1+i,a);
	}

	for (i = 0; i < x; i++) { 
	  set_entry0(0,i,0);
	  if (insert_cl_1(SIG(1, i, 0), FF)) { bug(8); return 1; }
	  if (NHOLE) for (j = 1; j < m; j++) 
	    if ((Seed[j] == HOLE) && 
		(insert_cl_1(SIG(1, i, j), FF))) { bug(8); return 1; }
	}
      }
    }

    if (k_flag > 100) {
      printf("c = %d, k = %d, m = %d, k_flag = %d\n", c, k, m, k_flag);
      for (i = c-(k_flag % 100); i < c; i++) { 
	set_entry0(0,i,1);
      }
    }
  }

  x = c/newaddk-k;
  if (x < 0) x = 0;

  for (a = 0;  a < newaddk && a < c; a++) {
    /* no entry after the second row will be 0 */
    for (i = 2; i < r; i++) {
      for (j = 0; j < x; j++) {
	int y;
	if (IDEMPOTENT == 3 || IDEMPOTENT == 2) {
	  if (insert_cl_1(SIG(i, j+a*x, 0), FF)) { bug(8); return 1; }
	  if (NHOLE) for (y = 1; y < m; y++) 
	    if ((Seed[y] == HOLE) && 
		insert_cl_1(SIG(i, j+a*x, y), FF)) { bug(8); return 1; }
	} else if (k_flag < 100) {
	  if (insert_cl_1(SIG(i, j+a*x, a), FF)) { bug(8); return 1; }
	  if (NHOLE) for (y = 1; y < m; y++) 
	    if ((Seed[y] == HOLE) && 
		insert_cl_1(SIG(i, j+a*x, (y+a)%m), FF)) { bug(8); return 1; }
	}
      }

      for (j = 0; j < k; j++) {
	int y;
	int y1 = j+a*k+x*newaddk;
	if (y1 < c) {
	  if (IDEMPOTENT == 3) {
	    if (insert_cl_1(SIG(i, y1, 0), FF)) { bug(8); return 1; }
	    if (NHOLE) for (y = 1; y < m; y++) 
	      if ((Seed[y] == HOLE) && 
		  insert_cl_1(SIG(i, y1, y), FF)) 
		{ bug(8); return 1; }
	  } else {
	    if (insert_cl_1(SIG(i, y1, a), FF)) { bug(8); return 1; }
	    if (NHOLE) for (y = 1; y < m; y++) 
	      if ((Seed[y] == HOLE) && 
		  insert_cl_1(SIG(i, y1, (y+a)%m), FF)) 
		{ bug(8); return 1; }
	  }
	}
      }
    }
  }

  /* restriction on the first few columns */
  if (RESTRICT < 50 && RESTRICT % 10 != 0) {
    int v1 = Oarray[1][0] + 1;
    int m1 = 5-RESTRICT/10;
    RESTRICT %= 10;

    while (v1 == 0 || Seed[v1] != v1) v1++;
    for (j = RESTRICT-1; j >= 0; j--) {
      int y;
      for (y = v1+j*m1+1; y < m; y++) {
	if (Oarray[0][j] == 0) {
	  /*printf("A[1, %d] != %d\n", j, y);*/
	  if (insert_cl_1(SIG(1, j, y), FF)) { bug(8); return 1; }
	} else {
	  /*printf("A[2, %d] != %d\n", j, y);*/
	  if (insert_cl_1(SIG(2, j, y), FF)) { bug(8); return 1; }
	}
      }
    }
  } else if (RESTRICT >= 200 && RESTRICT < 1000 && (RESTRICT % 100 == 0)) {
    int u = RESTRICT/100;
    int v = c/u;
    x = i = 0;
    for (j = 0; j < c; j++) if (Oarray[3][j] == UNKNOW) {
      printf("<3,%d> = ", j);
      for (k = 1; k < m; k++) if (k % u != x) {
	if (insert_cl_1(SIG(3, j, k), FF)) { bug(8); return 1; }
      }
      if (++i == v) { 
	i = 0; 
	printf("%d mod %d\n", x, u);
	if (++x == u) x = 0; 
      }
    }
    printf("\n");
  } else  {
    i = j = 0;
    while (j < 3) { if (Seed[++i] != HOLE) j++; }
    for (j = i; j < m; j++) {
      if (insert_cl_1(SIG(1, 0, j), FF)) { bug(8); return 1; }
    }
  }

  return 0;
}

#ifndef HP_UX
#ifdef PRIVATE
pmd_extra_cls () 
{
  int i, j, s, x;
  int sol[] = {
10, 0, 1, 3, 9,
11, 0, 5, 4, 1,
12, 0, 8, 2, 5,
10, 1, 2, 4, 0,
11, 1, 6, 5, 2,
12, 1, 9, 3, 6,
10, 2, 3, 5, 1,
11, 2, 7, 6, 3,
12, 2, 0, 4, 7,
-1};
  printf("\nnew unit clauses\n");
  
  s = 0;
  for (j = 0; j < c; j++) 
    for (i = 0; i < r; i++) {
      x = sol[s++];
      if (x == -1) {
	printf("\nI'v found an error:\n");
	print_pmd(stdout); 
	return 1;
      }
      set_entry0(i, j, x);
    }

  print_pmd(stdout); 

  return 0;
}
#endif
#endif

void print_pmd(file)
     FILE *file;
{
  int i, j, x, y, k;

  fprintf(file, "\n     Base Blocks    ");
  for (y = 1; y <= K_apart; y++) fprintf(file, "\t\t    %d-apart", y);

  for (j = 0; j < c; j++) {
    for (k = 0; k < MULTI; k++) {

      fprintf(file, "\n ");
      for (x = 0; x < k; x++) fprintf(file, " ");
      fprintf(file, "(");

      for (i = 0; i < r; i++) {
	if (Oarray[i][j] < m) {
	  y = Oarray[i][j];
	  for (x = 0; x < k; x++) y = Mext[y];
	  fprintf(file, "%2d ", y);
	} else {
	  y = Oarray[i][j]-m+1+k*INCOMPLETE/MULTI;
	  fprintf(file, "x%d ", y);
	}
      }
      fprintf(file, ")   ");

      for (y = 1; y <= K_apart; y++) {
	fprintf(file, "\t\t");
	for (i = 0; i < r; i++) {
	  int i1 = (i + y) % r;
	  if (Oarray[i][j] < m && Oarray[i1][j] < m) {
	    int x2 = (W[(i)? r-i : 0] * DIFF(Oarray[i1][j], Oarray[i][j])) % m;
	    for (x = 0; x < k; x++) x2 = Mext[x2];
	    fprintf(file, " %2d", x2);
	  }
	}
      }
    }

    if (j < DOUBLE)     
      for (k = 0; k < MULTI; k++) {
      fprintf(file, "\n ");
      for (x = 0; x < k; x++) fprintf(file, " ");
      fprintf(file, " (");

      for (i = r-1; i >= 0; i--) {
	if (Oarray[i][j] < m) {
	  y = Oarray[i][j];
	  for (x = 0; x < k; x++) y = Mext[y];
	  fprintf(file, "%2d ", y);
	} else {
	  y = Oarray[i][j]-m+1+k*INCOMPLETE/MULTI;
	  fprintf(file, "x%d ", y);
	}
      }
      fprintf(file, ")   ");

      for (y = 1; y <= K_apart; y++) {
	fprintf(file, "\t\t");
	for (i = r-1; i >= 0; i--) {
	  int i1 = (i + r - y) % r;
	  if (Oarray[i][j] < m && Oarray[i1][j] < m) {
	    /* W[i] or W[i1]? */
	    int x2 = (W[(i)? r-i : 0] * DIFF(Oarray[i1][j], Oarray[i][j])) % m;
	    for (x = 0; x < k; x++) x2 = Mext[x2];
	    fprintf(file, " %2d", x2);
	  }
	}
      }
    }
  }

  fprintf(file, "\n\n");

  if (num_rem > 0) {
    if (k_flag == 3 && MULTI == r) {
      W[0] = 1; 
      i = Seed[m]; j = 1;
      while (i != 1) { W[j++] = i; i = (i*Seed[m])%m; }
    } else if (W[1] == 1)
      for (i = 0; i < r; i++) W[i] = i+1;

    printf("Additional blocks:\n");
    for (i = 0; i < num_rem; i++) {
      printf("   (");
      for (j = 0; j < PMD; j++) printf("%2d ", (remainder[i]*(W[j]-1))%m);
      printf(")\n");
    }
    printf("\n");
  }
}

void print_pmd_model (file)
     FILE *file;
{
  int i, x, y, z;

  for (i = rcm; i > 0; i--) if (Value[i] == TT) {
    z = (i-3) % m;
    x = (i-3) / m;
    y = x % c;
    x = 1 + x / c;
    if (Oarray[x][y] < 0) Oarray[x][y] = z;
  }
  
  if (INCOMPLETE == 0 || INCOMPLETE == RAMSEY)
    fprintf(file, "\n%d-HPMD(%d^%d) #%d:\n", 
	    PMD, RAMSEY, ((INCOMPLETE)?1:0)+m/RAMSEY, Branch_succ);
  else 
    fprintf(file, "\n%d-HPMD(%d^%d, %d^1) #%d:\n", 
	    PMD, RAMSEY, m/RAMSEY, INCOMPLETE, Branch_succ);
  print_pmd(file);

  if (MODEL != 1) pmd_unit_cls();
}

void pmd_print_code()
{
  int i, j, x, y, a;

  printf("rcm = %d, kcm = %d, Max_atom = %d, Addk = %d\n\n", 
	 rcm, kcm, Max_atom, Addk);

  for (i = 1; i < r; i++)
    for (j = 0; j < c; j++)
      for (x = 0; x < m; x++) {
	printf("SIG(%d, %d, %d) = %d\n", i, j, x,SIG2(i,j,x));
      }    

  for (i = 0; i < K_apart; i++)
    for (j = 0; j < c; j++)
      for (x = 1; x <= max_seed; x++) 
	for (a = 0; a < Addk; a++) {
	printf("PHI(%d, %d, %d, %d) = %d\n", i, j, x, a, PHI(i,j,x,a));
      }    

  for (i = 0; i < K_apart; i++)
    for (y = 0; y < r; y++) 
      for (x = 1; x < max_seed; x++) 
	for (a = 0; a < Addk; a++) {
	printf("THI(%d, %d, %d, %d) = %d\n", i, y, x, a, THI(i,y,x,a));
      }
} 

pmd_read_partial ()
{
  int i, j, k;
  char name[20];

  sprintf(name, "c%d.in", LINE%1000);
  if (Input_sqs == NULL) { open_input_sqs(name); }
  if (fscanf(Input_sqs, "%d", &i) == EOF) {
    printf("No more blocks.\n"); 
    fclose(Input_sqs);
    Input_sqs = NULL;
    return 1;
  }

  printf("Read in a partial set of blocks:\n");
  for (j = 0; j < c; j++) {
    printf("\n ( ");
    for (i = 0; i < r; i++) {
      if (fscanf(Input_sqs, "%d", &k) == EOF) { printf("\n"); return 0; }
      if (Oarray[i][j] >= m) {
	printf("- ");
	if (k != -1) { printf("Bad input (-1 expected): %d\n", k); exit(0); }
      } else if (k < 0) {
	printf("X ");
      } else {
	printf("%d ", k);
	set_entry(i,j,k);
      }
    }
    printf(")");
  }
  printf("\n\n");

  return 0;
}

void pmd_gene_partials ()
{
  printf("Getting there ...\n");
  fix_remainder(PMD);
  printf("Jessus Chris!\n");
  exit (0);
}

int pmd_fill_seed(s)
     int s;
{
  int i, j, k, reps[50], comb[50], w[10];
  int x, y, z, z0, good;
  int oarray[MAX_ROW][MAX_COL];

  k = 0;
  printf("working on %d ...\n", s);
  i = fill_seed(s, PMD);
  for (j = 1; j < m; j++) if (Seed[j] == j) {
    printf("[ %d", y = j);
    for (x = 1; x < PMD; x++) {
      y = Mext[y];
      if (y == j) x = m;
      else printf(", %d", y);
    }
    printf(" ]\n");
    if (x < m) reps[k++] = j;
  }

  printf("\nGenerating tables ...\n");
  Input_sqs = (FILE *) open_fname_out("w");
  x = s; w[0] = 0; w[1] = 1;
  for (y = 2; y < PMD; y++) { w[y] = ABG_f[x][w[y-1]]; x = (x * s)%m; }

  x = RESTRICT % 100;
  if (x > k) { printf("Warning: impossible to pick %d out of %d\n", x, k);
	       exit(0); }
  if (x >= c || Oarray[0][x-1] >= m) {
    printf("Warning: not enough number of blocks to fill (c = %d, n = %d)\n",
	   c, x);
    exit(0); 
  }
  
  z = 0; z0 = (RESTRICT%1000)+100;
  for (y = 0; (y <= x); y++) comb[y] = y;
  while (comb[0] != k && z < z0) {
    good = 1;
    for (j = 0; j < c; j++) {
      /*int h = reps[comb[j]];*/
      int h = (s-1)*reps[comb[j]];

      for (i = 0; i < PMD; i++) {
	if (Oarray[i][j] >= m)
	  oarray[i][j] = -1;
	else if (Oarray[i][j] >= 0)
	  oarray[i][j] = Oarray[i][j];
	else if (j < x) {
	  if (Seed[oarray[i][j] = (w[i]*h)%m] == HOLE) good = 0;;
	} else  oarray[i][j] = -2;
      }
    }

    printf("Finding a %s one:\n", (good)? "good" : "bad");
    if (good) fprintf(Input_sqs, "%d %d\n", ++z, x);
    for (j = 0; j < c; j++) {
      for (i = 0; i < PMD; i++) {
	printf("%d ", oarray[i][j]);
	if (good) fprintf(Input_sqs, "%d ", oarray[i][j]);
      }
      printf("\n");
      if (good) fprintf(Input_sqs, "\n");
    }

    printf("\n");
    if (good) fprintf(Input_sqs, "\n");

    if ((comb[0] + x) == k)
      comb[0] = k;
    else 
      next_combination(x, k, comb);
  }

  fclose(Input_sqs); 
  printf("Finding %d good tables.\n", z);
  return (s);
}

pmd_mod23_cls ()
{
  int array[MAX_COL][MAX_ROW];
  int mo, i, j, k;
  char name[20];

  sprintf(name, "b%d.in", LINE%1000);
  if (Input_sqs == NULL) { open_input_sqs(name); }
  if (fscanf(Input_sqs, "%d", &mo) == EOF) {
    printf("No more blocks.\n"); 
    fclose(Input_sqs);
    Input_sqs = NULL;
    return 1;
  }

  printf("Read in blocks mod %d:\n", mo);
  for (j = 0; j < c; j++) {
    printf("\n ( ");
    for (i = 0; i < r; i++) {
      if (Oarray[i][j] >= m) {
	printf("- ");
	fscanf(Input_sqs, "%d", &k);
	if (k != -1) { printf("Bad input (-1 expected): %d\n", k); exit(0); }
      } else {
	fscanf(Input_sqs, "%d", &k);
	printf("%d ", array[j][i] = k);
      }
    }
    printf(")");
  }
  printf("\n\n");

  /* generate unit clauses */
  for (i = 1; i < r; i++)
    for (j = 0; j < c; j++) if (Oarray[i][j] == UNKNOW)
      for (k = 1; k < m; k++) if (k % mo != array[j][i])
	if (insert_cl_1(SIG(i, j, k), FF)) return 1;

  return 0;
}

int pmd_mod23_blocks ()
{
  if (m % 3 == 0 && RESTRICT / 1000 == 3) {
    if (pmd_mod_blocks(3)) return 1; 
  } else if (m % 2 == 0) {
    if (pmd_mod_blocks(2)) return 1; 
  }

  return 0;
}

#define MAX_K_MOD 3
pmd_mod_blocks (mo)
     int mo;
     /* this function is very, very long, because it uses
	several 2 or 3 dimension arrays that cannot be easily past 
	as parameters. */
{
  int tuples[MAX_COL][21][MAX_ROW];
  int load[MAX_COL];
  int code[MAX_COL][201];
  int array[MAX_COL][MAX_ROW];
  int apar[MAX_COL][MAX_K_MOD][MAX_K_MOD];
  int goal[MAX_K_MOD][MAX_K_MOD], apar_sum[MAX_K_MOD][MAX_K_MOD];
  int c0, i, j, k, good;
  int x[MAX_K_MOD];

  /* initialize */
  for (k = 0; k < K_apart; k++) 
    for (i = 0; i < mo; i++) {
      goal[k][i] = apar_sum[k][i] = 0;
      for (j = 0; j < c; j++) apar[j][k][i] = 0;
    }
  for (j = 0; j < c; j++) code[j][0] = 0;
  for (j = 1; j < m; j++) if (Seed[j] != HOLE) 
    for (k = 0; k < K_apart; k++) goal[k][j % mo]++;
  if (MULTI > 1) {
    for (j = 1; j < m; j++) 
      if (Seed[j] != HOLE && (j % mo != Mext[j] % mo)) {
	printf("Multipliers in trouble: %d != %d mo %d\n", 
	       j, Mext[j], mo);
	exit(0);
      }
    for (i = 0; i < mo; i++) for (k = 0; k < K_apart; k++) goal[k][i] /= MULTI;
  }
  for (i = 0; i < num_rem; i++) goal[0][remainder[i] % mo]--; 

  printf("Number of remainders by %d: ", mo);
  for (i = 0; i < mo; i++) printf(" %d of %d's,", goal[0][i], i); 
  printf("\n\n");

  /* skip the first few cases */
  j = 0;
  if (FLAG > 1000) { 
    c0 = 0;
    mod_init_col(mo, array[j], j);
    while (FLAG != c0) {
      mod_inc_col(mo, array[j], j);
      c0 = (Oarray[0][j] >= m) ? 1 : 0;
      for (k = 0; k < K_apart; k++) {
	mod_apart_count(mo, array[j], j, k, x);
	for (i = 0; i < mo-1; i++) {
	  c0 = (c0 << 3) + x[i];
	}
      }
      c0 += 1000;
      mod_insert_code(code[j], c0);
      printf("c0 = %d\n", c0);
    }
    good = 0; 
  } else {
    good = 1; 
  }

  /* fill the array */
  printf("Searching for blocks mod %d ...\n", mo);
  while (j < c) {

    if (good) {
      mod_init_col(mo, array[j], j);
    } else {
      good = 1;
      while (j >= 0 && good) {
	if (good = mod_inc_col(mo, array[j], j)) {
	  code[j][0] = 0;
	  if (j--) {
	    for (k = 0; k < K_apart; k++) 
	      for (i = 0; i < mo; i++) {
		apar_sum[k][i] -= apar[j][k][i];
		apar[j][k][i] = 0;
	      }
	  }
	}
      }
      if (good) { printf("\nNo table mod %d!!!\n\n", mo); return 1; }
      good = 1;
    }

    if (TRACE > 2) {
      printf("col %d: ( ", j);
      for (i = 0; i < r; i++) 
	if (Oarray[i][j] >= m) {
	  printf("- ");
	} else {
	  printf("%d ", array[j][i]);
	}
      printf(")\n");
    }

    for (k = 0; good && k < K_apart; k++) {
      mod_apart_count(mo, array[j], j, k, x);
      for (i = 0; i < mo; i++) 
	if ((apar_sum[k][i] + x[i]) > goal[k][i]) good = 0;

      if (good) {

	for (i = 0; i < mo; i++) {
	  apar[j][k][i] = x[i];
	  apar_sum[k][i] += x[i];

	  if (TRACE > 2)
	    printf("For %d-apart, remainder %d: %d in col %d, and %d in total (<= %d)\n", 
		   k+1, i, x[i], j, apar_sum[k][i], goal[k][i]);

	  }
      } else {
	/* backtracking */
	good = k;
	for (k = 0; k < good; k++) 
	  for (i = 0; i < mo; i++) {
	    apar_sum[k][i] -= apar[j][k][i];
	    apar[j][k][i] = 0;
	  }
	good = 0;
      }
    }

    if (good) {
      c0 = (Oarray[0][j] >= m) ? 1 : 0;
      for (k = 0; k < K_apart; k++) 
	for (i = 0; i < mo-1; i++) {
	  c0 = (c0 << 3) + apar[j][k][i];
	}

      c0 += 1000;
      if (TRACE > 2) printf("code of col %d = %d\n", j, c0);

      if ((j && c0 < code[j-1][200]) || mod_insert_code(code[j], c0)) {
	good = 0;
	/* backtracking */
	for (k = 0; k < K_apart; k++) 
	  for (i = 0; i < mo; i++) {
	    apar_sum[k][i] -= apar[j][k][i];
	    apar[j][k][i] = 0;
	  }
      } else 
	j++;
    } 
  }

  printf("The first set of blocks mod %d (initial code: %d):\n", 
	 mo, CREATE = code[0][200]);
  for (j = 0; j < c; j++) {
    printf("\n ( ");
    for (i = 0; i < r; i++) {
      if (Oarray[i][j] >= m) {
	printf("- ");
      } else {
	printf("%d ", array[j][i]);
      }
    }
    printf(")");
  }
  printf("\n\n");

  /* generate more sets of blocks */
  for (j = 0; j < c; j++) load[j] = 0;
  for (j = 0; j < c; j++) {
    code[j][0] = 0;
    mod_init_col(mo, array[j], j);
    good = 1;
    while (good) {
      for (k = 0; good && k < K_apart; k++) {
	mod_apart_count(mo, array[j], j, k, x);
	for (i = 1; i < mo; i++) if (apar[j][k][i] != x[i]) good = 0;
      }

      if (good && (j || Oarray[0][0] >= m || array[0][1] == 1)) {
	printf("col %d: ", j);
	for (i = 0; i < r; i++) {
	  if (Oarray[i][j] >= m) {
	    printf("- ");
	  } else {
	    printf("%d ", array[j][i]);
	  }
	}
	c0 = mod_encode(mo, array[j], j);
	printf(" (code = %d)\n", c0);

	/*
	for (k = 0; k < K_apart; k++) 
	  for (i = 0; i < mod; i++) 
	    printf("apar[%d][%d][%d] = %d != %d = x[%d]\n", j, k, i, apar[j][k][i], x[i], i);
	*/

	if (!mod_insert_code(code[j], c0)) {
	  if (load[j] < 20) {
	    k = load[j]++;
	    for (i = 0; i < r; i++) tuples[j][k][i] = array[j][i];
	  } else 
	    printf("overflow in 21\n");
	}

      }
      good = !mod_inc_col(mo, array[j], j);
    } 
  }

  for (j = 0; j < c; j++) {
    i = load[j];
    printf("%d col%d, ", i, j);
    code[j][200] = i-1;
    for (k = 0; k < i; k++) code[j][k] = mod_encode(mo, tuples[j][k], j);
  }
  printf("\n");

  Input_sqs = (FILE *) open_fname_out("w");
  good = 0;
  for (j = 0; j < c; j++) {
    load[j] = 0; 
    if (good < code[j][200]) good = code[j][200];
  }
  good++;

  while ( good ) {
    good--;
    fprintf(Input_sqs, "%d %d ", CREATE, mo);
    for (j = 0; j < c; j++) {
      for (i = 0; i < r; i++) {
	if (Oarray[i][j] >= m) {
	  fprintf(Input_sqs, "-1 ");
	} else {
	  fprintf(Input_sqs, "%d ", tuples[j][load[j]][i]);
	}
      }
    }
    fprintf(Input_sqs, "\n");

    for (j = 0; j < c; j++) {
      if (++load[j] >= code[j][200]) load[j] = 0;
    }
  }

  fclose(Input_sqs); 
  return 2;
}

mod_init_col (mo, col, j)
     int mo, col[], j;
{
  int i;
  for (i = 0; i < r; i++) 
    if (Oarray[i][j] == UNKNOW) col[i] = 0;
    else if (Oarray[i][j] < m) col[i] = Oarray[i][j] % mo;
}

int mod_inc_col (mo, col, j)
     int mo, col[], j;
{
  int i;

  for (i = 0; i < r; i++) if (Oarray[i][j] == UNKNOW) {
    if (col[i] == mo-1) col[i] = 0;
    else { col[i]++; return 0; }
  }
  return 1;
}

mod_apart_count(mo, col, j, k, x)
     int mo, col[], j, k, x[];
{
  int i;

  /*
  printf("col %d: ( ", j);
  for (i = 0; i < r; i++) 
    if (Oarray[i][j] >= m) {
      printf("- ");
    } else {
      printf("%d ", col[i]);
    }
  printf(")\n");
  */

  k++;
  for (i = 0; i < mo; i++) x[i] = 0;
  for (i = 0; i < r; i++) 
    if (Oarray[i][j] < m && Oarray[(i+k)%r][j] < m) {
      /*
      printf("c[%d] = %d, c[%d] = %d, c[%d] - c[%d] = %d\n",
	     (i+k)%r, col[(i+k)%r], i, col[i],
	     (i+k)%r, i, (mo + col[(i+k)%r] - col[i])%mo);
	     */
      if (k)
	x[(mo + col[(i+k)%r] - col[i])%mo]++;
      else
	x[col[i]%mo]++;
    }

  if (j < DOUBLE) {
    int col2[10];
    for (i = 1; i <= r; i++) col2[i-1] = col[r-i];
    for (i = 0; i < r; i++) 
      if (Oarray[i][j] < m && Oarray[(i+k)%r][j] < m) {
	if (k)
	  x[(mo + col2[(i+k)%r] - col2[i])%mo]++;
	else
	  x[col2[i]%mo]++;
      }
  }
}

int mod_insert_code (list, c)
     int list[], c;
     /* insert c into the list and keep the list sorted */
{
  int l, rr, mm;
  list[MAX_COL-1] = c;
  l = 1; rr = list[0]; 
  while (l <= rr) {
    mm = (l+rr)/2;
    if (list[mm] == c) { return 1; }
    /* c is already in the list */

    if (list[mm] > c) rr = mm-1;
    else l = mm+1;
  }

  /* c is not in the list */
  if (list[0] == MAX_COL-1) {
    printf("WARNING: Overflow in mo_insert_code: %d\n\n", MAX_COL); 
  } else {
    l = list[0]++;
    while (l > rr) { list[l+1] = list[l]; l--; }
    list[rr+1] = c;
  }

  /*
  printf("\nC: ");
  for (l = list[0]; l > 0; l--) printf("%d ", list[l]);
  printf("\n");
  */

  return 0;
}

mod_encode(mo, col, j)
     int mo, col[], j;
{
  int i, c0;
  
  c0 = (Oarray[0][j] >= m) ? 1 : 0;
  if (c0) 
    for (i = 1; i < r; i++)
      c0 = (c0 << mo) + col[i];
  else {
    int m1, m2, good;

    m1 = 0;
    for (m2 = 1; m2 < r; m2++) {
      good = 1;
      for (i = 0; (good > 0) && i < r; i++) 
	if (col[(m1+i)%r] > col[(m2+i)%r]) good = 0;
	else if (col[(m1+i)%r] != col[(m2+i)%r]) good = -1;
      if (!good) m1 = m2;
    }
    for (i = 1; i < r; i++) 
      c0 = (c0 << mo) + col[(i+m1)%r];
  }
  return c0;
}

print_sig(i, j, k)
     int i, j, k;
{
  printf("SIG(%d, %d, %d) = %d\n", i, j, k, SIG(i, j, k));
}

p_pmd() { print_pmd(stdout); }

/***************************/
int q100_clauses()
{
  int cl_arr [ MAX_ATOM ], sign_arr [ MAX_ATOM ];

  if (q100_unit_cls()) return 1;

  /*pmd_extra_cls(); print_pmd(stdout); */

  if (q100_unique_cls(cl_arr, sign_arr)) return 1;

  if (q100_pair_cls(cl_arr, sign_arr)) return 1;

  if (pmd_posi_cls(cl_arr, sign_arr)) return 1;

  return 0;
}

int q100_unit_cls()
{
  int x, y, i, j;
  int addk = get_addk();
  if (addk < 2) addk = QGROUP-1;

  for (i = addk-1; i >= 0; i--) if (i < c) {
    set_entry0(0,i,0);
    set_entry(1,i,i+1);
  }

  if (RESTRICT > 20) y = RESTRICT-20; else y = 2;
  x = 1; j = 0; 
  for (i = addk; i < c; i++) {
    set_entry0(0, i, x);
    j++;
    if (j == y) { x++; j = 0; }
  }

  for (i = 1; i < r; i++)
    for (x = 0; x < c; x++) 
      if (insert_cl_1(SIG(i, x, 0), FF)) { bug(9); return 1; }

  if (RESTRICT > 20) {
    /* restriction on the first column. */
    for (i = 2; i < r; i++)
      for (x = i+3; x < QGROUP; x++) 
	if (insert_cl_1(SIG(i, 0, x), FF)) { bug(10); return 1; }
  }

  return 0;
}

int q100_unique_cls(cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
{
  int i, j, u, v;
  int addk = get_addk();
  if (addk < 2) addk = QGROUP-1;

  /* each entry has at most one value */
  /* i * j = u and i * j = v imply u = v. */
  for (i = 0; i < r; i++) 
    for (j = 0; j < c; j++) 
      for (u = QGROUP-1; u >= 0; u--) 
	for (v = u-1; v >= 0; v--) {
	  if (insert_cl_2(SIG(i, j, u), 
			  SIG(i, j, v), 
			  FF, cl_arr, sign_arr)) return 1;
	}

  /* no two elements are the same in the same column */
  /* i * v = u and j * v = u imply i = j. */
  for (i = 1; i < r; i++) 
    for (j = i-1; j >= 0; j--) 
      for (v = 0; v < c; v++) 
	for (u = 0; u < m; u++) {
	  if (insert_cl_2(SIG(i, v, u), 
			  SIG(j, v, u), 
			  FF, cl_arr, sign_arr)) return 1;
	}

  /* no two elements are the same in the same row */
  /* v * i = u and v * j = u imply i = j. */
  for (i = addk-1; i > 0; i--) if (i < c)
    for (j = i-1; j >= 0; j--) 
      for (v = 1; v < r; v++) 
	for (u = 0; u < QGROUP; u++) {
	  if (insert_cl_2(SIG(v, i, u), 
			  SIG(v, j, u), 
			  FF, cl_arr, sign_arr)) return 1;
	}

  /* last part of the second row is in increasing order */
  for (i = addk; i < c; i++) 
    for (j = 1; j < QGROUP; j++)
      for (u = 1; u < j; u++) {

	for (v = i+1; v < c; v++) 
	  if (insert_cl_2(SIG(1, i, j), 
			  SIG(1, v, u), 
			  FF, cl_arr, sign_arr)) return 1;

	if (insert_cl_2(SIG(0, i, j), 
			SIG(1, i, u), 
			FF, cl_arr, sign_arr)) return 1;
      }	

  return 0;
}

int q100_pair_cls(cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
{
  int k, i, j, i1, j1, u, v;

  for (k = 0; k < K_apart; k++) 
    for (u = 0; u < m; u++)
      for (v = 0; v < m; v++) 
	for (i = c-1; i >= 0; i--) {

	  for (j = 0; j < r; j++) {
/*
if (k == 0 && j == 1 && i == 0 && u == 1 && v == 5)
  { printf("YOYO(%d, %d, %d, %d)", k, i, u, v); bug(115); }
if (k == 0 && j == 3 && i == 1 && u == 1 && v == 5) 
  { printf("YOYO(%d, %d, %d, %d)", k, i, u, v); bug(315); }
*/
	    if (insert_cl_all_3(SIG(j, i, u),
				SIG((j+k+1)%r, i, v),
				YOYO(k, i, u, v),
				1, cl_arr, sign_arr))
	      return 1;
	  }

	  for (j = i+1; j < c; j++) {
/*
if (k == 0 && j == 3 && i == 1 && u == 1 && v == 5)
  { printf("YOYO(%d, %d/%d, %d, %d)", k, i, j, u, v); bug(15); }
*/
	    if (insert_cl_2(YOYO(k, j, u, v),
			    YOYO(k, i, u, v),
			    0, cl_arr, sign_arr))
	      return 1;
	  }
	}

  return 0;
}

int blocks_clauses()
{
  int cl_arr [ MAX_ATOM ], sign_arr [ MAX_ATOM ];

  if (blocks_unit_cls()) return 1;

  /*pmd_extra_cls(); print_pmd(stdout); */

  if (blocks_unique_cls(cl_arr, sign_arr)) return 1;

  if (blocks_pair_cls(cl_arr, sign_arr)) return 1;

  if (pmd_posi_cls(cl_arr, sign_arr)) return 1;

  return 0;
}

int blocks_unit_cls()
{
  int i, j;

  for (i = c-(k_flag % 100)-1; i >= 0; i--) set_entry0(0,i,0);
  for (i = c-(k_flag % 100); i < c; i++) set_entry0(0,i,1);
  for (i = c-((k_flag/100) % 10); i < c; i++) set_entry0(0,i,2);

  if (RESTRICT < 50 && RESTRICT % 10) {
    set_entry(1,0,1);
    for (j = 1; j < RESTRICT && j < c; j++) 
      for (i = m/2; i < m; i += j) {
	if (insert_cl_1(SIG(3, j, i), FF)) { bug(8); return 1; }
      }
  }

  return 0;
}

int blocks_unique_cls(cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
{
  int x, i, j, u, v;

  /* each entry has at most one value */
  /* i * j = u and i * j = v imply u = v. */
  for (i = 0; i < r; i++) 
    for (j = 0; j < c; j++) 
      for (u = m-1; u >= 0; u--) 
	for (v = u-1; v >= 0; v--) {
	  if (insert_cl_2(SIG(i, j, u), 
			  SIG(i, j, v), 
			  FF, cl_arr, sign_arr)) return 1;
	}

  /* no two elements are the same in the same column */
  /* i * v = u and j * v = u imply i = j. */
  for (i = 1; i < r; i++) 
    for (j = i-1; j >= 0; j--) 
      for (v = 0; v < c; v++) 
	for (u = 0; u < m; u++) {
	  if (insert_cl_2(SIG(i, v, u), 
			  SIG(j, v, u), 
			  FF, cl_arr, sign_arr)) return 1;
	}


  /* the second row is in increasing order */
  x = c-(k_flag % 100);
  for (i = 0; i < x; i++)
    for (j = i+1; j < x; j++) 
      for (u = 2; u < m; u++)
	for (v = u-1; v > 0; v--) {
	  if (insert_cl_2(SIG(1, i, u), 
			  SIG(1, j, v), 
			  FF, cl_arr, sign_arr)) return 1;
	}
  for (i = x; i < c; i++)
    for (j = i+1; j < c; j++) 
      for (u = 2; u < m; u++)
	for (v = u-1; v > 0; v--) {
	  if (insert_cl_2(SIG(1, i, u), 
			  SIG(1, j, v), 
			  FF, cl_arr, sign_arr)) return 1;
	}

  return 0;
}

int blocks_pair_cls(cl_arr, sign_arr)
     int cl_arr[], sign_arr[];
{
  int k, i, j, i1, j1, u, v;

  for (i = 0; i < c; i++)
    for (i1 = i+1; i1 < c; i1++) 
      for (j = 0; j < r; j++)
	for (j1 = 0; j1 < r; j1++)
	  for (u = 0; u < m; u++)
	    for (v = 0; v < m; v++) 
	      for (k = 1; k <= K_apart; k++) {
		if (insert_cl_4(SIG(j, i, u),
				SIG((j+k)%r, i, v),
				SIG(j1, i1, u),
				SIG((j1+k)%r, i1, v),
				0, cl_arr, sign_arr))
		  return 1;
	      }
  return 0;
}


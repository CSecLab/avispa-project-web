html_column_1(300).
html_column_2(120).
html_column_3(150).

% print_statistics_axioms_heading :-
%       Print the header of the AXIOM GENERATION STATISTICS
print_statistics_axioms_heading :-
	value(output,standard),!,
	format(user_output,"\nSTATISTICS (AXIOMS GENERATION)\tRUNTIME(sec)\n",[]).
print_statistics_axioms_heading :-
	value(output,planning),!,
	format(user_output,"\nSTATISTICS (AXIOMS GENERATION)\tRUNTIME(sec)\n",[]).
print_statistics_axioms_heading :-
	value(output,html),!,
	format(user_output,"<TABLE>\n",[]),
	html_column_1(WidthAxioms),
	html_column_2(WidthTime),
	format(user_output,"<TR><TD WIDTH=~w>STATISTICS (AXIOMS GENERATION)</TD><TD WIDTH=~w>RUNTIME(sec)</TD></TR>\n",[WidthAxioms,WidthTime]).

print_statistics_axioms_end :-
	value(output,standard),!,	
	get_total_encoding_time(EncTime),
	SecEncTime is EncTime/1000,	
	format(user_output,"\t\t\t\t------\n",[]),
	format(user_output,"Total:\t\t\t\t~w\n",[SecEncTime]).
print_statistics_axioms_end :-
	value(output,planning),!,	
	get_total_encoding_time(EncTime),
	SecEncTime is EncTime/1000,	
	format(user_output,"\t\t\t\t------\n",[]),
	format(user_output,"Total:\t\t\t\t~w\n",[SecEncTime]).
print_statistics_axioms_end :-
	value(output,html),!,	
	get_total_encoding_time(EncTime),
	SecEncTime is EncTime/1000,	
	html_column_1(WidthAxioms),
	html_column_2(WidthTime),
	format(user_output,"<TR><TD WIDTH=~w></TD><TD WIDTH=~w>--------</TD></TR>\n",[WidthAxioms,WidthTime]),
	format(user_output,"<TR><TD WIDTH=~w>Total</TD><TD WIDTH=~w>~w</TD></TR></TABLE><br>\n",[WidthAxioms,WidthTime,SecEncTime]).
	
% print_statistic_axioms2sat_heading :-
%       Print the header of the AXIOM TRANSLATION STATISTICS
print_statistics_axioms2sat_heading :-
	value(output,standard),!,
	format(user_output,"\nSTATISTICS (AXIOMS TRANSLATION)\tCLAUSES\tRUNTIME(sec)\n",[]).
print_statistics_axioms2sat_heading :-
	value(output,planning),!,
	format(user_output,"\nSTATISTICS (AXIOMS TRANSLATION)\tCLAUSES\tRUNTIME(sec)\n",[]).
print_statistics_axioms2sat_heading :-
	value(output,html),!,
	format(user_output,"<TABLE>\n",[]),
	html_column_1(WidthAxioms),
	html_column_2(WidthClauses),	
	html_column_3(WidthTime),
	format(user_output,"<TR><TD WIDTH=~w>STATISTICS (AXIOMS TRANSLATION)</TD><TD WIDTH=~w>CLAUSES</TD><TD WIDTH=~w>RUNTIME(sec)</TD></TR>\n",[WidthAxioms,WidthClauses,WidthTime]).

print_statistics_axioms2sat_end :-
	value(output,standard),!,	
	get_total_axioms_translation_time(TransTime),
	SecTransTime is TransTime/1000,
	format(user_output,"\t\t\t\t\t------\n",[]),	
	format(user_output,"Total:\t\t\t\t\t~w\n",[SecTransTime]).
print_statistics_axioms2sat_end :-
	value(output,planning),!,	
	get_total_axioms_translation_time(TransTime),
	SecTransTime is TransTime/1000,
	format(user_output,"\t\t\t\t\t------\n",[]),	
	format(user_output,"Total:\t\t\t\t\t~w\n",[SecTransTime]).
print_statistics_axioms2sat_end :-
	value(output,html),!,	
	get_total_axioms_translation_time(TransTime),
	SecTransTime is TransTime/1000,
	html_column_1(WidthAxioms),
	html_column_2(WidthClauses),	
	html_column_3(WidthTime),
	format(user_output,"<TR><TD WIDTH=~w></TD><TD WIDTH=~w></TD><TD WIDTH=~w>---------</TD></TR>\n",[WidthAxioms,WidthClauses,WidthTime]),
	format(user_output,"<TR><TD WIDTH=~w>Total</TD><TD WIDTH=~w></TD><TD WIDTH=~w>~w</TD></TR></TABLE><br>\n",[WidthAxioms,WidthClauses,WidthTime,SecTransTime]).
	

% print_statistics_axioms(AxType) :-
%       Print the AxType AXIOMS GENERATION STATISTICS
print_statistics_axioms(AxType) :-
	value(output,standard),!,
	get_encoding_time(AxType,Time),
	SecTime is Time/1000,
	axiomlabel2axiomstring(AxType,AxSTR),
 	format(user_output,"~w\t~w\n",[AxSTR,SecTime]).
print_statistics_axioms(AxType) :-
	value(output,planning),!,
	get_encoding_time(AxType,Time),
	SecTime is Time/1000,
	axiomlabel2axiomstring(AxType,AxSTR),
 	format(user_output,"~w\t~w\n",[AxSTR,SecTime]).
print_statistics_axioms(AxType) :-
	value(output,html),!,
	get_encoding_time(AxType,Time),
	SecTime is Time/1000,
	axiomlabel2axiomstring(AxType,AxSTR),
	html_column_1(WidthAxioms),
	html_column_2(WidthTime),
 	format(user_output,"<TR><TD WIDTH=~w>~w</TD><TD WIDTH=~w>~w</TD></TR>\n",[WidthAxioms,AxSTR,WidthTime,SecTime]).

% print_statistics_axioms_translation(AxType) :-
%       Print the AxType AXIOMS TRANSLATION STATISTICS
print_statistics_axioms_translation(AxType) :-
	value(output,standard),!,
	retract(value(tmp_clause_counter,CC0)),
	value(clause_counter,CC1),
	assert(value(tmp_clause_counter,CC1)),
	CC is CC1-CC0,
	assert_axioms_clauses_number(AxType,CC),
	get_axioms_translation_time(AxType,Time),
	SecTime is Time/1000,
	axiomlabel2axiomstring(AxType,AxSTR),
 	format(user_output,"~w\t~w\t~w\n",[AxSTR,CC,SecTime]).
print_statistics_axioms_translation(AxType) :-
	value(output,planning),!,
	retract(value(tmp_clause_counter,CC0)),
	value(clause_counter,CC1),
	assert(value(tmp_clause_counter,CC1)),
	CC is CC1-CC0,
	assert_axioms_clauses_number(AxType,CC),
	get_axioms_translation_time(AxType,Time),
	SecTime is Time/1000,
	axiomlabel2axiomstring(AxType,AxSTR),
 	format(user_output,"~w\t~w\t~w\n",[AxSTR,CC,SecTime]).
print_statistics_axioms_translation(AxType) :-
	value(output,html),!,
	retract(value(tmp_clause_counter,CC0)),
	value(clause_counter,CC1),
	assert(value(tmp_clause_counter,CC1)),
	CC is CC1-CC0,
	assert_axioms_clauses_number(AxType,CC),
	get_axioms_translation_time(AxType,Time),
	SecTime is Time/1000,
	axiomlabel2axiomstring(AxType,AxSTR),
	html_column_1(WidthAxioms),
	html_column_2(WidthClauses),	
	html_column_3(WidthTime),
	format(user_output,"<TR><TD WIDTH=~w>~w</TD><TD WIDTH=~w>~w</TD><TD WIDTH=~w>~w</TD></TR>\n",[WidthAxioms,AxSTR,WidthClauses,CC,WidthTime,SecTime]).

print_atoms_number(Atoms) :-
	value(output,standard),!,
	format(user_output,'\nNumber of Atoms: \t~w',[Atoms]).
print_atoms_number(Atoms) :-
	value(output,planning),!,
	format(user_output,'\nNumber of Atoms: \t~w',[Atoms]).
print_atoms_number(Atoms) :-
	value(output,html),!,
	format(user_output,'Number of Atoms: ~w<br>\n',[Atoms]).

print_clauses_number(C) :-
	value(output,standard),!,
	format(user_output,'\nNumber of Clauses: \t~w\n',[C]).
print_clauses_number(C) :-
	value(output,planning),!,
	format(user_output,'\nNumber of Clauses: \t~w\n',[C]).
print_clauses_number(C) :-
	value(output,html),!,
	format(user_output,'Number of Clauses: ~w<br>\n',[C]).

print_statistics(CAT) :-
	retract(value(previous_ax_type,PAT)),
	retract(value(tmp_clause_counter,CC0)),
	value(clause_counter,CC1),
	assert(value(tmp_clause_counter,CC1)),
	CC is CC1-CC0,
	statistics(runtime,[_,RT]),
	explanation(PAT,E),
	RT1 is RT/1000,
	format(user_output,'~w~w\t~w\n',[E,CC,RT1]),
	assert(value(previous_ax_type,CAT)).

explanation(initial_fact,'Initial Facts:\t\t\t').
explanation(goal,'Goal:\t\t\t\t').
explanation(ape_axiom,'Action Effect Axioms:\t\t').
explanation(classical_frame_axiom,'Classical Frame Axioms:\t\t').
explanation(explanatory_frame_axiom,'Explanatory Frame Axioms:\t').
explanation(at_least_one_axiom,'At-least-one Axioms:\t\t').
explanation(complete_exclusion_axiom,'Complete Exclusion Axioms:\t').
explanation(conflict_exclusion_axiom,'Conflict Exclusion Axioms:\t').

axiomlabel2axiomstring(initial_fact,'Initial Facts:\t\t') :- !.
axiomlabel2axiomstring(goal,'Goals:\t\t\t') :- !.
axiomlabel2axiomstring(ape_axiom,'Ape Axioms:\t\t') :- !.
axiomlabel2axiomstring(explanatory_frame_axiom,'Explanatory Frame Axioms:') :- !.
axiomlabel2axiomstring(conflict_exclusion_axiom,'Conflict Exclusion Axioms:') :- !.
axiomlabel2axiomstring(complete_exclusion_axiom,'Complete Exclusion Axioms:') :- !.
axiomlabel2axiomstring(classical_frame_axiom,'Classical Frame Axioms:') :- !.
axiomlabel2axiomstring(at_least_one_axiom,'At-least-one Axioms:') :- !.
axiomlabel2axiomstring(Ax,Ax).

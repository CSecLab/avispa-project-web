(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* utilities *)
open Types;;
open Globals;;

let get_identifier_name identifierNumber = fst (List.assoc identifierNumber !Globals.ident_list)
;;
let rec get_identifier_number identifierName identifierList=
  match identifierList with
    (number,(name,identifierType))::tail ->if (identifierName=name)
    then  number
    else
      (get_identifier_number identifierName tail);
    |_-> ErrorHandler.printExceptionMessage (Failure ("Identifier name "^identifierName^": Not found") )  "Utilities" "getId";raise(Not_found);
;;
let get_identifier_type identifierNumber = snd (List.assoc identifierNumber !Globals.ident_list)
;;
let rec findtype  identifierName identifierlist notifyNotFound=
  match identifierlist with
      [] -> if notifyNotFound then ErrorHandler.printExceptionMessage Not_found "Utilities" "findtype";
	raise Not_found;
  | head::tail -> if fst (snd head) == identifierName then snd (snd head) else findtype identifierName tail notifyNotFound
;;
let fresh_var protocolStep = List.assoc protocolStep !fresh;;

let oph timeTerm =  Op("h",[timeTerm]);;
let opprim privateKeyTerm = match privateKeyTerm with
    Op("prim",[key]) -> key
  | _ -> Op("prim",[privateKeyTerm]);;
let opmr userTerm =  Op("mr",[userTerm]);;
let oppk publicKeyTerm =  Op("pk",[publicKeyTerm]);;
let opsk secretKeyTerm =  Op("sk",[secretKeyTerm]);;
let opfu functionTerm =  Op("fu",[functionTerm]);;
let optable tableTerm  = Op("table",[tableTerm]);; 

let opnonce nonceTerm =  Op("nonce",[nonceTerm]);;
let oppair termPart1 termPart2 = Op("c",[termPart1;termPart2]);;
let opcrypt keyTerm cryptedTerm = Op("crypt",[keyTerm;cryptedTerm]);;
let opscrypt key cryptedTerm = Op("scrypt",[key;cryptedTerm]);;
let opfunct functionTerm parameterTerm = Op("funct",[functionTerm;parameterTerm]);;

let opsum operandTerm1 operandTerm2 = Op("sum",[operandTerm1;operandTerm2]);;
let opminus operandTerm1 operandTerm2 = Op("minus",[operandTerm1;operandTerm2]);;
let opmult operandTerm1 operandTerm2 = Op("mult",[operandTerm1;operandTerm2]);;
let opdiv operandTerm1 operandTerm2 = Op("div",[operandTerm1;operandTerm2]);;
let opmod operandTerm1 operandTerm2 = Op("mod",[operandTerm1;operandTerm2]);;
let oppow operandTerm1 operandTerm2 = Op("pow",[operandTerm1;operandTerm2]);;

let oprcrypt operandTerm1 operandTerm2 = Op("rcrypt",[operandTerm1;operandTerm2]);;
let opand operandTerm1 operandTerm2 = Op("and",[operandTerm1;operandTerm2]);;
let opor operandTerm1 operandTerm2 = Op("or",[operandTerm1;operandTerm2]);;
let opnand operandTerm1 operandTerm2 = Op("and",[operandTerm1;operandTerm2]);;
let opnor operandTerm1 operandTerm2 = Op("nor",[operandTerm1;operandTerm2]);;

let opw step sender receiver acqKnowledge initialKnowledge boolean session  
  = Op("w",[ step; sender; receiver; acqKnowledge; initialKnowledge; boolean; session]);;
let opm step realsender officialSender receiver contents session 
  = Op("m",[step;realsender;officialSender;receiver;contents;session]);; 
let opi knownTerm = Op("i",[knownTerm]);; 
let opsecret t1 t2 =  Op("secret",[t1;t2]);; 
let ops sessionCounter =  Op("s",[sessionCounter]);;
let opf sessionCounter =  Op("f",[sessionCounter]);;

let opTableElement tableTerm userTerm =  Op("tb",[tableTerm;userTerm]);;

let oprequest authenticator authenticated identificator term_value = Op("request", [authenticator;authenticated;identificator;term_value]);;
let opwitness authenticated authenticator identificator term_value = Op("witness", [authenticated;authenticator;identificator;term_value]);;




let op_of_type typ =
  match typ with
      User -> opmr
    | SyKey -> opsk
    | FrSyKey -> opsk
    | PcKey(_) -> oppk
    | FrPcKey(_) -> oppk
    | PeKey(_) -> (fun t -> opprim (oppk t))
    | FrPeKey(_) -> (fun t -> opprim (oppk t))
    | Table -> optable
    | Function -> opfu
    | Number -> opnonce
;;
let oparith_of_nb = function
    1 -> opsum
  | 2 -> opminus
  | 3 -> opmult
  | 4 -> opdiv
  | 5 -> opmod
  | _ -> oppow
;;
let oplogic_of_nb = function 
    1 -> oprcrypt
  | 2 -> opand
  | 3 -> opor
  | 4 -> opnand
  | _ -> opnor
;;


(* list managing functions *)

let rec union l1 l2 = match l1 with
    [] -> l2
  | head::tail -> if List.mem head l2 then union tail l2 else union tail (head::l2)
;; 
let rec sub l1 l2 = match l1 with
    [] -> []
  | head::tail -> if (List.mem head l2) then sub tail l2 else head::(sub tail l2)
;;
let rec remove element list =
	if (element=List.hd list)
		then
			List.tl list
		else
			[(List.hd list)]@(remove element (List.tl list))
;;
let rec interleave = function
   [] -> (fun l->l)
 | (a1::l1) as a1_l1 -> (function
        [] -> a1_l1
      | (a2::l2) as a2_l2 ->
             if (a1 > a2)
               then
                 a2::(interleave a1_l1 l2)
             else
               if (a1 = a2)
                 then
                   a1::(interleave l1 l2)
               else
                 a1::(interleave l1 a2_l2))
;;
let list_product l1 l2 =
let res = ref [] in
List.iter(fun x -> 
  List.iter(fun y -> res:=!res@[x@y])l2
    ) l1;
!res
;;
let merge l1 l2 =
let res = ref [] in
(
  List.iter ( fun (index1,data1) ->
	       try (res:=!res@[index1,data1@(List.assoc index1 l2)])
	       with Not_found -> res:=!res@[(index1,data1)]

)l1;
!res
)
;;
let rec suppr_double = function
    [] -> []
  | head::tail -> head::(suppr_double (sub tail [head]))
;;

let for_all_user functionToApply =
  List.iter (fun (identifierNumber,(identifierName,identifierType)) -> match identifierType with
                | User -> (functionToApply identifierNumber)
                | _ -> ())
    !Globals.ident_list
;;
let get_sender protocolStep =
  try(fst (fst (List.assoc protocolStep !Globals.msg_list)))
  with not_found -> 0
;;
let get_receiver protocolStep =
  if protocolStep == 0
  then
    get_sender 1
  else
    snd (fst (List.assoc protocolStep !Globals.msg_list))
;;
let get_msg protocolStep =
  snd (List.assoc protocolStep !Globals.msg_list)
;;
let firstS userNumber =
  let protocolStep = ref 1
  in
    while (get_sender !protocolStep <> userNumber && !protocolStep <= !Globals.nbMsgs) do
      incr protocolStep
     done;
    !protocolStep
;;

let last_received_message userNumber =
  let result = ref 0 in
    (
      for i = 1 to !Globals.nbMsgs do
      	let re = (get_receiver i) in
	  if (re = userNumber) then result := i;
      done;
      !result
    )
;;  
let get_instance identifierNumber sessionInstances=
  try
    List.assoc identifierNumber sessionInstances;
  with 
	Not_found -> get_identifier_name identifierNumber
;;
let key_of msg = match msg with
    Id(u) ->
      (
        match (get_identifier_type u) with

          | FrPcKey(i) -> (Id(i))
          | FrPeKey(i)-> (Id(i))
          | PcKey(i)  -> (Id(i))
          | PeKey(i)-> (Id(i))
          | _ -> msg       
      )
  | TableElement (tableNumber,userNumber,isPrivate) -> TableElement (tableNumber,userNumber,not isPrivate)
  | _ -> msg
;;
let rec replace_by_instance termToInstantiate instance=
    match termToInstantiate with
    Op(operator,[term]) ->Op(operator,[(replace_by_instance term instance)])
  | Op(operator,[term1;term2]) ->Op(operator,[(replace_by_instance term1 instance);(replace_by_instance term2 instance)])
  | Cons(name) ->Cons(get_instance (get_identifier_number name !Globals.ident_list) instance)
  | Var(name) ->Cons(get_instance (get_identifier_number name !Globals.ident_list) instance )
  | x ->x
;;
let rec to_term message  =
  match message with
      Pair(part1,part2) ->
      	oppair (to_term part1) (to_term part2 )
    | Crypt(3,key,cryptedMessage) ->
	opscrypt (to_term key ) (to_term cryptedMessage)
    | Crypt(_,key,cryptedMessage) ->
	opcrypt (to_term key) (to_term cryptedMessage)
    | Arith (operatorNumber,operand1,operand2) -> 
	(oparith_of_nb operatorNumber) (to_term operand1) (to_term operand2)
    | Logic (operatorNumber,operand1,operand2) ->
	(oplogic_of_nb operatorNumber)(to_term operand1) (to_term operand2)
    | Func(identifierNumber,parameter) ->
	opfunct (to_term (Id(identifierNumber))) (to_term parameter)
    | TableElement(tableNumber,tableUser,isPrivate) ->
	if not(isPrivate) 
	then opTableElement(to_term (Id(tableNumber))) (to_term (Id(tableUser)))
	else opprim (opTableElement(to_term (Id(tableNumber))) (to_term (Id(tableUser))))
    | Int(number) -> Cons(string_of_int number)
    | Id(identifierNumber) -> 
	(try
	   let identifiertype = findtype (get_identifier_name identifierNumber) !Globals.ident_list true
	   in
	     ((op_of_type identifiertype) (Var(get_identifier_name identifierNumber)))
	 with Not_found -> (Var(get_identifier_name identifierNumber)))
;;
let get_user_list messageList =
  let resultList = ref [] in
    List.iter (fun (step,((senderNumber,receiverNumber),message))->
		 if not(List.mem senderNumber (!resultList)) then resultList:=!resultList@[senderNumber];
		 if not(List.mem receiverNumber (!resultList)) then resultList:=!resultList@[receiverNumber])messageList;
!resultList
;;

(*
the next function split a string into a list of string
*)
let rec split s c = (* s = string, c = char, returns a list of strings *)
  if (not (String.contains s c)) then
    [s]
  else
    let len = String.length s in
    let fst_occurrence = String.index s c in
      if (fst_occurrence = 0 ) then
	if (len > 1) then
	  split (String.sub s 1 (len-1)) c
	else 
	  []
      else
	let fst_sub = (String.sub s 0 fst_occurrence)in
	let tail_string = (String.sub s (fst_occurrence+1) (len-(fst_occurrence+1))) in
	  if (String.length tail_string =0 ) then 
	    [fst_sub]
	  else
	    fst_sub::(split tail_string c)
;;
      


let polish_form_parser s name =
  let stack = ref ([] : term list) in
  let result = ref (Rule("",Empty,Empty)) in
  let pop () = match !stack with
      [] -> raise Not_found
    | head::tail ->
	(stack := tail;
	 head)
  in
  let pop2 () = 
    let snd = pop() in
    let fst = pop() in
      [fst;snd]
  in
(*
  let print_stack () = 
  print_newline();
  print_string "stack :\t";
  List.iter
  (fun x -> Interface.print_term x; print_string " ")
  !stack; 
  flush stdout;
  print_newline();
  in
*)
  let print_stack () = () in
  let add_stack head =
    stack := [head]@(!stack)
  in
  let make_inverse term =
    match term with
      | Op("pk",[Cons(s)]) -> 
	  let new_s = (String.concat "" [s;"'"]) in
	    Op("pk",[Cons(new_s)])
      | Op("pk",[Op("c",[Cons(s);xvar])]) ->
	  let new_s = (String.concat "" [s;"'"]) in
	    Op("pk",[Op("c",[Cons(new_s);xvar])])
      | t -> t
  in
  let token_list = split s ' ' in
    (List.iter
       (fun x ->
	  match x with
	      "=>" -> 
		print_stack ( );
		let rhs = pop() in
		let lhs = !stack in
		  if (lhs = []) then
		    result := (Rule(name,Empty,rhs))
		  else
		    result := (Rule(name,Op(".",lhs),rhs));
	    | "c" ->
	       	add_stack(Op("c",(pop2 ()) ));print_stack ();
	    | "crypt" ->
	       	add_stack(Op("crypt",pop2()));print_stack();
	    | "scrypt" ->
	       	add_stack(Op("scrypt",pop2()));print_stack();
	    | "rcrypt" ->
	       	add_stack(Op("rcrypt",pop2()));print_stack();
	    | "tb" ->
	       	add_stack(Op("tb",pop2()));print_stack();
	    | "funct" ->
	       	add_stack(Op("scrypt",pop2()));print_stack();
	    | "pk" ->
	       	add_stack(oppk (pop()));print_stack();
	    | "sk" ->
	       	add_stack(opsk (pop()));print_stack();
	    | "inv" ->
	       	add_stack(opprim (make_inverse(pop())));print_stack();
	    | "nonce" ->
	       	add_stack(opnonce (pop()));print_stack();
	    | "mr" ->
	       	add_stack(opmr (pop()));print_stack();
	    | "table" ->
	       	add_stack(optable (pop()));print_stack();
	    | "fu" ->
	       	add_stack(opfu (pop()));print_stack();
	    | "i" ->
	       	(*add_stack(opi pop()) ;*)print_stack();
	    | item -> 
	       	let res =
		  if ((String.get item 0) = 'x') then
		    let len_item = (String.length item - 1) in
		    let real_item = (String.sub item 1 len_item) in
		      Var(real_item)
		  else
		    let real_item = (String.sub item 4 (String.length item - 4)) in
		      if (real_item = "intruder") then
		      	Cons("I")
		      else 
		      	Cons(real_item)
	       	in
		  add_stack(res);print_stack();
       )
       token_list
    );
    !result
;; 


let rec constraintsResolve constraintsList =
  match constraintsList with
      [] -> true
    | (x,y)::tail ->
	(List.for_all
	   (fun (a,b) ->
	      ((not(a=x)||(b=y))&&(not(b=y)||(a=x)))
	   )
	   tail
	)&&
	(constraintsResolve tail)
;;
(*
let rec compare_term_matching term_a term_b =
  let in_set element a_set =  
   (List.map 
      (function [] -> [] | [x] -> x | _ -> []) 
      (List.map 
	 (fun x -> 
	    (compare_term_matching element x)
	 ) 
	 a_set
      )
   ) in
   let rec compare_multiset set_a set_b =
    match set_a with
	[] -> [[]]
      | head::tail ->
	  let tail_result = (compare_set tail set_b) in
	  let head_result = (in_set head set_b) in
	    List.filter 
	      (fun x -> (constraintsResolve x))
	      (list_product tail_result head_result)
   in
   let rec compare_list_term list_a list_b =
     let head_result = (compare_term_matching (List.hd list_a) (List.hd list_b)) in
     let tail_result = (compare_list_term (List.tl list_a) (List.tl list_b)) in
       (List.filter
	  (fun x -> (constraintsResolve x))
	  (list_product tail_result head_result)
       )
   in
    if (term_a = term_b) then 
      []
    else (* the � . � is commutative *)
      match term_a with
	  Op(".",term_a_arg) ->
	    begin
	      match term_b with
	      	  Op(".",term_b_arg) ->
		    (compare_set term_a_arg term_b_arg)
		| _ -> [[("1","2");("1","3")]] (* unsatisfiable constraint *)
	    end
      	| Var(x) -> 
	    begin
	      match term_b with
		  Var(y) -> [[(x,y)]]
	      	| _ -> [[("1","2");("1","3")]] (* unsatisfiable constraint *)
	    end
	| Op(cons_a,list_a) ->
	    begin
	      match term_b with
		  Op(cons_b,list_b) -> 
		    if (cons_a = cons_b) then
		      (compare_list_term list_a list_b)
		    else
		      [[("1","2");("1","3")]] (* unsatisfiable constraint *)
		| _ -> [[("1","2");("1","3")]] (* unsatisfiable constraint *)
	    end
      	| _ -> [[("1","2");("1","3")]] (* unsatisfiable constraint *)
;;
*)

let rec compare_term term_a term_b =
  let compare_term_list list_a list_b =
    List.for_all2
      (fun x y -> (compare_term x y))
      list_a
      list_b
    in
      if (term_a = term_b) then
      	true
      else
      	match term_a with
	    Op(".",list_a) -> 
	      begin
	     	match term_b with
		    Op(".",list_b) -> 
		      (
		     	List.for_all 
			 (
			   fun x ->
			     List.mem x list_b
			 )
			 list_a
		      ) &&
		      (
		     	List.for_all 
			 (
			   fun x ->
			     List.mem x list_a
			 )
			 list_b
		      )
		  | _ -> false
	      end
	  | Op(op_a,list_a) ->
	      begin
	      	match term_b with
		    Op(op_b,list_b) -> (op_a = op_b)&&( compare_term_list list_a list_b)
	      	  | _ -> false
	      end
	  | _ -> false
;;

let compare_rule rule_a rule_b =
  match rule_a with
      Rule(name_a,lhs_a,rhs_a) ->
	match rule_b with
	    Rule(name_b,lhs_b,rhs_b) ->
	      (*
	      	(List.exists (fun x -> constraintsResolve x) ((compare_term_matching lhs_a lhs_b)@(compare_term_matching rhs_a rhs_b)))
	      *)
	      (compare_term lhs_b lhs_a) &&(compare_term rhs_b rhs_a) 
;;

(*
let compare_term term_a term_b =
  (List.exists (fun x -> (constraintsResolve x)) (compare_term_matching term_a term_b))
;;
*)
(*
  to use this function, one needs a compare : 'a -> 'a -> bool function
*)

let rec remove_double_occurrences comparison_function a_list =
  let rec remove_all_occurrences comparison_function term tail_list =
    match tail_list with
	[] -> []
      | head::tail ->
	  if (comparison_function head term) then
	    (remove_all_occurrences comparison_function term tail)
	  else
	    [head]@(remove_all_occurrences comparison_function term tail)
  in
    match a_list with
	[] -> []
      | head::tail ->
	  [head]@(remove_double_occurrences comparison_function (remove_all_occurrences comparison_function head tail))
;;

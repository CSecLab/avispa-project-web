(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(***********************************************************************)
(* handling the --goal command ligne option *)
open Types;;
open Globals;;
open Utilities;;

let rec check_secret_sharing userList = match userList with
    [] -> true
    | head::tail ->
	let finalUserKnowledge= (List.assoc (!Globals.nbMsgs) (Utilities.compute_know_of_user (fst head) !Globals.nbMsgs))in
	  if(List.exists(fun knownIdentifier -> (fst knownIdentifier = (Id (!Globals.secret_goal)))) finalUserKnowledge)
	  then
 	    false
	  else
	    (check_secret_sharing tail)
;;
let not_has_role_of_principal_sharing_N sessionInstances =
  let usersFilter= (fun  instanceCouple -> match  instanceCouple with 
			(_,"I") -> true
		      | _ -> false) 
  in
  let intruderRoles = List.find_all usersFilter sessionInstances in
    check_secret_sharing intruderRoles
;;
let principal_is_defined userNumber instance_couple =
  match instance_couple with
       	(identifierNumber,instance) -> (identifierNumber == userNumber)
;;
let honest_principal userNumber instanceList=
  ((List.assoc userNumber instanceList) <> "I") 
;;
let build_goal_term termOrder userNumber sessionInstances =
  let userName =  (List.assoc userNumber sessionInstances) in
  let step = (Utilities.firstS userNumber) -1 in
    if (honest_principal userNumber  sessionInstances) then 
      Utilities.opw ( (* we use userName to insure term unicity *)
	Cons(string_of_int step)) (* step *)
	(Var("1"^(!underscore)^userName)) (* sender *)
	(Utilities.opmr(Cons(userName))) (* receiver *)
	(Var("l1"^(!underscore)^userName)) (* AcqKnowledge *)
	(Var("etc1"^(!underscore)^userName)) (* InitialKnowledge *)
	(Var("T1"^(!underscore)^userName)) (* boolean *)
	(if (termOrder=1) then (Var("c")) else ops(Var("c"))) (* session *)
    else
      raise Not_found
;;
let build_goal () =
  let goalRules = ref ([] : rule list) in
  let sessionCounter = ref 0 in
    (
      match !Globals.goal_type with
	  1 -> (* correspondence goal *)
	    (List.iter (fun sessionInstances ->
			  let firstUserNumber = (fst !Globals.correspondence_goal) and secondUserNumber = (snd !correspondence_goal) in
			    incr sessionCounter;
			    if ((List.exists (principal_is_defined firstUserNumber) sessionInstances)&&(List.exists (principal_is_defined secondUserNumber) sessionInstances)) then 
			      try
				goalRules := 
				[
				  Rule(
				    "# lb=Correspondence_Goal_"^(string_of_int !sessionCounter)^(!underscore)^(List.assoc firstUserNumber sessionInstances)^(!underscore)^(List.assoc secondUserNumber sessionInstances)^", type=Goal",
				    (Op(".",[build_goal_term 1 firstUserNumber sessionInstances;
					     build_goal_term 2 secondUserNumber sessionInstances])),
				     Empty
				   )
				   ;
				   Rule(
				       "# lb=Correspondence_Goal_"^(string_of_int !sessionCounter)^(!underscore)^(List.assoc secondUserNumber sessionInstances)^(!underscore)^(List.assoc firstUserNumber sessionInstances)^", type=Goal", 
				       (Op(".",[build_goal_term 2 firstUserNumber sessionInstances;
					    	build_goal_term 1 secondUserNumber sessionInstances ])),
				       Empty
				   )
				]
				@(!goalRules)
			      with
				  Not_found -> ()
			    else 
			      if (List.exists (principal_is_defined firstUserNumber) sessionInstances) then
				try
				  goalRules := 
				  [
				    Rule(
					 "# lb=Correspondence_Goal_"^(string_of_int !sessionCounter)^(!underscore)^(List.assoc firstUserNumber sessionInstances)^", type=Goal", 
					 (build_goal_term 2 firstUserNumber sessionInstances),(* todo *)
					 Empty
				    )
				     ]
				  @(!goalRules)
				with
				    Not_found -> ()
			      else
				if (List.exists (principal_is_defined secondUserNumber) sessionInstances) then
				  try
				       goalRules := 
				       [
					 Rule(
					   "# lb=Correspondence_Goal_"^(string_of_int !sessionCounter)^(!underscore)^(List.assoc secondUserNumber sessionInstances)^", type=Goal",
					   (build_goal_term 2 secondUserNumber sessionInstances),(* to do *)
					   Empty
					 )
				       ]
				       @(!goalRules)
				     with
					 Not_found -> ();
		       ) 
	       !Globals.session_instances
	    )
      	| _ -> (* secrecy attack *)
	    let counter = ref 1 in
	      List.iter
		( 
		  fun session -> 
	     	    (
		      if (not_has_role_of_principal_sharing_N session) then
			begin
			  goalRules := 
			  (
			    Rule(
			      "# lb=Secrecy_Goal"^(!underscore)^string_of_int(!counter)^", type=Goal",
			      (Op(".",[Utilities.opi(Var("secret"));Utilities.opsecret (Var("secret")) (Utilities.opf(Cons(string_of_int !counter)))])),
			      Empty
			    )	
			  )
			  ::!goalRules
			end;
		      incr counter;
		    )
		)!Globals.session_instances;
    );
    !goalRules
;;

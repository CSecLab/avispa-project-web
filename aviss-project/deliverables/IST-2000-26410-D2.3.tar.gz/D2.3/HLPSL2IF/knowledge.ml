(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* Module for the management of user's knowledge *)

open Types;;
open Globals;;
open Utilities;;


(*
This function is used to check for atomic knowledge
*)
let in_knowledge m  knowledge_list = (List.mem_assoc m knowledge_list);;


(*
This function recursively checks for the composition of a message
*)
let rec can_be_composed l mesg = 
  ((in_knowledge mesg l) or
   (
     match mesg with
	 Pair(part1,part2) ->
      	   ((can_be_composed l part1) && (can_be_composed l part2))
       | Crypt(3,key,cryptedMessage) ->
	   ((can_be_composed l key ) && (can_be_composed l cryptedMessage))
       | Crypt(_,key,cryptedMessage) ->
	   ((can_be_composed l key) && (can_be_composed l cryptedMessage))
       | Arith (operatorNumber,operand1,operand2) -> 
	   ((can_be_composed l operand1) && (can_be_composed l operand2))
       | Logic (operatorNumber,operand1,operand2) ->
	   ((can_be_composed l operand1) && (can_be_composed l operand2))
       | Func(identifierNumber,parameter) ->
	   ((can_be_composed l (Id(identifierNumber))) && (can_be_composed l parameter))
       | Int(number) -> true
       | Id(identifierNumber) -> false 
   ))
;;

(*
iteration using can_be_composed over the list of knowledge
*)

let rec infers_for_know l =
  let previous_step = ref ([]:(msg * bool) list) in
  let current_step = ref l in
  let has_changed = ref true in
    while (!has_changed) do
      previous_step := !current_step;
      has_changed := false;
      current_step := ([]:(msg * bool) list);
      let insert list_of_msg = 
	(List.iter (fun m -> current_step := (m,false)::!current_step) list_of_msg)
      in
      let can_compose = (can_be_composed !previous_step) in
     	List.iter 
	  (
	    fun (message,was_decomposed) ->
	     if (not was_decomposed) then
	       match message with
		   Pair(part1,part2) ->
      		     (
		       insert [part1;part2];
		       has_changed := true
		     )
		 | Crypt(3,key,cryptedMessage) ->
		     if (can_compose key) then
		       (
			 insert [cryptedMessage];
			 has_changed := true
		       )
		     else
		       current_step := (message,false)::!current_step
		 | Crypt(_,key,cryptedMessage) ->
		     if (can_compose (key_of key)) then
		       if (can_compose key) then
			 (
			   insert [cryptedMessage];
			   has_changed := true
			 )
		       else
			 (
			   insert [cryptedMessage];
			   has_changed := true ;
			   current_step := (message,true)::!current_step
			 )
		     else
		       current_step := (message,false)::!current_step
		 | Arith (operatorNumber,operand1,operand2) -> 
		     if ((can_compose operand1)or(can_compose operand2)) then
		       (
			 insert [operand1;operand2];
			 has_changed := true
		       )
		     else
		       current_step := (message,false)::!current_step
		 | Logic (operatorNumber,operand1,operand2) ->
		     if ((can_compose operand1)or(can_compose operand2)) then
		       (
			 insert [operand1;operand2];
			 has_changed := true
		       )
		     else
		       current_step := (message,false)::!current_step
		 | Func(identifierNumber,parameter) ->
		     current_step := (message,true)::!current_step
		 | Int(number) -> 
		     current_step := (message,true)::!current_step			       
		 | Id(identifierNumber) ->
 		     current_step := (message,true)::!current_step
	     else
	       current_step := (message,true)::!current_step
	  )
	  !previous_step;
    done;
    !current_step
	       ;;


(*
iteration over the step to find knowledge at step i
*)

let rec compute_know_of_user u step =
  match step with
      0 -> 
	(try( [
		(0,
		 infers_for_know (( List.map (fun x -> (Id(x),true)) (List.assoc u !Globals.ident_knowledge) )@ ( List.map (fun x ->(x,false)) (List.assoc u !Globals.init_msg_knowledge) ))) ])
	with not_found->
	  [(0,( List.map (fun x -> (Id(x),true)) (List.assoc u !Globals.ident_knowledge)))])
    | i -> 
	let previous_knowledge = compute_know_of_user u (i-1) in
	let last_knowledge = ref (List.assoc (i-1) previous_knowledge) in
      	let ((se,re),msg) = List.assoc i !Globals.msg_list in
	  
	(*
	  add_if_unknown : add msg in last_knowledge if it doesn't already exists
	*)
	let add_if_unknown mesg bool_val =
	  if not (can_be_composed !last_knowledge mesg ) then last_knowledge := (mesg,bool_val)::!last_knowledge
	in
	  if u = re then
	    (add_if_unknown (Id(se)) false;
	       add_if_unknown msg false)
	  else 
	    if u = se then
	      List.iter 
		(fun i -> add_if_unknown (Id(i)) true)
        	(add_keys (fresh_var i));
	  (i, infers_for_know (!last_knowledge))::previous_knowledge
;;

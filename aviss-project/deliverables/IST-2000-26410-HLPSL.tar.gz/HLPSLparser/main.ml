(***********************************************************************)
(*                                                                     *)
(*                                 HLPSL                               *)
(*                                                                     *)
(*                     AVISS Project IST 2000-26410                    *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                                main.ml                              *)
(*                                 Loria                               *)
(*                             main program                            *)
(***********************************************************************)
open Rules;;
open Interface;;
open Globals;;
(* ----------------
   main : unit -> unit
   Input:
   Output:
   Role:
   Use:
   Rem:
   ---------------- *)
let main () =
  let filename      = ref "" in
  let path          = ref "" in
     (Arg.parse 
	 [("--intruder",Arg.Set(flag_intru)," (print intruder rules)");
	  ("--rules",Arg.Set(flag_rules),"    (print protocol rules)");
	  ("--init",Arg.Set(flag_init),"     (print initial state)");
	  ("--goal",Arg.Set(flag_goal),"     (print goal)");
	  ("--ident",Arg.Set(flag_ident),"    (print identifiers list)");
	  ("--simplif",Arg.Set(flag_simplif),"  (print simplification rules)");
	  ("--para",Arg.Set(flag_para),"  (print parallel rules)");
	  ("--knowledge",Arg.Set(flag_knowledge),"  (print knowledge of users at different protocol steps)");
	  ("--all",Arg.Set(flag_all),"      (print everything)");
	  ("-l",Arg.String(fun s -> (path := s)),"path     (path for the input file)")
	 ]
	 (fun s -> (filename := s))
	 "Usage: casrul [options] [file]\n Options:");
    (* Parsing of the input and error handling *)
    let file = ((!path)^(!filename)) in
    let channel = 
      if (file = "")
      then stdin
      else 
      	try (open_in file) 
      	with Sys_error(f) -> (
	  print_endline ("Error :"^f);
	  exit(-1)
      	)  in  
     let parse = call_parser channel in    
     if (parse <> 0)
      then  exit 0;
      comp_fresh();
      compute_know();
      check_proto();
      if ((not !flag_intru) && (not !flag_rules) && (not !flag_init) && (not !flag_goal) && (not !flag_ident)&&(not !flag_para)&&(not !flag_ident)&&(not !flag_knowledge))
      then 
      	begin

	  (* Print a protocol summary *)
    	  print_newline ();
    	  print_endline "# Knowledge:";
    	  print_ident_knowledge ();
    	  print_newline ();  
    	  print_endline "# List of messages:";
    	  print_msglist ();
    	  print_newline ();
	  if (parse = 0) then print_endline "### This protocol is correct ! ###";
      	end;

;;    
main();;

%:- use_module(library(lists)).
:- use_module(library(system)).
:- use_module(library(charsio)).

% :- ensure_loaded(newlists).
% :- ensure_loaded(newload).
% :- ensure_loaded(state).
% :- ensure_loaded(output).

% :- ensure_loaded(encoding).
% %:- ensure_loaded('encoding-1.2.pl').
% %:- ensure_loaded('encoding-1.1.pl').

% :- ensure_loaded(solver).
% :- ensure_loaded('../config.pl').

sate(Problem) :-
	set(problem,Problem),
	load_problem,
	initialise_system_state,
	sate.

sate_axioms(Problem) :-
	set(problem,Problem),
	load_problem,
	initialise_system_state,
	axioms2sat,
	print_statistics_axioms_end,
	% Added
	print_hash_table,
	solve,!.

sate(Problem,Encoding,TermDepthBound,Steps,Solver) :-
	load_problem,
	set(problem,Problem),
	set(encoding,Encoding),
	set(term_depth_bound,TermDepthBound),
	set(steps,Steps),
	set(solver,Solver),
	initialise_system_state,
	sate.

sate :-
	print_statistics_axioms_heading,
	value(encoding,AxTypes),
	axioms(initial_fact),
	axioms(goal),
	axioms(AxTypes),
	print_statistics_axioms_end,
	retract_encoder_initialization,
	axioms2sat,
	print_statistics_axioms2sat_end,
	% Added
	print_hash_table,
	!,
	solve,!.

%-----------------------------------------------------------------------
%        BEGIN: MODEL INCREMENTALITY HANDLING
%

find_another_plan :-
	value(dimacs,on),
	assert_previous_attacks_negated,
	solve_new_attack,
	reset_extra_clause_counter,
	!.	

solve_new_attack :-
	( value(dimacs,on) ->
	    file_name(dimacs_previous_attack,FN_DIMACS_ATTACK),	
	    tell(FN_DIMACS_ATTACK),
	    print_extra_clauses,
	    told,
	    file_name(dimacs_header,FN_DIMACS_HEADER),
	    tell(FN_DIMACS_HEADER),
	    value(curnum,N),
	    N1 is N-1,
%	    value(clause_counter,C),
	    get_total_axioms_clauses_number(TmpC),
	    value(extra_clause_counter,EXTC),
	    C is TmpC + EXTC,
	    format(user_output,'\nNumber of Atoms: \t~w',[N1]),
	    format(user_output,'\nNumber of Clauses: \t~w\n',[C]),
	    print_dimacs_header(N1,C),
	    told,
	    value(encoding,Encoding),
	    findall(FN,
		    (
		      member(AxType,[initial_fact,goal|Encoding]),
		      atom_concat(AxType,'.dimacs_clauses',POST),
		      file_name(POST,FN)
		    ),
		    FNs
		   ),
    	    file_name(dimacs,FN_DIMACS),
	    concat_files([FN_DIMACS_HEADER,FN_DIMACS_ATTACK|FNs],FN_DIMACS),
%	    file_name(dimacs_clauses,FN_DIMACS_CLAUSES),
%	    concat_files(FN_DIMACS_HEADER,FN_DIMACS_CLAUSES,FN_DIMACS),
	    delete_file(FN_DIMACS_HEADER,[ignore]),
%	    delete_file(FN_DIMACS_CLAUSES,[ignore]),
	    file_name(log,LOGFILE),
	    delete_file(LOGFILE,[ignore]),
	    solve(FN_DIMACS,LOGFILE),
	    print_output
	;
	    findall(FN,
		    (
		      member(AxType,[initial_fact,goal|Encoding]),
		      atom_concat(AxType,'.clauses',POST),
		      file_name(POST,FN)
		    ),
		    FNs
		   ),
    	    file_name(clauses,FN_CLAUSES),
	    concat_files(FNs,FN_CLAUSES)
	).

assert_previous_attacks_negated :-
	parse_log(Ans,_),
	( Ans=unsat ->
	    format('\nNo previous plan found\n\n',[])
	;
	    assert_previous_attacks_negated(Ans)
	).

assert_previous_attacks_negated([]).
assert_previous_attacks_negated([Ns|Ms]) :-
	assert_previous_attack_negated(Ns),
	assert_previous_attacks_negated(Ms).

assert_previous_attack_negated(Ns) :-
	value(steps,Steps),
	setof(~(I:A),
	      N^I^(member(N,Ns),atomof(N,I:A),predicate(action,A),value(time,I),I<Steps),
	      Att),
	assert(value(extra_clause,Att)).

print_extra_clauses :-
	value(extra_clause,C),
	print_clause(C),
	increment_extra_clause_counter,
	retract(value(clause_counter,New)),
	Old is New - 1,
	assert(value(clause_counter,Old)),
	fail.
print_extra_clauses.

% add_previous_attack_negated(Ns) :-
% 	value(steps,Steps),
% 	setof(N,
% 	      A^I^(member(N,Ns),atomof(N,I:A),predicate(action,A),value(time,I),I<Steps),
% 	      ANs),
% 	conjunction_list2dimacs_clause(ANs,C),
% 	file_name(dimacs_previous_attack,FN_DIMACS_ATTACK),	
% 	tell(FN_DIMACS_ATTACK),
% 	format('~w\n',[C]),
% 	told,
% 	file_name(dimacs,FN_DIMACS),
% 	format_to_chars("cat ~w >> ~w",[FN_DIMACS_ATTACK,FN_DIMACS],CHARS),	
% 	atom_chars(CMD,CHARS),
% 	system(CMD,_).

collect_conjunts_list([A],A) :- !.
collect_conjunts_list([A|As],A & Rest) :-
	collect_conjunts_list(As,Rest).
	
conjunction_list2dimacs_clause(As,C) :-
	conjunction_list2dimacs_clause(As,'0',C).
conjunction_list2dimacs_clause([],C,C).
%	format_to_chars("~w 0\n",[PrevC],CHARS),
%	atom_chars(C,CHARS).
conjunction_list2dimacs_clause([A|As],PrevC,C) :-
	format_to_chars("-~w ~w",[A,PrevC],CHARS),
	atom_chars(CurrC,CHARS),
	conjunction_list2dimacs_clause(As,CurrC,C).
	
change_goals(Gs) :-
	retractall_sate_declarations,
	value(problem,Problem),
	value(problems_dir,ProblemsDir),
	format_to_chars('~w/~w.sate',[ProblemsDir,Problem],CHARS),
	atom_codes(FN,CHARS),
	% Read and assert each row of the file
	load_problems_file(FN),
	% Retract the old goals
	retractall(goal(_,_)),
	% Assert the new goals
	assert_sate_declaration_list(Gs),	
	check_problem,
	% Reset counter old values
	reset_statistics, 
	reset_clause_counter,
	retract_axioms_clauses_number(goal),
	reset_timer, % Steps
	retractall(value(goal_instance,_)), % Reset of the analyzed goal instances
	retractall(value(goal_disjunct,_)),		
	format(user_output,"\nSTATISTICS (GOAL AXIOMS GENERATION)\tRUNTIME(sec)\n",[]),
	axioms(goal),
	format(user_output,"\nSTATISTICS (GOAL AXIOM TRANSLATION)\tCLAUSES\tRUNTIME(sec)\n",[]),
	axioms2sat(goal),
	format(user_output,"\n\nWould you like to solve with the new goals ? ['yes.' or 'no.']\n\n",[]), 
	read(user_input,ANSWER),
	(ANSWER = yes ->
	    solve,!
	;
	    true
	).

% [LC]: Improve this, e.g. if the previous steps number is
%       lesser, then build and add the new parts..
%       Moreover we don't have to regenerate the initial_fact
%       file.
change_steps(N) :-
% 	retractall_sate_declarations,
% 	value(problem,Problem),
% 	value(problems_dir,ProblemsDir),
% 	format_to_chars('~w/~w.sate',[ProblemsDir,Problem],CHARS),
% 	atom_codes(FN,CHARS),
% 	% Read and assert each row of the file
% 	load_problems_file(FN),
	% Reset counter old values
	reset_statistics, 
	reset_clause_counter,
	reset_extra_clause_counter,
	value(encoding,Encoding),
	retract_axioms_clauses_numbers([initial_fact,goal|Encoding]),
	retractall(value(goal_instance,_)), % Reset of the analyzed goal instances
	retractall(value(goal_disjunct,_)),	
	reset_atom_db, % Reset hash table and numof
	set(steps,N),
	reset_timer, % Steps
% 	format(user_output,"\nSTATISTICS (GOAL AXIOMS GENERATION)\tRUNTIME(sec)\n",[]),
% 	axioms(goal),
	axioms2sat,
	get_total_axioms_translation_time(TransTime),
	SecTransTime is TransTime/1000,
	format(user_output,"\t\t\t\t\t------\n",[]),	
	format(user_output,"Total:\t\t\t\t\t~w\n",[SecTransTime]),
	% Added
	print_hash_table,
	format(user_output,"\n\nWould you like to solve with the new steps number ? ['yes.' or 'no.']\n\n",[]), 	
	read(user_input,ANSWER),	    
	(ANSWER = yes ->
	    solve,!
	;
	    true
	).

%
%          END: MODEL INCREMENTALITY HANDLING
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: AXIOMS HANDLING
%

axioms([]).
axioms([AxType|AxTypes]) :-
	axioms(AxType),
	axioms(AxTypes).

axioms(AxType) :-
	\+is_list(AxType),
	open_output_file_axioms(AxType),
	statistics(runtime,_),
	print_encoding_axioms(AxType),
	statistics(runtime,[_,RT]),
	assert_encoding_time(AxType,RT),	
	close_output_file_axioms(AxType),
	print_statistics_axioms(AxType).

%
%          END: AXIOMS HANDLING
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: ENCODING TIME HANDLING
%

assert_encoding_time(AxType,Time) :-
	atom_concat(AxType,'_encoding_time',STR),
	retractall(value(STR,_)),
	assert(value(STR,Time)).

assert_axioms_translation_time(AxType,Time) :-
	atom_concat(AxType,'_axioms_translation',STR),
	retractall(value(STR,_)),
	assert(value(STR,Time)).

get_total_encoding_time(TotTime) :-
	value(encoding,Encoding),
	findall(T,
		(
		  member(AxType,[initial_fact,goal|Encoding]),
		  get_encoding_time(AxType,T)
		),
		Ts),
	sum_list(Ts,TotTime).

get_encoding_time(AxType,Time) :-
	atom_concat(AxType,'_encoding_time',STR),
	value(STR,Time).

get_axioms_translation_time(AxType,Time) :-
	atom_concat(AxType,'_axioms_translation',STR),
	value(STR,Time).

get_total_axioms_translation_time(TotTime) :-
	value(encoding,Encoding),
	findall(T,
		(
		  member(AxType,[initial_fact,goal|Encoding]),
		  get_axioms_translation_time(AxType,T)
		),
		Ts),
	sum_list(Ts,TotTime).

%
%          END: ENCODING TIME HANDLING
%-----------------------------------------------------------------------

% sate :-
% 	open_output_file,
% 	write(user_output,'\nSTATISTICS\t\t\tCLAUSES\tRUNTIME(sec)\n'),
% 	print_encoding,
% 	close_output_file,
% 	% Added
% 	print_hash_table,
% 	solve.

initialise_system_state :-
	told,
	reset_timer,
	reset_extra_clause_counter,
	retractall(value(extra_clause,_)),
	retractall(value(attacks_number,_)),
	set(attacks_number,0),
	reset_clause_counter,
	reset_atom_db,
	reset_statistics.

load_problem :-
	value(problem,Problem),
	value(problems_dir,ProblemsDir),
	format_to_chars('~w/~w.sate',[ProblemsDir,Problem],CHARS),
	atom_codes(FN,CHARS),
	% Read and assert each row of the file
	load_problems_file(FN),
%	ensure_loaded(FN),
	check_problem.

% CHANGED: Introduced the possibility to have formulas in the initial
%          states and in the goals
% % BEFORE:
% check_problem :-
% 	facts(Fs),
% 	fluents(Fs,[]),
% 	goal(Gs),
% 	fluents(Gs,[]).
% fluents -->
% 	[P],
% 	{(predicate(fluent,P) ->
% 	  true;
% 	  format('Syntax error in ~w\n',[P]), fail )},
% 	fluents.

% [LC]: it is just a syntactical check.We should make a
%       language check then we should check with
%                predicate(fluent,F)
%       each fluent in the initial state and in the goal
% NOW
check_problem :-
	facts(Fs),
	wff_over_fluents(Fs,[]).
%       % [LC]: since the goals can contain variables 
%               then the check is meaningless  problems 
% 	goal(_,Gs),
% 	wff_over_fluents(Gs,[]).

wff_over_fluents -->
	[WFF],
	{
	 get_fluents(WFF,Fs),
	 fluents(Fs,[])
	},
	wff_over_fluents.
wff_over_fluents --> [].
fluents -->
	[P],
	{(predicate(fluent,P) ->
	  true
	 ;
%	  format('Syntax error in ~w\n',[P]), fail )},
  	  format('May be a syntax error in ~w\n',[P])
	 )},
	fluents.
fluents --> [].

% Open and close the axiom file about AxType
open_output_file_axioms(AxType) :-
	file_name_axioms(AxType,FN_AXIOMS),
	tell(FN_AXIOMS).
close_output_file_axioms(_) :- told. 

open_input_file_axioms(AxType) :-
	file_name_axioms(AxType,FN_AXIOMS),
	see(FN_AXIOMS).
close_input_file_axioms(_) :- seen. 

open_output_file(AxType) :-
	( value(dimacs,on) ->
	    atom_concat(AxType,'.dimacs_clauses',POST),
	    file_name(POST,FN_DIMACS_CLAUSES),
	    tell(FN_DIMACS_CLAUSES)
	;
	    atom_concat(AxType,'.clauses',POST),	    
	    file_name(POST,FN_DIMACS_CLAUSES),
	    tell(FN_DIMACS_CLAUSES)
	).
close_output_file(_) :- told. 

% Open and close the SAT file
open_output_file :-
	( value(dimacs,on) ->
	    file_name(dimacs_clauses,FN_DIMACS_CLAUSES),
	    tell(FN_DIMACS_CLAUSES) ;
	    file_name(clauses,FN_DIMACS_CLAUSES),
	    tell(FN_DIMACS_CLAUSES)
	).
close_output_file :- told. 

% Solve the SAT file
solve :-
	( value(dimacs,on) ->
	    file_name(dimacs_header,FN_DIMACS_HEADER),
	    tell(FN_DIMACS_HEADER),
	    value(curnum,N),
	    N1 is N-1,
%	    value(clause_counter,C),
	    get_total_axioms_clauses_number(C),
	    print_atoms_number(N1),
	    print_clauses_number(C),	    	    
	    print_dimacs_header(N1,C),
	    told,
	    value(encoding,Encoding),
	    findall(FN,
		    (
		      member(AxType,[initial_fact,goal|Encoding]),
		      atom_concat(AxType,'.dimacs_clauses',POST),
		      file_name(POST,FN)
		    ),
		    FNs
		   ),
    	    file_name(dimacs,FN_DIMACS),
	    concat_files([FN_DIMACS_HEADER|FNs],FN_DIMACS),
%	    file_name(dimacs_clauses,FN_DIMACS_CLAUSES),
%	    concat_files(FN_DIMACS_HEADER,FN_DIMACS_CLAUSES,FN_DIMACS),
	    delete_file(FN_DIMACS_HEADER,[ignore]),
%	    delete_file(FN_DIMACS_CLAUSES,[ignore]),
	    file_name(log,LOGFILE),
	    delete_file(LOGFILE,[ignore]),
	    solve(FN_DIMACS,LOGFILE),
	    print_output
	;
	    findall(FN,
		    (
		      member(AxType,[initial_fact,goal|Encoding]),
		      atom_concat(AxType,'.clauses',POST),
		      file_name(POST,FN)
		    ),
		    FNs
		   ),
    	    file_name(clauses,FN_CLAUSES),
	    concat_files(FNs,FN_CLAUSES)
	).

solve(FN_DIMACS,LOGFILE) :-
	value(solver,Solver),
	solver_invocation_command(Solver,FN_DIMACS,LOGFILE,CHARS),
	atom_codes(CMD,CHARS),
	system(CMD,_).

% Print the hash table containing the relation between ground instances
% of fluents and actions with the appropriate propositional variables
% (integer numbers)
print_hash_table :-
	( value(hash_table,on) ->
	    file_name(hash,FN_HASH_TABLE),
	    tell(FN_HASH_TABLE),
	    print_hash_table_entries,
	    told,!
	    ;
	    true
	).

print_hash_table_entries :-
	numof(T,N),
	format("numof(~w,~w).\n",[T,N]),
	false.
print_hash_table_entries.

% Build the file name for the axioms files
file_name_axioms(Post,FN) :-
	value(problems_dir,ProblemsDir),
	value(problem,Problem),
	format_to_chars('~w/~w-axioms.~w',
			[ProblemsDir,Problem,Post],CHARS),
	atom_codes(FN,CHARS).

% Build the file name for the SAT files
file_name(Post,FN) :-
	value(problems_dir,ProblemsDir),
	value(problem,Problem),
	value(encoding,Encoding),
	value(steps,Steps),
	value(solver,Solver),
	format_to_chars('~w/~w-~w-~w-~w.~w',
			[ProblemsDir,Problem,Encoding,Steps,Solver,Post],CHARS),
	atom_codes(FN,CHARS).

concat_files(Fs,F_OUT) :-
	make_concat_files_command(Fs,F_OUT,CMD),
	system(CMD).
		
concat_files(F1,F2,F3) :-
	format_to_chars('cat ~w ~w > ~w',[F1,F2,F3],CHARS),
	atom_codes(CMD,CHARS),	
	system(CMD).

make_concat_files_command(Fs,F_OUT,CMD) :-
	make_concat_files_command1(Fs,F_OUT,'cat',CMD).
make_concat_files_command1([],F_OUT,TmpCMD,CMD) :-
	format_to_chars('~w > ~w',[TmpCMD,F_OUT],CHARS),
	atom_codes(CMD,CHARS).
make_concat_files_command1([F|Fs],F_OUT,TmpCMD,CMD) :-
	format_to_chars('~w ~w',[TmpCMD,F],CHARS),
	atom_codes(NewCMD,CHARS),
	make_concat_files_command1(Fs,F_OUT,NewCMD,CMD).
	
reset_timer :-
	value(steps,Steps),
	retractall(value(time,_)),
	set_timer(Steps).

set_timer(N) :- N<0, !.
set_timer(N) :-
	asserta(value(time,N)),
	N1 is N-1,
	set_timer(N1).

% SATE DECLARATION HANDLING
assert_sate_declaration_list([]).
assert_sate_declaration_list([D|Ds]) :-
	assert(D),
	assert_sate_declaration_list(Ds).



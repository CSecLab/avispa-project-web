--- remoulade sauce intruder
--- REduced MOnadic LAzy intruder
module Remola where
import Monad
import Stddef
import Data
--- import If2ofmc

keepwitness = False

---------------------

gencheck :: Rho -> Possibilities
--- evaluate constraints of the form <term> from <intruder-knowledge>
--- to normal form, i.e. <vars> from <intruder-knowledge>

gencheck = 
 foldl 
  (\ rhosublist constraint ->
   flatten 
    (map 
     (\ (rho,sub) -> 
      let sigma = substitute sub in
      gencheck0 ((\ (x,y) -> (map sigma x,map sigma y)) constraint) rho sub)
     rhosublist))
  [([],[])]

gencheck0 :: Constraint -> Rho -> Substitution -> Possibilities

gencheck0 (terms,ik) rho sub = 
 --- eleminate trivial constraint " [] from ik "
 case terms of 
 [] -> [(rho,sub)] 
 _  ->
  --- don't process (uninstantiated) vars as in " x from ik "
  let (varterms,composeds) = split isTypedVar terms in 
  case composeds of 
  [] -> [(rho++[(terms,ik)],sub)] --- only vars: nothing to do
  _ -> 
   --- forget about all items that are in intruder knowledge
   let composeds' = filter (\x -> not (mem x ik)) composeds in 
   case composeds' of
   [] -> 
    case varterms of 
    [] -> [(rho,sub)]
    _  -> [(rho++[(varterms,ik)],sub)]
   _ ->
    --- now look at first composed term not (directly) in ik
    let t = head composeds'
        --- is there a unifier with any item in ik?
        substlist = flattenOpts (map (unify t) ik)
	unif_possibilities = 
         flatten 
	 (map (\ sub' -> 
	         gencheck0 (map (substitute sub') 
				(varterms++(tail composeds')),ik)
			   rho (sub'++sub))
	      substlist)
        --- can the term be composed from ik?
	comp_possibilities =
	  (case t of
	   C m1 m2 -> 
	    gencheck0 (m1:m2:(varterms++(tail composeds')),ik) rho sub
	   Crypt m1 m2 -> 
	    gencheck0 (m1:m2:(varterms++(tail composeds')),ik) rho sub
	    --- enter other operators here later
	   Scrypt m1 m2 ->
	    gencheck0 (m1:m2:(varterms++(tail composeds')),ik) rho sub
	   Tb m1 m2 ->
	    gencheck0 (m1:m2:(varterms++(tail composeds')),ik) rho sub
	   --- don't need handling Tb'!
	   Funct m1 m2 -> 
	    gencheck0 (m1:m2:(varterms++(tail composeds')),ik) rho sub
	   Rcrypt m1 m2 ->
	    gencheck0 (m1:m2:(varterms++(tail composeds')),ik) rho sub
	   _ -> [])
    in unif_possibilities ++ comp_possibilities

{- Examples/Tests 

gencheck0 ([Crypt (Atom (Pk "kb")) (C (Var 17) (Atom (Other "a")))],[Atom (Other "a"), Atom (Pk "kb")]) [] []
---> [([([Var 17],[Atom (Other "a"),Atom (Pk "kb")])],[])]

 
gencheck0 ([Crypt (Atom (Pk "kb")) (C (Var 17) (Atom (Other "a")))], [Atom (Other "a"), Atom (Pk "kb"),(Crypt (Atom (Pk "kb")) (C (Atom (Other "Na")) (Atom (Other "a")))) ]) [] []

---> [([],[(17,Atom (Other "Na"))]),([([Var 17],[Atom (Other "a"),Atom (Pk "kb"),Crypt (Atom (Pk "kb")) (C (Atom (Other "Na")) (Atom (Other "a")))])],[])]


gencheck0 ([Atom (Other "Na")],[Atom (Other "a"), Atom (Pk "kb"),(Crypt (Atom (Pk "kb")) (C (Atom (Other "Na")) (Atom (Other "a"))))]) [] []
---> []

-}

-----------------------------

analz :: Rho -> [Msg] -> [(Rho,Substitution,[Msg])]
--- Given rho and current intruder knowledge, compute new knowledge.

analz rho ik =
 map (\ (r,s,_,_,res) -> (r,s,mkset res)) (analz0 (rho,[],ik,[],[]))

analz0 ::     (Rho,Substitution,[Msg],[Msg],[Msg]) 
	  -> [(Rho,Substitution,[Msg],[Msg],[Msg])]
--- meaning of the three msg-lists:
--- 1. the not yet processed items
--- 2. encrypted messages for which we haven't (yet) found the key
--- 3. results (no further analysis possible)
--- behave as described in yannick/laurent's paper

getik :: Vartype -> Rho -> [Msg]
getik v [] = error ((show v)++" not found")
getik v ((w,ik):iks) = if (mem (Var v) w) then ik 
		       else getik v iks

analz0 (rho,sub,[],test,azed) =
 let loop [] = (False,[(rho,sub,[],[],azed)])
     {- a new case... -}
     loop ((Crypt t1 (Var v)):test') =
      let ps = gencheck (substitute_rho [(v,Crypt (inv t1) (Var (-v)))] rho) in
      --- if t1==(Pk' (Atom "ka")) then error ("kall"++(show rho)++" "++(show t1)++" "++(show ps))	
      --- else 
      if ps==[] then loop test'
      else (True,(map (\ (r,s) -> 
			 let s' = (s++[(v,Crypt (inv t1) (Var (-v)))])
			     sub = substitute s' in
			 (r,s',[sub (Var (-v))], map sub test', map sub azed)) ps))
     loop ((Crypt t1 t2):test') = 
      case t1 of
      Var x -> 
       let ps = gencheck (substitute_rho [(x,Pk (C (Atom "ni") (Atom "ni")))] 
					 rho) 
       in if ps==[] then loop test'
	  else (True,(map (\ (r,s) -> 
			     let s2 = s++[(x,Pk (C (Atom "ni") (Atom "ni")))]
				 s' = substitute s2
			     in (r,s2,[s' t2],map s' test',map s' azed)) ps))
      (Crypt _ _) -> --- this can't work!!!
        loop test'
      --- (Tb l i) -> error ("here is "++(show i))
      exp -> --- error (show t1 ) ---- ((Crypt t1 t2):test')) 
       let ps = gencheck (([inv t1],azed):rho) in 
       if (ps==[]) then loop test'
       else (True,(map (\ (r,s) ->
		        let sub = substitute s in
		        (r,s,[sub t2], map sub test', map sub azed)) ps)) 
     loop ((Scrypt t1 t2):test') = 
      let ps = gencheck (([t1],azed):rho) in 
      if ps==[] then loop test'
      else (True,(map (\ (r,s) ->
		       let sub = substitute s in
		       (r,s,[sub t2], map sub test', map sub azed)) ps))
--- we don't need this case:     loop ((Funct t1 t2):test') = 
     loop ((Rcrypt t1 t2):test') =
      let ps = gencheck (([t1],azed):rho) in 
      if ps==[] then loop test'
      else (True,(map (\ (r,s) ->
		       let sub = substitute s in
		       (r,s,[sub t2], map sub test', map sub azed)) ps))
     (b,possibilities) = loop test
 in if b then flatten (map analz0 possibilities) 
              --- one more iteration necessary
         else possibilities
analz0 (rho,sub,n:new,test,azed) =
 case n of 
 Atom a  -> analz0 (rho,sub,new,test,(Atom a):azed)
 --- not so sure about this:
 Mr m -> analz0 (rho,sub,new,test,(Mr m):azed)
 Pk m -> analz0 (rho,sub,new,test,(Pk m):azed)
 Pk' m  -> analz0 (rho,sub,new,test,(Pk' m):azed)
 Sk m  -> analz0 (rho,sub,new,test,(Sk m):azed)
 Nonce m -> analz0 (rho,sub,new,test,(Nonce m):azed)
 C m1 m2 -> analz0 (rho,sub,m1:m2:new,test,azed)
 Crypt m1 m2 -> analz0 (rho,sub,new,(Crypt m1 m2):test,(Crypt m1 m2):azed)
 Scrypt m1 m2 -> analz0 (rho,sub,new,(Scrypt m1 m2):test,(Scrypt m1 m2):azed)
 --- fix: Var _ ->  error "Das geht doch gar nicht!"
 Var v -> analz0 (rho,sub,new,test,azed)
 Tb t m -> analz0 (rho,sub,new,test,(Tb t m):azed)
 Tb' t m -> analz0 (rho,sub,new,test,(Tb' t m):azed)
 Fu m -> analz0 (rho,sub,new,test,(Fu m):azed)
 Funct m1 m2 -> analz0 (rho,sub,new,test,(Funct m1 m2):azed)
 Table t -> analz0 (rho,sub,new,test,(Table t):azed)
 Rcrypt m1 m2 -> analz0 (rho,sub,new,(Rcrypt m1 m2):test,(Rcrypt m1 m2):azed)
{- Examples

analz0 ([],[],[Atom (Other "a"),Atom (Pk "ka"),Crypt (Atom (Pk "ka")) (Atom (Other "na"))],[],[])
-> [([],[],[],[],[Crypt (Atom (Pk "ka")) (Atom (Other "na")),Atom (Pk "ka"),Atom (Other "a")])]

analz0 ([],[],[Atom (Other "a"),Atom (Pk' "ka"),Crypt (Atom (Pk "ka")) (Atom (Other "na"))],[],[])
-> [([],[],[],[],[Atom (Other "na"),Crypt (Atom (Pk "ka")) (Atom (Other "na")),Atom (Pk' "ka"),Atom (Other "a")])]

analz0 ([],[],[Atom (Other "a"),Atom (Pk "ka"),Crypt (Atom (Pk' "ka")) (Atom (Other "na"))],[],[])
-> [([],[],[],[],[Atom "na",Crypt (Atom "ka'") (Atom "na"),Atom "ka",Atom "a"])]

-}

{-
--- NSL attack simulated

--- nsl_i :: Rho
--- ik_j :: [Msg] 
--- pattern_k :: Substitution

ik0 = [Atom (Other "a"),Atom (Other "b"),Atom (Other "I"), Atom (Pk "ka"), Atom (Pk "kb"), Atom (Pk "ki"), Atom (Pk' "ki")]

--- 1a. I generates a message for w(1,a,b,...)
nsl0 = [([Var 0],ik0)] --- first message is "0"

--- 1b. Agent b receives message (expecting {a,xNa}_kb)
pattern0 = [(0,Crypt (Atom (Pk "kb")) (C (Atom (Other "a")) (Var 1)))]
nsl1 = fst (head (gencheck ( substitute_rho pattern0 nsl0 )))

--- 1c. Agent b sends reply message ({xNa,Nb}_ka)
(nsl2,_,ik1) = 
 head (analz nsl1
       ((Crypt (Atom (Pk "ka")) (C (Var 1) (C (Atom (Other "Nb")) (Atom (Other "b"))))):ik0))

--- 2a. I generates a message for w(1,I,a,...)
nsl3 = [([Var 3],ik1)]++nsl2

--- 2b. a expects {I,xNi}_ka
pattern1 = [(3,Crypt (Atom (Pk "ka")) (C (Atom (Other "I")) (Var 4)))]
(nsl4,s) = (head (gencheck (substitute_rho pattern1 nsl3)))

msg = (substitute s) (Crypt (Atom (Pk "ki")) (C (Var 4) (C (Atom (Other "Na")) (Atom (Other "a")))))

--- 2c. a replies {xNi,Na,a}_ki
ik2 = head (analz nsl4 (msg:ik1))
-}

----------- STATE STUFF -----------------------


--- Monadic Stuff
-----------------

newtype MState s res = St (s -> (s,res))

unState (St f) = f

instance Monad (MState s) where
    return x = St (\s -> (s, x))
    (St ma) >>= f = St (\s -> let (s', res1) = (ma s) 
                                  (St f') = (f res1) 
		              in  f' s')

runMonad :: s -> MState s res -> (s,res)
runMonad init (St f) = f init

getState :: MState s s
getState = St (\s -> (s, s))

setState :: s -> MState s ()
setState state = St (\s' -> (state, ()))

type Varmonad res = MState (Int,(String->Int)) res

checkvar :: String -> Varmonad Int
checkvar str = 
  do st <- getState
     let (i,sub) = st in
      if (sub str)==0 then do setState (i+1,\x -> if x==str then i+1 else sub x)
	                      return (i+1)
		      else return (sub str)

{- Step 0: Renaming Pattern Vars -}

renameMsg :: Msg -> Varmonad Msg
renameMsg (Atom sth) = return (Atom sth)
renameMsg (Mr m) = do m' <- renameMsg m
		      return (Mr m')
renameMsg (Pk m) = do m' <- renameMsg m
		      return (Pk m')
renameMsg (Pk' m) = do m' <- renameMsg m
		       return (Pk' m')
renameMsg (Sk m) = do m' <- renameMsg m
		      return (Sk m')
renameMsg (Nonce m) = do m' <- renameMsg m
		         return (Nonce m')
renameMsg (Var x) = do x' <- checkvar (show x)
	               return (Var x')
renameMsg (C m1 m2) = do m1' <- renameMsg m1
		         m2' <- renameMsg m2
		         return (C m1' m2')
renameMsg (Scrypt m1 m2) = do m1' <- renameMsg m1
 		              m2' <- renameMsg m2
		              return (Scrypt m1' m2')
renameMsg (Crypt m1 m2) = do m1' <- renameMsg m1
		             m2' <- renameMsg m2
		             return (Crypt m1' m2')
renameMsg (Session i)    = return (Session i)
renameMsg (Succsession m) = do m' <- renameMsg m
			       return (Succsession m')
renameMsg (Table t)       = do t' <- renameMsg t
			       return (Table t')
renameMsg (Fu    t)       = do t' <- renameMsg t
			       return (Fu t')
renameMsg (Tb    m1 m2) = do m1' <- renameMsg m1
		             m2' <- renameMsg m2
		             return (Tb m1' m2')
renameMsg (Tb'   m1 m2) = do m1' <- renameMsg m1
		             m2' <- renameMsg m2
		             return (Tb' m1' m2')
renameMsg (Funct m1 m2) = do m1' <- renameMsg m1
		             m2' <- renameMsg m2
		             return (Funct m1' m2')
renameMsg (Rcrypt m1 m2)= do m1' <- renameMsg m1
		             m2' <- renameMsg m2
		             return (Rcrypt m1' m2')

renameFact :: Fact -> Varmonad Fact
renameFact f =
    case f of
    M i m1 m2 m3 m4 m5  -> do m1' <- renameMsg m1
			      m2' <- renameMsg m2
			      m3' <- renameMsg m3
			      m4' <- renameMsg m4
			      m5' <- renameMsg m5
			      return (M i m1' m2' m3' m4' m5')
    W i m1 m2 m3 m4 m5  -> do m1' <- renameMsg m1
			      m2' <- renameMsg m2
			      m3' <- renameMsg m3
			      m4' <- renameMsg m4
			      m5' <- renameMsg m5
			      return (W i m1' m2' m3' m4' m5')
    Secret m1 m2        -> do m1' <- renameMsg m1
			      m2' <- renameMsg m2
			      return (Secret m1' m2')
    Give m1 m2          -> do m1' <- renameMsg m1
			      m2' <- renameMsg m2
			      return (Give m1' m2')
    Witness m1 m2 m3 m4 -> do m1' <- renameMsg m1
			      m2' <- renameMsg m2
			      m3' <- renameMsg m3
			      m4' <- renameMsg m4
			      return (Witness m1' m2' m3' m4')
    Request m1 m2 m3 m4 -> do m1' <- renameMsg m1
			      m2' <- renameMsg m2
			      m3' <- renameMsg m3
			      m4' <- renameMsg m4
			      return (Request m1' m2' m3' m4')


renameRuleVars :: Varmonad Rule -> Varmonad Rule
renameRuleVars rule =
  do s <- getState
     r <- rule
     let (lhs,rhs) = r 
	 (c,sub) = s in
      do lhs' <- mapM renameFact lhs
         rhs' <- mapM renameFact rhs
	 c'   <- (liftM fst) getState
	 setState (c',sub)
	 return (lhs',rhs')

--- e.g. try: snd (runMonad (7,\x -> 0) (renameRuleVars (return step0))

{- Step 1: LHS w term -}

type InterState = (State,Rule)

match_lhs_waiting_term :: InterState -> [InterState]
match_lhs_waiting_term ((time,facts,ik,rho,hst),(lhs,rhs)) =
  let lhswterms = filter isWTerm lhs in
   case lhswterms of
    [] -> [((time,facts,ik,rho,hst),(lhs,rhs))] --- nothing to do...
    [lhswterm] -> 
      flattenOpts 
       (map (\ (wfact,rest) -> 
              case (match_facts wfact lhswterm []) of
	      Some sub -> Some (substitute_interstate sub 
                                ((time,rest,ik,rho,hst),(lhs,rhs)))
	      None -> None) (splitters isWTerm facts))
    _ -> error ("multiple waiting terms in lhs of a rule: "++(show lhs))

splitters :: (a->Bool) -> [a] -> [(a,[a])]
splitters f l = splitters0 f l []

splitters0 f [] _ = []
splitters0 f (x:xs) l = 
 if f x then (x,xs++l):(splitters0 f xs (x:l)) 
        else splitters0 f xs (x:l)

match_facts :: Fact -> Fact -> Substitution -> Option Substitution
match_facts (W i m1 m2 m3 m4 m5) (W i' m1' m2' m3' m4' m5') sub1 =
  if (i /= i') then None
  else case unifyhelp m1 m1' sub1 of
       None -> None
       Some sub2 -> 
        case unifyhelp (substitute sub2 m2) (substitute sub2 m2') sub2 of
	None -> None
	Some sub3 ->
	 case unifyhelp (substitute sub3 m3) (substitute sub3 m3') sub3 of
	 None -> None
	 Some sub4 -> 
	  case unifyhelp (substitute sub4 m4) (substitute sub4 m4') sub4 of
	  None -> None
	  Some sub5 ->
	   unifyhelp (substitute sub5 m5) (substitute sub5 m5') sub5

--- nsl1_1 = head (tail (match_lhs_waiting_term (state0,step1 6)))

{- Step 2: LHS m term if pressent -}

match_msg_fact :: InterState -> [InterState]
match_msg_fact ((time,facts,ik,rho,hst),(lhs,rhs)) =
 let lhsmterms = filter isMTerm lhs in
  case lhsmterms of
  [] -> [((time,facts,ik,rho,hst),(lhs,rhs))] --- nothing to do!
  [M i off real rec mterm ses] -> 
   map (\ (rho',sub) -> 
	  substitute_interstate sub ((time,facts,ik,rho',hst++[M i off real rec mterm ses]),(lhs,rhs)))
       (gencheck (([mterm],ik):rho))
  _ -> error "multiple message terms"

--- nsl1_2 = head (match_msg_fact nsl1_1)

{- Step 3: Perform the actual step -}

perform_step :: InterState -> InterState
perform_step ((time,facts,ik,rho,hst),(lhs,rhs)) =
 ((time-1,(filter (\x -> (not (isMTerm x)) && (not (isGTerm x)) && (not (isRequest x))) rhs)++facts,ik,rho,hst),(lhs,rhs))
 
--- nsl1_3 = perform_step nsl1_2


{- Step 4: Update Intruder knowledge -}

normalizeSes :: Msg -> Msg
normalizeSes (Succsession m) = normalizeSes m
normalizeSes m = m

check_requests :: ([Fact],[Fact]) -> ([Fact],[Fact])
check_requests ([],facts) = ([],facts)
check_requests (r:reqs,facts) = 
  let (reqs',facts') = check_requests (reqs,facts)
      (reqs'',facts'') = split (match_request r) facts'
      facts''' = if (keepwitness) then facts' else facts'' in
  if (reqs''==[]) then (r:reqs',facts''')
  else (reqs',facts''')

match_request :: Fact -> Fact -> Bool
match_request (Witness a b c d) (Request b' a' c' d') = 
  (a==a') && (b==b') && (c==c') && (d==d')
match_request (Request a b c d) (Witness b' a' c' d') = 
  (a==a') && (b==b') && (c==c') && (d==d')
match_request _ _ = False


analz_knowl ((time,facts,ik,rho,hst),(lhs,rhs)) = 
 let mterms = filter isMTerm rhs
     gterms = map (\ (Give sec ses) -> Give sec (normalizeSes ses))
		  (filter isGTerm rhs)
     reqts  = filter isNIRequest rhs
     (reqts',facts') = check_requests (reqts,facts)
     newterms = [ m | M _ _ _ _ m _ <- rhs] 
     newgterms = [ m | Give m s <- rhs, case m of 
					(Var _) -> --- not verified hack ... error "message is var"
					            False
					_ -> case s of 
					     (Var _) -> error "Session is var"
					     _ -> True ]
     newfacts = foldr (\ fact facts -> 
		         case fact of
			  Secret sec ses -> let ses' = normalizeSes ses in
					    if (mem (Give sec ses') gterms)
					    then facts 
					    else (Secret sec ses):facts
			  _ -> fact:facts) 
		      [] facts' in
 if (reqts'/=[]) then error ("Unmatched requests "++(prlist (time,newfacts,ik,rho,hst)))
 else
  if (mterms==[] && gterms==[]) then 
   [((time,newfacts,ik,rho,hst),(lhs,rhs))] --- nothing changed !
  else
    let possibilities = analz rho (newterms++newgterms++ik) in
     map (\ (rho',sub,ik') 
          -> substitute_interstate sub 
 	     ((time,newfacts,ik',rho',hst++mterms),(lhs,rhs))) 
         possibilities

--- nsl1_4 = analz_knowl nsl1_3

{- Putting it all together -}

successors :: (Int -> Rule) -> Varmonad State -> Varmonad [State]
successors rule state = 
  do s <- state
     r <- renameRuleVars (return (rule (getTime s)))
     return (flatten (map ((map fst) . analz_knowl . perform_step)
	      (flatten (map match_msg_fact
	       (match_lhs_waiting_term (s,r))))))

getTime :: State -> Int
getTime (t,_,_,_,_) = t

{- nsl1_4' = head (snd (runMonad (1,(\x -> 0)) (successors step1 (return state0))))
 
attack_out = 
 do nsl1 <- successors step1 (return state0)
    nsl2 <- successors step1 (return (head nsl1))
    nsl3 <- successors step3 (return (head nsl2))
    return nsl3

nsl_out = --- map (\s -> showString (showState s)) (snd (runMonad (1,(\x -> 0)) attack_out))
	(snd (runMonad (1,(\x -> 0)) attack_out))
-}

prlist :: State -> String
prlist (_,facts,_,_,hist) = "Attack found:\n"++(show_factlist (review hist))++"\n"++
			    "Reached State:\n"++(show_factlist facts)

review :: [Fact] -> [Fact]
review [] = []
review [m] = [m]
review (m1:m2:ms) = 
 let (M _ _ s1 r1 n1 _) = m1
     (M _ _ s2 r2 n2 _) = m2
 in if (s1==s2) && (r1==r2) && (n1==n2) then m1:(review ms)
    else m1:(review (m2:ms))
  


secrecy_check :: [Int] -> State -> Bool
--- intlist is session numbers for the secrecy check
secrecy_check sessions (_,facts,ik,_,_) = 
   foldl (\ b (Secret s session) -> 
	    b && not ((mem (base session) sessions) && (mem s ik))) 
	 True
	 (filter isSecret facts)

base :: Msg -> Int
base (Session i) = i
base (Succsession m) = base m
base m = error ("Message "++(show m)++" has no base")
  
correspondence_check :: [[Fact]] -> State -> Bool
correspondence_check [] _ = True
correspondence_check (fs:goals) (_,facts,_,_,_) =
  let wfacts = filter isWTerm facts in
   case foldsubst fs wfacts [] of
    [] -> correspondence_check goals (0,facts,[],[],[])
    _ -> False

foldsubst :: [Fact] -> [Fact] -> Substitution -> [Substitution]
foldsubst [] wterms sub = [sub]
foldsubst (f:fs) wterms sub =
 flatten
  (map (\ sub -> foldsubst fs (map (substitute_fact sub) wterms) sub)
   (foldsingle f wterms sub))

foldsingle :: Fact -> [Fact] -> Substitution -> [Substitution]
foldsingle f wterms sub =
 if not (isWTerm f) then error (show f)
 else
  if (filter (not . isWTerm) wterms)/=[] then error (show wterms)
  else
   (flattenOpts (map (\x -> match_facts f x sub) wterms))


---------------- UNIFICATION AND SUBSTITUTE STUFF ------------------------

unify :: Msg -> Msg -> Option Substitution
unify t1 t2 = unifyhelp t1 t2 []

unifyhelp :: Msg -> Msg -> Substitution -> Option Substitution
unifyhelp (Var x) term subst = 
  if (occurs x term) then 
    if (term==(Var x)) then Some subst
    else None ---else error ("Das geht aber nicht!"++(show x)++";"++(show term))
  else Some ((x,term):subst) --- ((x,term):(subsub (x,term) subst))
unifyhelp term (Var x) subst = unifyhelp (Var x) term subst
unifyhelp (Atom a) (Atom b) subst = if a==b then Some subst else None
unifyhelp (Crypt m1 m2) (Crypt n1 n2) subst =
  let mgu = unifyhelp m1 n1 subst in
  case mgu of
    None -> None
    Some sub -> unifyhelp (substitute sub m2) (substitute sub n2) sub
unifyhelp (Scrypt m1 m2) (Scrypt n1 n2) subst =
  let mgu = unifyhelp m1 n1 subst in
  case mgu of
    None -> None
    Some sub -> unifyhelp (substitute sub m2) (substitute sub n2) sub
unifyhelp (C m1 m2) (C n1 n2) subst =
  let mgu = unifyhelp m1 n1 subst in
  case mgu of
    None -> None
    Some sub -> unifyhelp (substitute sub m2) (substitute sub n2) sub
unifyhelp (Succsession m) (Succsession m') subst = unifyhelp m m' subst
unifyhelp (Session i) (Session i') subst =
  if i==i' then Some subst else None
unifyhelp (Mr m) (Mr m') subst = unifyhelp m m' subst
unifyhelp (Pk m) (Pk m') subst = unifyhelp m m' subst
unifyhelp (Pk' m) (Pk' m') subst = unifyhelp m m' subst
unifyhelp (Sk m) (Sk m') subst = unifyhelp m m' subst
unifyhelp (Nonce m) (Nonce m') subst = unifyhelp m m' subst
unifyhelp (Table t) (Table t') subst = unifyhelp t t' subst
unifyhelp (Fu t) (Fu t') subst = unifyhelp t t' subst
unifyhelp (Tb m1 m2) (Tb n1 n2) subst =
  let mgu = unifyhelp m1 n1 subst in
  case mgu of
    None -> None
    Some sub -> unifyhelp (substitute sub m2) (substitute sub n2) sub
unifyhelp (Tb' m1 m2) (Tb' n1 n2) subst =
  --- what about matching Tb' Pk'?
  let mgu = unifyhelp m1 n1 subst in
  case mgu of
    None -> None
    Some sub -> unifyhelp (substitute sub m2) (substitute sub n2) sub
unifyhelp (Funct m1 m2) (Funct n1 n2) subst =
  let mgu = unifyhelp m1 n1 subst in
  case mgu of
    None -> None
    Some sub -> unifyhelp (substitute sub m2) (substitute sub n2) sub
unifyhelp (Rcrypt m1 m2) (Rcrypt n1 n2) subst =
  let mgu = unifyhelp m1 n1 subst in
  case mgu of
    None -> None
    Some sub -> unifyhelp (substitute sub m2) (substitute sub n2) sub

unifyhelp _ _ _ = None

substitute_rho :: Substitution -> Rho -> Rho
substitute_rho sub rho = 
  map (\ (ts,ik)  -> (map (substitute sub) ts, map (substitute sub) ik )) rho

substitute :: Substitution -> Msg -> Msg
substitute sub m = foldr subst_msg m sub

subst_msg :: (Vartype,Msg) -> Msg -> Msg 
subst_msg (x,t) (Atom a) = Atom a
subst_msg (x,t) (Mr m) = Mr (subst_msg (x,t) m)
subst_msg (x,t) (Pk m) = Pk (subst_msg (x,t) m)
subst_msg (x,t) (Pk' m) = Pk' (subst_msg (x,t) m)
subst_msg (x,t) (Sk m) = Sk (subst_msg (x,t) m)
subst_msg (x,t) (Nonce m) = Nonce (subst_msg (x,t) m)
subst_msg (x,t) (Crypt m1 m2) = Crypt (subst_msg (x,t) m1) (subst_msg (x,t) m2)
subst_msg (x,t) (Scrypt m1 m2) = Scrypt (subst_msg (x,t) m1) (subst_msg (x,t) m2)
subst_msg (x,t) (C m1 m2) = C (subst_msg (x,t) m1) (subst_msg (x,t) m2)
subst_msg (x,t) (Var y) = if (x==y) then t else (Var y)
subst_msg (x,t) (Session i) = (Session i)
subst_msg (x,t) (Succsession s) = Succsession (subst_msg (x,t) s)
subst_msg (x,t) (Table m) = Table (subst_msg (x,t) m)
subst_msg (x,t) (Fu m) = Fu (subst_msg (x,t) m)
subst_msg (x,t) (Tb m1 m2) = Tb (subst_msg (x,t) m1) (subst_msg (x,t) m2)
subst_msg (x,t) (Tb' m1 m2) = Tb' (subst_msg (x,t) m1) (subst_msg (x,t) m2)
subst_msg (x,t) (Funct m1 m2) = Funct (subst_msg (x,t) m1) (subst_msg (x,t) m2)
subst_msg (x,t) (Rcrypt m1 m2) = Rcrypt (subst_msg (x,t) m1) (subst_msg (x,t) m2)

substitute_fact :: Substitution -> Fact -> Fact
substitute_fact sub (M st m1 m2 m3 m4 ses) = 
  let s = substitute sub in
   M st (s m1) (s m2) (s m3) (s m4) (s ses)
substitute_fact sub (W st m1 m2 m3 m4 ses) = 
  let s = substitute sub in
   W st (s m1) (s m2) (s m3) (s m4) (s ses)
substitute_fact sub (Secret m1 m2) =
  let s = substitute sub in
   Secret (s m1) (s m2)
substitute_fact sub (Give m1 m2) =
  let s = substitute sub in
   Give (s m1) (s m2)
substitute_fact sub (Request m1 m2 m3 m4) =
  let s = substitute sub in
   Request (s m1) (s m2) (s m3) (s m4)
substitute_fact sub (Witness m1 m2 m3 m4) =
  let s = substitute sub in
   Witness (s m1) (s m2) (s m3) (s m4)

substitute_state :: Substitution -> State -> State
substitute_state sub (time,facts,ik,rho,hst) = 
  (time,
   map (substitute_fact sub) facts,
   map (substitute sub) ik,
   substitute_rho sub rho, 
   map (substitute_fact sub) hst)

substitute_interstate :: Substitution -> InterState -> InterState
substitute_interstate sub (state,(lhs,rhs)) =
  (substitute_state sub state, 
   (map (substitute_fact sub) lhs, map (substitute_fact sub) rhs))

occurs x (Atom a) = False 
occurs x (Crypt m1 m2) = (occurs x m1) || (occurs x m2)
occurs x (C m1 m2) =  (occurs x m1) || (occurs x m2)
occurs x (Var y) = x==y
occurs x (Session i) = False
occurs x (Succsession m) = occurs x m
occurs x (Mr m) = occurs x m
occurs x (Pk m) = occurs x m
occurs x (Pk' m) = occurs x m
occurs x (Sk m) = occurs x m
occurs x (Nonce m) = occurs x m
occurs x (Scrypt m1 m2) = (occurs x m1) || (occurs x m2)
occurs x (Fu m) = occurs x m
occurs x (Table m) = occurs x m
occurs x (Tb m1 m2) = (occurs x m1) || (occurs x m2)
occurs x (Tb' m1 m2) = (occurs x m1) || (occurs x m2)
occurs x (Funct m1 m2) = (occurs x m1) || (occurs x m2)
occurs x (Rcrypt m1 m2) = (occurs x m1) || (occurs x m2)



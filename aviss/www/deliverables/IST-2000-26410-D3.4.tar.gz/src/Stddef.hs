module Stddef where

myIsAlpha c              =  myIsUpper c  ||  myIsLower c
myIsDigit c              =  c >= '0'   &&  c <= '9'
myIsUpper c              =  c >= 'A'   &&  c <= 'Z'
myIsLower c              =  c >= 'a'   &&  c <= 'z'
myIsAlphanum c           =  myIsAlpha c  ||  myIsDigit c
myToLower c | myIsUpper c  = toEnum (fromEnum c - fromEnum 'A' + fromEnum 'a')
          | otherwise  = c
myAlphanum c = myIsAlphanum c || c=='_'

flatten = foldr (++) []

remlast [x] = []
remlast (x:xs) = x:(remlast xs)


data Option a = None | Some a deriving (Eq,Show)
mkset :: Eq a => [a] -> [a]
mkset [] = []
mkset (x:xs) = if (mem x xs) then mkset xs else x:(mkset xs)
mem x [] = False
mem x (y:ys) = x==y || (mem x ys)

--- flatten :: [[a]] -> [a]
--- flatten = foldr (++) []

flattenOpts :: [Option a] -> [a]
flattenOpts [] = []
flattenOpts ((Some x):xs) = x:(flattenOpts xs)
flattenOpts (_:xs) = flattenOpts xs

headOpts :: [a] -> Option a
headOpts [] = None
headOpts (x:xs) = Some x

split :: (a->Bool) -> [a] -> ([a],[a])
split f l = split0 f l [] []
  where split0 f []     l1 l2 = (reverse l1,reverse l2)
	split0 f (x:xs) l1 l2 = if f x then split0 f xs (x:l1) l2
				       else split0 f xs l1 (x:l2)


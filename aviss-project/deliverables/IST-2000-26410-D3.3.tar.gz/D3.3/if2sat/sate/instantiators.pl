predicates(T,Ps) :- predicates1(Ps,T).
predicates1([],_).
predicates1([P|Ps],T) :-
	predicate(T,P),
	predicates1(Ps,T).

predicate(action,P) :- !,
	constant(Arity,action),
	Arity=..[F|Ss],
	functor(Arity,F,N),
	functor(P,F,N),
	P=..[F|Ts],
	tuple(Ss,Ts).
predicate(S,P) :-
	constant(Arity,S),
	Arity=..[F|Ss],
	functor(Arity,F,N),
	functor(P,F,N),
	P=..[F|Ts],
	tuple(Ss,Ts).

tuple(Ss,Ts) :-
	value(term_depth_bound,D),
	tuple(Ss,D,Ts).

term(S,D,T) :-
	D>0,
	constant(Arity,S),
	Arity=..[F|Ss],
	functor(Arity,F,N),
	functor(T,F,N),
	D1 is D-1,
	T=..[F|Ts],
	tuple(Ss,D1,Ts).
term(S,D,T) :-
	super_sort(S,S0),
	term(S0,D,T).

tuple([],_,[]).
tuple([S|Ss],D,[T|Ts]) :-
	term(S,D,T),
	tuple(Ss,D,Ts).


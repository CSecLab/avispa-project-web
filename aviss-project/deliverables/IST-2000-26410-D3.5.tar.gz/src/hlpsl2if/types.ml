(***********************************************************************)
(*                                                                     *)
(*                                 Casrul                              *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)

(*
   Main types
*)
type type_var =
    User                 (* user identifier *)
  | FrSyKey              (* fresh symmetric key *)
  | SyKey                (* symmetric key *)
  | FrPcKey of int       (* fresh public key of (associated private key) *)
  | FrPeKey of int       (* fresh private key of (associated public key) *)
  | PcKey of int         (* public key of (associated private key) *)
  | PeKey of int         (* private key of (associated public key) *)
  | Table                (* table name *)
  | Number               (* number (can be a nonce) *)
  | Function             (* hash function (never decoded) *)
;;
(*
   type message (binary constructors)
*)
type msg =
    Id of int (* a message may be an integer identifier *)
  | Int of int (* an integer *)
  | TableElement of int * int * bool (* table element: table identifier number, user number, flag: false = public element, true = private element *)
  | Func of int * msg (* a function *)
  | Crypt of int * msg * msg  (* a cifer with 1: public key, 2: private key, 3: symmetric key *)
  | Arith of int * msg * msg (* an arithmetic operation *)
  | Logic of int * msg * msg (* a logic operation*)
  | Pair of msg * msg (* a  couple *)
;;
(*
   type term
*)
type term = 
    Empty (* empty element *)
  | Var of string (* variable *)
  | Cons of string (* constant *)
  | Op of string * (term list) (* operation defined with  string:mr,fu,tb,pk,sk,nonce... and 
applied to a list of terms *)
;;
(*
type rule = Rule of string * Infos.term * Infos.term
rule's description * LHS * RHS
*)
type rule =
   Rule of (string) * (term) * (term)
;;

package Writedatacfile;
use strict ;


$Writedatacfile::Casrul;
$Writedatacfile::self;
$Writedatacfile::commute;
BEGIN {
sub setCommute {
	$Writedatacfile::commute=shift;
}
}

sub Print {
  my $fh = $Writedatacfile::self->{OutPut};
  print $fh @_;
}

my $im;
my $iw = 0 ;
my $ii = 0 ;
my $io = 0 ;
my $ic = 0 ;
my $ih = 0 ;
my $th = 0 ;
my @ti = ();
my @tm = ();
my @tw = ();
my @tc = ();
my @to = ();
my $first = 1;
my $type = 0;
my $cas = 0 ; # shall always be 0

sub PrintDebug {
   # print @_;
}


sub GetSection {
  my $flags = shift;
  my $file = $Writedatacfile::self->{FileName};
  my $hlpsl = $Writedatacfile::self->{Casrul};
  open(FOO,"$hlpsl $flags $file |") or 
    die "cannot open file $file with $hlpsl $flags, stopped\n";
  return \*FOO;
}


# Call of subfunctions
sub WriteDatacFile {
  my $self = shift;
  PRINT_HEADERS();
  PRINT_PROTOCOL_CLAUSES();
  FLUSH();
  PRINT_SIMPLIF_INT();
  PRINT_END_VERIF();
  if ($self->{ParallelStudy}) {
    PRINT_PARALLEL_RULES();
  }
  PRINT_GOALS();
  PRINT_INIT();
  PRINT_EXECUTION();
}

sub PRINT_PARALLEL_RULES {
  my $result = $Writedatacfile::self->{ParallelStudy};
  PrintDebug "PRINT_PARALLEL_RULES...\n";
  # ReglesParalleles::PrintResult($result);
  $result->PrintResult();
  PrintDebug "PRINT_PARALLEL_RULES...\n";
}




# PRINT_MEMBER ()
# dump the content of the terms tables
# h, w, i, m, other
# in order to output a clause or rewrite rule in the
# correct format
sub PRINT_MEMBER {  
  # PRINT_MEMBER(s, c, d) :
  # version speciale de   PRINT_COMMENT
  # side = "LHS" | "RHS"
  # type = "Protocol_Rules" | "Goal"
  # d = 0 for the last step of protocol rules
  # d = 1 for the last step of protocol rules (master session)
  # d = 2 for the last step of protocol rules (slave session)
  my $side = shift;
  my $type_of_rule = shift;
  my $d = shift;
  my $file = $Writedatacfile::self->{FileName};
  my $flag = 0;
  my $message = "";
  my $casrul = $Writedatacfile::self->{Casrul};
  
  if (($type_of_rule =~ /Protocol/ ) or ($type_of_rule =~ /Goal/)){
    ####################################################
    #
    #   Initial part of the clause,  xTime or s(xTime)
    #
    ####################################################
    $flag = $io + $im + $iw + $ii + $ih;
    if ($ih == 0) { $th = "xTime"; }
    if ($flag > 0) { 
      #    print "\n side: $s case: $c\n";
      # LHS
      if ((
	   ($type_of_rule =~ /Protocol/) and ($side =~ /RHS/)) or
	   ($type_of_rule =~ /Goal/)) {
	Print  "R(xTime, ";
      }
      else {
	Print  "R(s(xTime), ";
      }
    }
    
    ###################################################
    #
    # Messages -- no trouble
    #
    ###################################################
    
    
    if ($im > 0) {
      if ($side =~ /LHS/){
	$first = 0;
	Print  " \\\n @tm[0].";
      }
      else {
	$message = @tm[0];
	if (($type_of_rule =~ /Protocol/) and ($d == 0 )) {
	  Print  "\\\n m(xStep,mr(I),xSender,xReceiver,xmesg,xsession).";
	  PrintDebug "\ndiverted message  : $message";
	}
      }
    }
    else {
      $message ="";
      if ($side =~ /LHS/) {
	$first = 1;
      }
    }
    if ($flag > 0) { 
      if ($type_of_rule =~ /Protocol/) {
	Print  "ee,";
      }
      else {
	Print  "xm,";
      }
    }
    
    ##################################################
    #
    #  Principals 
    #
    ##################################################
    
    # master session, LHS, last step
    if ($iw >0 ){

      if (($type_of_rule =~ /Protocol/) and ($d == 1 ) and ($side =~ /LHS/)){
	my $line; 
	my $name;
	my $session_p;
	open ( INIT, "$casrul --init $file|") or die "cannot open file";
	while ($line = <INIT>){	
	  if ( $line =~ /^w\([a-zA-Z0-9\_\(\)]+,[a-zA-Z0-9\_\(\)]+,mr\(([a-zA-Z0-9\_]+)\),.*,([0-9]+)\)\./ ) {
	    # $1 = principal's name , $2 = session's number
	    $name = $1;
	    $session_p = $2;
	    if ( $session_p != 1 ){
	      Print  "\\\n w(xstep$name$session_p ,xsender$name$session_p ,mr($name),xknow$name$session_p,xknowinit$name$session_p,xbool$name$session_p,xsession$name$session_p).";
	    }
	  }
	}
	close (INIT);
      }

      # master session, LHS, last step
      if (($type_of_rule =~ /Protocol/) and ($d == 1 ) and ($side =~ /RHS/)){	
	open ( INIT, "$casrul --init $file|") or die "cannot open file";
	while (my $line = <INIT> ) {
	  if ( $line =~ /^(w\([a-zA-Z0-9\_\(\)]+,[a-zA-Z0-9\_\(\)]+,mr\()([a-zA-Z0-9\_]+)(\),.*,)([0-9]+)\)\./ ) {
	    my $w_init = $1 ;
	    my $name =$2 ;
	    my $w_tail = $3 ;
	    my $session_p = $4;
	    if ($session_p != 1){
	      Print  "\\\n $w_init$name$w_tail s(xsession$name$session_p)).";
	    }
	  }
	}
	close (INIT);
      }
    }
    if ($iw > 0) {
      my $i;
      foreach ($i = 0; $i < $iw; $i++) {
	Print  " \\\n @tw[$i].";
      }
    }
    if ($flag > 0) { Print  "xw, \\\n"; }


    ###################################################
    #
    #  Intruder's knowledge and messages
    #
    ###################################################
    
    if ($ii > 0) {
      my $i = 0;
      foreach ($i = 0; $i < $ii; $i++) {
        if (($type_of_rule =~ /Protocol/) and (@ti[$i] =~ /^i([a-zA-Z0-9\,\.\(\)]+)/)) {
	  Print  " d$1.";
	}
	else {
	  Print "@ti[$i].";
	}
      }
    }
    
    if ($flag > 0) {
      
      
      #################################################
      #
      # in protocol,rules
      # 
      #################################################
      
      if ($type_of_rule =~ /Protocol/) {		# beginning of protocol rules
	my $msg = "";
	# first, let's divert the message and put it in $msg
	if ( $side =~ /RHS/) {		# RHS
	  if ( $message =~ /^([a-zA-Z0-9\(\)]*),([a-zA-Z0-9\(\)]*),([a-zA-Z0-9\(\)]*),([a-zA-Z0-9\(\)]*),([a-zA-Z0-9\_\'\(\)\ ,\-]*),([a-zA-Z0-9\(\)]*)$/){
	    $msg = "d(c($3,c($4,$5))).";
	    Print  $msg ;
	  }
	}
	
	# ...then, the big part
	if ($d == 0) {
	  if ($side =~ /RHS/ ){
	    if ($first){
	      Print  "xi.i(session(xc)),xp,svs(test,num(s(xnum)).tv.mesg(u(xmesg).vtt.ii.seq,num(xnum).$msg xi)),c(trace(xSender,xReceiver,xmesg,xsession),xlist)";
	    }
	    else {
	      Print  "xi.i(session(xc)),xp,svs(test,xt.tv.num(s(xnum)).mesg(u(xmesg).vtt.ii.seq,num(xnum).$msg xi)),c(trace(xSender,xReceiver,xmesg,xsession),xlist)";
	    }
	  }
	  else {
	    # case on the left, no message received
	    # => the initiator of the protocol 
	    # (the first message a bit special (initiator))
	    if ($first){
	      Print  "xi.i(session(xc)),xp,svs(msg,num(xnum).tt),xlist";
	    }
	    else {
	      Print  "xi.i(session(xc)),xp,svs(msg,xt.num(xnum).tt),xlist";
	    }
	  }
	  Print  " \\\n ) ";
	}
	if ($d == 1){
	  if ($side =~ /RHS/ ){
	    if ($Writedatacfile::self->{NbSessions} > 1) {
	      Print  "principal(s(xc)).";
	    }
	    Print  "xi.i(session(s(xc))),xp,svs(test,xt.num(xnum)),xlist";
	  }
	  else {
	    if ($Writedatacfile::self->{NbSessions} > 1) {
	      Print  "principal(xc).";
	    }
	    Print  "xi.i(session(xc)),xp,svs(msg,xt.num(xnum)),xlist";
	  }
	  Print  " \\\n ) ";
	}
	if ($d == 2){
	  if ($side =~ /LHS/){
	    Print  "xi.i(session(xc)),xp,svs(msg,xt.tt),xlist)";
	  }
	  else {
	    Print  "xi.i(session(s(xc))),xp,svs(test,xt.tv),xlist)";
	  }
	}
	
	
	#################################################
	#
	# Goals
	#
	#################################################
	
	if ($type_of_rule =~ /Goal/) {		# case of a goal
	  if ($type == 0){
	    Print  "xi,xp,svs(msg,xt),xlist \\\n )";
	  }
	  else {
	    Print  "xi,xp,svs(msg,tt),xlist \\\n )";
	  }
	}
      }
      FLUSH();
    }
  }
  PrintDebug "End of PRINT_MEMBER \n";
}




# PRINT_TERM ()
# dump the content of terms tables 
# h, w, i, m, other
# to output a suitable term of the form .-list
sub PRINT_TERM {
  # concatenation of the lists tm, tw, ti, to in t
  my $i = 0;
  my $n ;
  my @t = ();
  my $t ;
  foreach $n ('tm', 'tw', 'ti', 'to') {
    eval "foreach (\@$n){\@t[\$i++] = \$_}";
  }
  if ($ih > 0) {
    push @t, $th;
    $i++;
  }
  if  ($i > 0) {
    Print  (shift (@t));
  }
  foreach $t (@t) {
    Print  ".$t";
  }
  FLUSH();
}


# PRINT_CLAUSES ()
# uses global variable $cas
sub PRINT_CLAUSES {
  FLUSH();
  PrintDebug "PRINT_CLAUSES...\n";
  # 1 if in-between LHS and RHS
  my $Flag = shift;
  my $term = "";
  my $right = 0;
  my $buffer = "";
  $cas = 0 ;
  my $stepcount = 0;
  my $casrul = $Writedatacfile::self->{Casrul};
  my $inputfile = $Writedatacfile::self->{FileName};
  my $debug = $Writedatacfile::self->{NbSteps};

  open (CLAUSES, "$casrul $Flag $inputfile | ") or die "cannot open: $!\n";
  # look at the comments using PRINT_COMMENT
  while ($buffer = <CLAUSES>) {
    PrintDebug $buffer;
    if ( $stepcount < $Writedatacfile::self->{NbSteps}-1 ){
	# RHS
      if (($buffer =~ /^$/s) && ($right == 1)) {	
	# PRINT_COMMENT updates $cas
	if ($stepcount < $Writedatacfile::self->{NbSteps} -1){
	  PRINT_COMMENT();
	  PRINT_MEMBER("RHS","Protocol_Rules",0);
	  Print  "\n\n";
	}
	$right = 0;
	$stepcount++;
	PrintDebug "end of empty line\n";
      }
      else { # LHS
	if ($buffer =~ /^=>$/s) {
	  if (1){#($stepcount < $Writedatacfile::self->{NbSteps} -1){
	    PRINT_COMMENT();
	    PRINT_MEMBER("LHS","Protocol_Rules",0);
	    Print  " => \\\n";
	  }
	  $right = 1;
	  # last SWITCH;
	}
	else {
	  foreach $term (split /\./, $buffer) { MATCH_TERM($term) } # =~ s/\n//gm) }
	}
      }
    }
  }
  # prints the last RHS
  # in case $casrul's output doesn't end with an empty line
  if (($right == 1) && (SOMETHING_TO_PRINT() == 1)) {
    PRINT_MEMBER("RHS","Protocol_Rules",0);
    Print  "\n\n";
  }
  close (CLAUSES);
}


# PRINT_MASTER_LAST ("--rules",$file)
sub PRINT_MASTER_LAST {
  FLUSH();
  my $Flag = shift;
  # 1 if in-between the LHS and the RHS
  my $right = 0; 
  $cas = 0;
  my $stepcount = 0;
  my $casrul = $Writedatacfile::self->{Casrul};
  my $filename = $Writedatacfile::self->{FileName};

  PrintDebug "PRINT_MASTER_LAST\n";
  open (CLAUSES, "$casrul $Flag $filename |") or die "cannot open: $!\n";
  while (<CLAUSES>) {
  SWITCH: {
      if ( $stepcount == $Writedatacfile::self->{NbSteps} -1){
	my $term = "";
	foreach $term (split /\./, $_) { MATCH_TERM($term) } # =~ s/\n//gm) }
      }
      # RHS
      if (/^$/s && ($right == 1)) {	
	# PRINT_COMMENT updates $cas
	PRINT_COMMENT();
	if ( $stepcount == $Writedatacfile::self->{NbSteps} - 1 ){
	  PRINT_MEMBER("RHS","Protocol_Rules",1);
	  Print  "\n\n";
	}
	$right = 0;
	$stepcount++;
	last SWITCH;
      }
      # RHS
      if (/^=>$/s) {
	PRINT_COMMENT();
	if ( $stepcount == $Writedatacfile::self->{NbSteps} - 1) {
	  PRINT_MEMBER("LHS","Protocol_Rules",1);
	  Print  " => \\\n";
	}
	$right = 1;
	last SWITCH;
      }
    }
  }
  if (($right == 1) && (SOMETHING_TO_PRINT() == 1)) {
    PRINT_MEMBER("RHS","Protocol_Rules",1);
    Print  "\n\n";
  }
  close (CLAUSES);
};



# PRINT_SLAVE_LAST ("--rules",$file)
sub PRINT_SLAVE_LAST {
  FLUSH();
  my $Flag = shift ;
  my $casrul = $Writedatacfile::self->{Casrul};
  my $file = $Writedatacfile::self->{FileName};
  my $right = 0;
  $cas = 0;
  my $stepcount = 0;
  my $term;

  PrintDebug $casrul;
  open (CLAUSES, "$casrul $Flag $file |") or die "cannot open: $!\n";
  while (<CLAUSES>) {
    SWITCH : {
      if ( $stepcount == $Writedatacfile::self->{NbSteps} -1){
	foreach $term (split /\./, $_) { MATCH_TERM($term) } # =~ s/\n//gm) }
      }
      # RHS
      if (/^$/s && ($right == 1)) {	
	# PRINT_COMMENT updates $cas
	PRINT_COMMENT();
	if ( $stepcount == $Writedatacfile::self->{NbSteps} - 1 ){
	  PRINT_MEMBER("RHS","Protocol_Rules",2);
	  Print  "\n\n";
	}
	$right = 0;
	$stepcount++;
	last SWITCH;
      }
      # LHS
      if (/^=>$/s) {
	PRINT_COMMENT();
	if ( $stepcount == $Writedatacfile::self->{NbSteps} - 1) {
	  PRINT_MEMBER("LHS","Protocol_Rules",2);
	  Print  " => \\\n";
	}
	$right = 1;
	last SWITCH;
      }
    }
  }

  if (($right == 1) && (SOMETHING_TO_PRINT() == 1)) {
    PRINT_MEMBER("RHS","Protocol_Rules",2);
    Print  "\n\n";
  }
  close (CLAUSES);
};


sub PRINT_GOALS {
  FLUSH();
  FLUSH_C();

  my $file = $Writedatacfile::self->{FileName};
  my $casrul = $Writedatacfile::self->{Casrul};
  my $line = "";
  Print  "\n# Goals\n";
  open (GOALS, "$casrul --goal $file| ") or die "cannot open: $!\n";
  while ($line = <GOALS>) {
    # print $line;
    if ($line =~ (/^$/s) && (SOMETHING_TO_PRINT() == 1)) {
      PRINT_COMMENT();
      my $not_empty = $im + $iw + $ii + $io + $ic + $ih;
      PRINT_MEMBER("LHS","Goal");
      PrintDebug $type;
      if ($not_empty) {
	if ($type == 0) {
	  Print  "xi,xp, svs(msg,xsvs),xlist) \\\n => List(xlist)\n\n";
	}
	else {
	  Print  "xi, xp,xsvs) \\\n =>\n\n";
	}
      }
    }
    else {
      my $term; 
      foreach $term (split /\./, $line) {
	MATCH_TERM($term)
      }
    }
  }
  Print "\n\n";
}


# PRINT_COMMENT ()
# dump the content of comments table
# detects the keyword Divert, Memorize ($cas = 1) ou Impersonate ($cas = 2)
# in the comments (if they are not present : $cas = 0).
sub PRINT_COMMENT {

  if ($ic > 0) {
    my $i;
    foreach ($i = 0; $i < $ic; $i++) {
      my $comment = @tc[$i];
    SWITCH: {
	if ($comment =~ /.+Memo.+/s) {
	  $cas = 1;
	  last SWITCH;
	}
	if ($comment =~ /.+Divert.+/s) {
	  $cas = 1;
	  last SWITCH;
	}
	if ($comment =~ /.+Impersonate.+/s) {
	  $cas = 2;
	  last SWITCH;
	}
	$cas = 0;
      }	  
      Print  "$comment";
    }
  }
  FLUSH_C();
}





sub PRINT_EXECUTION {
  my $buffer ="";
  my $includepath = $Writedatacfile::self->{IncludePath};
  
  open (EXEC,"$includepath/Execution.dat") or die "Couldn't find include path\n";
  $buffer = "";
  while ( $buffer = <EXEC>){
    Print  "$buffer";
  }
  close(EXEC);
}



sub PRINT_HEADERS {
  my $includepath = $Writedatacfile::self->{IncludePath};
  my $buffer ="";
  
  open (ORDER,"$includepath/Order.dat") or die "Couldn't find include path\n";
  $buffer = "";
  while ( $buffer = <ORDER>){
    Print  "$buffer";
  }
  close(ORDER);
}




sub PRINT_SIMPLIF_INT {
  my $includepath = $Writedatacfile::self->{IncludePath};
  my $buffer = "";
  # tests so we do not have to import the whole theory
  my $pk_not_used = 1 ;
  my $sk_not_used = 1 ;
  my $xor_not_used = 1 ;
  my $func_not_used = 1;
  my $table_not_used = 1;
  my $casfile = $Writedatacfile::self->{FileName};
  open (SIMPLIF,"$includepath/simplif.dat") or die "Couldn't find include path\n";

  while ( $buffer = <SIMPLIF>){
    Print  "$buffer";
  }
  close(SIMPLIF);
  open(SOURCE," $casfile");
  while (<SOURCE>) {
    if ($pk_not_used && (( /public\_key/is )||(/table/is))){
      $pk_not_used=0;
      open(PK,"$includepath/public_key.dat") or die "\n Problem 0\n";
      while ($buffer = <PK>){Print  $buffer;}
      close(PK);
      if ($Writedatacfile::commute == 1) {
	# print "ca commute !\n";
      }
    }
    if ($xor_not_used && ( /XOR/is )) {
      $xor_not_used = 0;
      open( XOR,"$includepath/xor_enc.dat") or die "Couldn't find the Xor simplification file\n";
      while ($buffer = <XOR>){Print $buffer;}
      close(XOR);
    }
    if ($func_not_used && ( /function/is )) {
      $func_not_used = 0;
      open( FUNC,"$includepath/hash.dat") or die "Couldn't find the Xor simplification file\n";
      while ($buffer = <FUNC>){Print $buffer;}
      close(FUNC);
    }
    if ($table_not_used && ( /table/is )) {
      $table_not_used = 0;
      open(TABLE,"$includepath/table.dat") or die "Couldn't find the Xor simplification file\n";
      while ($buffer = <TABLE>){Print $buffer;}
      close(TABLE);
    }
  }
# we always include symmetric key because of composed keys
  open(SK,"$includepath/symmetric_key.dat") 
    or 
      die "\nProblem in opening symmetric simplifications file\n";
  while ($buffer = <SK>){Print  $buffer;}
  close(SK);
  close(SOURCE);
      if ($Writedatacfile::commute == 1) {
        # print "ca commute !\n";
      }
}



sub PRINT_PROTOCOL_CLAUSES {
#  $Writedatacfile::self = shift;
  PrintDebug "PRINT_PROTOCOL_CLAUSES...\n";
  Print  "\n#70\n";
  Print  "# Theory already treated: (list of clauses)\n";
  
  
  PRINT_CLAUSES("--rules");
  PRINT_MASTER_LAST("--rules");
  if ( $Writedatacfile::self->{NbSessions} >= 1 ){
    PrintDebug "More than one session detected\n";
    PRINT_SLAVE_LAST("--rules");
  }
  else {
    PrintDebug "Only one session detected...\n";
  }
  PrintDebug "ca marche \n";
}

# PRINT_INIT_TERM ()
sub PRINT_INIT_TERM {  
  my $sess  = $Writedatacfile::self->{NbSessions};
  my $sess2 = $Writedatacfile::self->{NbSessions};
  my $sess3 = $Writedatacfile::self->{NbSessions};
  my $flag  = $io + $im + $iw + $ii + $ih;
  my $etude = $Writedatacfile::self->{ParallelStudy};

  if ($ih == 0) { $th = "xTime"; }
  if ($flag > 0) { 
    Print  "R( $th, "; 
  }
  if ($im > 0) {
    my $i = 0;
    foreach ($i = 0; $i < $im; $i++) {
      Print  " \\\n @tm[$i].";
    }
  }
  if ($flag > 0) { Print  "ee, "; }
  if ($iw > 0) {
    my $i = 0;
    foreach ($i = 0; $i < $iw; $i++) {
      Print  " \\\n @tw[$i].";
    }
  }
  if ($flag > 0) { Print  "ee, \\\n"; }
  if ($ii > 0) {
    my $i = 0;
    foreach ($i = 0; $i < $ii; $i++) {
      Print  " @ti[$i].";
    }
  }
  while ($sess > 0 ){
    Print  "i(session($sess)).";
    $sess--;
  }
  if ($sess3 > 1) {
    Print  "principal(1).";
  }
  Print  " ";
  if ($flag > 0) { 
    Print  " ii,";
    if ($etude) {
      Print $etude->{Initial};
    }
    else {
      Print "ii";
    }
    Print ","; # pour la case parallele
    Print  "svs(msg,tt.num(9)),tt \\\n ) "; 
  }
  FLUSH();
}


sub PRINT_INIT {
  FLUSH();
  my $casrul  = $Writedatacfile::self->{Casrul};
  my $casfile = $Writedatacfile::self->{FileName};
  
  Print  "\n#7\n";
  Print  "# Theory: (list of clauses)\n\n";
  open (INIT, "$casrul --init $casfile | ") or die "cannot open: $!\n";
#  INIT = GetSection("--init");
  my $line;
  while ($line = <INIT>) {
    # print $line;
    if (($line =~ /^$/s) && (SOMETHING_TO_PRINT() == 1)) { 
      PRINT_COMMENT();
      Print  "=> ";      
      PRINT_INIT_TERM($Writedatacfile::self);
      Print  "\n\n";
    }
    else {
      my $term;  
      foreach $term (split /\./, $line) { 
	MATCH_TERM($term) 
      } 
    }
  }
  if (SOMETHING_TO_PRINT() == 1) { 
    PRINT_COMMENT();
    Print  "=> ";      
    PRINT_INIT_TERM($Writedatacfile::self);
    Print  "\n\n";
  }
  Print  "\n\n";
}



sub FLUSH {
  while ($im > 0) { shift @tm; $im--; };
  while ($iw > 0) { shift @tw; $iw--; };
  while ($ii > 0) { shift @ti; $ii--; };
  while ($io > 0) { shift @to; $io--; };
  $ih = 0;
}

sub FLUSH_C {
  $ic = 0;	
  foreach (@tc){ 
    shift (@tc); 
  } 
}

sub SOMETHING_TO_PRINT {
  if ($im + $iw + $ii +  $io + $ic + $ih > 0) { 1 }
  else { 0 };
}


# MATCH_TERM t:
# place t dans
# un des tableaux de termes de type h, w, i, m, c (comment), other
# suivant la premiere lettre de t
sub MATCH_TERM {
  my $term = @_[0];
 SWITCH: {
    if ($term =~ /^h\((.+)\)$/s) { 
      $th = $1;
      $ih++;
      last SWITCH;
    }
    if ($term =~ /^(w\(.+\))$/s) { 
      @tw[$iw] = $1;
      $iw++;
      last SWITCH;
    }
    if ($term =~ /^(i\(.+\))$/s) { 
      @ti[$ii] = $1;
      $ii++;
      last SWITCH;
    }
    if ($term =~ /^(witness\(.+\))$/s) { 
      @ti[$ii] = $1;
      $ii++;
      last SWITCH;
    }
    if ($term =~ /^(request\(.+\))$/s) { 
      @ti[$ii] = $1;
      $ii++;
      last SWITCH;
    }
    if ($term =~ /^(secret\(.+\))$/s) { 
      @ti[$ii] = $1;
      $ii++;
      last SWITCH;
    }
    if ($term =~ /^(give\(.+\))$/s) {
      @ti[$ii] = $1;
      $ii++;
      last SWITCH;
    }
    if ($term =~ /^(m\(.+\))$/s) { 
      @tm[$im] = $1;
      $im++;
      last SWITCH;
    }
    if ($term =~ /^(\#.+)$/s) {
      @tc[$ic] = $1;
      $ic++;
      last SWITCH;      
    }
    if ($term =~ /^(\n|\s)*$/s) {
      last SWITCH;      
    }    
    if ($term =~ /^(\S+)(\n|\s)*$/s) {
      @to[$io] = $1;
      $io++;
      last SWITCH;      
    }
  }
}


sub PRINT_END_VERIF {
  my $count = ($Writedatacfile::self->{NbSteps} - 1)* ($Writedatacfile::self->{NbSessions}) ;
  my $count = 10;
  my $i = 0;
  my $buff = "";
  
  Print "\n# End of verifications\n";
  Print "# The following rules are here for testing with a bounded\n";
  Print "# number of messages\n";
  Print "\n\n#70 100\n\n"; 
  while ( $count  > 0) {
    my $i = $count ;
    my $buff = "9";
    if ($type == 0) {
      Print  "\n => svs\(test, \\\n";
      while (  $i--  > 0 ) {
	Print  "mesg(vtt.xu$i,num($buff).xi$i).";
	$buff = "s($buff)";
      }
      Print  "tv.num\(xnum\)\)\\\n= \\\n svs\(msg,  \\\n";
      $i = $count;
      $buff="9";
      while (  $i--  > 0 ) {
	Print  "mesg(vtt.xu$i,num($buff).xi$i).";
	$buff="s($buff)";
      }
      Print  "tt.num(xnum)\) \n\n";
      $i = $count ;
      $buff= "9";
    }
    
    Print  "\n=> svs\(test, \\\n";
    while (  $i--  > 0 ) {
      Print  "mesg(vtt.xu$i,num($buff).xi$i).";
      $buff = "s($buff)";
    }
    Print  "tt.num(xnum)\)\\\n= \\\n svs\(msg,tt.num(9)\)\n\n";
    $count--;
  }
  Print "\n\n\#70\n\n";
}


################################################################################
#
#  Declarations of constant buffers
#
################################################################################







($IFTOCL::Warning = <<END_OF_WARNING);
#
# Warning : you are currently using casdat with typed awaited messages
# AND multiple sessions. This is not a good idea, since typed awaited
# messages prevent me from doing check after each message, and the check
# of messages will be done only after the end of the first session.
# There are no risks of finding wrong attacks this way, but a huge
# leak in what is to be done, i.e. I will have to work to much. And this
# is bad.
#                                        casdat3
#
END_OF_WARNING



1;

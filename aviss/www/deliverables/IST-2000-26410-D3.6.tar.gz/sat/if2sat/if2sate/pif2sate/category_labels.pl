% CATEGORY OF THE REWRITING RULES
%
% If the category labels change in the HLPSL2IF phase then is 
% sufficient to change the first parameters of the following 
% facts to preserve the correctness of the next phases


category_label(protocol_Rules,rules).
category_label(invariant_Rules,invariants).
category_label(decomposition_Rules,decompositions).
category_label(simplification,simplification).
category_label(intruder_Rules,intruder).
category_label(init,init).
category_label(goal,goal).

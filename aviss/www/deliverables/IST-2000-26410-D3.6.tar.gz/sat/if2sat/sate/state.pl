:- dynamic value/2.

toggle(F) :-
	retract(value(F,S)),
	toggle(S,S1),
	asserta(value(F,S1)),
	format('Flag ~w set to ~w.\n',[F,S1]).

toggle(on,off).
toggle(off,on).

set(Var,Value,OldValue) :-
	( value(Var,OldValue) ->
	    ( OldValue=Value ->
		true ;
		retract(value(Var,OldValue)),
		asserta(value(Var,Value)) ) ;
	    asserta(value(Var,Value)),
	    OldValue='UNDEF' ).
set(Var,Value) :-
	set(Var,Value,OldValue),
	(value(output,standard) ->	
	    ( OldValue=Value ->
		format('~w set to ~w\n',[Var,Value]) ;
		format('~w used to be ~w, now set to ~w\n',
		   [Var,OldValue,Value])
	    );
	    true
	).

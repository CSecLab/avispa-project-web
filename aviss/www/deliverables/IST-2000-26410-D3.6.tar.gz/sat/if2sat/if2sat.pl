if2sat(Pb) :-
%	set_prolog_flag(redefine_warnings,off),
%	ensure_loaded('if2sate/if2sate.pl'),	
	if2sate(Pb),
%	ensure_loaded('sate/sate.pl'),
	sate(Pb).

% OLD
% :- use_module(library(system)).
% :- use_module(library(charsio)).

% :- ensure_loaded('sate/operators.pl').
% :- ensure_loaded('sate/instantiators.pl').

% :- ensure_loaded('sate/sate_output.pl').
% :- ensure_loaded('sate/state.pl').
% :- ensure_loaded('sate/newlists.pl').
% :- ensure_loaded('sate/newload.pl').
% :- ensure_loaded('sate/encoding.pl').
% :- ensure_loaded('sate/solver.pl').

% :- ensure_loaded('if2sate/pif2sate/category_labels.pl').

% :- ensure_loaded('config.pl').

%:- dynamic syntax/1.

% if2sat :-
% 	set(output,html),
% %	set(output,standard),	
% 	set(intruder_const,off),
% 	set(multi_fresh_term,off),
% 	set(term_depth_bound,12),
% 	set(problems_dir,'/projects/aviss/test/web'),
% 	set(session_repetition,1),
% 	set(steps,1),
% 	prolog_flag(argv,ARGs),
% 	(ARGs=[] ->
% 	    format("\n\nERROR: you have not specified the IF file.\n",[]),
% 	    halt
% 	;
% 	    true
% 	),
% 	findall(OPT,
% 		(
% 		  member(OPT,ARGs),
% 		  atom_concat('--',_,OPT)
% 		),
% 		OPTs
% 	       ),
% 	member(PbName,ARGs),
% 	\+member(PbName,OPTs),
% 	(same_length([PbName|OPTs],ARGs,_) ->
% 	    true
% 	;
% 	    format("\n\nERROR: mistake in the list of arguments\n.",[]),
% 	    halt
% 	),
% 	value(problems_dir,DIR),
% 	atom_concat(DIR,'/',TmpFileName),
% 	atom_concat(TmpFileName,PbName,FileName),
% 	(\+file_exists(FileName) -> 
% 	    format("\n\nERROR: the file ~w does not exist\n.",[FileName]),
% 	    halt
% 	;
% 	    true
% 	),
% 	(parse_args(OPTs) ->
% 	    true
% 	;
% 	    format("\n\nERROR: mistake in the list of arguments\n.",[]),	    
% 	    halt
% 	),
% 	atom_concat(Pb,'.if',PbName),
% 	if2sat(Pb),
% 	halt.



% parse_args([]).
% parse_args([OPT|OPTs]) :-
% 	atom_chars(OPT,COPT),
% 	parse_args(COPT,[]),
% 	parse_args(OPTs).

% parse_args -->
% 	"--steps=",
% 	int_arg(N),
% 	{set(steps,N)}.

% parse_args -->
% 	"--session_repetitions=",
% 	int_arg(N),
% 	{set(session_repetition,N)}.

% parse_args -->
% 	"--multi_fresh_term=on",
% 	{set(multi_fresh_term,on)}.
% parse_args -->
% 	"--multi_fresh_term=off",
% 	{set(multi_fresh_term,off)}.

% parse_args -->
% 	"--solver=chaff",!,
% 	{set(solver,chaff)}.
% parse_args -->
% 	"--solver=sim",!,
% 	{set(solver,sim)}.
% parse_args -->
% 	"--solver=sato",!,
% 	{set(solver,sato)}.

% % parse_args -->
% % 	"--constraint_metavariables=on",
% % 	{set(constraint_metavariable,on)}.
% % parse_args -->
% % 	"--constraint_metavariables=off",
% % 	{set(constraint_metavariable,off)}.

% % Integer argument
% int_arg(I) --> 
% 	int_arg_code(IC),
% 	{number_chars(I,IC)}.

% int_arg_code([N|Ns]) --> int_arg_digit_code(N),int_arg_code(Ns).
% int_arg_code([N])    --> int_arg_digit_code(N).

% int_arg_digit_code(C) --> [C],{int_arg_digit(C)}.

% int_arg_digit(C)      :- "0"=<C, C=<"9".

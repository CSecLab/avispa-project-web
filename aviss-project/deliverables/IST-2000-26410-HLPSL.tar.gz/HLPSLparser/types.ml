(***********************************************************************)
(*                                                                     *)
(*                                 HLPSL                               *)
(*                                                                     *)
(*                     AVISS Project IST 2000-26410                    *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                                types.ml                             *)
(*                                 Loria                               *)
(*                    specification of the used types                  *)
(***********************************************************************)
(* ----------------
   Main types.
   ---------------- *)

(* ----------------
 type specifying the principal variables to be used.
   ---------------- *)

type type_var =
    User                 (* user id *)
  | FrSyKey              (* fresh symmetric key *)
  | SyKey                (* symmetric key *)
  | FrPcKey of int       (* fresh public key: private key *)
  | FrPeKey of int       (* fresh private key: public key *)
  | PcKey of int         (* public key: private key *)
  | PeKey of int         (* private key: public key *)
  | PcTable of int * int * int   (* table * user * private elt *)
  | PeTable of int * int * int   (* table * user * public elt *)
  | Table                (* table name *)
  | Number               (* number (can be a nonce) *)
  | Function             (* function (never decoded) *)
;;


(* ----------------
 type message
   ---------------- *)
type msg =
    Id of int (* a message can be an integer identifier *)
  | Int of int (* an integer *)
  | Func of int * msg (* a function *)
  | Crypt of int * msg * msg  (* a message crypted with 
                               1: public key, 2: private key, 3: symmetric key *) 
  | Arith of int * msg * msg (* an arithmetic operation *)
  | Logic of int * msg * msg (* a logical operation *)
  | Pair of msg * msg (* a couple *)
;;


(* ----------------
type term
   ---------------- *)

type term = 
    Empty (* empty element *)
  | Var of string (* variable *)
  | Cons of string (* a constant *)
  | Op of string * (term list) (* operation defined by string:mr,fu,tb,pk,sk,nonce... and applied to a list of terms *)
;;


(* ----------------
type rule = Rule of string * Infos.term * Infos.term
rule description * left term * right term
   ---------------- *)

type rule =
   Rule of (string) * (term) * (term)
;;

      
(* ----------------
type goal corresponding to the type of flaw that one looks for.
   ---------------- *)
type goal_type =
    Secrecy_of of string (* the intruder knows a secret information at the end
                            of the protocol *)
  | Corresp_between of string * string (* identification (authentication) flaw between the principals *)
;;


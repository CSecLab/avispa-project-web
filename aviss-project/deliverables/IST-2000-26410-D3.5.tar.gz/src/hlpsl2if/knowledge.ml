(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* Module for the management of user's knowledge *)

open Types;;
open Globals;;
open Utilities;;

let rec can_be_composed knowledgeList mesg = 
  ((List.mem_assoc mesg knowledgeList) or
   (
     match mesg with
	 Pair(part1,part2) ->
      	   ((can_be_composed knowledgeList part1) && (can_be_composed knowledgeList part2))
       | Crypt(3,key,cryptedMessage) ->
	   ((can_be_composed knowledgeList key ) && (can_be_composed knowledgeList cryptedMessage))
       | Crypt(_,key,cryptedMessage) ->
	   ((can_be_composed knowledgeList key) && (can_be_composed knowledgeList cryptedMessage))
       | Arith (operatorNumber,operand1,operand2) -> 
	   ((can_be_composed knowledgeList operand1) && (can_be_composed knowledgeList operand2))
       | Logic (operatorNumber,operand1,operand2) ->
	   ((can_be_composed knowledgeList operand1) && (can_be_composed knowledgeList operand2))
       | Func(identifierNumber,parameter) ->
	   ((can_be_composed knowledgeList (Id(identifierNumber))) && (can_be_composed knowledgeList parameter))
       | TableElement(tableNumber,userNumber,isPrivate) ->
	   ((can_be_composed knowledgeList (Id(tableNumber))) && (can_be_composed knowledgeList (Id(userNumber))))
       | Int(number) -> true
       | Id(identifierNumber) -> false 
   ))
;;
let rec infers_for_know lstmsgs =
  let previous_step = ref ([]:(msg * bool) list) in
  let current_step = ref lstmsgs in
  let has_changed = ref true in
    while (!has_changed) do
      previous_step := !current_step;
      has_changed := false;
      current_step := ([]:(msg * bool) list);
      let insert list_of_msg = 
	(List.iter (fun m -> current_step := (m,false)::!current_step) list_of_msg)
      in
      let can_compose = (can_be_composed !previous_step) in
     	List.iter 
	  (
	    fun (message,was_decomposed) ->
	     if (not was_decomposed) then
	       match message with
		   Pair(part1,part2) ->
      		     (
		       insert [part1;part2];
		       has_changed := true
		     )
		 | Crypt(3,key,cryptedMessage) ->
		     if (can_compose key) then
		       (
			 insert [cryptedMessage];
			 has_changed := true
		       )
		     else
		       current_step := (message,false)::!current_step
		 | Crypt(_,key,cryptedMessage) ->
		     if (can_compose (key_of key)) then
		       if (can_compose key) then
			 (
			   insert [cryptedMessage];
			   has_changed := true
			 )
		       else
			 (
			   insert [cryptedMessage];
			   has_changed := true ;
			   current_step := (message,true)::!current_step
			 )
		     else
		       current_step := (message,false)::!current_step
		 | Arith (operatorNumber,operand1,operand2) -> 
		     if ((can_compose operand1)or(can_compose operand2)) then
		       (
			 insert [operand1;operand2];
			 has_changed := true
		       )
		     else
		       current_step := (message,false)::!current_step
		 | Logic (operatorNumber,operand1,operand2) ->
		     if ((can_compose operand1)or(can_compose operand2)) then
		       (
			 insert [operand1;operand2];
			 has_changed := true
		       )
		     else
		       current_step := (message,false)::!current_step
		 | Func(identifierNumber,parameter) ->
		     current_step := (message,true)::!current_step
		 | TableElement(tableNumber,userNumber,isPrivate) ->  
		     current_step := (message,true)::!current_step
		 | Int(number) -> 
		     current_step := (message,true)::!current_step			       
		 | Id(identifierNumber) ->
 		     current_step := (message,true)::!current_step
	     else
	       current_step := (message,true)::!current_step
	  )
	  !previous_step;
    done;
    !current_step
;;
let rec compute_know_of_user userNumber step =
  match step with
      0 ->
	(try( [
		(0,
		 infers_for_know (( List.map (fun x -> (Id(x),true)) (List.assoc userNumber !Globals.ident_knowledge) )@ ( List.map (fun x ->(x,false)) (List.assoc userNumber !Globals.init_msg_knowledge) ))) ])
	 with not_found->
	   [(0,( List.map (fun identifierNumber -> (Id(identifierNumber),true)) (List.assoc userNumber !Globals.ident_knowledge)))])
    | protocolStep -> 
	let previousKnowledge = compute_know_of_user userNumber (protocolStep-1) in
	let lastKnowledge = ref (List.assoc (protocolStep-1) previousKnowledge) in
      	let ((sender,receiver),msg) = List.assoc protocolStep !Globals.msg_list in
	  
	(*
	  add_if_unknown : add msg in lastKnowledge if it doesn't already exists
	*)
	let add_if_unknown mesg isDecomposed =
	  if not (can_be_composed !lastKnowledge mesg ) then lastKnowledge := (mesg,isDecomposed)::!lastKnowledge
	in
	  if userNumber = receiver then
	    (add_if_unknown (Id(sender)) false;
	       add_if_unknown msg false)
	  else 
	    if userNumber = sender then
	      List.iter 
		(fun identifierNumber -> add_if_unknown (Id(identifierNumber)) true)
        	(fresh_var protocolStep);
	  (protocolStep, infers_for_know (!lastKnowledge))::previousKnowledge
;;

let rec know message userNumber protocolStep =
  try
    (* We extract the (message * bool) list part of the knowledge list corresponding  to 
   user [userNumber] at step [protocolStep] and we apply list.exists to verify that 
   at least one known message is equal to message *)
    List.exists (fun (m,x) -> m = message) (List.assoc protocolStep (List.assoc userNumber !knowledge))
  with
      Not_found -> (let errorMessage= ("Step : "^string_of_int(protocolStep)^"; user : "^(Utilities.get_identifier_name userNumber)) in
		      ErrorHandler.printExceptionMessage (Failure errorMessage) "Rules" "know";exit(-1))
;;

let compute_know () =
  for_all_user (fun userNumber -> knowledge := (userNumber,compute_know_of_user userNumber !Globals.nbMsgs)::!knowledge)
;;
(* ex check_comp function *)
let rec check_know_components protocolStep senderNumber messageToCompose = match messageToCompose with
  | Pair(couplePart1,couplePart2) -> (know messageToCompose senderNumber protocolStep) 
      || ((check_know_components protocolStep senderNumber couplePart1) && (check_know_components protocolStep senderNumber couplePart2))
  | Crypt(_,key,cryptedMessage) -> (know messageToCompose senderNumber protocolStep)
      || ((check_know_components protocolStep senderNumber key) && (check_know_components protocolStep senderNumber cryptedMessage))
  | Func(functionNumber,parameterMessage) -> (know messageToCompose senderNumber protocolStep) 
      || ((check_know_components protocolStep senderNumber (Id(functionNumber))) && (check_know_components protocolStep senderNumber parameterMessage))

  | TableElement(tableNumber,userNumber,_) -> (know messageToCompose senderNumber protocolStep)
      || ((check_know_components protocolStep senderNumber (Id(tableNumber))) && (check_know_components protocolStep senderNumber (Id(userNumber))))

  | Arith(_,operand1,operand2) -> (know messageToCompose senderNumber protocolStep) 
      || ((check_know_components protocolStep senderNumber operand1) && (check_know_components protocolStep senderNumber operand2))
  | Logic(_,operand1,operand2) -> (know messageToCompose senderNumber protocolStep) 
      || ((check_know_components protocolStep senderNumber operand1) && (check_know_components protocolStep senderNumber operand2))
  | Id(identifierNumber) -> (know (Id(identifierNumber)) senderNumber protocolStep)
  | Int(_) -> true
;;

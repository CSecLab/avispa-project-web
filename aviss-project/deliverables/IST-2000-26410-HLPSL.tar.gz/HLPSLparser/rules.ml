(***********************************************************************)
(*                                                                     *)
(*                                 HLPSL                               *)
(*                                                                     *)
(*                     AVISS Project IST 2000-26410                    *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                                                                     *)
(*                              rules.ml                               *)
(*                                 Loria                               *)
(*             Management of the protocols to be studied               *)
(***********************************************************************)
open Globals;;
open Types;;
open Utilities;;
open Interface;;

(* ----------------
   msg_to_atoms : msg -> msg list
   Input: a message (by the principals).
   Output: a list of messages.(cf files Infos)
   Role: decompose a message recursively in his atomic components.
   Use: union(ml) to build a list of atoms from two sub-lists
   Rem: transform a term in teh list of his atoms like for this example.
       c(mr(a),scrypt(sk(a),nonce(b))) -> ([mr(a)] [sk(a)] [nonce(b)])
   ---------------- *)
let rec msg_to_atoms = function
   Pair(m1,m2) -> union (msg_to_atoms m1) (msg_to_atoms m2)
 | Crypt(_,k,m) -> union (msg_to_atoms k) (msg_to_atoms m)
 | Func(f,m) -> union (msg_to_atoms (Id(f))) (msg_to_atoms m)
 | Arith(_,m1,m2) -> union (msg_to_atoms m1) (msg_to_atoms m2)
 | Logic(_,m1,m2) -> union (msg_to_atoms m1) (msg_to_atoms m2)
 | Int(i) -> []
 | Id(i) -> [Id(i)]
;;


(* ----------------
   pour_tout_user : (int -> unit) -> unit
   Input: function to be applied
   Output: 
   Role:  Apply the function f to each principal (used in the calculus and the 
          update of the knowledges of ech principal)
   Use:
   Rem:
   ---------------- *)
let pour_tout_user f =
   List.iter (fun (id,(s,t)) -> match t with
                | User -> (f id)
                | _ -> ())
             !ident_list
;;


(* ----------------
   nbofId : msg -> int
   Input: a message
   Output: the number corresponding to the identifier contained in the message 
           in output
   Role: give the number corresponding to an identifier.
   Rem: (old doc) find the list of fresh variables in each message. 	
        A first algorithm for the typing is :
	if a variable is fresh in an expected message, don't type it.
	else, look for its type.
	-> does not work for more than 2 principals.
   ---------------- *)
let nbofId = function
   Id(i) -> i 
 | _ -> print_endline "nbofId: Not an ident";exit(-1)
;;


(* ----------------
   comp_fresh : unit -> unit
   Input:
   Output:
   Role: Calcule la liste des variables fraiches.
   Use:
	val fold_left : f:('a -> 'b -> 'a) -> init:'a -> 'b list -> 'a
        (* [List.fold_left f a [b1; ...; bn]] is
           [f (... (f (f a b1) b2) ...) bn]. *)
	 val mem : 'a -> 'a list -> bool
        (* [mem a l] is true if and only if [a] is equal
           to an element of [l]. *)
   Rem: val msg_list : (int * ((int * int) * msg)) list ref
 	val fresh : (int * int list) list ref
   ---------------- *)
let comp_fresh () =

let persistent_var = ref[] in

   let init_persistent_var =
      ref (List.fold_left (fun lv (_,l) -> lv@l) [] !ident_knowledge)
   in

List.iter(fun v ->
  match (getIdentType v) with 
                     PcKey(v2) -> persistent_var:=!persistent_var@[v]@[v2];
                   | FrPcKey(v2) -> persistent_var:=!persistent_var@[v]@[v2];
                   | PeKey(v2) -> persistent_var:=!persistent_var@[v]@[v2];
                   | FrPeKey(v2) -> persistent_var:=!persistent_var@[v]@[v2];
                   | _ ->persistent_var:=!persistent_var@[v])!init_persistent_var;


     fresh := [(0,[])];(*initialisation de la liste des variables fraiches*)
     for i=1 to !nbMsgs do
        let msg = snd (List.assoc i !msg_list) (* message de l'�tape i *)
        in
          let fr =
         List.fold_left (fun lf v ->
	         if List.mem v !persistent_var 
		    then lf    (*TODO*)
                 else
                    match (getIdentType v)
                    with PcKey(v2) -> v::v2::lf
                       | FrPcKey(v2) -> v::v2::lf
                       | PeKey(v2) -> v::v2::lf;
                       | FrPeKey(v2) -> v::v2::lf
                       | _ -> v::lf)
                [] (List.map nbofId (msg_to_atoms msg))
          in
  (*print_string "Fresh in msg "; print_int i; print_string ":  "; List.iter (fun n -> print_ident n; print_string " ") fr; print_newline();*)
      	    fresh := (i,fr)::!fresh;
	    persistent_var := fr@(!persistent_var)
     done      
;;


(* ----------------
   know : msg -> int -> int -> bool
   Input: message,used, N� of step
   Output: boolean indicating if the message msg is in the knowledge of u at step i
   Role: verify if the message msg is in the knowledge of u at step i
   Use:
		val exists : f:('a -> bool) -> 'a list -> bool
	   (* [exists p [a1; ...; an]] checks if at least one element of
       the list satisfies the predicate [p]. That is, it returns
       [(p a1) || (p a2) || ... || (p an)]. *)
   Rem: (old doc) use the knowledge list built above with infers_for_know
         to see if msg is know by u at step i
   ---------------- *)
let rec know msg u i =
  try
(* Extract the fields (msg * bool) list of the list of knowledge corresponding
   to the user u and the step iand apply list.exists to verift that at least one
   known message connu is equal to msg*)
    List.exists (fun (m,x) -> m = msg) (List.assoc i (List.assoc u !knowledge) )
  with
      Not_found ->
(* Print an error message *)
	print_string "etape : ";
	print_int i;
	print_newline();
	print_string "user : ";
	print_string (getIdentId u);
	print_newline();
	print_endline "erreur !";
	exit(-1)
;;


(* ----------------
   ajoute_type_def : int -> term -> term
   Input: entier
   Output:
   Role:
   Use:
   Rem: only one nonce can be created in a message
---------------- *)
let rec ajoute_type_def i = function
(* FOR DEBUG print_string "ajoute_type_def: msg "; print_int i;*)
    Op("mr",l) as r -> (*pdb " -> op mr";*) r
  | Op("fu",l) as r -> (*pdb " -> op fu";*) r
  | Op("tb",l) as r -> (*pdb " -> op tb";*) r
  | Op("pk",l) as r -> (*pdb " -> op pk";*) r
  | Op("sk",l) as r -> (*pdb " -> op sk";*) r
  | Op("nonce",l) as r -> (*pdb " -> op nonce";*) r
  | Op(s,l) -> Op(s, (List.map (ajoute_type_def i) l))
  | Var("etc") as r -> (*pdb " -> op etc";*) r
  | Var("etc2") as r -> (*pdb " -> op etc2";*) r
  | Var(s) -> (*pdb (" -> var "^s);*)
      let rec findtype = function
	  [] -> raise Pas_trouve; pdb s ; exit(-1)
  | a::reste -> if fst (snd a) == s then snd (snd a) else findtype reste
      in
	(try
	    let typ = findtype !ident_list
            in
	    let j = if i < !nbMsgs then i+1 else i
            in 
	      if try (j>i) && (List.mem s (List.map getIdentId (fresh_var j)))
                 with Not_found -> print_int i;exit (-1)
	        then
	 	  try ((op_of_type typ) (Var("Time")))
		  with Not_found -> print_string s;exit(-1);(Var(s))  
(* TODO ERREUR: it does not yield anything... *)
 	      else
		begin
		  (Var(s))
	        end
	 with Pas_trouve -> Var(s))
  | x -> x
;;

(* ----------------
   compute_know : unit -> unit
   Input:
   Output:
   Role: Precalculation of the function know.
   Use: val pour_tout_user : (int -> unit) -> unit
    val compute_know_of_user : int -> int -> (int * (msg * bool) list) list
   Rem: val knowledge :(int * (int * (msg * bool) list) list) list ref

   ---------------- *)
let compute_know () = 
   pour_tout_user (fun i ->
(*FOR DEBUG      print_newline(); print_string "User: "; print_ident i;
 List.iter (
     fun (x,m) -> 
   
 FOR DBG   List.iter (fun  y->   print_int(x);print_string("---");print_endline ( string_of_msg y ))m)!init_msg_knowledge;*)

    knowledge := (i, compute_know_of_user i !nbMsgs)::!knowledge)
;;


(* ----------------
   check_receiver : int -> int -> int -> unit
   Input: step,identifier of receiver, identifier of sender,
   Output:
   Role: verify that the receiver is known by the sender at step no..
   Use: know : msg -> int -> int -> bool
           val print_ident : int -> unit (* print an identifier from !ident_list *)
   ---------------- *)
let check_receiver no idFrom idTo =
  if not (know (Id(idTo)) idFrom no) then
    begin
      print_string "  ERROR in Message ";
      print_int no;
      print_string ": ";
      print_ident idFrom;
      print_string " does not know ";
      print_ident idTo;
      print_newline ();
      exit 0
    end
;;


(* ----------------
   check_comp : int -> int -> msg -> bool
   Input: step, identifier of sender, message
   Output: boolean signaling that the message can be composed by the sender
   Role: verify recursively that the sender knows all the components of the 
         message that he is going to send.
   Use: val know : msg -> int -> int -> bool
   ---------------- *)
let rec check_comp no idFrom msg = match msg with (*TODO rename the function *)
  | Pair(m1,m2) -> (know msg idFrom no) || ((check_comp no idFrom m1) && (check_comp no idFrom m2))
  | Crypt(_,k,m) -> (know msg idFrom no) || ((check_comp no idFrom k) && (check_comp no idFrom m))
  | Func(f,m) -> (know msg idFrom no) || ((check_comp no idFrom (Id(f))) && (check_comp no idFrom m))
  | Arith(_,f,g) -> (know msg idFrom no) || ((check_comp no idFrom f) && (check_comp no idFrom g))
  | Logic(_,f,g) -> (know msg idFrom no) || ((check_comp no idFrom f) && (check_comp no idFrom g))
  | Id(i) -> (know (Id(i)) idFrom no)
  | Int(i) -> true
;;
  

(* ----------------
   check_compose : int * ((int * int) * msg) -> unit
   Input: step number, (identifier of sender, identifier of receiver, message)
   Output:
   Role: control function that verifies that the receiver is known by the sender
         and the components of the message that he is going to send.
   Use:check_receiver : int -> int -> int -> unit
       	   check_comp : int -> int -> msg -> bool
   ---------------- *)
let check_compose = function no,((idFrom , idTo), msg) ->
  check_receiver no idFrom idTo;
  if not (check_comp no idFrom  msg) then
    begin
(*      print_knowledge();*)
      print_string "  ERROR in Message ";
      print_int no;
      print_string ": ";
      print_ident idFrom;
      print_string " can not compose ";
      print_msg msg;
      print_newline ();
      exit 0
    end
;;

(* ----------------
   check_proto : unit -> unit
   Input:
   Output:
   Role: verify that each message in the list msg_list can be composed.
   Use: check_compose : int * ((int * int) * msg) -> unit		
			   val iter : f:('a -> unit) -> 'a list -> unit
            (* [List.iter f [a1; ...; an]] applies function [f] in turn to
            [a1; ...; an]. It is equivalent to
            [begin f a1; f a2; ...; f an; () end]. *)
   Rem:   
   ---------------- *)
let check_proto () =
   List.iter check_compose !msg_list
;;

(* ----------------
   compose : int -> msg -> int -> term
   Input: number identifying a user, message, step.
   Output: term
   Role: compose a terme 
   Use:
   Rem:   
   ---------------- *)
(*TODO attention modif not evident to code since the receiver decodes all he can *)

let rec compose u msg i  =
  match msg with
    Pair(m1,m2) ->
      oppair (compose u m1 i) (compose u m2 i)
  | _ -> try (match msg with
      Crypt(3,key,m) ->
	opscrypt (compose u key i) (compose u m i)
    | Crypt(_,key,m) ->
        opcrypt (compose u key i) (compose u m i)
    | Arith (a,m1,m2) -> 
	(oparith_of_nb a) (compose u m1 i) (compose u m2 i)
    | Logic (a,m1,m2) -> 
	(oplogic_of_nb a) (compose u m1 i) (compose u m2 i)
    | Func(f,m) -> 
	opfunct (compose u (Id(f)) i) (compose u m i)
    | Int(i) -> Cons(string_of_int i)
    | Id(j) -> 
        if ((know msg u i)or(!flag_init)) (* flag_init: for the decomposition of teh messages of the initial knowledge *)
        then
          ajoute_type_def i (Var(getIdentId j))
        else
	  
          if (List.mem j (fresh_var (i+1)))
          then
            ajoute_type_def i (Var(getIdentId j))
          else raise Not_found
    | _ -> raise Not_found)
  with Not_found ->
    if ((know msg u i)or(!flag_init)) then(* flag_init: for the decomposition of teh messages of the initial knowledge *)
      begin
	ajoute_type_def i (Var(string_of_msg msg))
      end
    else raise Not_found
	;;

(*TODO rajouter the management of fresh keys ! *)


(* ----------------
   key_of : msg -> msg
   Input: message can contain a key.
   Output: the key (if the function succeeds).
   Role: verify that the message corresponds to a key.
	this allows one to check if a message is crypted correctly.
   Use:val getIdentType : int -> type_var
   ---------------- *)
let key_of msg = match msg with 
    Id(u) -> 
      (
      	match (getIdentType u) with
	  | FrSyKey -> msg
	  | SyKey -> msg
	  | FrPcKey(i) -> (Id(i))
	  | FrPeKey(i) -> (Id(i))
	  | PcKey(i) -> (Id(i))
	  | PeKey(i) -> (Id(i))
	  | PcTable(_,_,i) -> (Id(i))
	  | PeTable(_,_,i) -> (Id(i))
	  | _ -> 
	      print_endline "Error message was not coded with a key";
	      exit(-1)
      )
  | _ ->       
      print_endline "Error message was not coded with a key";
      exit(-1)
;;


(* ----------------
   build : msg -> int -> int -> bool (*TODO rename the function*)
   Input:message, user, step.
   Output: boolean indicating if the pricipal knows all the atoms contained 
           in the messages that he has composed.
   Role: control function allowing one to verify that the components of a 
         message of a principal are all known to him.
   Use: val know : msg -> int -> int -> bool
	    val msg_to_atoms : msg -> msg list
   ---------------- *)
let build m u i =
  let b = ref true in
  List.iter 
    (
      fun msg -> if not (know msg u i) then b := false
    )
    (msg_to_atoms m);
    !b
;;


(* ----------------
   see : int -> msg -> int -> term
   Input: principal, message, step
   Output:
   Role: verify recursively if the message received by a principal u resembles 
         to what he was expecting.
   Use: val know : msg -> int -> int -> bool
            val key_of : msg -> msg
	    val string_of_msg : msg -> string
	    val ajoute_type_def : int -> term -> term
   Rem:   
   ---------------- *)
let rec see u msg i =

match msg with
    Pair(m1,m2) ->
      oppair (see u m1 i) (see u m2 i)
  | Crypt(3,key,m) ->
      if (know key u i) then 
	opscrypt (see u key i) (see u m i)
      else
      	ajoute_type_def i (Var(string_of_msg msg))
  | Crypt(_,key,m) ->
      if (know (key_of key) u i) then 
	opcrypt (see u key i) (see u m i)
      else
      	Var(string_of_msg msg)
  | Func(f,m) ->
      if (know (Id(f)) u i) && (build m u i) then
      	opfunct (see u (Id(f)) i) (see u m i)
      else
	(Var(string_of_msg msg))
  | Arith(a,m1,m2) ->
      (oparith_of_nb a) (see u m1 i) (see u m2 i)
  | Logic(1,m1,m2) ->(* management of XOR*)
      if ( (know m1 u i) or (know m2 u i))
	   then
	 (oplogic_of_nb 1) (see u m1 i) (see u m2 i)
	   else
	 ajoute_type_def i (Var(string_of_msg msg))
  | Logic(a,m1,m2) ->(oplogic_of_nb a) (see u m1 i) (see u m2 i)
  | Int(j) ->
      Cons(string_of_int j)
  | Id(j) ->
 ajoute_type_def i (Var(getIdentId j))
;;


let topNb = ref 0;;

(* ----------------
   newtop : unit -> term
   Input: 
   Output: 
   Role: 
   Use:
   Rem:   
   ---------------- *)
let newtop () = incr topNb;Var("Top"^(string_of_int !topNb));;


(* ----------------
   lexpect : int -> msg -> int -> term
   Input: user, message, step
   Output: a term used in the left part of the rules of the protocol in the 
           function w. 
   Role: compute the parameter term for teh function w designing the body of 
         the expected message.
   Use:
   Rem:
   ---------------- *)
let rec lexpect u msg i =
(*print_msg(msg);print_newline();*)
  match msg with
    Pair(m1,m2) ->
      oppair (lexpect u m1 i) (lexpect u m2 i)
  | Crypt(3,key,m) ->
      if (know key u i) then 
	opscrypt (lexpect u key i) (lexpect u m i)
      else
      	newtop()
  | Crypt(_,key,m) ->
      if (know (key_of key) u i) then 
	opcrypt (lexpect u key i) (lexpect u m i)
      else
	newtop()
  | Func(f,m) ->
      opfunct (lexpect u (Id(f)) i) (lexpect u m i)
  | Arith(a,m1,m2) ->
      (oparith_of_nb a) (lexpect u m1 i) (lexpect u m2 i)
  | Logic(1,m1,m2) ->(* management of XOR*)
      (try oprcrypt (compose u m1 i) (lexpect u m2 i)
      with Not_found->
	try oprcrypt (lexpect u m1 i) (compose u m2 i)
	    with Not_found ->newtop())
  | Logic(a,m1,m2) ->
      (oplogic_of_nb a) (lexpect u m1 i) (lexpect u m2 i)
  | Int(i) ->
      Cons(string_of_int i)
  |m ->
      try compose u m i 
      with Not_found->newtop()
 ;;


(* ----------------
   k : int -> int
   Input:step
   Output:step
   Role: function determining the step at which the receiver of the step in input 
         will receive the next message. If there is none, it output the step of
         the last message sent.
   Use:val get_receiver : int -> int
   ---------------- *)
let k i =
  let j = ref (i+1) in
(*TODO  exploit the paresse of caml ! since otherewise get_receiver fails !!!!*)    
    while (!j <= !nbMsgs) && ((get_receiver !j) <> (get_receiver i)) 
      do
      	incr j
      done;
    if !j > !nbMsgs then
      begin
	 if get_receiver i = get_sender 1 then 0 else
	  begin
      	    j := 1;
      	    while ((get_receiver !j) <> (get_receiver i)) && (!j <= i)
      	    do
	      incr j
      	    done;
	    !j
	  end
	  end
    else
      !j
;;


(* ----------------
   invk : int -> int
   Input: step
   Output: step
   Role: the inverse function of k : int -> int
         Given a step i, it determines the first step with the same receiver.
   Rem: k is bijective.
   ---------------- *)
let invk i =
  let c = ref 0 in
    while k !c <> i 
    do
      incr c
    done;
    !c
;;

(* ----------------
   termlist_of_list : term list -> term
   Input: list of terms 
   Output: a term
   Role: this function builds one single term by combining the terms of a list.
   Use: val oppair : term -> term -> term
   Rem:   
   ---------------- *)
let rec termlist_of_list = function
    [] -> Cons("etc2") (*TODO signification*)
  | [t] -> oppair t (Var("etc"))
  | h::tail -> oppair h (termlist_of_list tail)
;;


(* ----------------
   lknow_init : int -> term
   Input: identifier of a user
   Output:
   Role:
   Use:
   Rem:
   ---------------- *)
let lknow_init u =
   ajoute_type_def 1 (termlist_of_list ((List.map (fun i ->(Var((getIdentId i)))) (List.assoc u !ident_knowledge)) 
		      @ (List.map (fun msg ->compose u msg  0) (try(List.assoc u !init_msg_knowledge) with Not_found->[] ))))
;;
(* ----------------
   lknow_aux : int -> int -> int -> term list
   Input:
   Output:
   Role:
   Use:
   Rem:   
   ---------------- *)
let rec lknow_aux u k = function
    0 -> []
  | 1 ->  if u <> (get_sender 1)
            then []
          else
            List.map (fun x ->
                         Var(getIdentId x))
                     (add_keys(fresh_var 1))
  | i -> 
      if u <> (get_sender i) then
	lknow_aux u k (i-1)
      else
	(lknow_aux u k (i-1))
        @ (sub [ (Var(getIdentId (get_sender (i-1)))); (see u (get_msg (i-1)) k)]
               ((lknow_aux u k (i-1))
                @ (List.map (fun i ->
                                Var(getIdentId i))
                            (List.assoc u !ident_knowledge))
		@(List.map (fun msg ->compose u msg  0) (try(List.assoc u !init_msg_knowledge) with Not_found->[] ))
	       ))
        @ (List.map (fun x ->
                        Var(getIdentId x))
                    (add_keys (fresh_var i)))
;;

(* ----------------
   suppr_double : 'a list -> 'a list
   Input: list
   Output: list
   Role: delete the doubles withing a list (to obtain a Set of distinct elements)
   Use: val sub : 'a list -> 'a list -> 'a list
   ---------------- *)
let rec suppr_double = function
   [] -> []
 | a::reste -> a::(suppr_double (sub reste [a]))
;;


(* ----------------
   lknow : int -> int -> int -> term
   Input: user, step in which the klowledge is used, step in which one wants
          to compute the knowledge.
   Output: term 
   Role: compose the list of the knowledges at level i, knowing that one uses
         what one knew at level k (k>=i)
   Use:
   Rem:   
   ---------------- *)
let lknow u k i =
   termlist_of_list (suppr_double (lknow_aux u k i))
;;


(* ----------------
   un_secret_est_envoye : int -> bool
   Input: step
   Output: boolean indicating if a secret is sent at step i.
   Role: verify if a secret is sent at step i.
   Use:
   Rem:val goal_type : int ref (0:secrecy, 1:correspondence)
   ---------------- *)
let un_secret_est_envoye i =
  if !goal_type <> 0
    then false
  else
    (* compute the number of the first message where the secret appears *)
    let c = ref 1
    in
      while not (List.mem (Id(!secret_goal)) (msg_to_atoms (get_msg !c))) do incr c done;
      !c = i
;;

(* ----------------
   le_secret : int -> term
   Input: 
   Output:
   Role:
   Use:
   Rem:   
   ---------------- *)
let le_secret i =
  ajoute_type_def i (Var(getIdentId !secret_goal))
;;


(* ----------------
   generation of user rules
   ----------------
   build_user_rules : unit -> rule list
   Input:
   Output: list of the rules of the users.
   Role: generation of user rules.
   Use:
   Rem:   
   ---------------- *)
let  build_user_rules () =
  let user_rules = ref []  in
  
    
  let re = get_sender 1 in
  let se = Var("Se0") in
  let msg = Var("Msg0") in
  let iprim0 = if k 0 > 0 then 1 else 0 in

  let wl = (opw 
	      (Cons("0")) 
	      (opmr(se)) 
	      (opmr(Var(getIdentId re)))  
	      (ajoute_type_def 0 (lknow re 0 0))
	      (lknow_init re) 
	      (Var("bool")) 
	      (Var("c"))
	   ) in

  let wr = (opw 
	      (Cons(string_of_int (k 0))) 
	      (compose re (Id(get_sender (k 0))) 0) 
	      (opmr(Var(getIdentId (get_receiver (k 0)))))  
	      (ajoute_type_def 0 (lknow re iprim0 iprim0))
	      (lknow_init re) 
	      (Cons("true")) 
	      (Var("c"))
	   ) in
    
  let mr = (opm 
	      (Cons("1")) 
	      (opmr(Var(getIdentId re))) 
	      (opmr(Var(getIdentId re))) 
	      (compose re (Id(get_receiver 1)) 0) 
	      (compose re (get_msg 1) 0)  
	      (Var("c"))
	   ) in
    
  let leftm = Op(".",[ (oph (ops (Var("Time")))); wl]) in	  

  let rightm = Op(".", (if (un_secret_est_envoye 1) 
			then [ (oph (Var("Time"))); mr; wr; (opsecret (le_secret 0) (opf (Var("c"))))]
			else [ (oph (Var("Time"))); mr; wr])) in
    
    user_rules := (Rule(("# Step 0"),leftm,rightm))::!user_rules;

    
    (* the case i from 1 to n-1 *)
    for i=1 to (!nbMsgs-1) 
    do
      topNb := 0;
      match List.assoc i !msg_list with (se,re),msg ->
	  begin
	    let iprim = if k i > i then i+1 else 0 in
	    let cprim = if  k i > i then Var("c") else ops(Var("c")) in
    let iki = if (invk i) >= i then 0 else (invk i)+1 in
	    let wl = (opw (Cons(string_of_int i)) (opmr(Var(getIdentId se))) (opmr(Var(getIdentId re))) (ajoute_type_def i (lknow re (i+1) iki)) (lknow_init re) (Var("bool")) (Var("c"))) in
	    let sen =  if k i = 0 then (Var("Se0")) else (compose re (Id(get_sender (k i)))i) in
	    let wr = (opw (Cons(string_of_int (k i))) sen (opmr(Var(getIdentId re))) (ajoute_type_def i (lknow re iprim iprim)) (lknow_init re) (Cons ("true")) cprim) in
  	    let ml = (opm (Cons(string_of_int i)) (opmr(Var("r"))) (opmr(Var(getIdentId se))) (opmr(Var(getIdentId re))) (see re msg i)  (Var("c2"))) in
	    let mr = (opm (Cons(string_of_int (i+1))) (opmr(Var(getIdentId re))) (opmr(Var(getIdentId re))) (compose re (Id(get_receiver (i+1))) i) (compose re (get_msg (i+1)) i)   (Var("c2"))) in
    	    let leftm = Op(".", [ (oph (ops (Var("Time")))); ml; wl]) in	  
	    let rightm = Op(".", (if (un_secret_est_envoye (i+1)) 
				  then [ (oph(Var("Time"))); mr; wr; (opsecret (le_secret i) (opf (Var("c"))))]
				  else [ (oph(Var("Time"))); mr; wr])) in
	      user_rules := !user_rules@[(Rule(("# Step "^(string_of_int i)),leftm,rightm))];
	  end;
    done;

    topNb := 0;
    (
    match List.assoc !nbMsgs !msg_list with (se,re),msg ->
      let i = !nbMsgs in
      let iprim = if  k i > i then i+1 else 0 in
      let iki = if (invk i) >= i then 0 else (invk i)+1 in
      let cprim = if  k i > i then Var("c") else ops(Var("c")) in
      let l1 = (lexpect re msg i) in
      let l2 = (ajoute_type_def i (lknow re i iki)) in
      let l3 = (lknow_init re) in
      let wl = (opw 
		  (Cons(string_of_int i)) 
		  (opmr(Var(getIdentId se))) 
		  (opmr(Var(getIdentId re))) 
		  l2 
		  l3 
		  (Var("bool")) 
		  (Var("c"))
	       ) in
	let l1 = if k i <> 0 then (compose re (Id(get_sender (k i))) i) else Var("Se0") in
	let l2 = (opmr(Var(getIdentId re))) in
      let wr = (opw
		  (Cons(string_of_int (k i))) 
		  l1 
		  l2 
		  (ajoute_type_def i (lknow re iprim iprim))
		  (lknow_init re) 
		  (Cons("true")) 
		  cprim
	       ) in

      let ml = (opm 
		  (Cons(string_of_int i)) 
		  (opmr(Var("r"))) 
		  (opmr(Var(getIdentId se))) (opmr(Var(getIdentId re))) (see re msg i)  (Var("c2"))
	       ) in

      let leftm = Op(".",[ (oph( ops (Var("Time")))); ml; wl]) in	  

      let rightm = Op(".",[ (oph (Var("Time"))); wr]) in

      	user_rules := (!user_rules)@[(Rule(("# Step "^(string_of_int i)),leftm,rightm))]
    );
    !user_rules;
;;



(* ----------------
   pour_tout_user_sauf_intrus : (int -> unit) -> unit
   Input: function havin a user identifier in input
   Output:
   Role: apply a function f in input to all users except the intruder.
   ---------------- *)
let pour_tout_user_sauf_intrus f = 
List.iter
  (
    fun (id,(s,t)) -> match t with
      | User -> if s <> "I" then (f id) else ()
      | _ -> ()
  )
!ident_list
;;


(* ----------------
   build_init_state : unit -> rule
   Input:
   Output:rule relative to the initial state.
   Role: generation of the initial state (cf Initial state in the specification 
         article) 
   Use:
   Rem: the test of except the intruder does not work if the intruder takes part 
        in a normal session --- bug to be removed!  
   ---------------- *)
let  build_init_state () =
  let linit = ref [] in
  let c = ref 1 in
  List.iter
    (
     fun inst -> pour_tout_user_sauf_intrus 
	 (
	  fun u ->
	    let fs = firstS u - 1 in
(* put in v the list of typed instances of the knowledges of the user u *)
	    let v = List.map (fun x -> ((op_of_type (getIdentType x)) (Cons (List.assoc x inst)) )) (List.assoc u !ident_knowledge) in

(* the intruder inherits the knowledge of a user if he is in that instance *)
	    if ((List.assoc u inst)="I")
	    then
	      List.iter (fun x -> if (List.mem (opi(x)) !intruder_knowledge = false) then intruder_knowledge:=!intruder_knowledge @ [opi(x)]) v ;

	    let vs = 
	      if fs<>0 
	      then Cons (List.assoc (get_sender fs) inst) 
	      else Var ("Se0"^string_of_int !c) in
	    let vr = 
	      if fs<>0 
	      then Cons (List.assoc (get_receiver fs) inst) 
	      else Cons (List.assoc (get_sender 1) inst) in
	    let li = 
	      if fs<>0 
	      then lknow_init (get_receiver fs) 
	      else Var ("Know0"^string_of_int !c) in
	    let w = (opw 
		       (Cons(string_of_int fs)) 
		       (opmr(vs)) 
		       (opmr(vr)) 
		       (Cons("etc2")) 
		       (termlist_of_list (v @ (List.map (fun msg ->replaceByInstance(compose u msg  0) inst) (try(List.assoc u !init_msg_knowledge) with Not_found->[] ))))
		       (Cons("true")) 
		       (Cons(string_of_int !c))
		    ) in
            match vr with
	      Cons "I" -> ()
	    | _ -> linit := w::!linit;
	 );
       incr c
    )
    !session_instances;

  Rule("# Initial state",
       Empty,
       (Op (".", ((oph (Var("Time")))::!linit)@(!intruder_knowledge)))
      )
;;


(* ----------------
   build_simplification_rules : rule list
   Input:
   Output:
   Role:
   Use:
   Rem:   
   ---------------- *)
let build_simplification_rules = 
  [ (Rule
       ("# Idempotence",
	(Op(".",[ (Var "1"); (Var "1") ])),
	(Var "1")));
    (Rule
       ("# for Secrecy goal",
	(opf (ops (Var "1"))),
	(opf (Var "1"))))      
  ]
;;


(* ----------------
   call_parser : in_channel -> int
   Input:
   Output:
   Role: call of the parser and error handling
   Use:
   Rem:   
   ---------------- *)
let call_parser channel =
  (try (let lexbuf = Lexing.from_channel channel
  in
  Parser_proto.protocol Lexer_proto.token lexbuf)
  with Parsing.Parse_error ->
    if !cpt_err = 0
    then cpt_err := 1;
    print_string "  Syntax error(";
    print_int !no_err;
    print_string ") line ";
    print_int !cpt_line;
    match !no_err
    with 
      0 -> print_endline ": missing PROTOCOL keyword"
    | 1 -> print_endline ": missing protocol name after PROTOCOL"
    | 2 -> print_endline ": missing semi-colon after protocol name"
    | 3 -> print_endline ": missing IDENTIFIERS keyword"
    | 4 -> print_endline ": missing KNOWLEDGE or MESSAGES keyword"
    | 5 -> print_endline ": missing MESSAGES keyword"
    | 6 -> print_endline ": missing colon in declaration"
    | 7 -> print_endline ": missing semi-colon at the end of a declaration of variables"
    | 8 -> print_endline ": missing KNOWLEDGE keyword"
    | 9 -> print_endline ": missing comma in a list of identifiers"
    | 10 -> print_endline ": missing/wrong type in variable declarations"
    | 11 -> print_endline ": missing comma or colon in knowledge declaration"
    | 12 -> print_endline ": missing comma or semi-colon in a list of knowledges"
    | 13 -> print_endline ": missing identifier name in list"
    | 14 -> print_endline ": missing identifier name in list or MESSAGES keyword"
    | 15 -> print_endline ": missing identifier name in list or KNOWLEDGE keyword"
    | 16 -> print_endline ": missing index of message"
    | 17 -> print_endline ": missing dot after index of message"
    | 18 -> print_endline ": missing sender name in message"
    | 19 -> print_endline ": missing arrow after sender name"
    | 20 -> print_endline ": missing receiver name in message"
    | 21 -> print_endline ": missing colon after receiver name"
    | 22 -> print_endline ": missing SESSION_INSTANCES keyword"
    | 23 -> print_endline ": missing squared bracket in session instance"
    | 24 -> print_endline ": bad definition of INTRUDER strategy"
    | 25 -> print_endline ": missing INTRUDER, INTRUDER_KNOWLEDGE or GOAL keyword"
    | 26 -> print_endline ": bad definition of GOAL strategy"
    | 27 -> print_endline ": bad parallel declaration"
    | 28 -> print_endline ": bad secret declaration"
    | 29 -> print_endline ": bad xor use"

    | _ -> print_endline ": unknown");
  !cpt_err
    ;;

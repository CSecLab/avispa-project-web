{--------------------------------------------------------
| If2ofmc.hs                                            |
|--------------------------------------------------------
| Translator from IF to Haskell for on-the-fly model checking
|
| $Author: moedersh $
| $Revision: 1.13 $ of $Date: 2002/02/11 13:17:25 $
| [imported from personal repository 
|  on revision 1.17 at 2001/07/13]
|
| Overview:
| ---------
| (1) AST: Abstract Syntax Tree (for IF)
| (2) Parser for IF (Producing AST-type data)
| (3) Evaluations and transformations necessary on the AST
| (4) Pretty printer producing the Haskell code
|------------------------------------------------------}

module If2ofmc where
import Stddef
import Data

infixl 5 >.>

{-------------------------------------
   PART (1): AST for IF
 -------------------------------------
 Note: We rely on the input consisting 
 of well-formed IF-Terms only.
 -------------------------------------}

type Variable = String
type Atom     = String

data Message 
     = PVariable Variable
     | PMr Atom
     | PPk Message
     | PPk' Message
     | PSk Message
     | PNonce Message
     | PCrypt Message Message
     | PScrypt Message Message
     | PC Message Message
     | SessionNr Int
     | SuccSession Message
     | Step Int
     | StepTerm Variable
     | PAtom String
     | Etc
     | Ptable Message
     | Ptb Message Message 
     | Ptb' Message Message
     | Pfu Message
     | Pfunct Message Message
     | PRcrypt Message Message
     deriving (Eq, Show)

getvarsmsg :: Message -> [String]
getvarsmsg m =
 case m of 
  PMr a -> if (ifkey "x" a) then [a] else []
  PVariable v -> if (ifkey "x" v) then [v] else []
  PC m1 m2 -> (getvarsmsg m1) ++ (getvarsmsg m2)
  PCrypt m1 m2  -> (getvarsmsg m1) ++ (getvarsmsg m2)
  PScrypt m1 m2  -> (getvarsmsg m1) ++ (getvarsmsg m2)
  PNonce m1 -> getvarsmsg m1
  PPk m1 -> getvarsmsg m1
  PPk' m1 -> getvarsmsg m1
  PSk m1 -> getvarsmsg m1
  SuccSession m1 -> getvarsmsg m1
  Ptable m1 -> getvarsmsg m1
  Ptb m1 m2 ->  (getvarsmsg m1) ++ (getvarsmsg m2)
  Ptb' m1 m2 ->  (getvarsmsg m1) ++ (getvarsmsg m2)
  Pfu m1 -> getvarsmsg m1
  Pfunct m1 m2 ->  (getvarsmsg m1) ++ (getvarsmsg m2)
  PRcrypt m1 m2 ->  (getvarsmsg m1) ++ (getvarsmsg m2)
  _ -> []

data MBool = MTrue
           | MFalse
           | MVar String deriving (Eq,Show)

data Term 
     = PW Message Message Message Message Message MBool Message
     | PM Message Message Message Message Message Message
     | I Message 
     | Subst String String
     | PSecret Message Message
     | PGive Message Message
     | PRequest Message Message Message Message
     | PWitness Message Message Message Message
     deriving (Eq, Show)

type PState = [Term]

data PRule
     = Initial PState
     | MsgRule PState PState
     | Flaw PState 
     deriving (Eq, Show)

{-------------------------------------
   PART (2): Parser: IF -> AST
 -------------------------------------}

type Parser t = String -> (t, String)

predchar :: (Char -> Bool) -> Parser Char
predchar p (x:xs) = if (p x) then (x,xs) else error ("Something else expected")
predchar p [] = error "Unexpected EOF"

keychar :: Char -> Parser Char
keychar c l = predchar (== c) l

mklistparser :: Parser t -> Parser [t]
mklistparser pa str = let (p,str') = pa str in ([p],str')

pconcat :: Parser [t] -> Parser [t] -> Parser [t]
pconcat p1 p2 str = 
       let (p1',str') = p1 str in 
	   let (p2', str'') = p2 str' in
	       ((p1'++p2'),str'')

keyword :: String -> Parser String
keyword key = foldl pconcat (\x -> ([],x)) (map (mklistparser . keychar) key)

consume :: String -> String -> String
consume key str = let (_,rest) = keyword key str in rest

parse_after :: Parser t -> String -> String -> (t,String)
parse_after  p eingabe key = let (ps,rest) = p eingabe in 
                             (ps, consume key rest)

ifkey :: String -> String -> Bool
ifkey [] _ = True
ifkey (x:xs) [] = False
ifkey (x:xs) (y:ys) = (x==y) && (ifkey xs ys)

aslongas :: (Char -> Bool) -> Parser String
aslongas p [] = ([],[])
aslongas p (x:xs) = 
	 if (p x) then let (str,rest) = aslongas p xs in (x:str, rest)
	 else ([], x:xs)

pAtom :: Parser Atom
pAtom str = 
  let str' = if (ifkey "id" str) then consume "id" str else str in
  aslongas (\x -> myAlphanum x || x=='\'') str'

pVariable :: Parser Variable
pVariable = pconcat (keyword "x") pAtom

applFrst :: Parser t -> (t->s) -> Parser s
applFrst p f inp = let (ps,r)= p inp in (f ps, r)

pMessage :: Parser Message
pMessage inp =
  if (ifkey "x" inp) then applFrst pVariable PVariable inp
  else if (ifkey "mr" inp) then parse_after (applFrst pAtom PMr) (consume "mr(" inp) ")" 
  else if (ifkey "pk(" inp) then 
         let (ps,rest)=parse_after pMessage (consume "pk(" inp) ")" in
	   if (ifkey "'" rest) then
	    (PPk' ps, consume "'" rest)
	    else (PPk ps,rest)
  else if (ifkey "sk(" inp) then 
         parse_after (applFrst pMessage PSk) (consume "sk(" inp) ")"	 
  else if (ifkey "nonce(" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "nonce(" inp) ")" in
        (PNonce msg1, rest)
  else 
    if (ifkey "crypt(" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "crypt(" inp) "," in
        (parse_after (applFrst pMessage (\x -> PCrypt msg1 x)) rest ")")
  else 
    if (ifkey "scrypt(" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "scrypt(" inp) "," in
        (parse_after (applFrst pMessage (\x -> PScrypt msg1 x)) rest ")")
  else
    if (ifkey "c(" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "c(" inp) "," in
        (parse_after (applFrst pMessage (\x -> PC msg1 x)) rest ")")
  else if (ifkey "etc2" inp) then (Etc,(consume "etc2" inp)) 
  else if (ifkey "etc" inp) then (Etc,(consume "etc" inp)) 
  else if (ifkey "table(" inp) then
      parse_after pMessage (consume "table(" inp) ")"
  else if (ifkey "tb(" inp) then
         let (ps,rest)=parse_after pMessage (consume "tb(" inp) "," 
	     (ps',rest')=parse_after pMessage rest ")" in
	   if (ifkey "'" rest') then
	    (Ptb' ps ps', consume "'" rest')
	    else (Ptb ps ps',rest')
  else if (ifkey "fu(" inp) then
          parse_after (applFrst pMessage Pfu) (consume "fu(" inp) ")"
  else if (ifkey "funct(" inp) then
      let (msg1,rest) = parse_after pMessage (consume "funct(" inp) "," in
        (parse_after (applFrst pMessage (\x -> Pfunct msg1 x)) rest ")")
  else if (ifkey "rcrypt(" inp) then
      let (msg1,rest) = parse_after pMessage (consume "rcrypt(" inp) "," in
        (parse_after (applFrst pMessage (\x -> PRcrypt msg1 x)) rest ")")
  else
    let (atom,rest)=pAtom inp in
      if (ifkey "x" atom) then (PVariable atom,rest)
      else (PAtom atom,rest)

pInt :: Parser Int
pInt str = let (num,rest) = aslongas myIsDigit str in (read num, rest)


pSession :: Parser Message
pSession inp =
  if (ifkey "x" inp) then 
    let (var,rest) = pVariable inp in 
      (PVariable var,rest)
  else if (ifkey "para" inp) then
    (SessionNr (-1),consume "para" inp)
  else if (ifkey "s" inp) then
    let (term,rest)=pSession (consume "s(" inp) in
      (SuccSession term, consume ")" rest)  
  else applFrst pInt SessionNr inp

pSecret :: Parser Message
pSecret inp =
  if (ifkey "f" inp) then
    let (msg,rest) = pSecret (consume "f(" inp) in 
      (msg,consume ")" rest)   
  else if (ifkey "x" inp) then 
    let (var,rest) = pVariable inp in 
      (PVariable var,rest)
  else if (ifkey "para" inp) then
    (SessionNr (-1), consume "para" inp)
  else if (ifkey "s" inp) then
    let (term,rest)=pSecret (consume "s(" inp) in
      (SuccSession term, consume ")" rest)  
  else applFrst pInt SessionNr inp

pStep :: Parser Message
pStep str = 
  if (ifkey "x" str) then
    let (var,rest) = pVariable str in (StepTerm var,rest)
  else let (num,rest) = aslongas myIsDigit str 
       in (Step (read num), rest)

pBool :: Parser MBool
pBool str =
  if (ifkey "true" str) then (MTrue,consume "true" str)
  else if (ifkey "false" str) then (MFalse,consume "false" str)
       else if (ifkey "x" str) then 
                  let (name,rest) = pAtom str in (MVar name, rest)
            else error "Corrupted Bool"

pTerm :: Parser Term
pTerm inp =
  if ifkey "witness" inp then 
    let (sender,rest1) = pMessage (consume "witness(" inp)
	(receiv,rest2) = pMessage (consume "," rest1)
	(identi,rest3) = pMessage (consume "," rest2)
	(termli,rest4) = pMessage (consume "," rest3) in
    (PWitness sender receiv identi termli, consume ")" rest4)
  else if (ifkey "w" inp) then 
    let (step,rest)=pStep (consume "w(" inp) in
    let (sender,rest2)=pMessage (consume "," rest) in
    let (receiver,rest3)=pMessage (consume "," rest2) in
    let (acknow,rest4)=pMessage (consume "," rest3) in
    let (know,rest5)=pMessage (consume "," rest4) in
    let (bool,rest6)=pBool (consume "," rest5) in
    let (sc,rest7)=pSession (consume "," rest6) in
    (PW step sender receiver acknow know bool sc, consume ")" rest7)
  else if (ifkey "m" inp) then 
    let (step,rest)=pStep (consume "m(" inp) in
    let (rlsender,rest2)=pMessage (consume "," rest) in
    let (ofsender,rest3)=pMessage (consume "," rest2) in
    let (receiver,rest4)=pMessage (consume "," rest3) in
    let (contents,rest5)=pMessage (consume "," rest4) in
    let (sc,rest6)=pSession (consume "," rest5) in
    (PM step rlsender ofsender receiver contents sc, consume ")" rest6)
  else if (ifkey "i" inp) then
    let (know,rest)=pMessage (consume "i(" inp) in
    (I know, consume ")" rest)
  else if ifkey "secret" inp then
    let (secterm,rest) = pMessage (consume "secret(" inp) in
    let (sessterm,rest') = pSecret (consume "," rest) in
    (PSecret secterm sessterm, consume ")" rest')
  else if ifkey "give" inp then
    let (secterm,rest) = pMessage (consume "give(" inp) in
    let (sessterm,rest') = pSecret (consume "," rest) in
    (PGive secterm sessterm, consume ")" rest')
  else if ifkey "request" inp then 
    let (sender,rest1) = pMessage (consume "request(" inp)
	(receiv,rest2) = pMessage (consume "," rest1)
	(identi,rest3) = pMessage (consume "," rest2)
	(termli,rest4) = pMessage (consume "," rest3) in
    (PRequest sender receiv identi termli, consume ")" rest4)
  else error ("The parser is very confused now."++(thefirst 20 inp))

thefirst 0 _ = []
thefirst _ [] = []
thefirst n (x:xs) = x:(thefirst n xs)

pState :: Parser PState
pState inp =
  let (fact,rest)=pTerm inp in
  if (ifkey "." rest) then 
     let (state,rest2)=pState (consume "." rest) in (fact:state,rest2)
  else ([fact],rest)

pk_scan :: PRule -> PRule
pk_scan rule = handle_privates (map remlast (cont_priv rule)) rule

handle_privates :: [String] -> PRule -> PRule
handle_privates [] r = r
handle_privates (x:xs) rule = 
  let rule' = if (contains rule x) 
              then (psubstitute (psubstitute rule x (PPk (PVariable x))) (x++"'") (PPk' (PVariable x)))
	      else rule 
  in handle_privates xs rule'

cont_priv :: PRule -> [String]
cont_priv (Initial state) = flatten (map contTermpriv state)
cont_priv (MsgRule lhs rhs) = flatten ((map contTermpriv lhs )
				 ++ (map contTermpriv  rhs))
cont_priv (Flaw state) = cont_priv (Initial state)

contTermpriv :: Term -> [String]
contTermpriv (PW _ _ _ m4 m5 _ _) = (contMsgPriv m4) ++ (contMsgPriv m5)
contTermpriv (PM _ _ _ _ m5 _) = (contMsgPriv m5)
contTermpriv (I m) = (contMsgPriv m)
contTermpriv (Subst t1 t2) = []
contTermpriv (PSecret m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contTermpriv (PGive m1 m2)  = (contMsgPriv m1) ++ (contMsgPriv m2)
contTermpriv (PRequest m1 m2 m3 m4) = flatten (map contMsgPriv [m1,m2,m3,m4])
contTermpriv (PWitness m1 m2 m3 m4) = flatten (map contMsgPriv [m1,m2,m3,m4])

privname :: String -> Bool
privname [] = False
privname "'" = True
privname (x:xs) = privname xs

contMsgPriv :: Message -> [String]
contMsgPriv (PVariable v) = if (privname v) then [v] else []
contMsgPriv (PMr v) =  if (privname v) then [v] else []
contMsgPriv (PPk v) =  contMsgPriv v --- if (privname v) then [v] else []
contMsgPriv (PPk' v) =  contMsgPriv v --- if (privname v) then [v] else []
contMsgPriv (PSk v) =  contMsgPriv v --- if (privname v) then [v] else []
contMsgPriv (PCrypt m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (PScrypt m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (PC m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (SessionNr m) = []
contMsgPriv (SuccSession m) = contMsgPriv m
contMsgPriv (Step m) = []
contMsgPriv (StepTerm m) = []
contMsgPriv (Ptable m) = contMsgPriv m
contMsgPriv (Pfu m) = contMsgPriv m
contMsgPriv (Ptb m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (Ptb' m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (Pfunct m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (PRcrypt m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)

contMsgPriv _ = []

contains :: PRule -> String -> Bool
contains (Initial state) term = (filter (contTerm term) state)/=[]
contains (MsgRule lhs rhs) term = (filter (contTerm term) lhs)/=[] 
				  || (filter (contTerm term) rhs)/=[]
contains (Flaw state) term = contains (Initial state) term

contTerm :: String -> Term -> Bool
contTerm term (PW _ _ _ m4 m5 _ _) = (contMsg term m4) || (contMsg term m5)
contTerm term (PM _ _ _ _ m5 _) = (contMsg term m5)
contTerm term (I m) = (contMsg term m)
contTerm term (Subst t1 t2) = False
contTerm term (PSecret m1 m2) = (contMsg term m1) || (contMsg term m2)
contTerm term (PGive m1 m2) = (contMsg term m1) || (contMsg term m2)
contTerm term (PRequest m1 m2 m3 m4) = foldr (||) False (map (contMsg term) [m1,m2,m3,m4])
contTerm term (PWitness m1 m2 m3 m4) = foldr (||) False (map (contMsg term) [m1,m2,m3,m4])

contMsg :: String -> Message -> Bool
contMsg s (PVariable v) = s==v
contMsg s (PMr m) = s==m
contMsg s (PPk p) = contMsg s p
contMsg s (PPk' p) = contMsg s p
contMsg s (PSk s') = contMsg s s'
contMsg s (PCrypt m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (PScrypt m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (PC m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (SessionNr m) = False
contMsg s (SuccSession m) = contMsg s m
contMsg s (Step m) = False
contMsg s (StepTerm m) = False
contMsg s (Ptable m) = contMsg s m
contMsg s (Pfu m) = contMsg s m
contMsg s (Ptb m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (Ptb' m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (Pfunct m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (PRcrypt m1 m2) = (contMsg s m1) || (contMsg s m2)

contMsg _ _ = False

psubstitute :: PRule -> String -> Message -> PRule
psubstitute (Initial state) str term = Initial (map (substTerm str term) state)
psubstitute (MsgRule lhs rhs) str term =  
  MsgRule (map (substTerm str term) lhs)(map (substTerm str term) rhs)
psubstitute (Flaw state) str term = Flaw (map (substTerm str term) state)

substTerm :: String -> Message -> Term -> Term
substTerm str term (PW m1 m2 m3 m4 m5 m6 m7) = 
  PW m1 m2 m3 (substMsg str term m4) (substMsg str term m5) m6 m7
substTerm str term (PM m1 m2 m3 m4 m5 m6) = 
  PM m1 m2 m3 m4 (substMsg str term m5) m6
substTerm str term (I m) = I (substMsg str term m)
substTerm str term (Subst t1 t2) = (Subst t1 t2)
substTerm str term (PSecret m1 m2) = 
  PSecret (substMsg str term m1) (substMsg str term m2)
substTerm str term (PGive m1 m2) = 
  PGive (substMsg str term m1) (substMsg str term m2)
substTerm str term (PRequest m1 m2 m3 m4) =
  PRequest (substMsg str term m1)
	  (substMsg str term m2)
	  (substMsg str term m3)
	  (substMsg str term m4)
substTerm str term (PWitness m1 m2 m3 m4) =
  PWitness (substMsg str term m1)
	  (substMsg str term m2)
	  (substMsg str term m3)
	  (substMsg str term m4)

substMsg :: String -> Message -> Message -> Message
substMsg s t (PVariable v) = if (s==v) then t else (PVariable v)
substMsg s t (PCrypt m1 m2) = PCrypt (substMsg s t m1) (substMsg s t m2)
substMsg s t (PScrypt m1 m2) = PScrypt (substMsg s t m1) (substMsg s t m2)
substMsg s t (PC m1 m2) = PC (substMsg s t m1) (substMsg s t m2)
substMsg s t (SuccSession m) = SuccSession (substMsg s t m)
substMsg s t (Ptable m) = Ptable (substMsg s t m)
substMsg s t (Ptb k m) = Ptb (substMsg s t k) (substMsg s t m)
substMsg s t (Ptb' k m) = Ptb' (substMsg s t k) (substMsg s t m)
substMsg s t (Pfunct k m) = Pfunct (substMsg s t k) (substMsg s t m)
substMsg s t (PRcrypt k m) = PRcrypt (substMsg s t k) (substMsg s t m)
substMsg _ _ m = m

pRule :: [String] -> String -> ([String],[String],[Int],[String]) -> (PRule,([String],[String],[Int],[String]),[String])
pRule (inp:lines) name (rulez,goalz,secs,vars) =
  if (ifkey "h(xTime)." inp) then 
    let (state,"") = pState (consume "h(xTime)." inp) in
    (pk_scan (Initial state), (rulez,goalz,secs,vars), lines)
  else if (ifkey "h(s(xTime))." inp) then 
    let (lhs, "") = pState (consume "h(s(xTime))." inp) in
    let "=>":(l:ls) = lines in
    let (rhs, "") = pState (consume "h(xTime)." l) in
    (pk_scan (MsgRule lhs rhs),(name:rulez,goalz,secs,vars),ls)
  else if (ifkey "para" name) then 
    let (lhs, "") = pState inp in
    let "=>":(l:ls) = lines in
    let (rhs, l') = pState l in
    if (l'=="") || (ifkey "#" l') 
    then (pk_scan (MsgRule lhs rhs),(name:rulez,goalz,secs,vars),ls)
    else error "Expected end"
  else 
    let (state,"") = pState inp in 
    (pk_scan (Flaw state), 
      (rulez,if (ifkey "corr" name) then name:goalz else goalz,secs,vars), lines)

{------------------------
 PART (3): AST -> Haskell 
 ------------------------}
cuc :: String -> Message -> String
cuc str msg = "("++str++" "++(cMsg msg)++")"

cbc :: String -> Message -> Message -> String
cbc str msg1 msg2 = "("++str++" "++(cMsg msg1)++" "++(cMsg msg2)++")"

cMsg :: Message -> String
cMsg (PVariable v) = if (ifkey "xTime" v) then "(Atom (show time))" else "(Var "++v++")" 
cMsg (PMr atom) = "(Mr "++(cMsg (PAtom atom))++")" --- catomstr "Other" atom
cMsg (PPk atom) = cuc "Pk" atom --- catom "Pk" atom
cMsg (PSk atom) = cuc "Sk" atom --- catom "Other" atom
cMsg (PPk' atom) = cuc "Pk'" atom --- catom "Pk'" atom
cMsg (PNonce atom)= cuc "Nonce" atom --- catom "" atom
cMsg (PCrypt msg1 msg2) = cbc "Crypt" msg1 msg2
cMsg (PScrypt msg1 msg2) = cbc "Scrypt" msg1 msg2
cMsg (PC msg1 msg2) = cbc "C" msg1 msg2
cMsg (SessionNr n)= "(Session ("++(show n)++"))"
cMsg (SuccSession msg)="(Succsession "++(cMsg msg)++")"
cMsg (Step n)=show n
cMsg (StepTerm v)=v
cMsg (PAtom string)= "(Atom \""++string++"\")" --- catomstr "Other" string 
cMsg Etc = cMsg (PAtom "Etc") --- catomstr "Other" "Etc"
cMsg (Ptable t) = cuc "Table" t
cMsg (Ptb m1 m2) = cbc "Tb" m1 m2
cMsg (Ptb' m1 m2) = cbc "Tb'" m1 m2
cMsg (Pfunct m1 m2) = cbc "Funct" m1 m2
cMsg (Pfu m) = cuc "Fu" m
cMsg (PRcrypt m1 m2) = cbc "Rcrypt" m1 m2

cStep :: Message -> String
cStep step = (cMsg step) ++" " 

cTerm :: Term -> String
cTerm (PW step sender receiver acKno kno b se) 
  = "(W "++(cMsg step)        ++" "
         ++(cMsg sender)      ++" "
	 ++(cMsg receiver)    ++" "
	 ++(cMsg acKno)	      ++" "
	 ++(cMsg kno)	      ++" "
	 ++(cMsg se)	      ++")"
cTerm (PM step realsender sender receiver message se) 
  = "(M "++(cStep step)
         ++(cMsg realsender)  ++" "
         ++(cMsg sender)      ++" "
	 ++(cMsg receiver)    ++" "
	 ++(cMsg message)     ++" "
	 ++(cMsg se)	      ++")"
cTerm (I msg) = "(M 0 (Mr (Atom \"p\")) (Mr (Atom \"p\")) (Mr (Atom \"p\")) "++(cMsg msg)++" (Var (-1)) )"
cTerm (PSecret x f) = "(Secret "++(cMsg x)++" "++(cMsg f)++")"
cTerm (PGive x f) = "(Give "++(cMsg x)++" "++(cMsg f)++")"
cTerm (Subst a b) = a++"=="++b
cTerm (PRequest a b c d) = "(Request "++(flatten (map cMsg [a,b,c,d]))++")"
cTerm (PWitness a b c d) = "(Witness "++(flatten (map cMsg [a,b,c,d]))++")"

trimPair :: Message -> Message -> Message
trimPair (PC msg1 msg2) msg3 = PC msg1 (trimMsg (PC msg2 msg3))
trimPair msg1 msg2 = PC msg1 (trimMsg msg2)

trimMsg :: Message -> Message
trimMsg msg = 
  case msg of
    PC msg1 msg2      -> let msg1' = trimMsg msg1
	 	         in trimPair msg1' msg2
    SuccSession msg1 -> SuccSession (trimMsg msg1)
    PCrypt msg1 msg2  -> PCrypt (trimMsg msg1) (trimMsg msg2)
    PScrypt msg1 msg2 -> PScrypt (trimMsg msg1) (trimMsg msg2)
    Ptable m -> Ptable (trimMsg m)
    Pfunct m1 m2 -> Pfunct (trimMsg m1) (trimMsg m2)
    Ptb m1 m2 -> Ptb (trimMsg m1) (trimMsg m2)
    Ptb' m1 m2 -> Ptb' (trimMsg m1) (trimMsg m2)
    PRcrypt m1 m2 -> PRcrypt (trimMsg m1) (trimMsg m2)
    Pfu m -> Pfu (trimMsg m)
    otherwise        -> msg

trimTerm :: Term -> Term
trimTerm (PW m1 m2 m3 m4 m5 b m6) = PW (trimMsg m1)(trimMsg m2)(trimMsg m3)(trimMsg m4)(trimMsg m5) b (trimMsg m6)
trimTerm (PM m1 m2 m3 m4 m5 m6) = PM (trimMsg m1)(trimMsg m2)(trimMsg m3)(trimMsg m4)(trimMsg m5)(trimMsg m6)
trimTerm (I m1) = I (trimMsg m1)
trimTerm (PSecret m1 m2) = PSecret (trimMsg m1)(trimMsg m2)
trimTerm (PGive m1 m2) = PGive (trimMsg m1)(trimMsg m2)
trimTerm (Subst a b) = (Subst a b)
trimTerm (PRequest m1 m2 m3 m4) = PRequest (trimMsg m1) (trimMsg m2) (trimMsg m3) (trimMsg m4)
trimTerm (PWitness m1 m2 m3 m4) = PWitness (trimMsg m1) (trimMsg m2) (trimMsg m3) (trimMsg m4)
 
trimState :: PState -> PState
trimState = map trimTerm

isNtSubst :: Term -> Bool
isNtSubst (Subst _ _) = False
isNtSubst _ = True

isik :: Term -> Bool
isik (I (PVariable _)) = False
isik (I _) = True
isik _ = False

getvars :: Term -> [String]
getvars (PW m1 m2 m3 m4 m5 _ m6) = flatten (map getvarsmsg [m1,m2,m3,m4,m5,m6])
getvars (PM m1 m2 m3 m4 m5 m6) = flatten (map getvarsmsg [m1,m2,m3,m4,m5,m6])
getvars (PSecret m1 m2) = flatten (map getvarsmsg [m1,m2])
getvars (PGive m1 m2) = flatten (map getvarsmsg [m1,m2])
getvars (PWitness m1 m2 m3 m4) = flatten (map getvarsmsg [m1,m2,m3,m4])
getvars (PRequest m1 m2 m3 m4) = flatten (map getvarsmsg [m1,m2,m3,m4])
getvars (I m) = getvarsmsg m
getvars _ = []

cState :: PState -> (String,[String])
cState' [] = error "Empty State!"
cState' [x] = (cTerm x,getvars x)
cState' (x:xs) = let (xs',vs) = cState' xs in
                  ((cTerm x) ++ ", " ++ xs',(getvars x)++vs)
cState s = cState' (trimState (filter isNtSubst s))

transSubs [] = ""
transSubs ((u,v):rest) = ", "++u++"=="++v++(transSubs rest)

cRule :: (PRule,String)  -> (String,[Int],[String])
cRule ((Initial state),_) = 
  let ik = map (\ (I m) -> m) (filter isik state )
      state' = filter (not . isik) state 
      (strstate,vs) = cState state' in
   ("state0 :: State\nstate0=(1,[" ++ strstate ++ "],("++(flatten ((map (\ c -> (cMsg c)++":") ik) ))++"[]),[],[])",[],vs)
cRule ((MsgRule lhs rhs), name) = 
  let (lhs',vars1) = cState lhs
      (rhs',vars2) = cState rhs in
  (name++":: Int -> Rule\n"++name++" = \\ time -> (["++lhs'++"],["++rhs'++"])",[],vars1++vars2)
cRule ((Flaw state),name) 
  = if (ifkey "corr" name) then
    let (state',vars)=cState state in
     (name ++ "= [" ++ state' ++ "]",[],vars)
    else let [_,PSecret _ (SessionNr i)] = state in
	  ("",[i],[])


--------------------- The new version ----------------

{------------------------
 PART (3): AST -> Haskell 
 ------------------------}


tuc :: (String -> Int) -> (Msg -> Msg) -> Message -> (Int -> Msg)
tuc f con msg = \ time -> con ((tMsg f msg) time)

tbc :: (String -> Int) -> (Msg -> Msg -> Msg) -> Message -> Message 
       -> (Int -> Msg)
tbc f con msg1 msg2 = \ time -> con (tMsg f msg1 time) (tMsg f msg2 time)

tMsg :: (String -> Int) -> Message -> (Int -> Msg)
tMsg f (PVariable v) = if (ifkey "xTime" v) then (\ time -> Atom (show time)) 
	 				    else (\ _ -> Var (f v)) 
tMsg f (PMr atom) = 
  if (ifkey "x" atom) then 
    \ time -> (Mr (Var (f atom)))
  else
    \ time -> (Mr (Atom atom))
  --- new hack!
tMsg f (PPk atom) = tuc f Pk atom
tMsg f (PSk atom) = tuc f Sk atom
tMsg f (PPk' atom) = tuc f Pk' atom
tMsg f (PNonce atom) = tuc f Nonce atom
tMsg f (PCrypt msg1 msg2) = tbc f Crypt msg1 msg2
tMsg f (PScrypt msg1 msg2) = tbc f Scrypt msg1 msg2
tMsg f (PC msg1 msg2) = tbc f C msg1 msg2
tMsg f (SessionNr n)= \ time -> (Session n)
tMsg f (SuccSession msg)= tuc f Succsession msg
--- tMsg f (Step n)=show n
--- tMsg f (StepTerm v)=v
tMsg f (PAtom string) = \ time -> Atom string
tMsg f Etc = \ time -> Atom "Etc"
tMsg f (Ptable t) = tuc f Table t
tMsg f (Ptb m1 m2) = tbc f Tb m1 m2
tMsg f (Ptb' m1 m2) = tbc f Tb' m1 m2
tMsg f (Pfu t) = tuc f Fu t
tMsg f (Pfunct m1 m2) = tbc f Funct m1 m2
tMsg f (PRcrypt m1 m2) = tbc f Rcrypt m1 m2

--- cStep :: Message -> String
--- cStep step = (tMsg step) ++" " 

tTerm :: (String -> Int) -> Term -> (Int -> Fact)
tTerm f (PW (Step step) sender receiver acKno kno b se)
  = \ t -> 
       (W step (tMsg f sender t) (tMsg f receiver t) (tMsg f acKno t) 
	       (tMsg f kno t) (tMsg f se t))
tTerm f (PM (Step step) realsender sender receiver message se)
  = \ t -> 
    (M step (tMsg f realsender t) (tMsg f sender t) (tMsg f receiver t) 
	    (tMsg f message t) (tMsg f se t))
tTerm f (I msg) = \ t ->
  let d = Mr (Atom "p") in
  (M 0 d d d (tMsg f msg t) (Var (-1)))
tTerm f (PSecret x y) = \ t -> Secret (tMsg f x t) (tMsg f y t)
tTerm f (PGive x y) = \ t -> Give (tMsg f x t) (tMsg f y t)
tTerm f (PRequest a b c d) = 
  \t -> Request (tMsg f a t) (tMsg f b t) (tMsg f c t) (tMsg f d t)
tTerm f (PWitness a b c d) = 
  \t -> Witness (tMsg f a t) (tMsg f b t) (tMsg f c t) (tMsg f d t)

tState :: (String -> Int) -> PState -> (Int -> [Fact])
tState f list = \ t -> map (\ term -> tTerm f term t) 
			   (trimState (filter isNtSubst (compactIs list)))

compactIs :: PState -> PState
compactIs l = 
 let (ik,other) = split isik l 
     mergeIK [] = []
     mergeIK [x] = [x]
     mergeIK ((I m1):(I m2):xs) = mergeIK ((I (PC m1 m2)):xs)
 in (mergeIK ik)++other

tRule :: (String -> Int) -> (PRule,String) -> 
         ([State], [Int -> Rule], [[Fact]]) ->
         ([State], [Int -> Rule], [[Fact]])
---      initial state, rules,         correspondence goals, secrecy goals

tRule f ((Initial state),_) (init,rules,corr) = 
  let ik = map (\ (I m) -> m) (filter isik state )
      state' = filter (not . isik) state in
   ([(1,tState f state' 0,(map (\c -> tMsg f c 0) ik),[],[])],	
    rules,corr)
tRule f ((MsgRule lhs rhs),_) (init,rules,corr) =
  (init,(\ t -> ((tState f lhs t),(tState f rhs t))):rules,corr)
tRule f ((Flaw state),name) (init,rules,corr) =
  if ifkey "corr" name then (init,rules,(tState f state 0):corr)
  else (init, rules, corr)
    
--------------------- Main Routine(s) ----------------

f >.> g = \x -> g (f x)

mkSet [] = []
mkSet (x:xs) = x:(filter (\y -> x/=y) (mkSet xs))

newlooping :: Bool -> String -> [String] -> [(PRule,String)]
	      -> [(PRule,String)]

newlooping ignore name [] rules = rules
newlooping ignore name (x:xs) rules =
     if (ifkey "#" x) && (not (ifkey "##" x)) then 
       let (name',_) = if (ifkey "# lb=" x) then
			  pAtom (consume "# lb=" x)
		       else pAtom (consume "# " x) in
       let name''= if myIsLower (head name') then name'
		   else (myToLower (head name')):(tail name') in
         newlooping (shallIgnore name'') name'' xs rules
     else
       if (x=="" || (ifkey " #" x) || (ifkey "Fresh" x) || (ifkey "##" x)) 
       then newlooping ignore name xs rules
       else
	if ignore then newlooping True name xs rules
	else 
         let (rule,_,rest) = pRule (x:xs) name ([],[],[],[])
	 ---    (coded,sec,vars) = (cRule (rule,name)) 
	 in 
	 ---coded:(looping False "No name given" rest (a,b,sec++c,vars++d))
	 newlooping False "No name given" rest ((rule,name):rules)
 
getenv :: [(PRule,String)] -> ([String],[String],[Int],[String])
getenv rules =
 let rulez = map snd (filter (\ x -> case x of (MsgRule _ _, _) -> True 
					       _ -> False) rules)
     goalz = map snd (filter (\ x -> case x of (Flaw _, name) -> ifkey "corr" name
					       _ -> False) rules)
     secr  = map (\ (Flaw [_,PSecret _ (SessionNr i)],_) -> i)
		 (filter (\x -> case x of (Flaw [_,PSecret _ (SessionNr i)],_) -> True
					  _ -> False) rules)
     vars  = mkSet (flatten (map (\ ruleAndName -> let (_,_,vs) = cRule ruleAndName in vs) 
				 rules)) in
  (rulez,goalz,secr,vars)

output :: [(PRule,String)] ->  ([String],[String],[Int],[String]) -> [String]
output rules (rulez,goalz,secr,vars) = 
 ("module Rules where\nimport Remola\nimport Data\n":
  (map (\ ruleAndName -> let (code,_,_) = cRule ruleAndName in code) rules))++
 ["allrules = [ "++(tail (flatten (map (\x -> ",("++x++")") rulez)))++" ]\n"++
  "correspondence_goal = ("++(flatten (map (\x -> x++":") goalz))++"[])\n"++
  "secrecy_goal :: [Int]\nsecrecy_goal = "++(show secr)++"\n"++
  (fst (foldr (\ x (s,i) -> (x++"="++(show i)++"\n"++s,i+1)) ("\n",1) (mkSet ("time":vars))))]

looping :: [String] -> [String]
looping input = 
  let rules = newlooping False "No name given" input []
      env = getenv rules
  in output rules env

ifparser :: [String] -> (State, [Int -> Rule], [[Fact]], [Int])
ifparser input =
  let prules = newlooping False "No name given" input []
      (_,_,secr,vars) = getenv prules
      f = getnaming 1 vars
      getnaming i [] var = 0
      getnaming i (x:xs) var = if (var==x) then i
			       else getnaming (i+1) xs var
      (init,rules,corr) = foldr (\ pr (i,r,c) -> --- let (i',r',c') = 
				   tRule f pr (i,r,c))
						 --- in (i'++i,r'++r,c'++c)
				([],[],[]) prules
  in (head init,rules,corr,secr)

{-
looping :: Bool -> [String] -> ([String],[String],[Int],[String]) -> [String]
looping ignore name [] (rulez,goalz,secr,vars) =
 ["allrules = [ "++(tail (flatten (map (\x -> ",("++x++")") rulez)))++" ]\n"++
  "correspondence_goal = ("++(flatten (map (\x -> x++":") goalz))++"[])\n"++
  "secrecy_goal :: [Int]\nsecrecy_goal = "++(show secr)++"\n"++
  (fst (foldr (\ x (s,i) -> (x++"="++(show i)++"\n"++s,i+1)) ("\n",1) (mkSet ("time":vars))))]
looping ignore name (x:xs) env
  =  if (ifkey "#" x) && (not (ifkey "##" x)) then 
       let (name',_) = if (ifkey "# lb=" x) then
			  pAtom (consume "# lb=" x)
		       else pAtom (consume "# " x) in
       let name''= if myIsLower (head name') then name'
		   else (myToLower (head name')):(tail name') in
         looping (shallIgnore name'') name'' xs env
     else
       if (x=="" || (ifkey "Fresh" x) || (ifkey "##" x)) 
       then looping ignore name xs env
       else
	if ignore then looping True name xs env
	else 
         let (rule,(a,b,c,d),rest) = pRule (x:xs) name env 
	     (coded,sec,vars) = (cRule (rule,name)) in 
	 coded:(looping False "No name given" rest (a,b,sec++c,vars++d))
-}

shallIgnore str = not (foldr (\ k b -> b || (ifkey k str)) False 
			     ["step","init","corres","secr","para"])

--- pinteracter = lines >.> tail >.> (\x -> (("module Rules where\nimport Remola\nimport Data\n"):(looping False "" x ([],[],[],[])))) >.> unlines

pinteracter = lines >.> tail >.> looping >.> unlines

--- main = interact interacter


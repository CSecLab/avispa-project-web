%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     PARSER: INTERMEDIATE FORMAT TO A PROLOG INTERMEDIATE FORMAT     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              Luca Compagna                          %
%                  (E-mail: compa@mrg.dist.unige.it)                  %
%                  (E-mail: compa@dai.ed.ac.uk)                       %
%                        University of Genova                         %
%                        University of Edinburgh                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% importing a standard library for working with lists  
:- use_module(library(lists)).

:- retractall(hlpsl_output(_)).
:- retractall(syntax(_)).

% if2pif(F_IF,F_IIF) :- 
%     Translate the intermediate format file F_IF in to the IIF 
%     file F_IIF
if2pif(F_IF,F_PIF) :- 
    file2stream(F_IF,STREOF),
    !,
    append(STR,[(-1)],STREOF),
    parse_if(PB,STR,[]),
    open(F_PIF,write,STREAM,[eof_action(eof_code)]), 
    write_pif(STREAM,PB),
    close(STREAM).

parser_if(FI,PB) :- 
    file2stream(FI,STREOF),
    !,
    append(STR,[(-1)],STREOF),
    parse_if(PB,STR,[]).

%-----------------------------------------------------------------------
%        BEGIN: READ OF INPUT FILE AND TRANSLATION OF IT IN A STRING
%

% The sequence of chars in F is translated in STR i.e. the list 
% containing the ascii representation of each char without the 
% comment lines where the comment char C is specified by the fact 
% comment_char(C).
file2stream(F,STR) :- 
    open(F,read,STREAM,[eof_action(eof_code)]),
    readfile(STREAM,STR),
    close(STREAM).


% read the input file
readfile(STR,L) :- 
	get_code(STR,C),
	value_char(STR,C,L).
value_char(STR,C,L):-
	comment_char(CC),
	C==CC,
	remove_comment(STR,L),
	(L\==(-1)->readfile(STR,L);true).
% % Do not comment if you want to eliminate EOF 
% % in the preprocessing step
% value_char(STR,C,L):-
% 	C==10,
% 	readfile(STR,L).
value_char(STR,C,[C|L]) :- 
	C\=(-1),
	readfile(STR,L).
value_char(_,(-1),[(-1)]).

% delete of comments present in the input stream STR
comment_char(37). % comment char equal to '%'
remove_comment(STR,L):-
	get_code(STR,C),
	(\+end_comment(C,L) -> 
	    remove_comment(STR,L);
	    true
	).
end_comment(C,[-1]):-
	C==(-1).
end_comment(C,_):-
	C==10.

%
%          END: READ OF INPUT FILE AND TRANSLATION OF IT IN A STRING
%-----------------------------------------------------------------------


%-----------------------------------------------------------------------
%        BEGIN: ROOT's GRAMMAR RULES
%
parse_if(problem(OPTs,LRRs)) --> 
	parse_options(OPTs),
	parse_labelled_rules(LRRs).

%-----------------------------------------------------------------------
%        BEGIN: OPTIONS' GRAMMAR RULES
%
parse_options([OPT|OPTs]) -->
	parse_option(OPT),
	parse_options(OPTs).

parse_options([]) --> !.

parse_options(OPTs) -->
	[10],
	parse_options(OPTs).

parse_options(OPTs) -->
	parse_comment_line,
	parse_options(OPTs).	

parse_option(OPT) --> 
	parse_typed(OPT).

parse_typed(typed) --> 
	"# option=typed",sp,[10],
	{assert(hlpsp_output(typed))}.

parse_typed(untyped) --> 
	"# option=untyped",sp,[10],
	{assert(hlpsp_output(untyped))}.
%
%          END: OPTIONS' GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: LABELLED REWRITING RULES' GRAMMAR RULES
%
parse_labelled_rules([LRR|LRRs]) -->
	parse_labelled_rule(LRR),
	parse_labelled_rules(LRRs).
parse_labelled_rules(LRRs) -->
	[10],
	parse_labelled_rules(LRRs).
parse_labelled_rules(LRRs) -->
	parse_comment_line,
	parse_labelled_rules(LRRs).
parse_labelled_rules([]) -->
	parse_comment_line.
parse_labelled_rules([LRR]) -->
	parse_labelled_rule(LRR).
parse_labelled_rules([]) -->
	[10].
%
%          END: LABELLED REWRITING RULES' GRAMMAR RULES
%-----------------------------------------------------------------------
%
%          END: ROOT's GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: CATEGORIES' GRAMMAR RULES
%


category_labels(
  [
		'Protocol_Rules',
		'Invariant_Rules',
		'Decomposition_Rules',
		'Intruder_Rules',
		'Init',
		'Goal'
  ]
).

parse_category(LOWLB) -->
	text(LB),
	{category_labels(LBs),member(LB,LBs),
	 atom_chars(LB,[FC|RCs]),
	 (upper_char(FC) -> 
	     (
		 [UPA]="A",
		 [LOWA]="a",
		 LOWFC is FC-UPA+LOWA
	     );
	     LOWFC = FC
	 ),
	 atom_chars(LOWLB,[LOWFC|RCs])
	},!.

%
%          END: CATEGORIES' GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: COMMENT LINE's GRAMMAR RULES
%

parse_comment_line -->
	sp,"##",sp,useless,!.

useless --> "\n".
useless -->
	[C],
	{C\==10},
	useless.

%
%          END: COMMENT LINE's GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: LABELLED REWRITING RULE's GRAMMAR RULES
%

parse_labelled_rule(lrr(LOWLB,T,LHS,RHS)) --> 
	sp, "#", sp, "lb=", text(LB),
	sp,",",sp,"type=",parse_category(T),sp,[10],
	{atom_chars(LB,[FC|RCs]),
	 (upper_char(FC) -> 
	     (
		 [UPA]="A",
		 [LOWA]="a",
		 LOWFC is FC-UPA+LOWA
	     );
	     LOWFC = FC
	 ),
	 atom_chars(LOWLB,[LOWFC|RCs])
        },
	parse_generic_rule(LHS-RHS),!.

%
%          END: LABELLED REWRITING RULE's GRAMMAR RULES
%-----------------------------------------------------------------------


%-----------------------------------------------------------------------
%        BEGIN: REWRITING RULE's GRAMMAR RULES
%
parse_generic_rule(LHS-RHS) -->
	(
	    parse_rule(LHS-RHS)
	;
	    parse_idempotence_rule(LHS-RHS)
	;
	    parse_secrecy_rule(LHS-RHS)
	;
	    parse_decomposition_rule(LHS-RHS)
	;
	    parse_flaw_rule(LHS-RHS)
	).

parse_rule(LHS-RHS) --> 
	parse_state(LHS), sp, [10],
	"=>",sp,[10],
	parse_state(RHS),sp,!.

parse_rule(LHS-[]) --> 
	parse_state(LHS), sp,!.
	           
parse_idempotence_rule([V,V]-[V]) --> 
	variable(V),".",variable(V), sp, [10],
	"=>",sp,[10],
	variable(V),sp,!.

parse_secrecy_rule([f(s(MSG))]-[f(MSG)]) --> 
	"f(s(",parse_message(MSG),"))",sp, [10],
	"=>",sp,[10],
	"f(",parse_message(MSG),")",sp,!.

parse_flaw_rule(LHS-[]) --> 
	parse_terms(LHS), sp, !.

% It is more general: we could bind it.
% In fact each terms in both the LHS and
% RHS have the following form: i(MSG)..
parse_decomposition_rule(LHS-RHS) --> 
	parse_terms(LHS),sp, [10],
	"=>",sp,[10],
	parse_terms(RHS),sp,!.

%
%          END: REWRITING RULE's GRAMMAR RULES
%-----------------------------------------------------------------------


%-----------------------------------------------------------------------
%        BEGIN: STATE's GRAMMAR RULES
%
parse_state([h(Time)|Ts]) -->
	"h(",sp,time(Time),sp,
	")",sp,".",sp,
	parse_terms(Ts),sp,!.

parse_state([h(Time)]) -->
	"h(",sp,time(Time),sp,
	")",sp,!.

% parse_state(Ts) -->
% 	parse_terms(Ts),sp,!.

parse_terms([T|S]) -->
	parse_term(T),sp,
	".",sp,
	parse_terms(S),sp.

parse_terms([T]) -->
	parse_term(T),sp.

%
%          END: STATE's GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: TERM's GRAMMAR RULES
%

parse_term(T) -->
	(
	    (parse_principal_term(T),!);
	    (parse_message_term(T),!);
	    (parse_intruder_knowledge_term(T),!);
	    (parse_secret_term(T),!)%;
%	    (variable(T),!)
	).

parse_principal_term(w(I,S,R,AQUKNW,INKNW,BOOL,SN)) -->
	sp,"w(",
	step(I),sp,",",sp,
	ag_id(S),sp,",",sp,
	ag_id(R),sp,",",sp,
	parse_knowledge(AQUKNW),sp,",",sp,
	parse_knowledge(INKNW),sp,",",sp,
	boolean(BOOL),sp,",",sp,
	session(SN),
	sp,")",!.

parse_message_term(m(I,RS,DS,R,MSG,SN)) -->
	sp,"m(",sp,
	step(I),sp,",",sp,
	ag_id(RS),sp,",",sp,
	ag_id(DS),sp,",",sp,
	ag_id(R),sp,",",sp,
	parse_message(MSG),sp,",",sp,
	session(SN),
	sp,")",!.

parse_intruder_knowledge_term(i(MSG)) -->
	"i(",
	parse_message(MSG),
	")",!.

parse_secret_term(secret(MSG,f(SES))) -->
	"secret(",
	parse_message(MSG),",",
	"f(",
	session(SES),
	")",
	")",!.

%
%          END: TERM's GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: KNOWLEDGE's GRAMMAR RULES
%

parse_knowledge([KNW|KNWs]) -->
	"c(",sp,
	parse_message(KNW),sp,
	",",sp,
        parse_knowledge(KNWs),
	sp,")".

parse_knowledge([]) -->
	"xetc",natural(_).

parse_knowledge([]) -->
	"xetc".

parse_knowledge([]) -->
	"etc",natural(_).

parse_knowledge([]) -->
	"etc".

parse_knowledge(V) -->
	variable(V).

%
%          END: KNOWLEDGE's GRAMMAR RULES
%-----------------------------------------------------------------------


%-----------------------------------------------------------------------
%        BEGIN: MESSAGE's GRAMMAR RULES
%
parse_message(MSG) -->
	parse_binary_msg(MSG),!.
parse_message(MSG) -->
	parse_unary_msg(MSG),!.

%-----------------------------------------------------------------------
%        BEGIN: BINARY MESSAGES' GRAMMAR RULES
%
parse_binary_msg(MSG) -->
	parse_pair(MSG),!.
parse_binary_msg(MSG) -->
	parse_scrypt(MSG),!.
parse_binary_msg(MSG) -->
	parse_crypt(MSG),!.
parse_binary_msg(MSG) -->
	parse_function(MSG),!.
parse_binary_msg(MSG) -->
	parse_xor(MSG),!.

parse_pair(c(MSG1,MSG2)) -->
	"c(",sp,
	parse_message(MSG1),
	sp,",",	sp,
	parse_message(MSG2),
	sp,")",!.	

parse_scrypt(scrypt(UN,MSG)) -->
	"scrypt(",sp,
	parse_unary_msg(UN),
	sp,",",sp,
	parse_message(MSG),	
	sp,")",!.

parse_crypt(crypt(UN,MSG)) -->
	"crypt(",sp,
	parse_unary_msg(UN),
	sp,",",sp,
	parse_message(MSG),	
	sp,")",!.

parse_function(funct(UN,MSG)) -->
	"funct(",sp,
	parse_unary_msg(UN),
	sp,",",sp,
	parse_message(MSG),	
	sp,")",!.

parse_xor(xor(MSG1,MSG2)) -->
	"-(",parse_message(MSG1),	
	",", parse_message(MSG2),
	")",!.

%
%          END: BINARY MESSAGES' GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: UNARY MESSAGES' GRAMMAR RULES
%
parse_unary_msg(primed(pk(A))) -->
	"pk(",
	atomic(A),
	")'",!.
parse_unary_msg(pk(A)) -->
	"pk(",
	atomic(A),
	")",!.
parse_unary_msg(sk(A)) -->
	"sk(",
	atomic(A),
	")",!.
parse_unary_msg(nonce(A)) -->
	"nonce(",
	atomic(A),
	")",!.
parse_unary_msg(nonce(A)) -->
	"nonce(",
	atomic(A),
	")",!.
parse_unary_msg(fu(A)) -->
	"fu(",
	atomic(A),
	")",!.

parse_unary_msg(mr(A)) -->
	"mr(",
	atomic(A),
	")",!.

parse_unary_msg(primed(A)) -->
	variable(A),"'",!.

parse_unary_msg(A) -->
	variable(A),!.

%
%          END: UNARY MESSAGES' GRAMMAR RULES
%-----------------------------------------------------------------------
%
%          END: MESSAGES' GRAMMAR RULES
%-----------------------------------------------------------------------


%-----------------------------------------------------------------------
%        BEGIN: MEDIUM LEVEL's GRAMMAR RULES
%

% TODO: MAYBE CAN BE ALSO A natural
atomic(A) --> fresh_const(A).
atomic(A) --> const_text(A).
atomic(A) --> variable(A).

step(S)   --> natural(S); variable(S).

ag_id(mr(C))    --> "mr(", const_text(C), ")",!.
ag_id(mr(V))    --> "mr(", variable(V), ")",!.
ag_id(V)        --> variable(V),!.

boolean(true)    --> "true",!.
boolean(false)   --> "false",!.
boolean(V)       --> variable(V),!.

session(s(S))    --> "s(",session(S),")",!.
session(S)       --> natural(S);variable(S),!.

time(s(T))  --> "s(",time(T),")".
time(xTime) --> "xTime".

fresh_const(c(C,T)) -->
	(
	    ("c(",const_text(C),",",time(T),")",!)
	;
	    ("c(",const_text(C),",",const_text(T),")",!)
	).

const_text(C) -->
	[FC],
	{
          low_char(FC),
	  atom_chars('x',[X]),
          FC \== X 
        },
	text_code(RC),{atom_chars(C,[FC|RC])}.
const_text(C) -->
	[FC],
	{
          low_char(FC),
	  atom_chars('x',[X]),
          FC \== X, 
          atom_chars(C,[FC])
        }.
const_text(C) -->
	[FC],
	{
          upper_char(FC),
	  [UPA]="A",
	  [LOWA]="a",
	  LFC is FC-UPA+LOWA
        },
	text_code(RC),
	{
          atom_chars(C,[LFC|RC])
        }.
const_text(C) -->
	[FC],
	{
          upper_char(FC),
	  atom_chars('I',[I]),
          FC \== I,
	  LFC is FC + 32,
          atom_chars(C,[LFC])
        }.
const_text(intruder) -->
	"I".

% BEGIN CASE 1: Variables and metavariables ARE NOT distinct
variable(V) --> 
	"x",text_code(TC),
	{append("x",TC,VC),atom_chars(V,VC)}.
% END CASE 1
% % BEGIN CASE 2: Variables and metavariables ARE distinct
% variable(V) --> 
% 	"x",[C],
% 	{     
% 	       \+upper_char(C),
% 	       text_el(C)
%         },
% 	text_code(TC),
% 	{append("x",[C|TC],VC),atom_chars(V,VC)},!.
% variable(V) --> 
% 	"x",[C],
% 	{     
% 	       \+upper_char(C),
% 	       text_el(C)
%         },
% 	{append("x",[C],VC),atom_chars(V,VC)}.
% metavariable(MV) --> 
% 	"x",[C],
% 	{     
% 	       upper_char(C)
%         },
% 	text_code(TC),
% 	{append("x",[C|TC],MVC),atom_chars(MV,MVC)},!.
% metavariable(MV) --> 
% 	"x",[C],
% 	{     
% 	       upper_char(C)
%         },
% 	{append("x",[C],MVC),atom_chars(MV,MVC)}.
% END CASE 2

%
%          END: MEDIUM LEVEL's GRAMMAR RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: LOW LEVEL's GRAMMAR RULES AND LOW LEVEL PREDICATES
%

% Sequence of characters (with the underline)
text(T) --> 
	text_code(TC), 
	{atom_chars(T,TC)}.

text_code([C|Cs]) --> [C], {text_el(C)}, text_code(Cs).
text_code([C])    --> [C], {text_el(C)}.

% Sequence of characters (without the underline symbol)
text_no_underscore(C) --> 
	text_no_underscore_code(CC), 
	{atom_chars(C,CC)}.

text_no_underscore_code([C|Cs]) --> [C], {text_no_underscore_el(C)}, 
	                            text_no_underscore_code(Cs).
text_no_underscore_code([C])    --> [C], {text_no_underscore_el(C)}.

% Real real
real(N) --> 
	real_code(NC),
	{number_chars(N,NC)}. 

real_code([N|Ns])  --> real_digit_code(N),real_code(Ns).
real_code([N])     --> real_digit_code(N).

real_digit_code(C)  --> [C],{digit(C); C=:="."}. 

% Natural number
natural(I) --> 
	natural_code(IC),
	{number_chars(I,IC)}.

natural_code([N|Ns]) --> natural_digit_code(N),natural_code(Ns).
natural_code([N])    --> natural_digit_code(N).

natural_digit_code(C) --> [C],{digit(C)}.

% Basic type predicates
digit(C)      :- "0"=<C, C=<"9".
low_char(C)   :- "a"=<C, C=<"z".
upper_char(C) :- "A"=<C, C=<"Z".

char(C)       :- upper_char(C).
char(C)       :- low_char(C).

text_el(C) :- upper_char(C).
text_el(C) :- low_char(C).
text_el(C) :- digit(C).
text_el(D) :- D=:="_".

text_no_underscore_el(C) :- upper_char(C).
text_no_underscore_el(C) :- low_char(C).
text_no_underscore_el(C) :- digit(C).

% SEQUENCE OF SPACE CHARACTERS  
sp0 --> " ".
%sp0 --> "\n". % if you want to consider EOL like a space character
%sp0 --> "\t".

sp --> sp0, sp, !.
sp --> sp0, !.
sp --> [].

% End Of Line character
eol --> "\n", !.
eol --> sp, "\n",!.
eol --> [].

%
%          END: LOW LEVEL's GRAMMAR RULES AND LOW LEVEL PREDICATES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: WRITE THE PROLOG INTERMEDIATE FORMAT
%

write_pif(STR,PB) :-
	assert(syntax(pif)),
	print(STR,PB),
	retract(syntax(pif)).

% %-----------------------------------------------------------------------
% %        BEGIN: PORTRAY VERSION 1
% %

% % VERSION 1: we use a predicate symbol 'section' which will contain the 
% %            section's tag and a list of the labelled rewriting rules 
% %            containing in the section

% portray(problem(TYPE,SECs)) :-
% 	syntax(pif),
% 	format("problem(~w,~n",[TYPE]),
% 	format("[~n",[]),
% 	print(SECs),
% 	format("]~n",[]),
% 	format(").~n",[]).

% portray([section(LB,LRRs)]) :-
% 	syntax(pif),
% 	format("~2|section(~w,~n",[LB]),
% 	format("~2|[~n",[]),
% 	print(LRRs),
% 	format("~2|]~n",[]),
% 	format("~2|)~n",[]).

% portray([section(LB,LRRs)|SECs]) :-
% 	syntax(pif),
% 	format("~2|section(~w,~n",[LB]),
% 	format("~2|[~n",[]),
% 	print(LRRs),
% 	format("~2|]~n",[]),
% 	format("~2|),~n",[]),
% 	print(SECs).


% portray([lrr(LB,LHS,RHS)]) :-
% 	syntax(pif),
% 	format("~4|lrr(~w,~n",[LB]),
% 	format("~4|[~n",[]),
% 	retract(syntax(pif)),
% 	assert(syntax(pif_terms)),
% 	print(LHS),
% 	format("~4|],~n",[]),
% 	format("~4|[~n",[]),
% 	print(RHS),
% 	retract(syntax(pif_terms)),
% 	assert(syntax(pif)),
% 	format("~4|]~n",[]),
% 	format("~4|)~n",[]).

% portray([lrr(LB,LHS,RHS)|LRRs]) :-
% 	syntax(pif),
% 	format("~4|lrr(~w,~n",[LB]),
% 	format("~4|[~n",[]),
% 	retract(syntax(pif)),
% 	assert(syntax(pif_terms)),
% 	print(LHS),
% 	format("~4|],~n",[]),
% 	format("~4|[~n",[]),
% 	print(RHS),
% 	retract(syntax(pif_terms)),
% 	assert(syntax(pif)),
% 	format("~4|]~n",[]),
% 	format("~4|),~n",[]),
% 	print(LRRs).

% portray([]) :-
% 	syntax(pif).

% portray([T]) :-
% 	syntax(pif_terms),
% %	(T=..[w|_];T=..[m|_];T=..[i|_];T=..[h|_];T=..[secret|_])
% 	format("~6|~w~n",[T]).	

% portray([T|Ts]) :-
% 	syntax(pif_terms),
% %	(T=..[w|_];T=..[m|_];T=..[i|_];T=..[h|_];T=..[secret|_])
% 	format("~6|~w,~n",[T]),
% 	print(Ts).

% portray([]) :-
% 	syntax(pif_terms).

% %
% %          END: PORTRAY VERSION 1
% %-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PORTRAY VERSION 2
%

% VERSION 2: each rewriting rule is a quadruple <LB,CAT,LHS,RHS>
%            where LB is the rule's label, CAT is the rule's category 
%            (tag of section containing the rule) and, LHS and RHS are 
%            the left-hand-side and the righ-hand-side, respectively

portray(problem(OPTs,LRRs)) :-
	syntax(pif),
	format("problem(~w,~n",[OPTs]),
	format("[~n",[]),
	print(LRRs),
	format("]~n",[]),
	format(").~n",[]).

portray([lrr(LB,CAT,LHS,RHS)]) :-
	syntax(pif),
	format("~2|lrr(~w,~w,~n",[LB,CAT]),
	format("~2|[~n",[]),
	retract(syntax(pif)),
	assert(syntax(pif_terms)),
	print(LHS),
	format("~2|],~n",[]),
	format("~2|[~n",[]),
	print(RHS),
	retract(syntax(pif_terms)),
	assert(syntax(pif)),
	format("~2|]~n",[]),
	format("~2|)",[]).

portray([lrr(LB,CAT,LHS,RHS)|LRRs]) :-
	syntax(pif),
	format("~2|lrr(~w,~w,~n",[LB,CAT]),
	format("~2|[~n",[]),
	retract(syntax(pif)),
	assert(syntax(pif_terms)),
	print(LHS),
	format("~2|],~n",[]),
	format("~2|[~n",[]),
	print(RHS),
	retract(syntax(pif_terms)),
	assert(syntax(pif)),
	format("~2|]~n",[]),
	format("~2|),~n",[]),
	print(LRRs).

portray([]) :-
	syntax(pif).

portray([T]) :-
	syntax(pif_terms),
%	(T=..[w|_];T=..[m|_];T=..[i|_];T=..[h|_];T=..[secret|_])
	format("~6|~w~n",[T]).	

portray([T|Ts]) :-
	syntax(pif_terms),
%	(T=..[w|_];T=..[m|_];T=..[i|_];T=..[h|_];T=..[secret|_])
	format("~6|~w,~n",[T]),
	print(Ts).

portray([]) :-
	syntax(pif_terms).


%
%          END: PORTRAY VERSION 2
%-----------------------------------------------------------------------
%
%          END: WRITE THE PROLOG INTERMEDIATE FORMAT
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: DEBUG AND TEST SECTION
%

check_grammar_rules(FI,GR,OUT) :-
	file2stream(FI,STREOF),
	!,
	append(STR,[10,(-1)],STREOF), 
	CGR=..[GR,OUT,STR,[]],
	call(CGR).

%
%          END: DEBUG AND TEST SECTION
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: MAYBE USEFUL PREDICATES
%

% metavar_list([MV|MVs]) --> metavariable(MV),sp,",",sp,metavar_list(MVs).
% metavar_list([MV]) --> metavariable(MV).

% metavariable(mv(MV)) --> metavariable_cod(MVC), {atom_chars(MV,MVC)}.
% metavariable(inv(MV)) --> 
% 	metavariable_cod(TMVC), 
% 	"'", 
% 	{
% %          append("x_",TMVC,MVC),
%           append("x",TMVC,MVC), % does not change its original value
%           atom_chars(MV,MVC)
%         },
% 	!.
% metavariable(MV) --> 
% 	metavariable_cod(TMVC), 
% 	{
% %          append("x_",TMVC,MVC),
%           append("x",TMVC,MVC), % does not change its original value
%           atom_chars(MV,MVC)
%         }.
% metavariable_cod([A|B]) --> [A],{upper_char(A)}, chars_code(B).
% metavariable_cod([A]) --> [A],{upper_char(A)}.

% % var_list([V|Vs]) --> variable(V),sp,",",sp,var_list(Vs).
% % var_list([V]) --> variable(V).

% variable(inv(V)) --> 
% 	variable_cod(TVC), 
% 	"'", 
% 	{
% %          append("x_",TVC,VC),
%           append("x",TVC,VC), % does not change its original value
%           atom_chars(V,VC)
%         },!.
% variable(V) --> 
% 	variable_cod(TVC), 
% 	{
% %          append("x_",TVC,VC),
%           append("x",TVC,VC), % does not change its original value
%           atom_chars(V,VC)
%         }.

% % The intruder is a constant
% % variable('intruder') --> [73].
% variable_cod([A|B]) --> [A],{low_char(A)}, chars_code(B).
% variable_cod([A]) --> [A],{low_char(A)}.

% % Sequence of characters returned in low-case 
% chars_to_low(LC) --> 
% 	chars_code_to_low(LCC), 
% 	{atom_chars(LC,LCC)}.

% chars_code_to_low([C|Cs]) --> [C], {low_char(C)}, chars_code_to_low(Cs).
% chars_code_to_low([LC|Cs]) --> [C], {upper_char(C),LC is C + 32}, chars_code_to_low(Cs).
% chars_code_to_low([C]) --> [C], {low_char(C)}.
% chars_code_to_low([LC]) --> [C], {upper_char(C),LC is C + 32}.

%
%          END: MAYBE USEFUL PREDICATES
%-----------------------------------------------------------------------

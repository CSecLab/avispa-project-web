#!/usr/bin/perl

package Parallel;
use strict;

$Parallel::hlpsl2if;


sub new {
  my $self = {};
  $self->{FileName} = $_[1];
  $self->{Rules} = "# Rules for unbounded number of parallel sessions\n\n";
  $self->{Initial} = "";
  $self->{NumberOfClauses} = 0;
  $self->{OutPut} = $_[2];
  bless $self;
  return $self;
}



$Parallel::max_rule = 255;


#
#  Printing methods
#


sub Print {
  my $self = shift;
  my $fh = $self->{OutPut};
  
  print $fh @_;
}





sub PrintResult {
  my $self = shift;
  my $rules = $self->{Rules};
  # print $rules;
  $self->Print($rules);
}


sub PrintInitial {
  my $self = shift;
  
  $self->Print($self->{Initial});
}


#
# global rules, int -> string
#

$Parallel::rule_list_number = 0;
%Parallel::RuleList = ();
keys(%Parallel::RuleList) = $Parallel::max_rule;

#
# well,...
#
$Parallel::intrudersinitialknowledge_number = 0;
%Parallel::intrudersInitialKnowledge = ();
keys(%Parallel::intrudersInitialKnowledge) = $Parallel::max_rule;


#
# parallel inferences given by datalog resolution
#
$Parallel::parallel_rule_number = 0;
%Parallel::parallel_Rule_List_comment = ();
%Parallel::parallel_Rule_List_LHS = ();
%Parallel::parallel_Rule_List_RHS = ();
keys(%Parallel::parallel_Rule_List_comment) = $Parallel::max_rule;
keys(%Parallel::parallel_Rule_List_LHS) = $Parallel::max_rule;
keys(%Parallel::parallel_Rule_List_RHS) = $Parallel::max_rule;



#
# auxiliary functions
#

sub add_parallel_rule { # comment, LHS, RHS
  my $comment = shift;
  my $LHS = shift;
  my $RHS = shift;
  $LHS = transform_to_lazy($LHS);
  $Parallel::parallel_rule_number = $Parallel::parallel_rule_number +1;

  if ($Parallel::parallel_rule_number > $Parallel::max_rule) {
    return 0;
  }
  else {
    $Parallel::parallel_Rule_List_LHS{$Parallel::parallel_rule_number} = $LHS;
    $Parallel::parallel_Rule_List_RHS{$Parallel::parallel_rule_number} = $RHS;
    $Parallel::parallel_Rule_List_comment{$Parallel::parallel_rule_number} = $comment;
    
    return $Parallel::parallel_rule_number;
  } 
}

sub transform_to_lazy (){
  my $Rule_Member = shift;
  my $term;
  my $result ="ii";
  foreach $term (split(/\./,$Rule_Member)){
    if ($term =~ /^i([a-zA-Z0-9\,\_\(\)\']+)/) {
      $result .= ".v$1";
    }
    else {
      $result .= ".$term";
    }
  }
  return $result;
}



#
# functions that fill the {Rule} part of $self
#


sub add_to_rules_parallel_rule { # adds the rule in the %Parallel::RuleList
  my $number = shift;
  my $rule = "";
  my $comment =$Parallel::parallel_Rule_List_comment{$number};
  my $LHS=$Parallel::parallel_Rule_List_LHS{$number};
  my $RHS=$Parallel::parallel_Rule_List_RHS{$number};
  $rule  = "$comment -- message to send\nR(s(xTime),xm,xw,xi,xp .\\\nparallel($number,xupar,i(xTerme)), \\\n" ;
  $rule .= "svs(test,mesg(seq.v(xTerme).xuseq,xdseq.num(xoldnum)).xmesg.num(xnum)),xlist) => \\\n";
  $rule .= "R(xTime,xm,xw,xi, xp. \\\nparallel($number,$LHS,$RHS), \\\n" ;
  $rule .= "svs(test,mesg(seq.vtt.xuseq,xdseq.xdpar.i(xTerme).num(xoldnum)). \\\n";
  $rule .= "mesg(xupar,xdseq.num(xnum)).xmesg.num(s(xnum))),c(tracepara(xTerme),xlist))\n\n";
  %Parallel::RuleList = (%Parallel::RuleList,$Parallel::rule_list_number++ => $rule);
  $rule  = "$comment -- decomposition of a message to send\nR(s(xTime),xm,xw,xi,xp .\\\nparallel($number,xupar,i(xTerme)), \\\n" ;
  $rule .= "svs(test,mesg(seq.tu(x1,i(xTerme).x2).xuseq,xdseq.num(xoldnum)).xmesg.num(xnum)),xlist) => \\\n";
  $rule .= "R(xTime,xm,xw,xi, xp. \\\nparallel($number,$LHS,$RHS), \\\n" ;
  $rule .= "svs(test,mesg(seq.tu(x1,x2).xuseq,xdseq.xdpar.i(xTerme).num(xoldnum)). \\\n";
  $rule .= "mesg(xupar,xdseq.num(xnum)).xmesg.num(s(xnum))),c(tracepara(xTerme),xlist))\n\n";  
  %Parallel::RuleList = (%Parallel::RuleList,$Parallel::rule_list_number++ => $rule);
  $rule  = "$comment -- decomposition of knowledge\nR(s(xTime),xm,xw,xi,xp .\\\nparallel($number,xupar,i(xTerme)), \\\n" ;
  $rule .= "svs(test,mesg(seq.xuseq,ti(x1,i(xTerme).x2).xdseq.num(xoldnum)).xmesg.num(xnum)),xlist) => \\\n";
  $rule .= "R(xTime,xm,xw,xi, xp. \\\nparallel($number,$LHS,$RHS), \\\n" ;
  $rule .= "svs(test,mesg(seq.xuseq,ti(x1,i(xTerme).x2).xdseq.xdpar.i(xTerme).num(xoldnum)). \\\n";
  $rule .= "mesg(xupar,xdseq.num(xnum)).xmesg.num(s(xnum))),c(tracepara(xTerme),xlist))\n\n";  
  %Parallel::RuleList = (%Parallel::RuleList,$Parallel::rule_list_number++ => $rule);
}
   

sub add_to_rules_parallel_rules {# no args !
  my $a_rule_number =0 ;

  while (++$a_rule_number <= $Parallel::parallel_rule_number) { 
    add_to_rules_parallel_rule($a_rule_number);
  }
}



sub concat_all_rules {
  my $rule ="";
  my $rule_number;
  
  foreach $rule_number (keys %Parallel::RuleList) {
    $rule .= "$Parallel::RuleList{$rule_number}\n\n";
  }
  return $rule;
}

#
# functions to add the rules in the initial state
#


sub add_to_init_state_parallel_rule { # int -> string
  my $this_rule = shift;
  my $LHS=$Parallel::parallel_Rule_List_LHS{$this_rule};
  my $RHS=$Parallel::parallel_Rule_List_RHS{$this_rule};
  my $rule = ".parallel($this_rule,$LHS,$RHS)";
  my $atom;
  my $result = "";

  foreach $atom (split(/x/,$rule)){
    if ($result) {
      $result .= "x_${this_rule}_$atom";
    }
    else {
      $result = $atom;
    }
  }
  

  return $result;  
}

sub add_to_init_state_parallel_rules { # the string of initial state
  my $initial_state = shift;
  my $a_rule_number = 0;

  while (++$a_rule_number <= $Parallel::parallel_rule_number) { 
    $initial_state .= add_to_init_state_parallel_rule($a_rule_number);
  }
  return $initial_state;
}


#
# parse function
#

sub parse {# name of the hlpsl file
  my $filename = shift;

  open(inputstream,"$Parallel::hlpsl2if --para $filename |") or die "cannot open file $filename\n";
  
  my $type = "";
  my $label = "";
  my $line;
  my $side;
  my $LHS;
  my $RHS;

  NEXT_LINE : while ($line = <inputstream>) {
    if (($line =~ /^[ \t\n]*$/)||($line =~ /^\#\#/)) {
      goto NEXT_LINE;
    }
    if ($line =~ /\# lb=([a-zA-Z0-9\_]+), type=([a-zA-Z]+)/) {
      $label = $1;
      $type = $2;
      $side = "lhs";
      goto NEXT_LINE;
    }
    else {
      if ($type =~ /Parallel/) {
	
	chomp($line);

	if ($side =~ /rhs/) {
	  $RHS = $line;
	  # print "rhs :$RHS\n";
	  add_parallel_rule("\# lb=$label, type=Parallel",$LHS,$RHS);
	  goto NEXT_LINE;
	}
	if ($line =~ /=>/) {
	  $side = "rhs";
	  # print "changing side\n";
	  goto NEXT_LINE;
	}
	if($side =~ /lhs/) {
	  $LHS=$line;
	  # print "lhs : $LHS\n";
	  goto NEXT_LINE;
	}
      }
    }
  };
  close(inputstream);
}



sub give_parallel_rules {
  my $self = shift;


  add_to_rules_parallel_rules();
  $self->{Rules} .= concat_all_rules();

  return $self;
}  


#
# Init function
#


sub give_parallel_in_init_term { 
  my $self= shift;

  $self->{Initial} .= "ii";
  $self->{Initial} .= add_to_init_state_parallel_rules();
  $self = $self->give_parallel_rules();
  return $self;
}


sub init { # Rules, initial state
  my $self = shift;

  parse($self->{FileName});
  $self = $self->give_parallel_in_init_term();
  
  return $self;
}

1;

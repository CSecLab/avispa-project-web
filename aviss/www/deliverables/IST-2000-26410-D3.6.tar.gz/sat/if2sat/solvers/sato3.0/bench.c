/*********************************************************************
; Copyright 1992-97, The University of Iowa (UI).  All rights reserved. 
; By using this software the USER indicates that he or she has read, 
; understood and will comply with the following:
;
; --- UI hereby grants USER nonexclusive permission to use, copy and/or
; modify this software for internal, noncommercial, research purposes only.
; Any distribution, including commercial sale or license, of this software,
; copies of the software, its associated documentation and/or modifications
; of either is strictly prohibited without the prior consent of UI.  Title
; to copyright to this software and its associated documentation shall at
; all times remain with UI.  Appropriate copyright notice shall be placed
; on all software copies, and a complete copy of this notice shall be
; included in all copies of the associated documentation.  No right is
; granted to use in advertising, publicity or otherwise any trademark,
; service mark, or the name of UI.  Software and/or its associated
; documentation identified as "confidential," if any, will be protected
; from unauthorized use/disclosure with the same degree of care USER
; regularly employs to safeguard its own such information.
;
; --- This software and any associated documentation is provided "as is," and
; UI MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
; THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
; USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL
; NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL
; PROPERTY RIGHTS OF A THIRD PARTY.  UI, the University of Iowa,
; its Regents, officers, and employees shall not be liable under any
; circumstances for any direct, indirect, special, incidental, or
; consequential damages with respect to any claim by USER or any third
; party on account of or arising from the use, or inability to use, this
; software or its associated documentation, even if UI has been advised
; of the possibility of those damages.
*********************************************************************/
#include "main.h"

#define MAX_RAMSEY        50
#define PAIR2KEY(i,j) ((i * n) + j + 1)

/**** The following function generates the input clauses for
  the Queen problems ****/

int queen_clauses ()
     /* return 1 if an empty clause is found; otherwise, 0 */
{
  SATOINT cl_arr [ MAX_ATOM ], sign_arr [ MAX_ATOM ];
  SATOINT n, n1, x, y, v, u;

  n = LINE = QUEEN;
  n1 = n-1;

  /* Each row must have a queen. */
  for (x = n1; x >= 0; x--) {
    v = n1;
    for (y = 0; y < n; y++) {
      cl_arr[y] = PAIR2KEY(x, v--);
      sign_arr[cl_arr[y]] = 1;
    }
    Clause_num++;
    if (insert_clause ( cl_arr, sign_arr, n) == 1)	
      return 1;
  }

  if (!IDEMPOTENT) {
  /* Each column must have a queen. */
  for (x = n1; x >= 0; x--) {
    v = n1;
    for (y = 0; y < n; y++) {
      cl_arr[y] = PAIR2KEY(v--, x);
      sign_arr[cl_arr[y]] = 1;
    }
    Clause_num++;
    if (insert_clause ( cl_arr, sign_arr, n) == 1)	
      return 1;
  }}

  /* No two queens are in the same column. */
  for (x = n1; x >= 0; x--)
    for (y = n1; y >= 0; y--) 
      for (v = x-1; v >= 0; v--) {
	cl_arr[0] = PAIR2KEY(x, y);
	sign_arr[cl_arr[0]] = 0;
	cl_arr[1] = PAIR2KEY(v, y);
	sign_arr[cl_arr[1]] = 0;
	Clause_num++;
	if (insert_clause ( cl_arr, sign_arr, 2) == 1)	
	  return 1;
      }

  /* No two queens are in the same row. */
  for (x = n1; x >= 0; x--)
    for (y = n1; y >= 0; y--) 
      for (v = x-1; v >= 0; v--) {
	cl_arr[0] = PAIR2KEY(y, x);
	sign_arr[cl_arr[0]] = 0;
	cl_arr[1] = PAIR2KEY(y, v);
	sign_arr[cl_arr[1]] = 0;
	Clause_num++;
	if (insert_clause ( cl_arr, sign_arr, 2) == 1)	
	  return 1;
      }

  /* No two queens are in the same diagonal. */
  for (x = n1; x >= 0; x--)
    for (y = n1; y >= 0; y--) 
      for (v = x-1; v >= 0; v--) 
	for (u = n1; u >= 0; u--) 
	  if (x - v == abs(y - u)) {
	    cl_arr[0] = PAIR2KEY(x, y);
	    sign_arr[cl_arr[0]] = 0;
	    cl_arr[1] = PAIR2KEY(v, u);
	    sign_arr[cl_arr[1]] = 0;
	    Clause_num++;
	    if (insert_clause ( cl_arr, sign_arr, 2) == 1)	
	      return 1;
	  }

  return 0;
}

/**** The following function generates the input clauses for
  the pigeon-hole problems ****/

int pigeonhole_clauses ()
     /* return 1 if an empty clause is found; otherwise, 0 */
{
  SATOINT cl_arr [ MAX_ATOM ], sign_arr [ MAX_ATOM ];
  SATOINT n, nminus1, x, y, v;

  n = LINE = PIGEON;
  nminus1 = n-1;

  /*  each pigeon is in a hole. */
  for (x = n; x >= 0; x--) {
    v = nminus1;
    for (y = 0; y < n; y++) {
      cl_arr[y] = PAIR2KEY(x, v--);
      sign_arr[cl_arr[y]] = 1;
    }
    Clause_num++;
    if (insert_clause ( cl_arr, sign_arr, n) == 1)	
      return 1;
  }

  /* No hole has more than one pigeon */
  for (x = n; x >= 0; x--)
    for (y = nminus1; y >= 0; y--) 
      for (v = x-1; v >= 0; v--) {
	cl_arr[0] = PAIR2KEY(x, y);
	sign_arr[cl_arr[0]] = 0;
	cl_arr[1] = PAIR2KEY(v, y);
	sign_arr[cl_arr[1]] = 0;
	Clause_num++;
	if (insert_clause ( cl_arr, sign_arr, 2) == 1)	
	  return 1;
      }
  return 0;
}

/**** The following function generates the input clauses for
  Ramsey number problems ****/
/*  
   | 3   4   5   6   7    8     9
 --|------------------------------
 3 | 6   9  14  18  22  28-29

*/

int ramsey_clauses ()
     /* return 1 if an empty clause is found; otherwise, 0 */
{
  SATOINT n, r, x, y, u, v;
  SATOINT pair_to_key [MAX_RAMSEY] [MAX_RAMSEY];
  SATOINT comb[MAX_RAMSEY];
  SATOINT cl_arr [ MAX_ATOM ], sign_arr [ MAX_ATOM ];

  if (RAMSEY > MAX_RAMSEY) {
    fprintf ( stderr, "%d >= MAX_RAMSEY(=%d) (redefine it in test.c).\n",
	       RAMSEY, MAX_STACK);
    exit(0);
  } else if (PIGEON <= 2 || QUEEN <= 2) {
    fprintf ( stderr, "The solution is trivial when min(%d, %d) <= 2.\n\n",
	     PIGEON, QUEEN);
    exit(0);
  } else if (PIGEON >= RAMSEY || QUEEN >= RAMSEY) {
    fprintf ( stderr, "The solution is trivial when max(%d, %d) >= %d.\n\n",
	     PIGEON, QUEEN, RAMSEY);
    exit(0);
  }

  n = RAMSEY;
  LINE = n-1;

  x = 0;
  for (u = 0; (u < n); u++)
    for (v = u+1; (v < n); v++)
      pair_to_key[v][u] = pair_to_key[u][v] = ++x;

  r = QUEEN-1;
  for (x = 0; x < n-r; x++) 
    for (y = x+r; y < n; y++) 
      if (n - y + x >= r+1) {
	cl_arr[0] = pair_to_key[x][y];
	sign_arr[cl_arr[0]] = 0;
	Clause_num++;
	if (insert_clause ( cl_arr, sign_arr, 1) == 1)	
	  return 1;
      }
      

  /* there are no p-cliques */
  r = PIGEON-1; 
  /* there are no 3-cliques */
  r = 2;
  for (x = 0; (x <= r); x++) comb[x] = x;
  
  while (comb[0] != n) {
    u = 0;
    for (x = r; (x > 0); x--)
      for (y = x-1; (y >= 0); y--) {
	v = cl_arr[u++] = pair_to_key[comb[y]][comb[x]];
	sign_arr[v] = 0;
      }
    Clause_num++;
    if (insert_clause ( cl_arr, sign_arr, u) == 1)	
      return 1;
  
    if ((comb[0] + r + 1) == n)
      comb[0] = n;
    else 
      next_combination(r, n, comb);
  }

  if (RAMSEY > 10) {
  /* no degree greater than q for R(3,q) */
  r = QUEEN-1; 
  for (x = 0; (x <= r); x++) comb[x] = x;
  
  while (comb[0] != n) {
    for (y = n-1; (y >= 0); y--) {
      x = r;
      while ((x >= 0) && (y != comb[x])) x--;
      if (x < 0) {
	u = 0;
	for (x = r; x >= 0; x--) {
	  v = cl_arr[u++] = pair_to_key[y][comb[x]];
	  sign_arr[v] = 0;
	}
	Clause_num++;
	if (insert_clause ( cl_arr, sign_arr, u) == 1)	
	  return 1;
      }
    }
    if ((comb[0] + r + 1) == n)
      comb[0] = n;
    else 
      next_combination(r, n, comb);
  }
  }

  /* there are no q-independent sets */
  r = QUEEN-1; 
  for (x = 0; (x <= r); x++) comb[x] = x;
  
  while (comb[0] != n) {
    u = 0;
    for (x = r; (x > 0); x--)
      for (y = x-1; (y >= 0); y--) {
	v = cl_arr[u++] = pair_to_key[comb[y]][comb[x]];
	sign_arr[v] = 1;
      }
    Clause_num++;
    if (insert_clause ( cl_arr, sign_arr, u) == 1)	
      return 1;
  
    if ((comb[0] + r) == n)
      comb[0] = n;
    else 
      next_combination(r, n, comb);
  }

  return 0;
}

void next_combination(r, n, comb)
     SATOINT r, n, comb[];
{
  SATOINT i, j, nr1;
  
  /*
  printf("[ ");
  for (i = 0; i <= r; i++) printf("%2d ", comb[i]);
  printf("]\n");
  */

  i = r;
  nr1 = n - i;
  while (comb[i] == nr1 + i) i--;
  nr1 = ++comb[i];
  for (j = i+1; (j <= r); j++) comb[j] = ++nr1;
}
    
/*****/
int next_permutation (p, l)
     int p[], l;
{
  int i, j, x, y;

  if (l-- < 2) return 0;
  i = l - 1;
  x = p[l]; y = p[i];
  while (y > x) {
    x = y;
    if (i-- == 0) return 0;
    y = p[i];
  }

  j = l;
  while (y > p[j]) j--;

  p[i] = p[j]; 
  p[j] = y;

  i++;
  j = l;
  while (i < j) {
    x = p[i];
    p[i++] = p[j];
    p[j--] = x;
  }

  /*
  printf("   Perm: ");
  for (i = 0; i <= l ; i++) printf(" %d", p[i]);
  printf("\n");
  */
  return 1;
}

int gcd(a, b)
     int a, b;
{
  int x;
  while (a>0) {
    x = b % a;
    b = a; 
    a = x; 
  }
  return b;
}







{------------------------------------------------------
 Haskell library for lazy on-the-fly model checking
 $Author: moedersh $
 $Revision: 1.1 $ of  $Date: 2001/10/02 16:21:04 $
 [imported from personal repository 
  on revision 1.10 at 01/07/13]
 ------------------------------------------------------}

module Lazylib where 

--- Aux lists
flatten :: [[a]] -> [a]
flatten [] = []
flatten (x:xs) = x ++ (flatten xs)

--- Trees
data Tree element = Node element [Tree element]
     deriving (Eq,Show)

--- Sets
type Set a = [a]
emptyset :: Set a
emptyset = []

union  a b = mkSet (a++b)

notin :: Eq a => a -> Set a -> Bool
notin a as = not (elem a as)

deleteBy                :: (a -> a -> Bool) -> a -> [a] -> [a]
deleteBy eq x []         = []
deleteBy eq x (y:ys)     = if x `eq` y then ys else y : deleteBy eq x ys

deleteFirstsBy          :: (a -> a -> Bool) -> [a] -> [a] -> [a]
deleteFirstsBy eq        = foldl (flip (deleteBy eq))

diff :: Eq a => Set a -> Set a -> Set a
diff =  deleteFirstsBy (==)

subseteq :: Eq a => Set a -> Set a -> Bool
subseteq xs ys = all (\x -> elem x ys) xs

seteq xs ys = subseteq xs ys && subseteq ys xs

rootElt :: Tree a -> a
rootElt (Node a _) = a

mapBranches :: ([Tree a] -> [Tree a]) -> Tree a -> Tree a
mapBranches f (Node a l) = Node a (map (mapBranches f) (f l))

filterBranches :: (a -> Bool) -> Tree a -> Tree a
filterBranches f (Node a l) = 
    Node a (filter (f.rootElt) (map (filterBranches f) l)) 

treeFilter :: (Tree a -> Bool) -> Tree a -> Tree a
treeFilter f (Node a l) = 
    Node a (filter f (map (treeFilter f) l))

--- telt: returns element at given address
telt :: [Int] -> Tree a -> a
telt [] (Node a _) = a
telt (n:ns) (Node _ l) = telt ns (head (drop (n) l))

--- Taddr: returns list of direct children at give address
taddr :: [Int] -> Tree a -> [Tree a]
taddr []  (Node _ l) = map (ttake 0) l
taddr (n:ns) (Node _ l) = taddr ns (head (drop (n) l))

--- ttake: returns top n levels
ttake :: Int -> Tree a -> Tree a
ttake 0 (Node a _) = Node a []
ttake n (Node a l) = Node a (map (ttake (n-1)) l)

countnodes :: Tree a -> Int
countnodes (Node _ l) = 1 + (foldl (\a r -> a + r) 0 (map countnodes l))


dfs :: (a -> Bool) -> Tree a -> [a]
dfs p (Node a l) = if p a then (a:rest) else rest
                        where rest = flatten (map (dfs p) l)

{------------------------------------
 PART (1): Data types
 ------------------------------------
 Mainly adopted from cas2lazy.hs
 Difference: Enumeration of identifiers in Msg-Type
 ------------------------------------}

type Atom = String

data AtomMessage = Time Message
		 | Name String deriving (Show,Eq)

data Message 
     = Atomic String
     | Mr Message
     | Pk Message
     | Sk Message
     | Pk' Message
     | Nonce Message
     | Crypt Message Message
     | Scrypt Message Message
     | C Message Message
     | End
     | Pre Message
     | SessionNr Int
     | SuccSession Message
     | Step Int
     | Etc 
     deriving (Eq, Show)

data Term 
     = W Message Message Message Message Message Bool Message
     | M Message Message Message Message Message Message
     | IK Message  ------------ !!!!!!!!!!!
     | H Message -------------- !!!!!!!!!!!
     | Secret Message Message
     deriving (Eq, Show)

bin2un :: Int -> Message
bin2un 0 = End
bin2un (n+1) = Pre (bin2un n)

xetc = Etc

successor :: Message -> Message
successor m = SuccSession m

prev_time :: Message -> Message
prev_time (Pre t) = t

type State = [Term]

data Rule
     = Initial State
     | MsgRule State State
     | Flaw State 
     deriving (Eq, Show)


{-------------------------------
PART 3: Model Check
--------------------------------}

type Creatable = (Message,Bool)

intrudertrafo1 :: [Creatable] -> [[Creatable]]
intrudertrafo1 ik =
  [ (x1,False)
    :(x2,False)
    :(map (\ x -> if (x==((C x1 x2),False)) 
                  then ((C x1 x2),True)
		  else x) ik)
  | ((C x1 x2),_) <- ik ]

intrudertrafo2 ik =
  [ (x2,False)
    :(map (\ x -> if (x==((Crypt (Pk x1) x2),False))
		  then ((Crypt (Pk x1) x2), iknows (Pk x1) ik)
		  else x) ik)
  | ((Crypt (Pk x1) x2),_) <- ik, 
    iknows (Pk' x1) ik ]

intrudertrafo2b ik = 
  [ (x2,False)
    :ik
  | ((Crypt (Pk' x1) x2),_) <- ik, 
    iknows (Pk x1) ik ]

iknows (C key1 key2) ik = (iknows key1 ik) && (iknows key2 ik)
iknows (Scrypt key msg) ik = ((iknows key ik) && (iknows msg ik)) 
                                || (elem ((Scrypt key msg)) (map fst ik))
iknows (Crypt key msg) ik = ((iknows key ik) && (iknows msg ik)) 
                                || (elem ((Crypt key msg)) (map fst ik))
iknows key ik = elem (key) (map fst ik) || (key== (Pk' (Atomic "ki")))

intrudertrafo4 ik =
  [ (msg,False)
    :(map (\ x -> if (fst x==(Scrypt key msg))
		  then ((Scrypt key msg),True)
		  else x) ik) 
  | (Scrypt key msg,_) <- ik , iknows key ik]

fixedpoint :: Eq a => (a -> a) -> a -> a
fixedpoint f x = if (x==(f x)) then x else fixedpoint f (f x)

fixedpointtrace f x = if (x==(f x)) then [x] else x:(fixedpointtrace f (f x))


filter_createls :: [Creatable] -> [Message]
filter_createls [] = []
filter_createls ((x,True):xs) =    filter_createls xs
filter_createls ((x,False):xs) = x:(filter_createls xs)

noncreate :: Message -> Creatable
noncreate x = (x,False)

elim_dup :: [Creatable] -> [Creatable]
elim_dup [] = []
elim_dup ((x,True):xs) = (x,True):(filter (\ (y,_) -> x/=y) (elim_dup xs))
elim_dup ((x,False):xs) = if (haspos x xs) then elim_dup xs else 
			    (x,False):(filter (\ (y,_) -> x/=y) (elim_dup xs))
  where haspos x xs = (filter (\ (y,b) -> x==y && b==True) xs) /= []

fixendum :: [Creatable] -> [Creatable]
fixendum x = 
  let l= ((intrudertrafo1 x) ++ 
                   (intrudertrafo2 x) ++ 
                   (intrudertrafo2b x)++ 
                   (intrudertrafo4 x))
    in 
       if (l==[]) then x else elim_dup (flatten l)

intrudertrafo :: State -> State
intrudertrafo state = 
  let (ik,sec,msg) = filtertypes state ([],[],[]) in
  ((map (\x -> IK x) 
    (filter_createls
    (fixedpoint fixendum (map (\x -> (x,False)) ik))))
  ++ (fixedpoint intrudertrafo3 sec) ++ msg)


filtertypes :: State -> ([Message],[Term],[Term]) -> ([Message],[Term],[Term])
filtertypes [] l = l
filtertypes ((IK m):ms) (ik,sec,other) = filtertypes ms (m:ik,sec,other)
filtertypes ((Secret m s):ms) (ik,sec,other) = filtertypes ms (ik,(Secret m s):sec,other)
filtertypes (m:ms) (ik,sec,other) = filtertypes ms (ik,sec,m:other)

intrudertrafo3 [] = []
intrudertrafo3 ((Secret x (SuccSession s)):secs) = (Secret x s):(intrudertrafo3 secs)
intrudertrafo3 (s:ecs) = s:(intrudertrafo3 ecs)

mkSet [] = []
mkSet (x:xs) = x:(filter (\y -> x/=y) (mkSet xs))



type Newstate = (State,State,[(String,String)]) --- With Rule Name


f:: State -> String -> [(String,String)] -> State -> Newstate

f state name history x = 
  let sucstate = mkSet (intrudertrafo x) in	
  let newstuff = diff sucstate state in
  let msgTerms = [ M m1 m2 m3 m4 m5 m6 | M m1 m2 m3 m4 m5 m6 <- newstuff ] in
  let msg = if (msgTerms==[]) then "" else beautify (head msgTerms) in 
  (newstuff,diff sucstate newstuff, (name,msg):history)

g :: Bool -> (State -> [State]) -> State -> State -> State -> Bool
g b sfct state1 state2 x = b ||
  (not (subseteq x (trimState ((flatten (sfct ((head [H t| H t <-state1]):state2)))++state1)) ))

beautify :: Term -> String
beautify (M _ (Mr (Atomic r)) (Mr (Atomic o)) (Mr (Atomic rc)) msg _) =
  (if (r==o) then r++"   " else r++"("++o++")") ++ "->" ++ rc ++ ": " ++ (bmsg msg)
beautify m = "Don't ask me how old this version must be " ++ (show m)

bcnt :: Message -> Int 
bcnt End = 0
bcnt (Pre msg) = 1+(bcnt msg)
bcnt (C _ cnt) = bcnt cnt
bcnt (Mr msg) = -1

bmsg :: Message -> String
bmsg (Atomic m) = m
bmsg (Mr x) = bmsg x
bmsg (Pk (C msg1 msg2)) =  (bmsg msg1) ++"("++(bmsg msg2)++")"
bmsg (Pk msg) =  (bmsg msg)
bmsg (Sk (C msg1 msg2)) =  (bmsg msg1) ++"("++(bmsg msg2)++")"
bmsg (Sk msg) =  (bmsg msg)
bmsg (Pk' (C msg1 msg2)) =  (bmsg msg1) ++"("++(bmsg msg2)++")"
bmsg (Pk' msg) =   (bmsg msg)
bmsg (Nonce (C msg1 msg2)) =  (bmsg msg1) ++"("++(bmsg msg2)++")"
bmsg (Nonce msg) =  (bmsg msg)
bmsg (Crypt m1 m2) = "{" ++ (bmsg m2) ++ "}" ++ (bmsg m1)
bmsg (Scrypt m1 m2) = "{" ++ (bmsg m2) ++ "}" ++ (bmsg m1)
bmsg (C m1 m2) = (bmsg m1)++ "," ++ (bmsg m2)
bmsg (End) = "0"
bmsg (Pre m) = show (bcnt (Pre m))
bmsg m = (show m)

succs:: Bool -> Newstate -> (State -> [State], String) -> [Newstate]
succs b (state1,state2,history) (sfct,name) = 
  let state = state1++state2 in
  let name' = if b then '*':name else name in
  let filtered = (filter (g b sfct state1 state2) (map trimState (sfct state))) in
  let filtered2 = filtered in --- geht doch nich so gut---- if (not b && filtered==[]) then (filter (g True sfct state1 state2)(map trimState (sfct state))) else filtered in
  map (f state name' history) filtered2
   

setequal s1 s2 = ((diff s1 s2)==[]) && ((diff s2 s1)==[])

myfilter [] = []
myfilter ((s1,s2,n):sets) =(s1,s2,n):(filter (\ (x1,x2,y) -> not( setequal (s1++s2) (x1++x2))) (myfilter sets))


trimPair :: Message -> Message -> Message
trimPair (C msg1 msg2) msg3 = C msg1 (trimMsg (C msg2 msg3))
trimPair msg1 msg2 = C msg1 (trimMsg msg2)

trimMsg :: Message -> Message
trimMsg msg = 
  case msg of
    C msg1 msg2      -> let msg1' = trimMsg msg1
		        in trimPair msg1' msg2
    Nonce msg1       -> Nonce (trimMsg msg1)
    Pre msg1         -> Pre (trimMsg msg1)
    SuccSession msg1 -> SuccSession (trimMsg msg1)
    Crypt (Pk x) (Crypt (Pk' x') msg) ->
              if (x==x') then trimMsg msg
              else Crypt (trimMsg (Pk x)) (trimMsg (Crypt (Pk' x') msg))
    Crypt (Pk' x) (Crypt (Pk x') msg) ->
	      if (x==x') then trimMsg msg
	      else Crypt (trimMsg (Pk' x)) (trimMsg (Crypt (Pk x') msg))
    Crypt msg1 msg2  -> Crypt (trimMsg msg1) (trimMsg msg2)
    Scrypt msg1 msg2 -> Scrypt (trimMsg msg1) (trimMsg msg2)
    otherwise        -> msg

trimTerm :: Term -> Term
trimTerm (W m1 m2 m3 m4 m5 b m6) = W (trimMsg m1)(trimMsg m2)(trimMsg m3)(trimMsg m4)(trimMsg m5) b (trimMsg m6)
trimTerm (M m1 m2 m3 m4 m5 m6) = M (trimMsg m1)(trimMsg m2)(trimMsg m3)(trimMsg m4)(trimMsg m5) (trimMsg m6)
trimTerm (IK m1) = IK (trimMsg m1)
trimTerm (H m1) = H (trimMsg m1)
trimTerm (Secret m1 m2) = Secret (trimMsg m1)(trimMsg m2)

trimState :: State -> State
trimState = map trimTerm

treeconstruct :: (a -> Bool -> [a]) -> Int -> a -> Tree a
treeconstruct successor i init = Node init (map (treeconstruct successor (i-1)) (successor init (i>0)) )

prlist :: Newstate -> String
prlist (s1,s2,l) = "\n*****\n" ++ (prnode (reverse l))

trsz 0 str = ""
trsz n (x:xs) = x:(trsz (n-1) xs)
trsz n []  = " " ++ (trsz (n-1) [])

prnode [] = ""
prnode ((step,msg):l) = ( trsz 18 ("(" ++ step ++ ") ")) 
                        ++  msg ++ "\n" ++ (prnode l)

wrids :: Int -> (Newstate -> Bool) -> Tree Newstate -> String
wrids 0 p (Node a l) = if p a then (prlist a) else []
wrids n p (Node a l) = if p a then ((prlist a)++rest) else rest
      where rest = flatten (map (wrids (n-1) p) l) 

top :: Tree Newstate -> State
top (Node (a,b,_) _) = a++b

children :: Tree Newstate -> [Tree Newstate]
children (Node _ l) = l

nth :: Tree Newstate -> Int -> Tree Newstate
nth t n = nthl (children t) n

nthl [] _ = error "Ply to short"
nthl (x:_) 0 = x
nthl (_:xs) n = nthl xs (n-1)

nprint :: Newstate -> String
nprint (_,_,labels) = show labels

nprintt :: Tree Newstate -> String
nprintt (Node a l) = nprint a

printniveau :: Tree Newstate -> String
printniveau (Node a l) = flatten (map nprintt l)

traverse :: Tree Newstate -> [Int] -> Tree Newstate
traverse t [] = t
traverse t (x:xs) = traverse (nth t x) xs

size :: Int -> Tree Newstate -> Int
size 0 _ = 1
size (n+1) (Node _ l) = foldl (+) 0 (map (size n) l)

len (Node _ l) = length l

#!/usr/bin/perl
#
#
# produce a file suitable for datac, using the lazy intruder strategy :
# automatic divert (not looking at intruder's definition)
#

package IFTOCL;
use strict ;
use perl::lib::Module::Writedatacfile;
use perl::lib::Module::ReglesParalleles ;

#######################################
# Edit according to your environment  #
#######################################

sub PrintDebug {
  #   print @_;
}

sub new {# $path , $file.cas $stream o\`u ecrire
  my $self = {};
  my $path =shift;
  my $filename = shift;
  $self->{FileName} = $filename;
  $self->{OutPut} = SetOutPutFile($filename);
  $self->{BinPath} = "$path/bin/";
  $self->{Casrul} = "$path/bin/hlpsl2if";
  $self->{IncludePath} = "$path/include";
  $self->{NbSteps} = undef;
  $self->{NbSessions} = undef;
  $ReglesParalleles::Datac="$path/bin/datac";
  $ReglesParalleles::Casrul="$path/bin/hlpsl2if";
  $WriteDatacfile::Casrul="$path/bin/hlpsl2if";
  $self->{ParallelStudy} = ReglesParalleles->new($filename,$self->{OutPut});
  bless($self);
  return $self;
}


sub BEGIN {# Init. function
  my $self;

  sub NeedsParallel {
    my $self =shift;
    my $file = $self->{FileName};
    my $casrul = $self->{Casrul};
    my $result = 0;
    open(TMP_FILE,"$casrul --para $file | grep mess |wc -l |") or die "Aaaargh !\n";
    $result = <TMP_FILE>; 
    PrintDebug "Testing the need for parallel sessions... ";
    if ($result) {
      PrintDebug "yes\n";
    }
    else {
      PrintDebug "no\n";
    }
    close TMP_FILE ;
    return $result;
  }

  sub Init {
    my $path = shift;
    my $file = shift;

    $self = new($path,$file);
    $self->{NbSteps} = GetNbSteps();
    $self->{NbSessions} = GetNbSessions();
    PrintDebug "there is $self->{NbSessions} regular session\n" ;
    $Writedatacfile::self = $self ;
    if (NeedsParallel($self) ){
      my $study = $self->{ParallelStudy};
      $self->{ParallelStudy} = $study->ComputeProtocolClauses();
    }
    else {
      $self->{ParallelStudy} = 0;
    }
    return $self;
  }


  sub GetNbSteps {
    my $nbsteps = 0;
    my $casfile = $self->{FileName};
    my $casrul = $self->{Casrul};
    my $debug;
    open(foo,"$casrul --rules $casfile | grep Step | wc -l |") or die "cannot open $!\n";
    $nbsteps = <foo>;
    chomp ($nbsteps);
    close(foo);
    return $nbsteps;
  }
  
  sub GetNbSessions {
    my $casfile = $self->{FileName};
    my $casrul = $self->{Casrul};
    my $buffer;
    my $term;
    my $debug;
    PrintDebug "Looking for the number of sessions...";
    my $sesscount=0;
    open(foo,"$casrul --init $casfile | grep w |") or die "cannot open $!\n";
    while ($buffer = <foo>) {
      foreach $term (split(/\./,$buffer)) {
	if ($term =~ /([0-9]+)\)$/ ) {
	  if ( ($debug = $1 ) >= $sesscount) {
	    $sesscount = $1;
	  }
	}
      }
    }
    close(foo);
    PrintDebug "$sesscount sessions found\n";
    return $sesscount;
  }
  
}

sub SetOutPutFile {
  my $casfile = shift;
  my $name = $casfile;
  my $fh;
  #  local FOO;
  if ( -e $casfile ){
    PrintDebug $name;
    if ($name =~ /(.*)\.cas$/ ){
      my $datfile = "$1.dat";
      PrintDebug "\n\tResult is in file $datfile\nHave a nice time ;)\n\n";
      open(FOO,"+> $datfile ") or die "Oups ! It seems I don't have write permissions";
      my $title = $IFTOCL::Title;
      print FOO "$title";
    }
    else {
      print FOO  "# Couldn't figure the name of the file out, writing to standard output\n";
    }
  }
  else { 
    die "$casfile not found\n";
  }
  $fh = \*FOO;
  return $fh;
}

#
# Fonctions used in Init
#


sub WriteDatacFile {
  my $self = shift;
  Writedatacfile::WriteDatacFile($self);
}




($IFTOCL::Title = <<END_OF_TITLE);
#                                                                                          
#         *****  *      ***** **                               * ***         ***** *       
#      ******  *     ******  **** *     *                    *  ****  *   ******  *        
#     **   *  *     **   *  *  ***     **                   *  *  ****   **   *  *         
#    *    *  *     *    *  *    *      **                  *  **   **   *    *  *          
#        *  *          *  *          ********    ****     *  ***            *  *           
#       ** **         ** **         ********    * ***  * **   **           ** **           
#       ** **         ** **            **      *   ****  **   **           ** **           
#     **** **         ** ******        **     **    **   **   **           ** **           
#    * *** **         ** *****         **     **    **   **   **           ** **           
#       ** **         ** **            **     **    **   **   **           ** **           
#  **   ** **         *  **            **     **    **    **  **           *  **           
# ***   *  *             *             **     **    **     ** *      *        *            
#  ***    *          *****             **      ******       ***     *     ****           * 
#   ******          *  *****            **      ****         *******     *  *************  
#     ***          *    ***                                    ***      *     *********    
#                  *                                                    *                  
#                   **                                                   **                
#                                                                                          
#                                                                                          
#                                                                                          
#
# (Version Objet,  12 avril  2001)
# 
END_OF_TITLE

1;





import Lazylib
import Rules

startfull = 25 --- full search (no pruning of tree) when 25 plies ahead.

succrel :: Newstate -> Bool -> [Newstate]
succrel nstate b = myfilter (foldr (++) [] (map (succs b nstate) allrules))
 
tree :: Int -> Tree Newstate
tree i= treeconstruct succrel (i-startfull) (initial_state i,[],[])

tree' :: Int -> Int -> Tree Newstate
tree' i j = treeconstruct succrel i (initial_state j,[],[])

attack_pred :: Newstate -> Bool
attack_pred (ns,os,_) = not (goal (ns++os))

niveau_n n = "Ply "++(show n)++"\n"++
                  let l=wrids n attack_pred (tree n)
		  in if (l==[]) then niveau_n (n+1)
		     else l

interacter :: String -> String
interacter _ = niveau_n 0

main = interact interacter

:- use_module(library(ordsets)).
:- multifile portray/1.
:- dynamic portray/1.

solver_invocation_command(sato,FN_DIMACS,LOGFILE,CHARS) :-
	value(sato_executable,SOLVER_PATH),
	format_to_chars('~w ~w > ~w',[SOLVER_PATH,FN_DIMACS,LOGFILE],CHARS).
solver_invocation_command(chaff,FN_DIMACS,LOGFILE,CHARS) :-
	value(chaff_executable,SOLVER_PATH),
	value(chaff_configfile,SOLVER_CONFIGFILE),
	format_to_chars('~w ~w ~w ~w > /dev/null',
			[SOLVER_PATH,FN_DIMACS,LOGFILE,SOLVER_CONFIGFILE],CHARS).
solver_invocation_command(sim,FN_DIMACS,LOGFILE,CHARS) :-
	value(sim_executable,SOLVER_PATH),
	value(sim_options,SOLVER_OPTIONS),
	format_to_chars('~w ~w ~w > ~w',[SOLVER_PATH,SOLVER_OPTIONS,FN_DIMACS,LOGFILE],CHARS).

print_output :-
	value(steps,Steps),
	parse_log(Ans,Time),
	( Ans=unsat ->
	    format('\nNo plan found in ~w sec and in ~w steps\n\n',[Time,Steps]),
	    ( value(sound,on) ->
		system('play sound/fail.wav') ;
		true ) ;
	    format('\nPlan found in ~w sec and in ~w steps:\n\n',[Time,Steps]),
	    value(attacks_number,Prev),
	    Curr is Prev + 1,
	    set(attacks_number,Curr),
	    assert(syntax(message_body)),
	    print_models(Ans),
%	    retract(syntax(message_body)),
	    (value(sound,on) ->
		system('play sound/success.wav') ;
		true )).

% % [LC]:TODO
% print_attack :-
% 	parse_log_get_actions(Ans,Time),
%  	( Ans=unsat ->
%  	    format('\nNo plan found in ~w sec\n\n',[Time]),
%  	    ( value(sound,on) ->
%  		system('play sound/fail.wav') ;
%  		true )
% 	;
%  	    format('\nPlan found in ~w sec:\n\n',[Time]),
%  	    value(attacks_number,Prev),
%  	    Curr is Prev + 1,
%  	    set(attacks_number,Curr),
%  	    print_model_actions(Ans),
%  	    (value(sound,on) ->
%  		system('play sound/success.wav') ;
%  		true )).

atomof(N,T) :-
	value(steps,S),
	I is ((N - 1) mod (S + 1)),
	M is N - I,
	numof(A,M),
	atom_codes(A,TCs),
	number_codes(I,CI),
	append(CI,[58|TCs],TTCs),
	append(TTCs,".",CsDot),
	read_from_chars(CsDot,T).
% Original version
% atomof(N,T) :-
% 	numof(A,N),
% 	atom_codes(A,Cs),
% 	append(Cs,".",CsDot),
% 	read_from_chars(CsDot,T).

% NEW PRINT_MODEL
print_models([]).
print_models([Ns|Ms]) :-
	setof(A,N^(member(N,Ns), atomof(N,A)),As),
	print_model(As),
	print_models(Ms).

print_model(As) :-
	value(output,planning),	
	value(time,I),
	setof(S,(member(I:S,As), predicate(fluent,S)),Ss),
	format('~w \n',[Ss]),
	value(steps,Steps),
	( I<Steps -> print_action(I,As) ),
	fail.
print_model(As) :-
	(value(output,html);value(output,standard)),		
	value(time,I),
	value(steps,Steps),
	( I<Steps -> print_attack_messages(I,As) ),
	fail.
print_model(_).


% % OLD PRINT_MODEL
% print_models([]).
% print_models([Ns|Ms]) :-
% 	setof(A,N^(member(N,Ns), atomof(N,A)),As),
% 	print_model(As),
% 	print_models(Ms).

% print_model(As) :-
% 	value(time,I),
% 	setof(S,(member(I:S,As), predicate(fluent,S)),Ss),
% 	format('~w \n',[Ss]),
% 	value(steps,Steps),
% 	( I<Steps -> print_action(I,As) ),
% 	fail.
% print_model(_).

print_action(I,As) :-
	setof(S,(member(I:S,As), predicate(action,S)),Ss), !,
	format('\nStep ~w:\t ~w\n\n',[I,Ss]).
print_action(I,_) :-
	format('\nStep ~w:\t ~w\t',[I,null]),
	format('[]\n\n',[]).

print_attack_messages(I,As) :-
	setof(S,(member(I:S,As), predicate(action,S)),Ss), !,	
	findall(msg(MSTEP,RealSender,A,B,MSG,SesBase),
		(
		  member(Op,Ss),
		  action(Op,_,Pre,Add,_),
		  member(m(MSTEP,A,B,MSG),Add),
		  (
		    member(wk(_,_,B,_,_,Ses),Pre),
		    RealSender = intruder
		  ;
		    member(wk(_,_,A,_,_,Ses),Pre),
		    RealSender = honest_agent
		  ),
		  pif2sate_gsession(Ses,SesBase)
		),
		TmpMSGs),
	remove_duplicates(TmpMSGs,MSGs),
	(MSGs=[] ->
	    format('\nStep ~w:\t ~w\n',[I,Ss])
	;
	    format('\nStep ~w:\t [',[I]),
	    print_messages(MSGs),
	    format(']\n',[])
	).
print_attack_messages(I,_) :-
	format('\nStep ~w:\t ~w\t',[I,null]),
	format('[]\n\n',[]).

print_messages([]) :- !.
print_messages([MSG]) :- !,
	print_message(MSG).
print_messages([MSG|MSGs]) :-
	print_message(MSG),
	format("; ",[]),
	print_messages(MSGs).	
print_message(msg(MSTEP,intruder,A,B,MSG,SesBase)) :-
	A\=mr(intruder),
	!,
	format("~w.~w. I(~p) -> ~p :",[SesBase,MSTEP,A,B]),
	print_message_body(MSG).
print_message(msg(MSTEP,_,A,B,MSG,SesBase)) :-
	format("~w.~w. ~p -> ~p : ",[SesBase,MSTEP,A,B]),
	print_message_body(MSG).

print_message_body(MSG) :-
	print(MSG).

% OUTPUT MESSAGES
portray(crypt(K,MSG)) :-
	syntax(message_body),
	format("{~p}~p",[MSG,K]).
portray(scrypt(K,MSG)) :- 
	syntax(message_body),	
	format("{~p}~p",[MSG,K]).
portray(c(MSG1,MSG2)) :- 
	syntax(message_body),	
	format("~p,~p",[MSG1,MSG2]).
portray(funct(K,MSG)) :- 
	syntax(message_body),	
	format("funct(~p,~p)",[K,MSG]).
portray(rcrypt(MSG1,MSG2)) :-
	syntax(message_body),	
	format("xor(~p,~p)",[MSG1,MSG2]).

portray(primed(T)) :-
	syntax(message_body),		
	format("~p'",[T]).
portray(T) :-
	syntax(message_body),	
	T=..[F,c(C,fresh)],
	member(F,[pk,sk,nonce]),
	format("~p",[C]).
portray(T) :-
	syntax(message_body),		
	T=..[F,C],
	member(F,[pk,sk,nonce,fu,mr]),	
	format("~p",[C]).
portray(intruder) :-
	format("I",[]).
% % [LC]: parse and print directly the attack
% parse_log_get_actions(Acts,Time) :-
% 	file_name(log,LOGFILE),
% 	see(LOGFILE),
% 	read2string(Cs),
% 	seen,
% 	value(solver,Solver),
% 	parse_log_get_actions(Solver,Cs,Acts,Time).

% parse_log_get_actions(chaff,Cs,Acts,Time) :-
% 	chaff_log_get_actions(Acts,Time,Cs,[]).

% % HERE CHAFF ATTACK
	


% Original
parse_log(Ans,Time) :-
	file_name(log,LOGFILE),
	see(LOGFILE),
	read2string(Cs),
	seen,
	value(solver,Solver),
	parse_log(Solver,Cs,Ans,Time).

read2string(Cs) :-
	get_code(C),
	( C== -1 ->
	    Cs=[] ;
	    Cs=[C|Cs1],
	    read2string(Cs1) ).

% user:portray(Cs) :- codes(Cs), atom_codes(A,Cs), format('"~w"',[A]).

codes([]).
codes([C|Cs]) :- number(C), codes(Cs).

parse_log(sato,Cs,Ans,Time) :- sato_log(Ans,Time,Cs,[]).
parse_log(chaff,Cs,Ans,Time) :- chaff_log(Ans,Time,Cs,[]).
parse_log(sim,Cs,Ans,Time) :- sim_log(Ans,Time,Cs,[]).

% SATO
sato_log(Ans,Time) --> sato_preamble, sato_rest(Ans,Time).
sato_preamble --> lines(10).
lines(1) --> line, !.
lines(N) --> line, {N1 is N-1}, lines(N1).
line --> [C], {C=\="\n"}, !, line.
line --> "\n".
sato_rest(unsat,Time) -->
	"The clause set is unsatisfiable.\n",
	sato_failure_postamble(Time).
sato_rest([Ns],Time) -->
	"Model #1: (indices of true atoms)\n",
	sep0, sato_model(Ns), sep0,
	"The number of found models is 1.\n",
	sato_success_postamble(Time).

sato_model([N|Ns]) --> number(N), sep0, sato_model(Ns), !.
sato_model([N]) --> number(N).

sato_failure_postamble(Time) -->
	lines(4),
	"run time (seconds)", sep0,
	number(Time),
	lines(6).
sato_success_postamble(Time) -->
	lines(7), 
	"run time (seconds)", sep0,
	number(Time),
	lines(6).

% CHAFF
chaff_log_get_actions(unsat,Time) -->
	"unsat",  sep,
	chaff_postamble(Time).

chaff_log_get_actions([Acts],Time) -->
	"\"[",
	chaff_model_get_actions(Acts),
	"]\"", sep,
	chaff_postamble(Time).

% chaff_model_get_actions(Acts) :-
% chaff_model_(Ns) --> chaff_model(Ns,1).
% chaff_model(Ns,N) --> "0", {N1 is N+1}, chaff_model(Ns,N1).
% chaff_model([N|Ns],N) --> "1", {N1 is N+1}, chaff_model(Ns,N1).
% chaff_model([],_) --> [].

% 	pippo
	
chaff_log(unsat,Time) -->
	"unsat", sep,
	chaff_postamble(Time).
chaff_log([Ns],Time) -->
	"\"[",
	chaff_model(Ns),
	"]\"", sep,
	chaff_postamble(Time).

chaff_postamble(Time) -->
	string, sep,
	"\"", float(Time), "\"", sep,
	number(_), sep,
	number(_), sep0.

% SIM
sim_log(unsat,Time) --> 
	"0",!,sep,
	number(_),sep,
	number(_),sep,
	number(_),sep,
	number(Time),
	lines(1),!.

sim_log([Ns],Time) --> 
	"1",!,sep,
	number(_),sep,
	number(_),sep,
	number(_),sep,
	number(Time),sep,	
	lines(1),
	"Solution",
	sim_model(Ns),
	lines(1),!.

%Parsing SIM clauses
sim_model(Ns) --> sep,"-",pnat(_),sim_model(Ns).
sim_model([N|Ns]) --> sep,pnat(N),sim_model(Ns).
sim_model([]) --> [].

%Parsing CHAFF clauses
chaff_model(Ns) --> chaff_model(Ns,1).
chaff_model(Ns,N) --> "0", {N1 is N+1}, chaff_model(Ns,N1).
chaff_model([N|Ns],N) --> "1", {N1 is N+1}, chaff_model(Ns,N1).
chaff_model([],_) --> [].

float(F) --> signed_number(M), "e", !, signed_number(E), {F is M*(10**E)}.
float(F) --> signed_number(F).

integer(N1) --> "-", !, pnat(N), {N1 is -N}.
integer(N) --> "+", !, pnat(N).
integer(N) --> pnat(N).

signed_number(N1) --> "-", !, number(N), {N1 is -N}.
signed_number(N) --> "+", !, number(N).
signed_number(N) --> number(N).

pnat(N) --> digit(C), digit_multi(Cs), !, {number_codes(N,[C|Cs])}.
pnat(N) --> digit(C), {number_codes(N,[C])}. 

number(N) --> digit_or_dot(C), digit_or_dot_multi(Cs), !, {number_codes(N,[C|Cs])}.
number(N) --> digit_or_dot(C), {number_codes(N,[C])}. 

digit(C) --> [C], {("0"=<C, C=<"9")}.

digit_multi([C|Cs]) --> digit(C), digit_multi(Cs), !.
digit_multi([C]) --> digit(C).
	
digit_or_dot(C) --> [C], {[C]="."}.
digit_or_dot(C) --> digit(C).

digit_or_dot_multi([C|Cs]) --> digit_or_dot(C), digit_or_dot_multi(Cs), !.
digit_or_dot_multi([C]) --> digit_or_dot(C).

sep0 --> sep.
sep0 --> [].

sep --> sep_char, sep, !.
sep --> sep_char.

sep_char --> " ".
sep_char --> "\n".
sep_char --> "\t".

string --> "\"", char_multi, "\"".
char_multi --> [C], {\+[C]="\""}, char_multi, !.
char_multi --> [].


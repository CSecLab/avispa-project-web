:- use_module(library(terms)).
:- ensure_loaded(operators).
:- ensure_loaded(instantiators).

:- dynamic numof/2.

print_wff(true) :- !.
print_wff(W) :- format('~w\n',[W]).
print_clause([true]) :- !.
print_clause(Ls) :- 
	print_literals(Ls),
	write('0\n'),
	increment_clause_counter.
print_dimacs_header(N,C) :-
	format('p cnf ~w ~w\n',[N,C]).

print_literals([]).
print_literals([L|Ls]) :-
	print_literal(L), write(' '),
	print_literals(Ls).

print_literal(~A) :- !, write('-'), print_atom(A).
print_literal(A) :- print_atom(A).

sate_term_hash(A,H) :-
	format_to_chars('~w',[A],CHARS),
	atom_codes(H,CHARS).

print_atom(A) :-
 	sate_term_hash(A,H),
	numof(H,N), !,
	write(N).
print_atom(A) :-
	retract(value(curnum,N)),
 	sate_term_hash(A,H),
	assert(numof(H,N)),
	write(N),
	N1 is N+1,
	assert(value(curnum,N1)).

print_encoding :-
	encode(W),
	( value(dimacs,on) ->
	    print_clause(W) ;
	    print_wff(W) ),
	fail.
print_encoding.

encode(W2) :-
	encode(initial_fact,W),
	simplify(W,W1),
	( value(dimacs,on) ->
	    clause_of(W1,W2) ;
	    W2=W1 ).
encode(W2) :-
	encode(goal,W),
	simplify(W,W1),
	( value(dimacs,on) ->
	    clause_of(W1,W2) ;
	    W2=W1 ),
	print_statistics(goal).
encode(W2) :-
	value(steps,N),
	value(encoding,Encoding),
	member(AxType,Encoding),
	print_statistics(AxType),
	encode(AxType,I,I1,W),
	simplify(W,W1),
	( value(dimacs,on) ->
	    clause_of(W1,W2) ;
	    W2=W1 ),
	value(time,I),
	I<N,
	I1 is I+1.
encode(_) :-
	print_statistics(goal),
	fail.

encode(initial_fact,W) :-
	predicate(fluent,P),
	facts(Fs),
	( member(P,Fs) ->
	    W=(0:P) ;
	    W=(~0:P) ).
encode(goal,N:G) :-
	value(steps,N),
	goal(Gs),
	member(G,Gs).
encode(ape_axiom,I,I1,W) :- 
	action(Op,Cond,Pre,Add,Del),
	predicate(action,Op),
	call(Cond),
	ape_axiom(I,I1,Op,Pre,Add,Del,W).
encode(explanatory_frame_axiom,I,I1,W) :- 
	predicate(fluent,P),
	explanatory_frame_axiom(P,I,I1,W).
encode(classical_frame_axiom,I,I1,I:Op=>(I:P<=>I1:P)) :-
	action(Op,Cond,_,Add,Del),
	predicate(action,Op),
	call(Cond),
	predicate(fluent,P),
	\+member(P,Add),
	\+member(P,Del).
encode(at_least_one_axiom,I,_,W) :-
	at_least_one_action_axiom(I,W).
encode(complete_exclusion_axiom,I,_,~(I:Op1 & I:Op2)) :- 
	action(Op1,Cond1,_,_,_),
	action(Op2,Cond2,_,_,_),
	( Op1@<Op2 -> true; \+ \+ (Op1=Op2)),  % early pruning
	call(Cond1),
	call(Cond2),
	predicate(action,Op1),
	predicate(action,Op2),
	Op1@<Op2.
encode(conflict_exclusion_axiom,I,_,~(I:Op1 & I:Op2)) :- 
	action(Op1,Cond1,Pre1,_,Del1),
	action(Op2,Cond2,Pre2,_,Del2),
	( Op1@<Op2 -> true; \+ \+ (Op1=Op2)),  % early pruning
	call(Cond1),
	call(Cond2),
	predicate(action,Op1),
	predicate(action,Op2),
	Op1@<Op2,
	( ( member(X,Pre1), member(X,Del2) ) ->
	    true ;
	    member(X,Pre2), member(X,Del1) ).

ape_axiom(I,_,Op,Pre,_,_,I:Op=>I:P) :-
	member(P,Pre),
	predicate(fluent,P).
ape_axiom(I,I1,Op,_,Add,_,I:Op=>I1:P) :- 
	member(P,Add).
ape_axiom(I,I1,Op,_,_,Del,I:Op=> ~I1:P) :- 
	member(P,Del).
	
explanatory_frame_axiom(P,_,_,_) :-
 	action(Op,Cond,_,Add,Del),
 	predicate(action,Op),
 	call(Cond),
	( member(P,Add) ->
	    assertz(value(addop,Op)) ;
	    member(P,Del) ->
	    assertz(value(delop,Op)) ;
	    true ),
	fail.
explanatory_frame_axiom(P,I,I1,(~I:P & I1:P)=>AddDisj) :-
	collect_disjuncts(addop,I,AddDisj).
explanatory_frame_axiom(P,I,I1,(I:P & ~I1:P)=>DelDisj) :- 
	collect_disjuncts(delop,I,DelDisj).

collect_disjuncts(Type,I,I:DelOp v Disj) :-
	retract(value(Type,DelOp)), !,
	collect_disjuncts(Type,I,Disj).
collect_disjuncts(_,_,false).
	
at_least_one_action_axiom(_,_) :-
	action(Op,Cond,_,_,_),
	predicate(action,Op),
	call(Cond),
	assertz(value(oneact,Op)),
	fail.
at_least_one_action_axiom(I,Disj) :-
	collect_disjuncts(oneact,I,Disj).

reset_atom_db :-
	retractall(numof(_,_)),
	retractall(value(curnum,_)),
	assert(value(curnum,1)).

reset_clause_counter :-
	retractall(value(clause_counter,_)),
	assert(value(clause_counter,0)).
increment_clause_counter :-
	retract(value(clause_counter,X)),
	X1 is X+1,
	assert(value(clause_counter,X1)).

atoms_at([],_,[]).
atoms_at([A|As],I,[I:A|IAs]) :-
	atoms_at(As,I,IAs).
	
reset_statistics :-
	retractall(value(tmp_clause_counter,_)),
	assert(value(tmp_clause_counter,0)),
	retractall(value(previous_ax_type,_)),
	assert(value(previous_ax_type,initial_fact)),
	statistics(_,_), !.

print_statistics(CAT) :-
	retract(value(previous_ax_type,PAT)),
	retract(value(tmp_clause_counter,CC0)),
	value(clause_counter,CC1),
	assert(value(tmp_clause_counter,CC1)),
	CC is CC1-CC0,
	statistics(runtime,[_,RT]),
	explanation(PAT,E),
	RT1 is RT/1000,
	format(user_output,'~w~w\t~w\n',[E,CC,RT1]),
	assert(value(previous_ax_type,CAT)).

explanation(initial_fact,'Initial Facts:\t\t\t').
explanation(goal,'Goal:\t\t\t\t').
explanation(ape_axiom,'Action Effect Axioms:\t\t').
explanation(classical_frame_axiom,'Classical Frame Axioms:\t\t').
explanation(explanatory_frame_axiom,'Explanatory Frame Axioms:\t').
explanation(at_least_one_axiom,'At-least-one Axioms:\t\t').
explanation(complete_exclusion_axiom,'Complete Exclusion Axioms:\t').
explanation(conflict_exclusion_axiom,'Conflict Exclusion Axioms:\t').

%% CLAUSIFIER

clause_of(A,C) :- clause_of(A,[],C).

clause_of(~(~A),C,CA) :- !, clause_of(A,C,CA).
clause_of(~(A v B),C,CAB) :- !,	clause_of(~A & ~B,C,CAB).
clause_of(~(A & B),C,CAB) :- !,	clause_of(~A v ~B,C,CAB).
clause_of(~(A <=> B),C,CAB) :- !, clause_of(~A <=> B,C,CAB).
clause_of(~(A <~> B),C,CAB) :- !, clause_of((A <=> B),C,CAB).
% clause_of(false v B,C,CB) :- !, clause_of(B,C,CB).
% clause_of(A v false,C,CA) :- !, clause_of(A,C,CA).
% clause_of(true v _,_,[true]) :- !.
% clause_of(_ v true,_,[true]) :- !.
clause_of(A v B,C,CAB) :- !,
	clause_of(A,C,CA),
	clause_of(B,CA,CAB).
% clause_of(true & B,C,CB) :- !, clause_of(B,C,CB).
% clause_of(A & true,C,CA) :- !, clause_of(A,C,CA).
% clause_of(false & _,_,[]) :- !.
% clause_of(_ & false,_,[]) :- !.
clause_of(A & _,C,CA) :- clause_of(A,C,CA).
clause_of(_ & B,C,CB) :- !, clause_of(B,C,CB).
clause_of(A => B,C,CAB) :- !, clause_of(~A v B,C,CAB).
clause_of(A <=> B,C,CAB) :- clause_of(~A v B,C,CAB).
clause_of(A <=> B,C,CAB) :- !, clause_of(~B v A,C,CAB).
clause_of(A <~> B,C,CAB) :- !, clause_of(~(A <=> B),C,CAB).
% clause_of(~(false),_,[true]) :- !.
% clause_of(~(true),_,[]) :- !.
clause_of(A,C,[A|C]).

simplify0((false & _),false) :- !.
simplify0((_ & false),false) :- !.
simplify0((true & Q),Q) :- !.
simplify0((Q & true),Q) :- !.
simplify0((true v _),true) :- !.
simplify0((_ v true),true) :- !.
simplify0((false v Q),Q) :- !.
simplify0((Q v false),Q) :- !.
simplify0((~false),true) :- !.
simplify0((~true),false) :- !.
simplify0(_=>true,true) :- !.
simplify0(false=>_,true) :- !.
simplify0(true=>A,A) :- !.
simplify0(A=>false,~A) :- !.
simplify0(A<=>true,A) :- !.
simplify0(true<=>A,A) :- !.
simplify0(A<=>false,~A) :- !.
simplify0(false<=>A,~A) :- !.
simplify0(A<~>true,~A) :- !.
simplify0(true<~>A,~A) :- !.
simplify0(A<~>false,A) :- !.
simplify0(false<~>A,A) :- !.
simplify0(A,A).

simplify((P & Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 & Q1), PQ1).
simplify((P v Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 v Q1), PQ1).
simplify((P <=> Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 <=> Q1), PQ1).
simplify((P => Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 => Q1), PQ1).
simplify((P <~> Q), PQ1) :- !,
	simplify(P,P1),
	simplify(Q,Q1),
	simplify0((P1 <~> Q1), PQ1).
simplify((~A),A2) :- !,
	simplify(A,A1),
	simplify0((~A1),A2).
simplify(_:A,true) :- invariant(A), !.
simplify(_:A,false) :- invariant(~(A)), !.
simplify(I:A,I:A2) :-
	invariant(A<=>A1),
	A1 @< A, !,
	simplify(I:A1,I:A2).
simplify(A,A).


% %% PARSER FOR DIMACS FILES
% %% Used for debugging purposes only (so far).
% parse_dimacs :-
% 	set(dimacs,off),
% 	file_name(dimacs,FN_DIMACS),
% 	see(FN_DIMACS),
% 	read2string(CHs),
% 	seen,
% 	dimacs(CHs,[]).

% dimacs -->
% 	"p cnf ",
% 	pnat(NA),
% 	" ",
% 	pnat(NC),
% 	"\n",
% 	{print(dimacs_problem(NA,NC))},
% 	dimacs_clauses.

% dimacs_clauses -->
% 	dimacs_clause(Pre==>Post), !,
% 	{print(Pre==>Post)},
% 	dimacs_clauses.
% dimacs_clauses --> [].

% dimacs_clause(Pre==>Post) -->
% 	integer(N), " ", !,
% 	dimacs_clause(Pre1==>Post1),
% 	{ N0 is abs(N),
% 	  atomof(N0,A),
% 	  ( N>0 ->
% 	      Pre=Pre1,
% 	      Post=[A|Post1] ;
% 	      Pre=[A|Pre1],
% 	      Post=Post1 ) }.
% dimacs_clause([]==>[]) --> "0\n".


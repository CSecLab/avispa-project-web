:- use_module(library(gauge)).

:- prolog_flag(compiling,_,profiledcode).
:- compile(sate).

gauge :- view([_:_]).
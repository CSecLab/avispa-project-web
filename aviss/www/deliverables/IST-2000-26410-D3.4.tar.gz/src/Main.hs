--- import Rules
import Data
import Stddef
import If2ofmc
import Remola

---- "main"

dummy = PMr "Me"

data Tree a = Node a [Tree a]

suckessor :: Int -> [(Int -> Rule)] -> State -> [(Int,State)]

suckessor seed rules state =
 let smons = map (\ rule -> successors rule (return state)) rules 
     unpacked =  
         map (\ mon ->
	      let St f = mon  
	          ((seed',_),states) = f (seed,\x -> 0) in
	       map (\ s -> (seed',s)) states) smons
 in flatten unpacked


treeconstruct :: Int -> Int -> [Int -> Rule] -> State -> Tree State
treeconstruct 0 s rules init = Node init []
treeconstruct d s rules init =  
 Node init (map (\ (i,n) -> treeconstruct (d-1) i rules n) (suckessor s rules init))


tree :: State -> [Int -> Rule] -> Int -> Tree State
tree state0 rules d = treeconstruct d 1 rules state0

attack_pred :: [[Fact]] -> [Int] -> State -> Bool
attack_pred correspondence_goal secrecy_goal s = 
  if (correspondence_check correspondence_goal s) 
     && (secrecy_check secrecy_goal s) 
  then False
  else error (prlist s)

niveau_n init rules corr secr n 
               = "Ply "++(show n)++"\n"++
                  let l=wrids n (attack_pred corr secr) (tree init rules n)
		  in if (l==[]) then niveau_n init rules corr secr (n+1)
		     else l

wrids :: Int -> (State -> Bool) -> Tree State -> String
wrids 0 p (Node a l) = if p a then (prlist a) else []
wrids n p (Node a l) = if p a then ((prlist a)++rest) else rest
      where rest = flatten (map (wrids (n-1) p) l) 



{-
treeconstruct :: (a -> Bool -> [a]) -> Int -> a -> Tree a
treeconstruct successor i init = Node init (map (treeconstruct successor (i-1)) (successor init (i>0)) )

prlist :: Newstate -> String
prlist (s1,s2,l) = "\n*****\n" ++ (prnode (reverse l))

trsz 0 str = ""
trsz n (x:xs) = x:(trsz (n-1) xs)
trsz n []  = " " ++ (trsz (n-1) [])

prnode [] = ""
prnode ((step,msg):l) = ( trsz 18 ("(" ++ step ++ ") ")) 
                        ++  msg ++ "\n" ++ (prnode l)


-} 

--- interacter :: String -> String
--- interacter _ = niveau_n 0
--- main = interact interacter


main = getContents >>= 
       (\ stdin -> 
       let ls = lines stdin
           fname = head ls
           path = map (\ s -> 0+(read s)) (tail ls) in ---if (tail ls)==[] then "" else head (tail ls) in
       readFile fname >>= 
       (\ (init,rules,corr,secr) -> 
	  putStr ("Ofmc (Revision: 1.14 $ of $Date: 2002/02/01 10:53:52)\n"++
	          "Checking "++fname++"\n"++
		  (if path==[] then
		   (niveau_n init rules corr secr 0)
		   else shn2 (tree init rules) (tail path))))
       . ifparser . lines)

--- interactive :: String -> String


--- shn :: [Int] -> String
--- shn l = (show (top (traverse (tree ((length l)+1)) l))) 
---        ++ "\n" ++ (printniveau (traverse (tree ((length l)+1)) l))


shn2 :: (Int -> Tree State) -> [Int] -> String 
shn2 tree l = (show (top (traverse (tree ((length l)+1) ) l)))
        ++ "\n" ++ (printniveau (traverse (tree ((length l)+1) ) l))


top :: Tree State -> State
top (Node a _) = a

children :: Tree State -> [Tree State]
children (Node _ l) = l

nth :: Tree State -> Int -> Tree State
nth t n = nthl (children t) n

nthl [] _ = error "Ply to short"
nthl (x:_) 0 = x
nthl (_:xs) n = nthl xs (n-1)

nprint :: State -> String
nprint (_,_,_,_,labels) = show labels

nprintt :: Tree State -> String
nprintt (Node a l) = nprint a

printniveau :: Tree State -> String
printniveau (Node a l) = flatten (map nprintt l)

traverse :: Tree State -> [Int] -> Tree State
traverse t [] = t
traverse t (x:xs) = traverse (nth t x) xs

size :: Int -> Tree State -> Int
size 0 _ = 1
size (n+1) (Node _ l) = foldl (+) 0 (map (size n) l)

len (Node _ l) = length l
--------------------------------
{- Old Main 
startfull = 25 --- full search (no pruning of tree) when 25 plies ahead.

succrel :: Newstate -> Bool -> [Newstate]
succrel nstate b = myfilter (foldr (++) [] (map (succs b nstate) allrules))
 
tree :: Int -> Tree Newstate
tree i= treeconstruct succrel (i-startfull) (initial_state i,[],[])

tree' :: Int -> Int -> Tree Newstate
tree' i j = treeconstruct succrel i (initial_state j,[],[])

attack_pred :: Newstate -> Bool
attack_pred (ns,os,_) = not (goal (ns++os))

niveau_n n = "Ply "++(show n)++"\n"++
                  let l=wrids n attack_pred (tree n)
		  in if (l==[]) then niveau_n (n+1)
		     else l

interacter :: String -> String
interacter _ = niveau_n 0

main = interact interacter

shn :: [Int] -> String
shn l = (show (top (traverse (tree ((length l)+1)) l))) 
        ++ "\n" ++ (printniveau (traverse (tree ((length l)+1)) l))

shn2 :: Int -> [Int] -> String 
shn2 i l = (show (top (traverse (tree' i ((length l)+1) ) l)))
        ++ "\n" ++ (printniveau (traverse (tree' i ((length l)+1) ) l))
-}


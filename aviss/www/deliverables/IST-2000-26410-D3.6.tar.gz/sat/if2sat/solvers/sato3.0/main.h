#define BSD /* for SUN and RS6000 */

/* SATOINT as int uses more space but saves time */ 
#define SATOINT         int        /* either int or short */

#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>  
#include "sato.h"



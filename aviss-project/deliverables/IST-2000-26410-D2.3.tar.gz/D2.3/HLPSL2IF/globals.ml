(***********************************************************************)
(*                                                                     *)
(*                                  hlpsl2if                           *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                              globals.ml                             *)
(*                                 Loria                               *)
(*                  d�claration des variables globales                 *)
(***********************************************************************)

open Types;;


let flag_intru    = ref false ;;
let flag_rules    = ref false ;;
let flag_init     = ref false ;;
let flag_init_ok  = ref false ;;
let flag_para     = ref false ;;
let flag_goal     = ref false ;;
let flag_ident    = ref false ;;
let flag_simplif  = ref false ;;
let flag_knowledge  = ref false ;;
let flag_typed  = ref false ;;
let flag_all      = ref false ;;
let flag_NuMSV_compatibility = ref false;;
  let underscore  = ref "_";;

let ident_table = ((Hashtbl.create 17) : (string, int) Hashtbl.t);; 

let ident_list = ref ([] : (int * (string * type_var)) list )

let ident_knowledge = ref ([] : (int * int list) list);;

let init_msg_knowledge = ref ([] : (int *  msg list)list);;

let intruder_knowledge = ref ([] : term list);;

let msg_list = ref ([] : (int * ((int * int) * msg)) list);;

let cpt_id = ref 0;; 

let proto_name = ref "noname";; 

let intruder_cases = ref ([] : int list);;

let goal_case = ref "";;

let nbMsgs = ref 0;;

let init_knowledge = ref ([] : (int * string) list);;

let session_instances = ref ([[]] : ((int * string) list) list);;

let init_msgs_per_session = ref ([] : (int * int) list);;

let secret_goal = ref 0;;

let correspondence_goal = ref (0,0);;

let goal_type = ref 0;; 

let fresh = ref ([] : (int * int list) list);; 

let knowledge = ref ([] : (int * (int * (msg * bool) list) list) list);;

let para_ident_list=ref ([] : int list);;

let para_session_instances = ref ([[]] : ((int * string) list) list);;

let role_list = ref ([] : (int * ((int * string) list)) list);;

let secret_ident_list=ref ([] : string list);;

let para_res  = ref ([] : (term list * term list) list );;

:- use_module(library(lists)).
:- use_module(library(system)).
:- use_module(library(charsio)).

:- ensure_loaded(state).
:- ensure_loaded(encoding).
:- ensure_loaded(solver).
:- ensure_loaded('../config.pl').

sate(Problem) :-
	set(problem,Problem),
	load_problem,
	initialise_system_state,
	sate.

sate(Problem,Encoding,TermDepthBound,Steps,Solver) :-
	load_problem,
	set(problem,Problem),
	set(encoding,Encoding),
	set(term_depth_bound,TermDepthBound),
	set(steps,Steps),
	set(solver,Solver),
	initialise_system_state,
	sate.

sate :-
	open_output_file,
	write(user_output,'\nSTATISTICS\t\t\tCLAUSES\tRUNTIME(sec)\n'),
	print_encoding,
	close_output_file,
	solve.

initialise_system_state :-
	told,
	reset_timer,
	reset_clause_counter,
	reset_atom_db,
	reset_statistics.

load_problem :-
	value(problem,Problem),
	value(problems_dir,ProblemsDir),
	format_to_chars('~w/~w.sate',[ProblemsDir,Problem],CHARS),
	atom_codes(FN,CHARS),
	ensure_loaded(FN),
	check_problem.

check_problem :-
	facts(Fs),
	fluents(Fs,[]),
	goal(Gs),
	fluents(Gs,[]).

fluents -->
	[P],
	{(predicate(fluent,P) ->
	  true;
	  format('Syntax error in ~w\n',[P]), fail )},
	fluents.
fluents --> [].

open_output_file :-
	( value(dimacs,on) ->
	    file_name(dimacs_clauses,FN_DIMACS_CLAUSES),
	    tell(FN_DIMACS_CLAUSES) ;
	    file_name(clauses,FN_DIMACS_CLAUSES),
	    tell(FN_DIMACS_CLAUSES) ).

close_output_file :- told.

solve :-
	( value(dimacs,on) ->
	    file_name(dimacs_header,FN_DIMACS_HEADER),
	    tell(FN_DIMACS_HEADER),
	    value(curnum,N),
	    N1 is N-1,
	    value(clause_counter,C),
	    format(user_output,'\nNumber of Atoms: \t~w',[N1]),
	    format(user_output,'\nNumber of Clauses: \t~w\n',[C]),
	    print_dimacs_header(N1,C),
	    told,
	    file_name(dimacs,FN_DIMACS),
	    file_name(dimacs_clauses,FN_DIMACS_CLAUSES),
	    concat_files(FN_DIMACS_HEADER,FN_DIMACS_CLAUSES,FN_DIMACS),
	    delete_file(FN_DIMACS_HEADER,[ignore]),
	    delete_file(FN_DIMACS_CLAUSES,[ignore]),
	    file_name(log,LOGFILE),
	    delete_file(LOGFILE,[ignore]),
	    solve(FN_DIMACS,LOGFILE),
	    print_output ;
	    true ).

file_name(Post,FN) :-
	value(problems_dir,ProblemsDir),
	value(problem,Problem),
	value(encoding,Encoding),
	value(steps,Steps),
	value(solver,Solver),
	format_to_chars('~w/~w-~w-~w-~w.~w',
			[ProblemsDir,Problem,Encoding,Steps,Solver,Post],CHARS),
	atom_codes(FN,CHARS).

concat_files(F1,F2,F3) :-
	format_to_chars('cat ~w ~w > ~w',[F1,F2,F3],CHARS),
	atom_codes(CMD,CHARS),
	system(CMD).

solve(FN_DIMACS,LOGFILE) :-
	value(solver,Solver),
	solver_invocation_command(Solver,FN_DIMACS,LOGFILE,CHARS),
	atom_codes(CMD,CHARS),
	system(CMD,_).
	    
reset_timer :-
	value(steps,Steps),
	retractall(value(time,_)),
	set_timer(Steps).

set_timer(N) :- N<0, !.
set_timer(N) :-
	asserta(value(time,N)),
	N1 is N-1,
	set_timer(N1).


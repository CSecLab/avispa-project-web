% Setting up the defaults

:- set(encoding,[ape_axiom,
%		 explanatory_frame_axiom
		 explanatory_frame_axiom,
%		 complete_exclusion_axiom]).
		 conflict_exclusion_axiom]).
%		 ]).
% :- set(encoding,[ape_axiom,
% 		 classical_frame_axiom,
% 		 at_least_one_axiom]).

:- set(term_depth_bound,7).
:- set(steps,2).

:- set(debug,off).
:- set(dimacs,on).
:- set(solver,chaff).
:- set(problems_dir,'../testsuite').
:- set(sound,off).
:- set(sato_executable,'../sato3.0/sato').
:- set(chaff_executable,'../chaff-spelt3/Chaff2').
:- set(chaff_configfile,'../chaff-spelt3/cherry.smj').

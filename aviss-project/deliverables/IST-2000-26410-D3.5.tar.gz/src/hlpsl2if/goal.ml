(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(***********************************************************************)
(* handling the --goal command ligne option *)
open Types;;
open Globals;;
open Utilities;;

let rec check_secret_sharing userList secret = 
  match userList with
      [] -> true
    | head::tail ->
      	let finalUserKnowledge= (List.assoc (!Globals.nbMsgs) (Knowledge.compute_know_of_user (fst head) !Globals.nbMsgs))in
	  if(List.exists
	       (fun knownIdentifier -> 
		  (fst knownIdentifier = (Id (secret)))
	       ) 
	       finalUserKnowledge
	    )
	  then
 	    false
	  else
	    (check_secret_sharing tail secret)
;;

let not_has_role_of_principal_sharing_N sessionInstances secret =
  let usersFilter= (fun  instanceCouple -> match  instanceCouple with 
			(_,"I") -> true
		      | _ -> false) 
  in
  let intruderRoles = List.find_all usersFilter sessionInstances in
    check_secret_sharing intruderRoles secret
;;

let principal_is_defined userNumber instance_couple =
  match instance_couple with
       	(identifierNumber,instance) -> (identifierNumber == userNumber)
;;

let honest_principal userNumber instanceList=
  ((List.assoc userNumber instanceList) <> "I") 
;;

let build_goal_term termOrder userNumber sessionInstances =
  let userName =  (List.assoc userNumber sessionInstances) in
  let step = (Utilities.firstS userNumber) -1 in
    if (honest_principal userNumber sessionInstances) then 
      Utilities.opw ( (* we use userName to insure term unicity *)
	Cons(string_of_int step)) (* step *)
	(Var("1"^(!underscore)^userName)) (* sender *)
	(Utilities.opmr(Cons(userName))) (* receiver *)
	(Cons("etc"))
	(Var("l1"^(!underscore)^userName)) (* AcqKnowledge *)
	(* (Var("etc1"^(!underscore)^userName)) (* InitialKnowledge *)*)
	(Var("T1"^(!underscore)^userName)) (* boolean *) 
	(if (termOrder=1) then (Var("c")) else ops(Var("c"))) (* session *)
    else
      raise Not_found
;;

let build_goal () =
  let goalRules = ref ([] : rule list) in
(*List.iter(fun x -> List.iter(fun (y,z)-> print_int y; print_endline z)(snd(x)))(!session_instances);*)
    
    (* correspondence goal *)
    (
      List.iter 
       (fun (firstUserNumber,secondUserNumber) ->
	  (List.iter (fun (sessionCounter,sessionInstances) ->
			if (
			  (List.exists (principal_is_defined  firstUserNumber) sessionInstances)
			  && (List.exists (principal_is_defined secondUserNumber) sessionInstances)
			) then 
			  try
			    goalRules := 
			    [
			      Rule(
				"# lb=Correspondence_Goal_"^(string_of_int sessionCounter)^(!underscore)^(List.assoc firstUserNumber sessionInstances)^(!underscore)^(List.assoc secondUserNumber sessionInstances)^", type=Goal",
				(Op(".",[build_goal_term 1 firstUserNumber sessionInstances;
					 build_goal_term 2 secondUserNumber sessionInstances])),
				Empty
			      )
			      ;
			      Rule(
				"# lb=Correspondence_Goal_"^(string_of_int sessionCounter)^(!underscore)^(List.assoc secondUserNumber sessionInstances)^(!underscore)^(List.assoc firstUserNumber sessionInstances)^", type=Goal", 
				(Op(".",[build_goal_term 2 firstUserNumber sessionInstances;
					 build_goal_term 1 secondUserNumber sessionInstances ])),
				Empty
			      )
			    ]
			    @(!goalRules)
			  with
			      Not_found -> (* ErrorHandler.printExceptionMessage (Failure ("Invalid goal")) "goal" "build_goal()"; *)()
		     )
	     !Globals.session_instances 
	  ))
       !Globals.correspondence_goal_list;
     
       (* secrecy attack *)
       let list_of_secret = ((!Globals.secret_goal_list)@(!Globals.stSecret_goal_list)) in
	 List.iter
	   (fun secret ->
	      (
	       	List.iter
		 (
		   fun (sessionCounter,session) -> 
	     	     (
		       if (not_has_role_of_principal_sharing_N session secret) then
			 goalRules := 
			 (
			   Rule(
			     "# lb=Secrecy_Goal"^(!underscore)^string_of_int(sessionCounter)^", type=Goal",
			     (Op(".",[ (opi(Var("secret"))) ; (opsecret (Var("secret")) (opf(Cons(string_of_int sessionCounter)))) ])),
			      Empty
			   )	
			 )
			 ::!goalRules
		     )
		 )
		 ((!Globals.session_instances)@(List.map (fun (session,(role,knowledge)) -> (session,knowledge)) !role_list));
	      )
	   )
	   list_of_secret;

	 (* authenticate case *)
	 match !Globals.authenticate_goal_list with
	     [] -> ignore();
	   | authenticate_goal_list ->
      	       let number = ref 0 in 
		 (List.iter
		    (
		      fun ((authenticator,authenticated),list_of_knowledge) -> 
			let  session_list = (List.map (fun (nb,list) -> list) !Globals.session_instances) in
			let authenticator_list = (List.filter (fun (session,(role,knowledge)) -> (role = authenticator)) !role_list)@(
			  (List.map (fun l -> (0,(authenticator,l))) session_list)
			)
			in
			let authenticated_list = (List.filter (fun (session,(role,knowledge)) -> (role = authenticated)) !role_list)@(
			  (List.map (fun l -> (0,(authenticated,l))) session_list)
			)
			in
			  (List.iter
			     (fun 
				  (session,(role,knowledge)) ->
				    let mr_authenticator = (List.assoc authenticator knowledge) in
			       	      (List.iter
		      			 (fun
				       	      (session2,(role2,knowledge2)) ->
						let mr_authenticated = (List.assoc authenticated knowledge2) in
						  goalRules := Rule(
						    "# lb=Authenticate"^(!underscore)^mr_authenticator^(!underscore)^mr_authenticated^(!underscore)^(string_of_int !number)^", type=Goal",
						    oprequest (opmr(Cons(mr_authenticator)))( opmr(Cons(mr_authenticated))) (Var("1")) (Var("2")) 
					       	      ,
					       	      Empty
						  )::(!goalRules);
						  incr number
		      			 )
		      			 authenticated_list
				      )
			     )
			     authenticator_list  
			  )
		    ) 
		    authenticate_goal_list
		 );

	  if not(!Globals.secret_ident_list =[]) then  
	    goalRules := Rule(
	      "# lb=secret_para, type=Goal",
	      (Op(".", [opi(Cons"x");opsecret (Cons"x") (opf (Cons"para"))]))
	      ,
	      Empty
	    )::!goalRules;
    );
    !goalRules
;;

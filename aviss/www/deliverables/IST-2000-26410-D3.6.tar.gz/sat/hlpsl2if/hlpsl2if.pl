:- use_module(library(lists)).
:- use_module(library(system)).
:- use_module(library(charsio)).

% hlpsl2if(Pb) :-
%      This predicate translates the HLPSL problem Pb 
%      (name of the file without extention) into the 
%      equivalent IF problem
hlpsl2if(Pb,OPTIONS) :-
	set_prolog_flag(redefine_warnings,off),
	working_directory(PrevPath, PrevPath),
	% PATCH FOR WORKING WITH A PROLOG EXECUTABLE
%	value(problems_dir,PbDIR),
	atom_concat(PrevPath,'/testsuite',NewPbDIR),
	set(problems_dir,NewPbDIR),
	%
	atom_concat(PrevPath,'/hlpsl2if',CurrPath),
	working_directory(PrevPath, CurrPath),
	% HLPSL2IF
        make_command(Pb,OPTIONS,CCMD),
	atom_chars(CMD,CCMD),
        exec(CMD,[pipe(_),pipe(_),pipe(_)],PCMD),	
	wait(PCMD,_),
	working_directory(CurrPath, PrevPath).

make_command(Pb,OPTs,CMD) :-
	make_options(OPTs,STROPTs),
        value(hlpsl2if,HLPSL2IF),
	value(problems_dir,PBsDIR),	
	format_to_chars('./~w ~w ~w/~w.hlpsl > ~w/~w.if',[HLPSL2IF,STROPTs,PBsDIR,Pb,PBsDIR,Pb],CMD).

make_options(OPTs,STROPTs) :-
	make_options(OPTs,STROPTs,'').

make_options([OPT],STROPTs,TMPSTR) :-
	format_to_chars('~w--~w',[TMPSTR,OPT],CSTROPTs),
	atom_chars(STROPTs,CSTROPTs).
make_options([OPT|OPTs],STROPTs,TMPSTR1) :-
	format_to_chars('~w--~w ',[TMPSTR1,OPT],CTMPSTR2),
	atom_chars(TMPSTR2,CTMPSTR2),
	make_options(OPTs,STROPTs,TMPSTR2).


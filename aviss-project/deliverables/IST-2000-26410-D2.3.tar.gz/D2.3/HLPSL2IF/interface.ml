(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* interfacing with stdout *)
open String;;
open Types;;
open Globals;;
open Utilities;;

let pdb messageToPrint =
  print_endline messageToPrint;
  flush stdout
;;
let print_type_var = function
   User -> print_string "User"
 | FrSyKey -> print_string "Symmetric_Key"
 | SyKey -> print_string "Symmetric_Key"
 | FrPcKey(_) -> print_string "Public_Key"
 | PcKey(_) -> print_string "Public_Key"
 | FrPeKey(_) -> print_string "Private_Key"
 | PeKey(_) -> print_string "Private_Key"
 | Number -> print_string "Number"
 | Table -> print_string "Table"
 | Function -> print_string "Function"
 | PcTable(_,_,_) -> ()
 | PeTable(_,_,_) -> ()
;;
let print_ident = function
   0 -> print_string "?"
 | identifierNumber -> print_string (fst (List.assoc identifierNumber !Globals.ident_list));
;;
let print_ident_list ()=
  List.iter(fun identifierNumber->
    print_string (fst(snd(identifierNumber)) ^ ":");
    print_string ("\tN�: ");print_int(fst(identifierNumber));print_newline();
    print_string ("\tType: ");print_type_var(snd(snd(identifierNumber)));print_newline();
)!Globals.ident_list
;;
let rec print_list printFunction separator =function
      [] -> ()
    | [head] -> printFunction head
    | head::tail -> printFunction head; print_string separator; print_list printFunction separator tail
;;
let print_init_knowledge () =
   List.iter (fun (userNumber,knownIdentifierList) ->
                 print_string "##  ";
                 print_ident userNumber;
                 print_string " knows ";
                 print_list print_ident ", " knownIdentifierList;
                 print_newline ())
             !Globals.ident_knowledge
;;
let string_of_msg =

   let rec string_of_msg isInfixed = function
      Id(0) ->
        "?"
    | Id(identifierNumber) ->
         let identifierName = Utilities.get_identifier_name identifierNumber in
         if (contains identifierName '\'')
              then
                  concat identifierName ["prim"]
              else
                  identifierName
    | Int(number) ->
        string_of_int number
    | Pair(messagePart1,messagePart2) ->
        string_of_msg false messagePart1
        ^(!underscore)^
        string_of_msg false messagePart2
    | Func(0,functionParameter) ->
        "?("^
        string_of_msg false functionParameter^
        ")"
    | Func(functionNumber,functionParameter) ->
        (Utilities.get_identifier_name functionNumber)^
        (!underscore)^
        string_of_msg false functionParameter^
        (!underscore)
    | Crypt(_,(Id(_) as keyIdentifier),cryptedMessage) ->
           (!underscore)^
        string_of_msg false cryptedMessage^
        (!underscore)^
        string_of_msg false keyIdentifier
    | Crypt(_,keyIdentifier,cryptedMessage) ->
        (!underscore)^
        string_of_msg false cryptedMessage^
        (!underscore)^
        string_of_msg false keyIdentifier^
        (!underscore)
    | Arith(operator,operand1,operand2) ->
        (
	  if isInfixed
          then
            "("
	  else 
	    ""	
	)  
        ^string_of_msg true operand1^
          (
	    match operator
            with 
		1 ->   "+"
              | 2 ->   "-"
              | 3 ->   "*"
              | 4 ->   "/"
              | 5 ->   "%"
	      |	6 ->   "#"
              | _ ->   "^"
	  )
	  ^string_of_msg true operand2^
        if isInfixed
        then
          ")"
	else ""
 | Logic(operator,operand1,operand2) ->
        (
	  if isInfixed
          then
            "("
	  else
	    ""
	)
        ^string_of_msg true operand1^
          (
	    match operator
            with 
		1 ->   "_Rcrypt_"
              | 2 ->   "_And_"
              | 3 ->   "_Or_"
              | 4 ->   "_Nand_"
              | _ ->   "_Nor_"
	  )
	  ^string_of_msg true operand2^
        if isInfixed
        then
          ")"
	else ""
   in
     string_of_msg false
;;
let print_msg =
   let rec print_msg inExpr = function
      Id(0) ->
           print_string "?"
    | Id(identifierNumber) ->
           print_ident identifierNumber
    | Int(number) ->
           print_int number
    | Pair(messagePart1,messagePart2) ->
           print_msg false messagePart1;
           print_string ",";
           print_msg false messagePart2
    | Func(0,functionParameter) ->
           print_string "?(";
           print_msg false functionParameter;
           print_string ")"
    | Func(functionNumber,functionParameter) ->
           print_ident functionNumber;
           print_string "(";
           print_msg false functionParameter;
           print_string ")"
    | Crypt(_,(Id(_) as keyIdentifier),cryptedMessage) ->
           print_string "{";
           print_msg false cryptedMessage;
           print_string "}";
           print_msg false keyIdentifier
    | Crypt(_,keyIdentifier,cryptedMessage) ->
           print_string "{";
           print_msg false cryptedMessage;
           print_string "}(";
           print_msg false keyIdentifier;
           print_string ")"
    | Arith(operator,operand1,operand2) ->
           if inExpr
             then
               print_string "(";
           print_msg true operand1;
           (match operator
            with 1 -> print_string "+"
               | 2 -> print_string "-"
               | 3 -> print_string "*"
               | 4 -> print_string "/"
               | 5 -> print_string "%"
	       | 6 -> print_string "#"
               | _ -> print_string "^");
           print_msg true operand2;
           if inExpr
             then
               print_string ")"
  | Logic(operator,operand1,operand2) ->
           if inExpr
             then
               print_string "(";
           print_msg true operand1;
           ( match operator
            with 1 -> print_string " - "
               | 2 -> print_string " and "
               | 3 -> print_string " or "
               | 4 -> print_string " nand "
               | _ -> print_string " nor ");
           print_msg true operand2;
           if inExpr
             then
               print_string ")"
   in
     print_msg false
;;
let print_msglist () =
  List.iter (fun (messageNumber,((senderIdentifier,receiverIdentifier),message)) ->
               print_string "##  ";
               print_int messageNumber;
               print_string ".  ";
               print_ident senderIdentifier;
               print_string " -> ";
               print_ident receiverIdentifier;
               print_string ":  ";
               print_msg message;
               print_newline ())
  !Globals.msg_list
;;
let rec print_term_list separator = function
    [] -> ErrorHandler.printExceptionMessage (Failure "print_term") "Interface" "print_term_list";raise (Failure "print_term")
  | [head] -> print_term head;
  | [head;Empty] ->
      print_term head
  | Empty::tail ->
      (print_term_list separator tail)
  | head::tail ->
       print_term head;
      (print_string separator);
      (print_term_list separator tail)

and print_term = function
    Empty -> ()
  | Cons(consValue) ->
      let newStr = ref (String.sub consValue 0 ((length consValue)-1)) in
	if (contains consValue '\'') then (print_string !newStr) else (print_string consValue);
  | Var(varValue) ->
      if (!Globals.flag_init_ok =false or varValue = "Time") then (print_string "x");
      let newStr = ref (String.sub varValue 0 ((length varValue)-1)) in
	if (contains varValue '\'') then (print_string !newStr) else (print_string varValue);
  | Op(".",termList) -> (print_term_list "." termList)
  | Op("nonce",nonceTermList) ->
      if (not !Globals.flag_typed) then
	match nonceTermList with 
	    [Op("c",ll)]->
	      (print_string "nonce(");
	      (print_term_list "," nonceTermList);
	      (print_string ")"); 
	  |_ ->
	      (print_term_list "," nonceTermList)
      else
	begin
	  (print_string "nonce(");
	  (print_term_list "," nonceTermList);
	  (print_string ")"); 
	end;
  | Op("sk",skTermList) ->
      if (not !Globals.flag_typed) then
	match skTermList with 
	    [Op("c",_)]->
	      (print_string "sk(");
	      (print_term_list "," skTermList);
	      (print_string ")"); 
	  | _ ->	
	      (print_term_list "," skTermList)
      else
	begin
	  (print_string "sk(");
	  (print_term_list "," skTermList);
	  (print_string ")");
	end;
  | Op("prim",[primTerm]) ->
      (print_term primTerm); 
      (print_string "'")
  | Op("prim",primTermList) ->
      ErrorHandler.printExceptionMessage (Failure("print_term (case: prim)")) "Interface" "print_term";raise (Failure("print_term (case: prim)"))
      (* prints pk cipher *)
  | Op("pk",pkTermList) ->
      if (not !Globals.flag_typed) then
	match pkTermList with 
	    [Op("c",_)]->
	      (print_string "pk(");
	      (print_term_list "," pkTermList);
	      (print_string ")"); 
	  | ll ->
	      (print_term_list "," pkTermList)
      else
	begin
	  (print_string "pk(");
	  (print_term_list "," pkTermList);
	  (print_string ")"); 
	end;  
  | Op("mr",userTermList) -> (* This is a special case, since mr can be added even if the rules are untyped *)
      if (not !Globals.flag_typed) then 
	begin
	  match userTermList with
	      [Cons(userName)] -> 
		begin
		  (print_string "mr("); 
	       	  (print_term_list "," userTermList);
		  (print_string ")");
		end;
	    | _ -> (print_term_list "," userTermList);
	end
      else 
 	begin
          (print_string "mr");
          (print_string "(");
          (print_term_list "," userTermList);
          (print_string ")");
	end;
  | Op(operatorString,operandTermList) ->
      (print_string operatorString);
      (print_string "(");
      (print_term_list "," operandTermList);
      (print_string ")");
;;
let print_rule = function 
    (Rule(label,left,Empty)) ->
      print_endline label;
      print_term left
  | (Rule(label,Empty,right)) ->
      print_endline label;
      print_term right
  | (Rule(label,left,right)) ->
      print_endline label;
      print_term left;
      print_string "\n=>\n";
      print_term right
;;
let rec print_para_rules=function
    (leftTermList,rightTermList)::tail ->print_string("message(");
      print_term_list "." leftTermList ;
      print_string(",");
      print_term_list "." rightTermList ;
      print_endline(",ii)");
      print_para_rules tail;
  |_ -> print_newline();
;;
let print_ident_knowledge userNumber=
  let userKnowledge = List.assoc userNumber !knowledge in
    List.iter ( fun (protocolStep,knowledgeList)-> 
		  print_string "\n##  ";
		  print_ident userNumber; print_string " knows at step ";print_int(protocolStep);print_string(" ");
		  List.iter( fun (message,b)->
			       print_msg (message);print_string(",");
			   )(List.rev knowledgeList);
	      )(List.rev userKnowledge);
    print_newline();
;;
let print_knowledge () =
  Utilities.for_all_user print_ident_knowledge
;;

(***********************************************************************)
(*                                                                     *)
(*                                 Casrul                              *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* handling --para command line option *)


open Types;;
open Globals;;
open Rules;;
open Utilities;;

let previous_compose_para = ref ([] : term list);;
let previousLeftTerms = ref ([] : term list);;

let leftMemberTerms = ref ([] : term list);;
let rightMemberTerms = ref ([] : term list);;
let currentSession =  ref ([] : (int * string) list);;

let rec check_intruder_compose term = (* doesn't do any knowledge inference *)
  (List.mem (opi term) !Globals.intruder_knowledge) ||
  (match term with
       Op("prim",[Op("tb",list_of_arg)]) -> (List.for_all (fun x -> check_intruder_compose x) list_of_arg)
     | Op("prim",_) -> false (* if a private key is not in intruder's knowledge and is not the private element of a table, the intruder cannot compose it *)
     |  Op(_,list_of_args) -> (List.for_all (fun x -> check_intruder_compose x) list_of_args)
     | _ -> false
  )
;;

let get_para_instance identifierNumber =
  try
    List.assoc identifierNumber !currentSession;
  with 
      Not_found ->  Utilities.get_identifier_name identifierNumber
;;

let rec replace_by_instance = function
    Op(operand,[term]) -> Op(operand,[(replace_by_instance term)])
  | Cons(consName) -> Cons(get_para_instance (get_identifier_number consName !Globals.ident_list))
  | Var(varName) -> Var(get_para_instance (get_identifier_number varName !Globals.ident_list)) 
  | x -> x;
;;

let check_secret instance =
  List.mem
    instance
    !Globals.secret_ident_list
;; 

let check_hidden_rule leftTermList rightTermList =
  let isHidden = ref false in
  let updateHidden name =
    isHidden := ((!isHidden)||(check_secret name))
  in
    if (rightTermList=[]) then 
      true
    else 
      begin
      	if (leftTermList = []) then 
      	  (List.iter 
	     (fun rightTerm ->
	      	match rightTerm with
		    Op(_,[]) -> ()
	      	  | Op(_,termList) ->  
		      if not(termList = [Empty]) then
		      	begin
		      	  Globals.intruder_knowledge:=!Globals.intruder_knowledge @ (List.map (fun x -> (opi x)) termList); 
		      	  isHidden:=true;
		      	end
	      	  | _ ->ignore();
	     ) 
	     rightTermList
      	  );
      	
      	(* test for the atomic terms of the RHS *)
      	List.iter 
      	  (fun rightTerm ->
	     match rightTerm with
		 Op(_,termList)-> if (List.mem (Op("v",termList)) leftTermList) then isHidden:=true;
	       |_->ignore();
      	  ) rightTermList;
      	
      	(* test for secret terms in LHS *)
      	List.iter 
      	  (fun leftTerm -> 
	     if (not !isHidden) then (
	       match leftTerm with
		   Op("v",[Op("mr",[Cons(consName)])])-> updateHidden consName;
		 |Op("v",[Op("nonce",[Cons(consName)])])->   updateHidden consName;
		 |Op("v",[Op("sk",[Cons(consName)])])->   updateHidden consName;
		 |Op("v",[Op("pk",[Cons(consName)])])->  updateHidden consName;
		 |Op("prim",[Op("pk",[Cons (consName)])])->  updateHidden (consName ^ "'");
		 |Op("v",[Op("fu",[Cons(consName)])])->  updateHidden consName;
		 |Op("v",[Op("tb",[Cons(consName)])])-> updateHidden consName;
		 |Op("v",[Op("prim",[Op("pk",[Cons (consName)])])])-> updateHidden ( consName ^ "'");
		 |_-> ignore();
	     )
      	  ) 
      	  leftTermList;
      	
      	(* test for secret terms in RHS *)
      	List.iter 
      	  (fun rightTerm ->
	     if (not !isHidden) then
	       (match rightTerm with
		    Op("j",[Op("mr",[Cons(consName)])])-> updateHidden consName;
	      	  |Op("j",[Op("nonce",[Cons(consName)])])->   updateHidden consName;
	      	  |Op("j",[Op("sk",[Cons(consName)])])->   updateHidden consName;
	      	  |Op("j",[Op("pk",[Cons(consName)])])->  updateHidden consName;
	      	  |Op("prim",[Op("pk",[Cons (consName)])])-> updateHidden (consName ^ "'");
	      	  |Op("j",[Op("fu",[Cons(consName)])])->  updateHidden consName;
	      	  |Op("j",[Op("tb",[Cons(consName)])])-> updateHidden consName;
	      	  |Op("j",[Op("prim",[Op("pk",[Cons (consName)])])])->  updateHidden ( consName ^ "'");
	      	  |_-> ignore();
	       )
      	  )
      	  rightTermList;
      	(* test for right hand term already in intruder's knowledge *)
	if (not(!isHidden)) then
      	  List.iter
      	    (fun a_term ->
	       match a_term with
		   Op("j",[the_term]) -> isHidden := ((check_intruder_compose the_term)||(!isHidden))
		 | Op("prim",[Op("pk",[Cons (consName)])])-> isHidden :=((check_intruder_compose a_term)||(!isHidden))
		 | _ -> ignore()
      	    )
      	    rightTermList;
    	!isHidden
      end;
;;

let rec add_type_para  = function
    Op(operator,[term]) -> Op(operator,[term])
  | Op(operator,termList) -> Op(operator, (List.map (add_type_para ) termList))
  | Var(varName) -> let varType = findtype varName !Globals.ident_list true in
      op_of_type varType (Var(varName));
  | Cons(consName) ->
      let varType = findtype consName !Globals.ident_list true in
        op_of_type varType (Cons(consName));
  | x -> x
;;

let filter_left_list leftTermList=
    (* filtering initial intruder knowledge *)
  let new_leftTermList=ref ([] : term list) in
    List.iter (fun leftTerm -> 
		 match leftTerm with 
		     (Op(operator,[term]))-> if not(check_intruder_compose term) then
		       new_leftTermList :=[leftTerm]@(!new_leftTermList)
		   |_->ignore()
	      ) 
      leftTermList ;
    !new_leftTermList;
;;

let rec compose_para userNumber message step   =
  match message with
      Pair(couplePart1,couplePart2) -> oppair (compose_para userNumber couplePart1 step) (compose_para userNumber couplePart2 step)
    | Crypt(3,key,m) -> opscrypt (compose_para userNumber key step) (compose_para userNumber m step)
    | Crypt(_,key,m) -> opcrypt (compose_para userNumber key step) (compose_para userNumber m step)
    | Arith (a,operand1,operand2) -> (oparith_of_nb a) (compose_para userNumber operand1 step) (compose_para userNumber operand2 step)
    | Logic (a,operand1,operand2) -> (oplogic_of_nb a) (compose_para userNumber operand1 step) (compose_para userNumber operand2 step)
    | Func(f,m) -> opfunct (compose_para userNumber (Id(f)) step) (compose_para userNumber m step)
    | TableElement(tableNumber,tableUser,isPrivate) -> 
	if not(isPrivate) 
	then opTableElement (compose_para userNumber (Id(tableNumber)) step) (compose_para userNumber (Id(tableUser)) step)
	else opprim (opTableElement (compose_para userNumber (Id(tableNumber)) step) (compose_para userNumber (Id(tableUser)) step))
    | Int(number) -> Cons(string_of_int number)
    | Id(identifierNumber) -> (
	let is_composed_by_user = ref false in
	  for i = 0 to step do
	  if (((get_sender i)=userNumber) && (List.mem identifierNumber (fresh_var i)))
	  then is_composed_by_user :=true;
	  done; 
	  
(*	  if (!is_composed_by_user) *)

	  if ((Knowledge.know message userNumber 0) or (!is_composed_by_user) )
	  then
	    replace_by_instance (add_type_para (Cons(Utilities.get_identifier_name identifierNumber)))
	  else 
	    replace_by_instance (add_type_para (Var(Utilities.get_identifier_name identifierNumber))))
;;



let rec build_para_function leftTermList rightTermList=
  (* Globals.para_res:=!Globals.para_res@([Op("\ndbg",(rightTermList@[Cons("ii")]@(if (leftTermList  = []) then [Cons("true")] else leftTermList )))]); *)
  (* local variables *)
  let tail = ref[] in (* to store the remaining member terms after removing those which will be replaced while applying build_para_function *)
  let matchFound=ref 0 in
    (* rules for matching the RHS rules *)
    List.iter 
      (fun x ->(* print_endline "RHS";Interface.print_term x;print_newline();*)
	 tail:= remove x rightTermList;
	 match (!matchFound,leftTermList,[x]@(!tail)) with
	   |(0,xu,(Op("d",[Cons(t)]))::xd)->build_para_function xu ([Op("j",[Cons(t)])]@xd);matchFound:=1;
	   |(0,xu,(Op("d",[Var(t)]))::xd)->build_para_function xu ([Op("j",[Var(t)])]@xd);matchFound:=1;
	   |(0,xu,(Op("d",[Op(operator,[t])]))::xd)->build_para_function xu ([Op("j",[Op(operator,[t])])]@xd);matchFound:=1;
	   |(0,xu,(Op("d",[Op("c",[t1;t2])]))::xd)->build_para_function xu ([Op("d",[t1])]@[Op("d",[t2])]@xd) ;matchFound:=1
	   |(0,xu,(Op("d",[Op("crypt",[t1;t2])])::xd)) ->
	      build_para_function 
		  (xu@[Op("u",[(opprim t1)])]) 
		  ([Op("d",[t2])]@xd);
	      build_para_function 
		  xu 
		  ([Op("j",[Op("crypt",[t1;t2])])]@xd);
	      matchFound:=1;
	   |(0,xu,(Op("d",[Op("scrypt",[t1;t2])])::xd))-> 
	      matchFound:=1;
	       build_para_function 
		   (xu@[Op("u",[t1])]) 
		   ([Op("d",[t2])]@xd);
	       matchFound:=1;
	       build_para_function 
		   xu 
		   ([Op("j",[Op("scrypt",[t1;t2])])]@xd);
	   |(0,xu,(Op("d",[Op("tb",[t1;t2])])::xd))-> 
	       matchFound:=1;
	       build_para_function 
		   xu 
		   ([Op("j",[Op("tb",[t1;t2])])]@xd);
	   |(0,xu,(Op("d",[Op("funct",[t1;t2])])::xd))-> 
	       matchFound:=1; 
	       build_para_function 
		   xu 
		   ([Op("j",[Op("funct",[t1;t2])])]@xd);
           |_->ignore();
      ) 
      rightTermList;
    (* rules for the LHS matching *)
    List.iter 
      (fun x -> (* print_endline "LHS";Interface.print_term x;print_newline();*)
	 tail:= remove x leftTermList;
	 match (!matchFound,[x]@(!tail),rightTermList) with
	   |(0,(Op("u",[Cons(t)]))::xu,xd)->
	      build_para_function 
		  ([Op("v",[Cons(t)])]@xu) 
		  xd;
	      matchFound:=1
	   |(0,(Op("u",[Var(t)]))::xu,xd)->
	      build_para_function 
		  ([Op("v",[Var(t)])]@xu) 
		  xd;
	      matchFound:=1
	   |(0,(Op("u",[Op(operator,[t])]))::xu,xd)->
	      build_para_function 
		  ([Op("v",[Op(operator,[t])])]@xu) 
		  xd;
	      matchFound:=1
	   |(0,(Op("u",[Op("c",[t1;t2])])::xu),xd)->
	      build_para_function 
		  ([Op("u",[t1])]@[Op("u",[t2])]@xu) 
		  xd;
	      matchFound:=1
	   |(0,(Op("u",[Op("crypt",[t1;t2])]))::xu,xd)->
	      build_para_function 
		  (xu@[Op("u",[t1])]@[Op("u",[t2])]) 
		  xd;
	      build_para_function 
		  ([Op("v",[Op("crypt",[t1;t2])])]@ xu) 
		  xd;
	      matchFound:=1;
	   |(0,(Op("u",[Op("scrypt",[t1;t2])]))::xu,xd)->
	      build_para_function 
		  ([Op("u",[t1])]@[Op("u",[t2])]@xu) 
		  xd;
	      build_para_function 
		  ([Op("v",[Op("scrypt",[t1;t2])])]@ xu) 
		  xd;
	      matchFound:=1;
	   |_->ignore();
      ) 
      leftTermList;
    (* filtering intruder known terms *)
    let filteredLeftList = filter_left_list leftTermList in  
      (* add the rule to the list *)
      List.iter 
	(function Empty -> ()
	   | rightTerm ->
	       if (!matchFound=0 && not(check_hidden_rule filteredLeftList [rightTerm]) ) then 
		 Globals.para_res:=!Globals.para_res@[
		   Op("datalogrule",([rightTerm] @ (if (filteredLeftList  = []) then [Cons("true")] else filteredLeftList )))]
	) 
	rightTermList
;;

let add_short_term_secret_instances () =
  List.iter
    (fun secret ->
      List.iter
       (fun instance_list ->
	  if (List.exists (function (id,instance) -> (id = secret)) instance_list) then
	    let instance = (List.assoc secret instance_list) in
	      Globals.intruder_knowledge := (opi ( op_of_type (get_identifier_type secret) (Cons(instance))))::(!Globals.intruder_knowledge)
       )
       !Globals.para_session_instances
    )
    !Globals.stSecret_goal_list
;;

let  build_para_rules () =  
  (* local variable for the list of users for who we will generate parallel rules *)
  add_short_term_secret_instances ();
  let currentUser= ref 0 in
    for sessionCounter=0 to (List.length !Globals.para_ident_list -1 )do
      currentUser:=List.nth !Globals.para_ident_list sessionCounter;
      currentSession:= List.nth !Globals.para_session_instances (sessionCounter+1);
      for step=0 to (!Globals.nbMsgs-1) do
	rightMemberTerms:=[];

	if (step=0 && (!currentUser=get_sender 1))
	then
	  rightMemberTerms:=[Op("d",[compose_para !currentUser (get_msg 1) 1])]
	else
	  (
	    if ((step+1) = !Globals.nbMsgs && !currentUser=get_receiver (step+1))
	    then 
	      (
		leftMemberTerms:=[Op("u",[compose_para !currentUser (get_msg (step+1)) step  ])]@(!previous_compose_para);
	      )
	    else
	      (
		if(!currentUser=get_sender (step+1))
		then
		  (
		    leftMemberTerms:=[Op("u",[compose_para !currentUser (get_msg step) (step-1)])]@(!previous_compose_para);
		    rightMemberTerms:=[Op("d",[compose_para !currentUser (get_msg (step+1)) (step+1)])]
		  )
	      );
	  );
	if ((!leftMemberTerms <> []) or (!rightMemberTerms <> []))
	then
	  build_para_function !leftMemberTerms !rightMemberTerms;
      done;
    done;
    (* adding intruder knowldge corresponding rules *)
    
    Globals.intruder_knowledge:=(List.filter (function (Op("i",[x])) -> not(x=Empty) | _ -> true ) !Globals.intruder_knowledge);
    (List.iter 
      (fun intruderTerm -> 
(* 	 if not(intruderTerm = Op("i",[Op("mr",[Cons("I")])])) then *)
	   Globals.para_res:= !Globals.para_res@[
	     Op("datalogrule",([intruderTerm] @ [Cons("true")]))
	   ]
(* 	 else *)
(* 	   Globals.para_res:= !Globals.para_res@[ *)
(* 	     Op("datalogrule",([Op("i",[Op("mr",[Cons("intruder")])])] @ [Cons("true")]))] *)
      )
      !Globals.intruder_knowledge);
    !Globals.para_res;
;;

let add_intruder_knowledge term =
  Globals.intruder_knowledge := (term)::(!Globals.intruder_knowledge)
;;

let changes_on_datalog_output list_of_rules =
  let parallel_rule_list = ref list_of_rules in
  let has_changed = ref true in
  let remove_already_known_terms a_rule =
    match a_rule with
	Rule(name,Op(".",lhs),rhs) ->
	  let new_lhs = ref (List.filter (fun x -> not(check_intruder_compose x)) lhs) in
	    has_changed := (!has_changed || not(Utilities.compare_term (Op(".",lhs)) (Op(".",!new_lhs))));
	    if not(check_intruder_compose rhs) then
	      if (!new_lhs = []) then
		(Rule(name,Empty,rhs))
	      else
		(* normal case : we return the list on lhs minus what the intruder does already know *)
		(Rule(name,Op(".",!new_lhs),rhs))
	    else
	      (* we're discarding the rule, since the intruder can compose the rhs term *)
	      (Rule(name,Empty,opmr (Cons("I"))));
      | r -> (r)
  in
  let add_a_term_to_knowledge a_rule =
   match a_rule with
       Rule(name,lhs,can_be_known) ->
	 if (lhs = Empty) then
	   begin
	     has_changed := true;
(* 	     print_string "\nthis term is added to intruder's knowledge : "; *)
(* 	     Interface.print_term can_be_known;  *)
(* 	     print_newline(); *)
	     if not(check_intruder_compose can_be_known) then
	       add_intruder_knowledge (opi can_be_known);
(* 	     else *)
(* 	       print_string "...no, could already be composed !\n "; *)
	     ([] : rule list);  
	   end
	 else
	   match can_be_known with
	       Op("c",arg_list) -> 
		 has_changed := true;
		 (List.map (fun x -> (Rule(name,lhs,x))) arg_list)
	     | Op("crypt",[the_key; the_message]) ->
		 if ((check_intruder_compose the_key)&&(check_intruder_compose (opprim the_key))) then
		   (has_changed := true;[Rule(name,lhs,the_message)])
		 else
		   [Rule(name,lhs,can_be_known)]
	     | Op("scrypt",[the_key;the_message]) ->
		 if (check_intruder_compose the_key) then
		   (has_changed := true;[Rule(name,lhs,the_message)])
		 else
		   [Rule(name,lhs,can_be_known)]
	     | _ -> [a_rule];
 in
let remove_rhs_included_in_lhs_rule list_of_rule =
   (List.filter
      (fun a_rule ->
	 match a_rule with
	     Rule(name,Op(".",lhs),rhs) ->
	       not(List.mem rhs lhs)
	   | _ -> true
      )
      list_of_rule
   )
in
let old_list_of_rules = ref ([] : rule list) in
  while (!has_changed) do
    has_changed := false;
    old_list_of_rules := !parallel_rule_list;
    parallel_rule_list := [];
    List.iter
      (fun x ->
	 parallel_rule_list := 
	   (remove_rhs_included_in_lhs_rule 
	     (add_a_term_to_knowledge
	      	(remove_already_known_terms x)))@(!parallel_rule_list)
      )
      !old_list_of_rules;
  done;
  (List.map
     (fun this_rule  ->
	match this_rule with
	    Rule(name,Op(".",lhs),rhs) ->
	      Rule(name,(Op(".",(List.map (fun x -> (opi x)) lhs))),(opi rhs))
	  | some_rule -> some_rule
     )
     (remove_double_occurrences Utilities.compare_rule !parallel_rule_list)
  )
;;  









4

(***********************************************************************)
(*                                                                     *)
(*                                 HLPSL                               *)
(*                                                                     *)
(*                     AVISS Project IST 2000-26410                    *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                              utilities.ml                           *)
(*                                 Loria                               *)
(*                            useful functions                         *)
(***********************************************************************)

open Types;;
open Globals;;

(* ----------------
getIdentId:
   Input: identifier number
   Output: identifier name
   Role: determine the name of an identifier
   Use:
   Rem:
---------------- *)
let getIdentId i = fst (List.assoc i !ident_list);;

(* ----------------
getId
   Input: name of the identifier, search list
   Output: number of the identifier
   Role: determine the number of an identifier given his name.
   Use:
   Rem:
---------------- *)
let rec getId s lst=
  match lst with
    (i,(str,t))::reste ->if (s=str)
    then  i
    else
      (getId s reste);
  |_-> raise (Not_found)
	;;


(* ----------------
getIdentType
   Input: number of an identifier
   Output: type of the identifier
   Role: determine the type of an identifier given his number
   Use:
   Rem:
---------------- *)
let getIdentType i = snd (List.assoc i !ident_list);;

 (* ----------------
findtype:
   Input: chain representing the name of an identifier, list of identifiers
   Output: type of the identifier
   Role: determine the type of an identifier
   Use:
   Rem:
---------------- *)
let rec findtype  str lst =
match lst with
  [] -> raise Pas_trouve; exit(-1)
  | a::reste -> if fst (snd a) == str then snd (snd a) else findtype str reste
;;


(* ----------------
   fresh_var: int -> int list
   Input: index in the list fresh
   Output: list of fresh variables
   Role: Return the list of variables fresh at step i.
   ---------------- *)
let fresh_var i = List.assoc i !fresh
;;


(* ----------------
   Constructors
   Type check
   define an operation term
---------------- *)
let oph t1 =  Op("h",[t1]);;
let opprim t1 =  Op("prim",[t1]);;
let opmr t1 =  Op("mr",[t1]);;
let oppk t1 =  Op("pk",[t1]);;
let opsk t1 =  Op("sk",[t1]);;
let opfu t1 =  Op("fu",[t1]);;
let optb t1 =  Op("tb",[t1]);;
let opnonce t1 =  Op("nonce",[t1]);;
let oppair t1 t2 = Op("c",[t1;t2]);;
let opcrypt t1 t2 = Op("crypt",[t1;t2]);;
let opscrypt t1 t2 = Op("scrypt",[t1;t2]);;

let optable t1 t2 = Op("table",[t1;t2]);;
let opfunct t1 t2 = Op("funct",[t1;t2]);;
let opsum t1 t2 = Op("sum",[t1;t2]);;
let opminus t1 t2 = Op("minus",[t1;t2]);;
let opmult t1 t2 = Op("mult",[t1;t2]);;
let opdiv t1 t2 = Op("div",[t1;t2]);;
let opmod t1 t2 = Op("mod",[t1;t2]);;
let oppow t1 t2 = Op("pow",[t1;t2]);;

let oprcrypt t1 t2 = Op("rcrypt",[t1;t2]);;
let opand t1 t2 = Op("and",[t1;t2]);;
let opor t1 t2 = Op("or",[t1;t2]);;
let opnand t1 t2 = Op("and",[t1;t2]);;
let opnor t1 t2 = Op("nor",[t1;t2]);;

let oprcrypt t1 t2 = Op("rcrypt",[t1;t2]);;
let opw t1 t2 t3 t4 t5 t6 t7 = Op("w",[t1;t2;t3;t4;t5;t6;t7]);;
let opm t1 t2 t3 t4 t5 t6 = Op("m",[t1;t2;t3;t4;t5;t6]);;
let opi t1 = Op("i",[t1]);;
let opsecret t1 t2 =  Op("secret",[t1;t2]);;
let opf t1 =  Op("f",[t1]);;
let ops t1 =  Op("s",[t1]);;


(* ----------------
 val op_of_type : Infos.type_var -> Infos.term -> Infos.term
 determine the operation to be applied for each variable type
   ---------------- *)
let op_of_type typ =
  match typ with
      User -> opmr
    | SyKey -> opsk
    | FrSyKey -> opsk
    | PcKey(_) -> oppk
    | FrPcKey(_) -> oppk
    | PeKey(_) -> (fun t -> opprim (oppk t))
    | FrPeKey(_) -> (fun t -> opprim (oppk t))
    | Table -> optb
    | Function -> opfu
    | Number -> opnonce
    | PcTable(_,_,_) -> raise (Call "op_of_type: tables non implementees")
    | PeTable(_,_,_) -> raise (Call "op_of_type: tables non implementees")
;;


(* ----------------
   oparith_of_nb : int -> term -> term -> term
   Input: integer representing the number of an arithmetic function.
   Output: a function giving a term
   Role: establish correspondence between a number and an arithmetic operator.
   ---------------- *)
let oparith_of_nb = function (* TODO one can make definition for designing the integers *)
    1 -> opsum
  | 2 -> opminus
  | 3 -> opmult
  | 4 -> opdiv
  | 5 -> opmod
  | 6 -> oprcrypt
  | _ -> oppow
;;

(* ----------------
   oplogic_of_nb : int -> term -> term -> term
   Input: integer representing the number of a logical function.
   Output: a function giving a term
   Role: establish correspondence between a number and a logical operator.
   ---------------- *)
let oplogic_of_nb = function (* TODO one can make definition for designing the integers *)
    1 -> oprcrypt
  | 2 -> opand
  | 3 -> opor
  | 4 -> opnand
  | _ -> opnor
;;


(* ----------------
   union:
   ----------------
   val union : 'a list -> 'a list -> 'a list
   ---------------- *)
let rec union l1 l2 = match l1 with
    [] -> l2
  | a::reste -> if List.mem a l2 then union reste l2 else union reste (a::l2)
;; 


(* ----------------
  subtraction:
   ----------------
  val sub : 'a list -> 'a list -> 'a list
   ---------------- *)
let rec sub l1 l2 = match l1 with
    [] -> []
  | a::reste -> if (List.mem a l2) then sub reste l2 else a::(sub reste l2)
;;


(* ----------------
  remove:
   ----------------

   ---------------- *)
let rec remove elt lst =
	if (elt=List.hd lst)
		then
			List.tl lst
		else
			[(List.hd lst)]@(remove elt (List.tl lst))
;;


(* ----------------
   interclasser: .
   ----------------
   val: 'a list -> 'a list -> 'a list
   ---------------- *)

let rec interclasser = function
   [] ->
        (fun l -> l)
 | (a1::l1) as a1_l1 -> (function
        [] -> a1_l1
      | (a2::l2) as a2_l2 ->
             if (a1 > a2)
               then
                 a2::(interclasser a1_l1 l2)
             else
               if (a1 = a2)
                 then
                   a1::(interclasser l1 l2)
               else
                 a1::(interclasser l1 a2_l2))
;;


(* ----------------
   insert: .
   ----------------
   val: 
   ---------------- *)
let inserer l no infos =
   let rec inserer_rec = function
      [] -> [(no,infos)]
    | (i,infos_i as elt_i)::li ->
           if (i < no)
             then
               elt_i::(inserer_rec li)
           else
             (no,infos)::elt_i::li
   in
     l := inserer_rec !l
;;


(* ----------------
   add_msg: add a message to msg_list
   ----------------
   val: int -> int -> int -> msg -> unit
   ---------------- *)
let add_msg no idFrom idTo msg =
   incr nbMsgs;
   if (no <> !nbMsgs)
     then
       (print_string "WARNING: message ";
        print_int no;
        print_string " reindexed ";
        print_int !nbMsgs;
        print_newline());
   msg_list := !msg_list @ [(!nbMsgs,((idFrom,idTo),msg))];
;;


(* ----------------
   add_ident_knowledge : val: int -> int list -> unit
   Input: identifier, list of identifiers
   Role: add an identifier to ident_knowledge
   Rem: add the fact that i knows the lIdi by maintaining the separated 
        list of knowledges connaissances.
        If it exists already then merge the separated list or merge them coded to
        be able to add the knowledges in several passes without any bug
   TODO improve this explanation!!!
   ---------------- *)
let add_ident_knowledge i lIdi =
  let rec add_ident_know_rec = function
      [] -> [(i,lIdi)]
    | (j,lIdj as infoj)::l ->
        if (i = j)
        then
          (i, interclasser lIdi lIdj)::l
        else
          if (i < j)
          then
            (i,lIdi)::l
          else
            infoj::(add_ident_know_rec l)
  in
    ident_knowledge := add_ident_know_rec !ident_knowledge
;;


(* ----------------
   add_ident_para
   Input: number of a user
   Output:
   Role: add the number of a user to the list of those for whom the rules
         are going to be generated //
   Rem:
   ---------------- *)
let add_ident_para i =
	para_ident_list:= !para_ident_list@[i]
;;


(* ----------------
   add_ident_secret
   Input: number of an identifier
   Output:
   Role: add the number of an identifier to be hidden in the rules //
   Rem:
   ---------------- *)
let add_ident_secret i =
	secret_ident_list:= !secret_ident_list@[i]
;;


(* ----------------
   add_ident: val: string -> type_var -> unit
   Input: identifier, table of identifiers
   Role: add an identifier to the table of identifiers
   Rem: Add a new identifier to the hashing table 
        incremente the identifier number and add the identifier to the list
        with his type
        if it is a user add his knowledge
---------------- *)
let add_ident id tId =
  incr cpt_id;
  Hashtbl.add ident_table id !cpt_id;
  ident_list := !ident_list @ [(!cpt_id,(id,tId))];
  if tId = User
  then
    add_ident_knowledge !cpt_id [!cpt_id]
      ;;


(* Add the intruder *)
    add_ident "I" User;;

(*TODO pkoi here?*)

(* ----------------
   get_sender : int -> int
   Input: index of a message in the list of messages.
   Output: Number of a principal
   Role: Given the list of messages, this function gives the number of the sender
   Use: external fst : 'a  'b -> 'a = "%field0" (give the first field of a structure)
            val assoc : 'a -> ('a * 'b) list -> 'b (predefined)
   Rem: val msg_list : (int * ((int * int) * msg)) list ref
   ---------------- *)
let get_sender i =
   fst (fst (List.assoc i !msg_list))
;;


(* ----------------
   get_receiver : int -> int
   Input: 
   Output: number of a principal
   Role: give the number of receiver of ith message in the list msg_list
   Use: external snd : 'a * 'b -> 'b = "%field1" (give the second field of a structure)
   ---------------- *)
let get_receiver i =
   if i == 0
     then
       get_sender 1
   else
     snd (fst (List.assoc i !msg_list))
;;


(* ----------------
   get_msg : int ->  msg
   Input: index of a message in the list !msg_list
   Output: a message
   Role: give the ith message in !msg_list
   ---------------- *)
let get_msg i =
   snd (List.assoc i !msg_list)
;;


(* ----------------
   firstS : int -> int
   Input: Number of a principal
   Output: Number of a message
   Role: give the number j of the first message sent by the principal u
   Use:external incr : int ref -> unit = "%incr" (increment function)
   Rem:
   ---------------- *)
let firstS u =
   let j = ref 1
   in
     while (get_sender !j <> u && !j <= !nbMsgs) do
	incr j
     done;
     !j(*TODO: what happens in the case (wrong) in which u does not participate
        in the communication?*) 
;;


(* ----------------
   add_keys : int list -> int list
   Input: list of identifiers
   Output: list of identifiers to which the associated public/private keys were added
   Role: Given the keys associated to the fresh keys (public or private)
   Use: val getIdentType : int -> type_var
   Rem:   
   ---------------- *)
let add_keys l = match l with
    [] -> []
| a::reste ->
         match (getIdentType a)
         with FrPcKey(j) -> [a;j]@reste(*TODO is it the same key value?*)
            | FrPeKey(j) -> [a;j]@reste
            | _ -> l
;;


(* ----------------
   infers_for_know : (msg * bool) list -> (msg * bool) list
   Input: a list where each element consists of two fields: 
               a message
               a boolean indicating if the message has been decomposed.
           this list represents the knowledge of a principal.
   Output: the updated input list
   Role: Compute the set of messages knows by decomposition starting from a 
         list of messages.
   Use: ajoute_connaissance
           est_decompose
           traite_cipher
           decompose_msgs
   Rem:   
   ---------------- *)
let infers_for_know lstmsgs =   
  let newElt = ref false
  and lMsg = ref lstmsgs
  in  
    
(* ----------------
   ajoute_connaissance:
   Input: 
   Output: 
   Role: add an elt to the list of messages known if it is not
         a number passes the tag saying that the list has been augmented to true
         and set the tag indicating that the message has been decomposed to false
   Use:
   Rem:   
   ---------------- *)
  let ajoute_connaissance = function
     Int(_) -> ()
   | msg ->
      	newElt := true;
      	if not (List.mem_assoc msg !lMsg)
          then
            lMsg := (msg,false)::!lMsg
  in

    
 (* ----------------
   est_decompose:
   Input: message
   Output: 
   Role: set the tag indicating that the message has been decomposed to true
   Use:
   Rem:   
   ---------------- *) 
  let est_decompose msg =   
     lMsg := (msg,true)::(List.remove_assoc msg !lMsg)
  in

 (* ----------------
   traite_cipher:
   Input: crypted message, cleartext message, key
   Output: 
   Role: update the flag indicating that the crypted message has been decomposed
         and add the crypted message to the knowledge list if the key is good
   Use: val mem_assoc : 'a -> ('a * 'b) list -> bool
           (* Same as [assoc], but simply return true if a binding exists,
           and false if no bindings exist for the given key. *)
   Rem:
   ---------------- *) 
  let traite_cipher msg msg2 key =
    if List.mem_assoc key !lMsg
      then
        begin
	est_decompose msg;
	ajoute_connaissance msg2;
        end
  in


 (* ----------------
   decompose_msg:
   Input: a message
   Output: 
   Role: update the flag indicating that the crypted message has been decomposed
         and add the components to the knowledge list
   Use: est_decompose
        ajoute_connaissance
   Rem:   
   ---------------- *) 
  let rec decompose_msg = function
    | Pair(m1,m2) as msg ->
      	ajoute_connaissance m1;
      	ajoute_connaissance m2;
      	est_decompose msg

    | Logic(1,m1,m2) as msg -> (* XOR *)


	if ((  List.mem_assoc m1 !lMsg ) or(  List.mem_assoc m2 !lMsg ))
	    then 
	  (  	  
		decompose_msg m1;
		decompose_msg m2;	
		est_decompose msg;	  
	  )	
	else
	  est_decompose msg;

    | Crypt(1,Id(u),m2) as msg ->
      	(
	  match getIdentType(u) with 
	    | FrPcKey(peId) ->
		traite_cipher msg m2 (Id(peId))
	    | PcKey(peId) ->
		traite_cipher msg m2 (Id(peId))
	    | PcTable(_,_,peId) ->
		traite_cipher msg m2 (Id(peId))
	    | _ -> est_decompose msg
	)
    | Crypt(2,Id(u),m2) as msg ->
      	(
	  match getIdentType(u) with 
	    | FrPeKey(pcId) ->
		traite_cipher msg m2 (Id(pcId))
	    | PeKey(pcId) ->
		traite_cipher msg m2 (Id(pcId))
	    | PeTable(_,_,pcId) ->
		traite_cipher msg m2 (Id(pcId))
	    | _ -> est_decompose msg
	)
    | Crypt(3,Id(u),m2) as msg ->
        (
	  match getIdentType(u) with 
	    | SyKey ->
		traite_cipher msg m2 (Id(u))	
	    | FrSyKey ->
		traite_cipher msg m2 (Id(u))	
	    | _ -> est_decompose msg
	)
    | Func(f,m) as msg ->
	if (List.mem_assoc (Id(f)) !lMsg)
	    then (ajoute_connaissance m;
	          decompose_msg m);
	est_decompose msg
    | msg -> est_decompose msg
  in

(* ----------------
   decompose_msgs:
   Input: 
   Output: 
   Role: decompose recursively the list of messages
   Use: decompose_msg
   Rem:   
   ---------------- *)
  let rec decompose_msgs () =
    newElt := false;
    List.iter (function (m,false) -> decompose_msg m | _ -> ())
      !lMsg;
    if !newElt then decompose_msgs ();
  in

    decompose_msgs();
    !lMsg
;;

(* ----------------
   compute_know_of_user : int -> int -> (int * (msg * bool) list) list
   Input: Number of a user, message number.
   Output:
   Role:
   Use:val map : f:('a -> 'b) -> 'a list -> 'b list
          (* [List.map f [a1; ...; an]] applies function [f] to [a1, ..., an],
           and builds the list [[f a1; ...; f an]]
           with the results returned by [f].  Not tail-recursive. *)
   Rem:
   ---------------- *)
let rec compute_know_of_user u = function

    (* The knowledge at the beginning *)
    0 ->
      (try( [(0,infers_for_know(( List.map (fun x -> (Id(x),true)) (List.assoc u !ident_knowledge) )@ ( List.map (fun x ->(x,false)) (List.assoc u !init_msg_knowledge) ))) ])
	with not_found->
	[(0,( List.map (fun x -> (Id(x),true)) (List.assoc u !ident_knowledge)))])

  | i -> let last = compute_know_of_user u (i-1)
         and ((se,re),msg) = List.assoc i !msg_list
         in
           let knowi = ref (List.assoc (i-1) last)
           in
             (let check_unknown m v =
                 if not (List.mem_assoc m !knowi)
                   then
                     knowi := (m,v)::!knowi
              in
                if u = re then
	          (check_unknown (Id(se)) false;
                   check_unknown msg false)
                else
                  if u = se
                    then
                      List.iter (fun i ->
                                    check_unknown (Id(i)) true)
                                (add_keys (fresh_var i)));
	       (i, infers_for_know (!knowi))::last
;;

(* ----------------
val getInstance :
   Input: identifier number
   Output: name of the instance of the identifier at a given session
   Role: determine the name of an instance of an identifier, else the name of
         the identifier
   Use:
   Rem:
---------------- *)
let getInstance id session_instances=
      try
	List.assoc id session_instances;
      with 
	Pas_trouve-> getIdentId id
      |	Not_found ->  getIdentId id
;;


(* ----------------
val replaceByInstance :term -> term
   Input: term of which one want to introduce an instance
   Output: term where the constants and the variables have been replaced by 
           corrresponding instances
   Role: instantiate the contents of input terms
   Use:val getInstance :
---------------- *)
let rec replaceByInstance trm inst=
    match trm with
    Op(opstr,[t]) ->Op(opstr,[(replaceByInstance t inst)])
  | Op(opstr,[t1;t2]) ->Op(opstr,[(replaceByInstance t1 inst);(replaceByInstance t2 inst)])
  | Cons(s) ->Cons(getInstance (getId s!ident_list) inst)
  | Var(s) ->Var(getInstance (getId s !ident_list) inst ) 
  | x ->x
;;

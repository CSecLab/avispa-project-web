(***********************************************************************)
(*                                                                     *)
(*                               hlpsl2if                              *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(***********************************************************************)
(* file errorHandler *)
let lineCounter = ref 1;; 
let errorsCounter = ref 0;; 

let errorNumber = ref 0;; 

let handleSystemError errorMessage=
  print_endline ("System error :"^errorMessage);
  exit(-1)
 ;;

let handleLexerError lexerBuffer errorMessage=
  print_endline "Lexer module:";
  print_string "Error line ";
  print_int !lineCounter;
  print_string ": ";
  print_string (lexerBuffer);
  print_endline errorMessage;
  exit 0 
;;

let handleParseError() =
  incr errorsCounter;
  print_endline  "Parser Module:";
  print_string "Suntax error number ";
  print_int !errorNumber;
  print_string " at line ";
  print_int !lineCounter;
  match !errorNumber
  with 
      0 -> print_endline ": missing PROTOCOL keyword"
    | 1 -> print_endline ": missing protocol name after PROTOCOL"
    | 2 -> print_endline ": missing semi-colon after protocol name"
    | 3 -> print_endline ": missing IDENTIFIERS keyword"
    | 4 -> print_endline ": missing KNOWLEDGE or MESSAGES keyword"
    | 5 -> print_endline ": missing MESSAGES keyword"
    | 6 -> print_endline ": missing colon in declaration"
    | 7 -> print_endline ": missing semi-colon at the end of a declaration of variables"
    | 8 -> print_endline ": missing KNOWLEDGE keyword"
    | 9 -> print_endline ": missing comma in a list of identifiers"
    | 10 -> print_endline ": missing/wrong type in variable declarations"
    | 11 -> print_endline ": missing comma or colon in knowledge declaration"
    | 12 -> print_endline ": missing comma or semi-colon in a list of knowledges"
    | 13 -> print_endline ": missing identifier name in list"
    | 14 -> print_endline ": missing identifier name in list or MESSAGES keyword"
    | 15 -> print_endline ": missing identifier name in list or KNOWLEDGE keyword"
    | 16 -> print_endline ": missing index of message"
    | 17 -> print_endline ": missing dot after index of message"
    | 18 -> print_endline ": missing sender name in message"
    | 19 -> print_endline ": missing arrow after sender name"
    | 20 -> print_endline ": missing receiver name in message"
    | 21 -> print_endline ": missing colon after receiver name"
    | 22 -> print_endline ": missing SESSION_INSTANCES keyword"
    | 23 -> print_endline ": missing squared bracket in session instance"
    | 24 -> print_endline ": bad definition of INTRUDER strategy"
    | 25 -> print_endline ": missing INTRUDER, INTRUDER_KNOWLEDGE or GOAL keyword"
    | 26 -> print_endline ": bad definition of GOAL strategy"
    | 27 -> print_endline ": bad parallel declaration"
    | 28 -> print_endline ": bad secret declaration"
    | 29 -> print_endline ": bad xor use"
    | 30 -> print_endline ": bad role declaration"
    | _ -> print_endline ": unknown";
;;

let handleSemanticError errorNumber faultyIdentifier=

  incr errorsCounter;
  print_endline  "Protocol analysis:";
  print_string "Semantic error number ";
  print_int errorNumber;
  print_string " at line ";
  print_int !lineCounter;

  match errorNumber
  with 
      0 -> print_endline ": Unknown."
    | 1 -> print_endline (": multiple declaration of "^faultyIdentifier^".")
    | 2 -> print_endline (": "^faultyIdentifier^" used in knowledge section before declaration.")
    | 3 -> print_endline (": "^faultyIdentifier^" is not a public key (cannot be inversed).")
    | 4 -> print_endline (": inconsistent use of the identifier" ^faultyIdentifier^" in messages section.")
    | 5 -> print_endline (": "^faultyIdentifier^" must be a user.")
    | 6 -> print_endline (": "^faultyIdentifier^" used in parallel section before declaration.")
    | 7 -> print_endline (": "^faultyIdentifier^" used in parallel secret  section before declaration.")
    | 8 -> print_endline (": "^faultyIdentifier^" used  as User but never declared.")
    | 9 -> print_endline (": "^faultyIdentifier^" used in message section before declaration.")
    | 10 -> print_endline (": "^faultyIdentifier^" used as public key but never declared.")
    | 11 -> print_endline (": "^faultyIdentifier^" used as a private key but never declared.")
    | 12 -> print_endline (": "^faultyIdentifier^" used as a function but never declared.")
    | 13 -> print_endline (": "^faultyIdentifier^" cannot be used for encrypting a message.")
    | 14 -> print_endline (": "^faultyIdentifier^" used as encrypting key, but never declared.")
    | 15 -> print_endline (": "^faultyIdentifier^" used as instance with different types.")
    | 16 -> print_endline (": "^faultyIdentifier^" used in session instances section before declaration.")
    | 17 -> print_endline (": "^faultyIdentifier^" is not a valid intruder knowledge.")
    | 18 -> print_string (": invalid index of message");
    | 19 -> print_endline (": "^faultyIdentifier^" is not a valid public key in knowledge of the intruder I.");
    | 20 -> print_endline (": "^faultyIdentifier^" is not a valid table name in knowledge of the intruder I.");
    | 21 -> print_endline (": "^faultyIdentifier^" is not a valid user in knowledge of the intruder I.");
    | 22 -> print_endline (": "^faultyIdentifier^" is not a valid user name in correspondance goal.");
    | 23 -> print_endline (": "^faultyIdentifier^" used in goal section but never declared.");

    | _ -> print_endline "Unknown";
;;

let printExceptionMessage runTimeException sourceModule sourceFunction =
  print_endline ("Exception: "^(Printexc.to_string runTimeException));
  print_endline ("Module: "^sourceModule );
  print_endline ("Function: "^sourceFunction );
  flush stdout
;;

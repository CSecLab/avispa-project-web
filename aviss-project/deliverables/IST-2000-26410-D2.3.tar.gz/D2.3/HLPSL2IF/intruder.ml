(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* intruder rules generator *)
open Types;;
open Globals;;
open Utilities;;
open Rules;;
let rec comb_term_list termList = 
    match termList with
(* Empty list *)
  	[] ->ErrorHandler.printExceptionMessage (Failure("comb_term_list")) "Intruder" "comb_term_list";raise  (Failure("comb_term_list"))
(* one element list *)
	  (* When the constructor Op has 2 arguments : mr,pk...*)
      | [Op(constructorString,[constructorArg])]->[termList] 
	  (* Case of couples *)
      | [Op("c",coupleList)]-> (comb_term_list coupleList)
	  (* When the constructor Op has more than 2 arguments : crypt,scrypt...*)
      | [Op(constructorString,constructorTermList)] as r-> [r]@ (comb_term_list constructorTermList)
	  (* Case of: Cons and Var *)
      | [head]as constOrVarTerm-> [constOrVarTerm]
(* The list has more than one element *)
      |  head::tail -> Utilities.list_product (comb_term_list [head]) (comb_term_list tail)
;;
let comb_term argTerm =
comb_term_list [argTerm]
;;
let rec rename_unknown_term messageTerm prefix =

  let rec rename_unknown_term_list counter termList lprefix =
    match termList with
	[] -> ErrorHandler.printExceptionMessage Not_found "Intruder" "rename_unknown_term_list";raise Not_found
      |	[head] -> [rename_unknown_term head (lprefix^(string_of_int counter)^(!underscore))]
      | head::tail  ->(* TODO replace by: (rename_unknown_term_list counter head lprefix )@... *)
  	  List.append [rename_unknown_term head (lprefix^(string_of_int counter)^(!underscore))]
	      (rename_unknown_term_list (counter+1) tail lprefix) 
  in

  match messageTerm with
      Empty -> ErrorHandler.printExceptionMessage Not_found "Intruder" "rename_unknown_term_list";raise Not_found
      |	Cons(consName) ->
	  (* special case of private keys *)
  	  if ((String.get consName ((String.length consName)-1)) == '\'') then
	    let newStr = ref (String.sub consName 0 ((String.length consName)-1)) in
	      Cons(prefix^(!newStr))
  	  else Cons(prefix^consName)(*general case *)
      | Var(varName) ->
  	  if (String.contains varName '\'') then
	    let newStr = ref (String.sub varName 0 ((String.length varName)-1)) in
	      Var(prefix^ !newStr)
  	  else
	    Var(prefix^varName)
      | Op(constructorString,constructorList) ->
  	  Op(constructorString,(rename_unknown_term_list 1 constructorList (prefix^constructorString^(!underscore)) ))
;;
let rec rename_if_unknown prefix message awaited_message =
  let rename_if_unknown_list prefix messageTermList awaitedMessageTermList =
    let counter = ref 0 in
      List.map2  (fun messageTerm awaitedMessageTerm ->
		    (
		      counter := !counter+1 ; 
		      rename_if_unknown 
			(prefix^(!underscore)^(string_of_int !counter)^(!underscore)) 
			messageTerm awaitedMessageTerm
		      )
		 ) 
	messageTermList awaitedMessageTermList
  in
    match message with
      	Empty -> Empty
      | Cons(s) -> Cons(s)
      | Var(s) -> Var(s)
      | Op(s,messageTermList) ->
	  match awaited_message with
	      Op(s,awaitedMessageTermList)  -> Op(s,(rename_if_unknown_list (prefix^s) messageTermList awaitedMessageTermList))
	    |_ -> (rename_unknown_term message prefix)
;;
let create_term_for_impersonate step = 
  let receiverNumber = (Utilities.get_receiver step) in
  let message_awaited_by_receiver = (Rules.see receiverNumber(Utilities.get_msg step) step) in
  let message_defined_in_protocol = ((Utilities.to_term (Utilities.get_msg step))) in
  (rename_if_unknown (!underscore) (message_defined_in_protocol) message_awaited_by_receiver)
;;
let build_all_user_list () =
  let userList = ref [] in
    List.iter
      (
	List.iter
	 (
	   fun instanceCouple ->
	     match Utilities.get_identifier_type (fst instanceCouple) with 
		 User -> if not ((List.mem (snd instanceCouple)) !userList) && (snd instanceCouple) <> "I" then userList := (snd instanceCouple)::!userList
	       | _ -> ()
	 ))!Globals.session_instances;
    !userList
;;
let  build_divert_rules () =
  let honestUserInstances = build_all_user_list() in
  let divertRuleList = ref [] in
    List.iter
      ( fun userInstance -> 
	  let rule = 
	    Rule(
	      "# lb=Divert_"^userInstance^", type=Intruder_Rules",
	      (Op(".",[ (Utilities.oph (Utilities.ops(Var("Time"))));
			(Utilities.opm (Var("1")) (Utilities.opmr (Cons(userInstance))) (Var("3")) (Var("4")) (Var("5")) (Var("6"))) ])),
	      (Op(".",[ (Utilities.oph (Var("Time"))); 
			(Utilities.opi (Utilities.opmr (Cons(userInstance)))); 
			(Utilities.opi (Var("3")));
			(Utilities.opi (Var("4")));
			(Utilities.opi (Var("5")))]))) in
	    divertRuleList := rule :: !divertRuleList) honestUserInstances;
    !divertRuleList
;;
let  build_memo_rules () =
  Rule(
    "# lb=Memorize,  type=Intruder_Rules",
    (Op(".",[ (Utilities.oph (Utilities.ops(Var("Time")))); 
	      (Utilities.opm (Var("1")) (Var("2")) (Var("3")) (Utilities.opmr (Cons("I"))) (Var("5")) (Var("6")))])),  
    (Op(".",[ (Utilities.oph (Var("Time"))); (Utilities.opi (Var("2"))); (Utilities.opi (Var("5")))]))
  )
;;
let  build_eavesdropping_rules () =
  let honestUserInstances = build_all_user_list() in
  let eavesDroppingRuleList = ref [] in
    List.iter
      ( fun userInstance -> 
	  let rule = 
	    Rule(
	       "# lb=Eaves_dropping_"^userInstance^", type=Intruder_Rules",
	      (Op(".",[ (Utilities.oph (Utilities.ops(Var("Time"))));
			(Utilities.opm (Var("1")) (Utilities.opmr (Cons(userInstance))) (Var("3")) (Var("4")) (Var("5")) (Var("6"))) ])), 
	      (Op(".",[ (Utilities.oph (Var("Time")));
			(Utilities.opm (Var("1")) (Var("2")) (Var("3")) (Var("4")) (Var("5")) (Var("6"))); 
			(Utilities.opi (Var("3")));
			(Utilities.opi (Var("4")));
			(Utilities.opi (Var("5")))]))) in
	    eavesDroppingRuleList := rule :: !eavesDroppingRuleList) honestUserInstances;
    !eavesDroppingRuleList
;;
let build_impersonate_rules_term protocolStep =
  let message_term = (create_term_for_impersonate protocolStep) in
    (*print_string "\n# message for impersonate "; print_int k;print_string "\t\t";
    print_term message_term; print_string "\n"; *)
    (comb_term message_term)
;;
let  build_impersonate_rules () =
  let impersonnateRuleList = ref [] in
    for protocolStep=1 to !Globals.nbMsgs do
      begin
	let impersonnateMessageTerm = (create_term_for_impersonate protocolStep) in
	let counter = ref 1 in
	  List.iter
	    (fun termList -> 
	       let receiverNumber = (Utilities.get_receiver protocolStep) in
	       let senderNumber = (Utilities.get_sender protocolStep) in
	       let receiverTerm = Utilities.opmr(Var(Utilities.get_identifier_name receiverNumber)) in
	       let senderTerm = Utilities.opmr(Var(Utilities.get_identifier_name senderNumber)) in
	       let wl = Utilities.opw
			  (Cons(string_of_int protocolStep)) 
			  senderTerm 
			  receiverTerm 
			  (Rules.add_type_def protocolStep (Rules.get_user_knowledge receiverNumber protocolStep protocolStep)) 
			  (Rules.initial_knowledge_terms receiverNumber) 
			  (Cons("true")) 
			  (Var("c")) in
	       let wr = Utilities.opw 
			  (Cons(string_of_int protocolStep)) 
			  senderTerm 
			  receiverTerm 
			  (Rules.add_type_def protocolStep (Rules.get_user_knowledge receiverNumber protocolStep protocolStep)) 
			  (Rules.initial_knowledge_terms receiverNumber) 
			  (Cons("false")) 
			  (Var("c")) in
       	       let mr = Utilities.opm (Cons(string_of_int protocolStep)) (Utilities.opmr(Cons("I"))) senderTerm receiverTerm impersonnateMessageTerm (Cons("0")) in
	       let rule =
		 Rule (
		   ("# lb=Impersonate_"^(string_of_int protocolStep)^(!underscore)^(string_of_int !counter)^", type=Intruder_Rules"),
		   (Op(".",[ (Utilities.oph (Utilities.ops(Var("Time")))); 
			     wl; 
		      	     (Rules.add_type_def protocolStep (Op(".",(Utilities.union [Utilities.opi receiverTerm;Utilities.opi senderTerm] (List.map (fun x -> (Utilities.opi x)) termList)))))])),
		   (Op(".",[ (Utilities.oph (Var("Time")));
			     mr;
			     wr;
			     (Rules.add_type_def protocolStep (Op(".",(Utilities.union [Utilities.opi receiverTerm;Utilities.opi senderTerm] (List.map (fun x -> (Utilities.opi x)) termList)))))]))
		 ) in
		 impersonnateRuleList := rule :: !impersonnateRuleList;
		 counter:= !counter+1;
	    ) 
	    (build_impersonate_rules_term protocolStep);
      end 
    done;
    !impersonnateRuleList
;;
let build_intruder_simplification_rules = 
  [ (Rule
       ("# lb=Decompose, type=Decomposition_Rules",
       	(Utilities.opi (Utilities.oppair (Var "1") (Var "2"))),
       	(Op(".",[ (Utilities.opi (Var "1")); (Utilities.opi (Var "2")) ]))));
    (Rule
       ("# lb=Decrypt_public_key, type=Decomposition_Rules",
       	(Op(".",[ (Utilities.opi (Utilities.opcrypt (Var "1") (Var "2"))); 
		  (Utilities.opi (Utilities.opprim (Var "1"))) ])),
       	(Op(".",[ (Utilities.opi (Var "2")); (Utilities.opi (Utilities.opprim (Var "1"))) ]))));
    (Rule
       ("# lb=Decrypt_private_key, type=Decomposition_Rules",
       	(Op(".",[ (Utilities.opi (Utilities.opcrypt (Utilities.opprim (Var "1")) (Var "2"))); 
		  (Utilities.opi (Var "1")) ])),
       	(Op(".",[ (Utilities.opi (Var "2")); (Utilities.opi (Var "1")) ]))));
    (Rule
       ("# lb=Decrypt_symmetric_key, type=Decomposition_Rules",
       	(Op(".",[ (Utilities.opi (Utilities.opscrypt (Var "1") (Var "2"))); 
		  (Utilities.opi (Var "1")) ])),
       	(Op(".",[ (Utilities.opi (Var "2")); (Utilities.opi (Var "1")) ]))))
  ]
;;

#!/usr/bin/perl -w
#
# Prepare un fichier datac pour explorer toutes les possibilit\'es d'utilisation de regles paralleles
#

package Sessions;
use strict;
use Shell qw(rm);



sub PrintDebug {
#  print @_;
}

sub new {
  my $self = {};
  $self->{FileName} = $_[1];
  $self->{Rules} = "# Rules for unbounded number of parallel sessions\n\n";
  $self->{Initial} = "";
  $self->{NumberOfClauses} = 0;
  $self->{OutPut} = $_[2];
  bless $self;
  return $self;
}

sub Print {
  my $self = shift;
  my $fh = $self->{OutPut};
  
  print $fh @_;
}


sub PrintResult {
  my $self = shift;

  PrintDebug "\nPrinting Result\n";

  $self->Print( CharToPrim( $self->{Rules} ) );
}


sub PrintInitial {
  my $self = shift;
  my $debug = $self->{Initial};
  PrintDebug "\nNow printing initial state :\n" .PrimToChar($debug)."\n\n";

  $self->Print($self->{Initial});
}


sub PrimToChar {
  my $string = @_[0];
  my $result = "";
  my $Atom = "";
  my $Begin = "1";

  foreach $Atom ( split(/\'/,$string) ) {
    if ($Begin) {
      $result .= "$Atom";
      $Begin = 0;
    }
    else {
      $result .= "cprim$Atom";
    }      
  }
  return $result;
}

sub CharToPrim {
  my $string = @_[0];
  my $result = "";
  my $Atom = "";
  my $Begin =1;

  foreach $Atom ( split(/cprim/,$string) ) {
    if ($Begin) {
      $result .= "$Atom";
      $Begin=0;
    }
    else {
      $result .= "\'$Atom";
    }
  }
  # print "CharToPrim" . $result . "\n" ;
  return $result;
}
  

sub ECRITURE_REGLES {
  my $self = shift ;

  my $filename = $self->{FileName};
  my $CasrulExe = $ReglesParalleles::CASRUL;
  open(MESSAGES,"$CasrulExe --para $filename | grep message |") or die "Cannot Find Input File\n";
#  open(MESSAGES,"NSPK_corr-mesg") or die "Cannot find input file\n";

  my $counter="a";
  my $regles="\n#7 \n# Theory \n\n";
  my $theory = ""; #"\n#7\n# Theory : (list of clauses)\n"; 
  my $message = "";
  my $buffer = "";
  my $attendu = "";
  my $emis  = "";
  my $term = "";
  my $nterm = "";

  PrintDebug "ECRITURE_REGLES...\n";
  PrintDebug "\t(file $filename opened)\n";
  while ($buffer = <MESSAGES> ){
    PrintDebug "\t\tmessage lu  : $buffer\n";
    if ($buffer =~ /^([a-zA-Z\(\)0-9\'\.,]+)$/ ){
      $message = $1;
      $message=PrimToChar($message);
      # print $message. "\n";
    }
    else {
      $message =" "
    }
    # print "# Message $counter)\n";
    if ( $message =~ /^message\(ii[\.]?(.*),ii[\.]?(.*),ii\)/s) {
      # print "$1\n$2 \n\n";
      $attendu= $1;
      $emis =$2;
      foreach $term (split(/\./,$emis) ) {
        if ($term =~ /i\((.+)\)/){
          $nterm=$1;
          if ( $attendu ) {
            $regles = "$regles\n\nSysteme(s(xTime),avant(ii.$attendu,ii.$term).message(xum.v($nterm),xdm,xl).ii) => \\\n";
            $regles = "$regles Systeme(xTime,avant(xu,xd).message(xum.$attendu,xdm,xl.v($nterm)).ii)\n\n";
          }
          else {
            $regles = "$regles\n\nSysteme(s(xTime),avant(ii,ii.$term).message(xum.v($nterm),xdm,xl).ii) => \\\n";
            $regles = "$regles Systeme(xTime,avant(xu,xd).message(xum,xdm,xl.v($nterm)).ii)\n\n";
          }
        }
      }  
# Ecriture de l'atome
      
      $theory = "$theory\n\n => Systeme(xTime,avant(xu$counter,xd$counter).$message.ii)\n"
    }
    else {
      print  TOTOR "";
      print TOTOR  "\# Fail with :-$message-\n";
    }
    $counter++;
  }
  $regles = CharToPrim($regles) ;
  $theory = CharToPrim($theory);
  print TOTOR $regles ;
  print TOTOR $theory ;
}

# if ("message(ii,ii.i(crypt(pk(p),sk(Ka))),ii)" =~ /^message\(ii[\.]?(.*),ii[\.]?(.*),ii\)/s){
# print "TOTOR\n";
# print "$1\n";
# print "$2\n";
# }




sub WriteDatacFile {
  my $self = shift;
  open(TOTOR,"> /tmp/temp.dat") or die "Cannot open temporary file";
  PrintDebug "WriteDatacFile...\n";

  print TOTOR  $ReglesParalleles::Preambule  ;

  ECRITURE_REGLES($self)   ;

  print TOTOR  $ReglesParalleles::Conclusion ;

  close(TOTOR);
}

sub ExecuteDatacFile {
  my $msg = "";
  my %Table =();
  my $Begin = "1";
  my $buffer = "";
  my $numero = "";
  my $Clause = "";
  my @RecvList = ();
  my @SendList = ();

  open(CLAUSES,"$ReglesParalleles::DATAC -x o -i /tmp/temp.dat |") or die "Ca foire !";

  keys(%Table)=255;# ca devrait suffire, 3*5*17
  
  PrintDebug "ExecuteDatacFile...\n";
  while ( $buffer = <CLAUSES> ){
    $buffer = PrimToChar($buffer);
    # print $buffer;
    # On recupere toutes les clauses qui passent
    if ( $Begin == "1") {
      if ($buffer =~ /Clause ([0-9]+): => R(.+)$/){
	$numero = $1;
	$Clause = $2;
	PrintDebug "Debug ;\n\t$numero\n$Clause\n\n";
	%Table = (%Table, $numero => $Clause);
      }
#      if ($buffer =~ /execution stopped/){
#	$Begin= "0";
#      }
    }
    else {# initialisation
      if ($buffer=~ /^\#[0-9]+$/) {
	$Begin = "1";
      }
    }
  }

  close(CLAUSES);
  chmod 0666 , "/tmp/temp.dat";
#  syscall "/bin/rm","-f","/tmp/temp.dat";
Shell::rm "/tmp/temp.dat";
  return %Table;
}

sub ParseRecv {
  my $RecvMsg = $_[0];
  my @RecvList = split(/\./,$RecvMsg);
  my $RecvTerm ="";

  foreach $RecvTerm (@RecvList) {
    if ($RecvTerm =~ /i\(/){
      # print "Recu :\t\t$RecvTerm\n"
    }
  }
  return @RecvList;
}
sub ParseSend {
  my $SendMsg = $_[0];
  my @SendList = split(/\./,$SendMsg);
  my $SendTerm = "";

  foreach $SendTerm (@SendList) {
    if ($SendTerm =~ /v\(/){
     # print "Envoye :\t$SendTerm\n"
    }
  }
  return @SendList;
}

sub ParseClause {# @_[1]=  $clause
  my $self = shift ;
  my $Clause = shift;
  my $Key = shift;
  my $Counter = "1" ;
  my @MesgRulesSend = ();
  my @MesgRulesRecv = ();
  my $Term = "";
  my @Terms = ();
  my $num = ++$self->{NumberOfClauses}; 
  my $Begin = 1;
  my $Atom = "";

  @Messages = split(/,(?=svs)/,$Clause);
  @Message = split(/.(?=mesg)/,$Messages[1]);
  #  @MesgRulesSend = ParseSend($Terms[0]);
  #  @MesgRulesRecv = ParseRecv($Terms[1]);
  my $msgcount = 0;
  foreach $mesg (@Message) {
    if ($msgcount) {
      print $mesg;
    }
    $msgcount++;
  }
  
}


#
# $(objet)->WriteProtocolClauses
#
sub ComputeProtocolClauses {
  my $self = shift;
  my %TableClauses = ();
  keys(%TableClauses) = 255;
  my $Key = "";
  my $msg = "";

  PrintDebug "ComputeProtocolClauses...\n";
  $self->WriteDatacFile() ;
  %TableClauses = ExecuteDatacFile();
  foreach $Key (keys %TableClauses){
    PrintDebug "$Key :";
    $msg = $TableClauses{$Key};
    PrintDebug $msg;
    PrintDebug "\n";
    if ($msg =~ /^\(x1,avant\(x2,x3\)\.message\((.+)\)\.ii\)$/) {
      PrintDebug $1; PrintDebug "\nTermes atomiques :\n";
      $self->ParseClause($1,$Key);
      PrintDebug "\n";
    }
    if ($msg =~ /^\(x1,connaissance\((.+)\)\)/ ){
      $self->{Initial} .= $1.".";
    }
  }
  $self->{Initial} .= "ii";
  return $self;
}


# WriteProtocolClauses;


###############################################################################################
#
# Constantes pour la construction de fichier .dat
#
###############################################################################################


($ReglesParalleles::Preambule = <<END_OF_PREAMBULE );
#  
# One solution : Resolution !


#1
# AC operators: (list of op1, op2, ...)
.

#2
# C operators: (list of op1, op2, ...)
=

#3
# Minimal operator:
a

#4
# Precedence ordering on operators:
Systeme > message > connaissance > u > d > v > i > c > scrypt > crypt > mr > pk > sk > nonce > s > ii > { . }
p > Ka > Na


#5
# Status of operators:
# ex:    f, g : lexico_left_right
#        h : lexico_right_left
#        i : multiset
# default: lexico_left_right
=, . : multiset

#6
# Strategy for applying inferences:
# operators:  ",": or
#             ";": and
#             "+": then
#             "(...)n": iteration (n can be *)
# Example: ref,(rcp;ep;(rp)*),(ep+rp)5
# Default: rp,lp,crp,clp,ep,ref,ef,res,f
res

#70
# Theory already treated: (list of clauses)

=> message(v(xt).xu,i(xt).xd,xl) = message(v(xt).xu,xd,xl)

=> message(u(xt).xu,d(xt).xd,xl) = message(u(xt).xu,xd,xl)

=> message(xu,ii,xl) = ii

=> avant(x1,x2).message(ii,xd,xl).ii = connaissance(xd)

=> v(xt).v(xt) = v(xt)

=> u(xt).u(xt) = u(xt)

=> d(xt).d(xt) = d(xt)

=> i(xt).i(xt) = i(xt)

=> ii.ii = ii

# pas de regle de simplification des u() pour l'instant

=> message(v(xt).xu,xd,v(xt).xl) = ii

=> message(u(xt).xu,xd,u(xt).xl) = ii

# Resolution : Est-ce que ca s'arrete un jour ???


END_OF_PREAMBULE

( $ReglesParalleles::Conclusion = <<END_OF_CONCLUSION);


#8
# Negation of the conjecture: (list of clauses)

#9
# Maximal number of clauses:
5000

#10
# Use of uncomplete AC-unification:
true

#11
# Maximal number of AC-MGUs: (0 -> no limit)
0

#12
# Use of simplification rules:
true

#14
# Subsumption algorithm:
#   forward subsumption:  0: None  1: AC-matching  2: Gottlob&Leitsch
# + backward subsumption:          4: AC-matching  5: Gottlob&Leitsch
2

#15
# Use of other reduction rules:
true

#16
# Maximal size of a clause: (0 -> no limit)
0

#23
# Maximal number of variables in a clause: (0 -> no limit)
0

#17
# Trace degree: (0: Nothing, 1: Inferences, 2: Detailed, 3: All)
1

#18
# Research strategy:  1: Non-Complete   2: Complete
#                     3: Breadth-First  4: Otter-like
2

#19
# Preference for:  1: Conjecture         2: Theory
#                  3: Negative clauses   4: 1+3    5: 2+3
#                  6: Positive clauses   7: 1+6    8: 2+6
#                  0: No preference
0

#20
# Try to simplify before the test of subsumption:
false

#21
# Use of Superposition Strategy:  (false -> Paramodulation)
true

#22
# Use of particular treatment for non-equational literals:
false

END_OF_CONCLUSION


1; # La classe a \'et\'e bien charg\'ee

/**CFile***********************************************************************

  FileName    [simTrace.c]

  PackageName [sim]

  Synopsis    [Running trace handling]

  Description [Internal procedures included in this module:
		<ul>
		<li> <b>SimDllTraceNodes()</b> Tracing search tree nodes
		     (heuristics choices)
		<li> <b>SimDllTraceLeafs()</b> Tracing search tree leafs
		     (backtracks)
		</ul>]
		
  SeeAlso     []

  Author      [Armando Tacchella]

  Copyright   [Copyright (c) 2000-2001 by DIST - Universita' di Genova, 
               Italia. All Rights Reserved. This software is for educational
               purposes only.  Permission is given to academic
               institutions to use, copy, and modify this software and
               its documentation provided that this introductory
               message is not removed, that this software and its
               documentation is used for the institutions' internal
               research and educational purposes, and that no monies
               are exchanged. No guarantee is expressed or implied by
               the distribution of this code.  Permission to
               distribute this code is given to ITC-IRST,
               provided that the code is distributed as is.
               Send bug-reports and/or questions to: sim@mrg.dist.unige.it]

  Revision    [v. 1.0]

******************************************************************************/


#include "simInt.h"


/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/


/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/


/**AutomaticEnd***************************************************************/

/*---------------------------------------------------------------------------*/
/* Definition of internal functions                                          */
/*---------------------------------------------------------------------------*/


/**Function********************************************************************

  Synopsis    [Tracing search nodes.]

  Description [Each time the function is called a counter is decremented.
               Once the number of ticks is reached, the functions outputs
               data on the look-ahead algorithms.]

  SideEffects [none]

  SeeAlso     []

******************************************************************************/
void SimDllTraceNodes()
{

  if (SimLapStat[SIMNODE_NUM] - 1 == 0) {

    /* If a given number of ticks elapsed, output statistics. */
    printf("Current depth %d\n", SimCnt[SIMCUR_LEVEL]);
    printf("Look-ahead statistics since last update:\n");
    printf("  Unit propagations: %d\n", 
	   SimStat[SIMUNIT_NUM] - SimLapStat[SIMUNIT_NUM]);
    SimLapStat[SIMUNIT_NUM] = SimStat[SIMUNIT_NUM];
#ifdef PURE_LITERAL
    printf("  Pure literals: %d\n", 
	   SimStat[SIMPURE_NUM] - SimLapStat[SIMPURE_NUM]);
    SimLapStat[SIMPURE_NUM] = SimStat[SIMPURE_NUM];
#endif
    printf("  Failed literals: %d\n", 
	   SimStat[SIMFAILED_NUM] - SimLapStat[SIMFAILED_NUM]);
    SimLapStat[SIMFAILED_NUM] = SimStat[SIMFAILED_NUM];
    printf("Current path (choice points only):\n  ");
    SimDllPrintPath();
#ifdef LEARNING    
    printf("Clauses (open/total/learned): %d / %d / %d\n",
	   SimCnt[SIMCUR_CL_NUM], SimCnt[SIMCL_NUM], 
	   Vsize(SimLearned));
#else
    printf("Clauses (open/total): %d / %d \n",
	   SimCnt[SIMCUR_CL_NUM], SimCnt[SIMCL_NUM]);
#endif	   
    printf("Variables (open/total): %d / %d \n", 
	   Vsize(SimProps) -  Vsize(SimStack), Vsize(SimProps));
    printf("\n");
    SimLapStat[SIMNODE_NUM] = SimParam[SIM_RUN_TRACE];

  } else if (SimLapStat[SIMNODE_NUM] > 0) {
    
    /* Decrease the number of ticks remaining. */
    SimLapStat[SIMNODE_NUM] -= 1;

  }

  return;

} /* End of SimDllTraceNodes. */


/**Function********************************************************************

  Synopsis    [Tracing search leafs.]

  Description [Each time the function is called a counter is decremented.
               Once the number of ticks is reached, the functions outputs
               data on the look-back algorithms.]

  SideEffects [none]

  SeeAlso     []

******************************************************************************/
void SimDllTraceLeafs()
{

  if (SimLapStat[SIMFAIL_NUM] - 1 == 0) {

    /* If a given number of ticks elapsed, output statistics. */
    printf("Current depth %d\n", SimCnt[SIMCUR_LEVEL]);
    printf("Look-back statistics since last update:\n");
    printf("  Maximum depth in the search tree: %d\n", SimStat[SIMDEPTH_MAX]);
#ifdef BACKJUMPING
    printf("  Skipped nodes: %d\n", 
	   SimStat[SIMSKIP_NUM] - SimLapStat[SIMSKIP_NUM]);
    SimLapStat[SIMSKIP_NUM] = SimStat[SIMSKIP_NUM];
#endif
#ifdef LEARNING
    printf("  Unit on learned: %d\n", 
	   SimStat[SIMULEARN_NUM] - SimLapStat[SIMULEARN_NUM]);
    SimLapStat[SIMULEARN_NUM] = SimStat[SIMULEARN_NUM];
#endif
    printf("Current path (choice points only):\n  ");
    SimDllPrintPath();
#ifdef LEARNING    
    printf("Clauses (open/total/learned): %d / %d / %d\n",
	   SimCnt[SIMCUR_CL_NUM], SimCnt[SIMCL_NUM], 
	   Vsize(SimLearned));
#else
    printf("Clauses (open/total): %d / %d \n",
	   SimCnt[SIMCUR_CL_NUM], SimCnt[SIMCL_NUM]);
#endif	   
    printf("Variables (open/total): %d / %d \n", 
	   Vsize(SimProps) -  Vsize(SimStack), Vsize(SimProps));
    printf("\n");
    SimLapStat[SIMFAIL_NUM] = SimParam[SIM_RUN_TRACE];

  } else if (SimLapStat[SIMFAIL_NUM] > 0) {
    
    /* Decrease the number of ticks remaining. */
    SimLapStat[SIMFAIL_NUM] -= 1;

  }

  return;

} /* End of SimDllTraceLeafs. */


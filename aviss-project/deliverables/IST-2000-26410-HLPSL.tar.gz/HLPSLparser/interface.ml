(***********************************************************************)
(*                                                                     *)
(*                                 HLPSL                               *)
(*                                                                     *)
(*                     AVISS Project IST 2000-26410                    *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                              interface.ml                           *)
(*                                Loria                                *)
(*             formatting functions and definition of output           *)
(***********************************************************************)
open String;;
open Types;;
open Globals;;
open Utilities;;

(* ----------------
Local variables in module
---------------- *)
let xor_suffix = ref 0 ;;

(* ----------------
   pdb : string -> unit
   Enter: any chain of characters
   Role: print a chain of characters s
   ---------------- *)
let pdb s =
  print_endline s;
  flush stdout
;;
(* ----------------
   print_type_var: val: type_var -> unit
   Enter: type of variables
   Role: print the types
---------------- *)

let print_type_var = function
   User -> print_string "User"
 | FrSyKey -> print_string "Symmetric_Key"
 | SyKey -> print_string "Symmetric_Key"
 | FrPcKey(_) -> print_string "Public_Key"
 | PcKey(_) -> print_string "Public_Key"
 | FrPeKey(_) -> print_string "Private_Key"
 | PeKey(_) -> print_string "Private_Key"
 | Number -> print_string "Number"
 | Table -> print_string "Table"
 | Function -> print_string "Function"
 | PcTable(_,_,_) -> ()
 | PeTable(_,_,_) -> ()
;;

(* ----------------
   print_ident:val: int -> unit.
   Enter: identifier.
   Role: print an identifier given the list ident_list;
   ---------------- *)
let print_ident = function
   0 -> print_string "?"
 | i -> print_string (fst (List.assoc i !ident_list));
(*print_string("(");print_type_var(getIdentType(i));print_string(")");*)

;;


(* ----------------
   print_ident_list : unit -> unit
   Role: implementation of the option --ident in the command line.
   (print the main information concerning the identifiers)
---------------- *)
let print_ident_list ()=
  List.iter(fun x->
    print_string (fst(snd(x)) ^ ":");
    print_string ("\tN�: ");print_int(fst(x));print_newline();
    print_string ("\tType: ");print_type_var(snd(snd(x)));print_newline();
)!ident_list

;;


(* ----------------
   print_list:val: ('a -> unit) -> string -> 'a list -> unit .
   Role: print a list to help the funtion f by separating strings s
   ---------------- *)

let print_list f s =
   let rec print_list_f = function
      [] -> ()
    | [x] -> f x
    | x::(y::l as yl) -> f x; print_string s; print_list_f yl
   in
     print_list_f
;;


(* ----------------
   print_ident_knowledge:val: unit -> unit
   Role: print the list of the knowledges
   ---------------- *)
let print_ident_knowledge () =
   List.iter (fun (i,lj) ->
                 print_string "#  ";
                 print_ident i;
                 print_string " knows ";
                 print_list print_ident ", " lj;
                 print_newline ())
             !ident_knowledge
;;


(* ----------------
   string_of_msg: val string_of_msg : msg -> string
   Role: convert a message in a chain of characters.
   ---------------- *)
let string_of_msg =
   let rec string_of_msg inExpr = function
      Id(0) ->
        "?"
    | Id(i) -> 
         let strId = getIdentId i in
         if (contains strId '\'') 
              then 
                  concat strId ["prim"]
              else 
                  strId
    | Int(i) ->
        string_of_int i
    | Pair(t1,t2) ->
        string_of_msg false t1
        ^"_"^
        string_of_msg false t2
    | Func(0,t) ->
        "?("^
        string_of_msg false t^
        ")"
    | Func(i,t) ->
        (getIdentId i)^
        "_"^
        string_of_msg false t^
        "_"
    | Crypt(_,(Id(_) as i),t) ->
        "_"^
        string_of_msg false t^
        "_"^
        string_of_msg false i
    | Crypt(_,Int(i),t) ->
        "_"^
        string_of_msg false t^
        "_"^
        string_of_int i
    | Crypt(_,k,t) ->
        "_"^
        string_of_msg false t^
        "_"^
        string_of_msg false k^
        "_"
    | Arith(f,i1,i2) ->
        (
	  if inExpr
          then
            "("
	  else 
	    ""	
	)  
        ^string_of_msg true i1^
          (
	    match f
            with 
		1 ->   "+"
              | 2 ->   "-"
              | 3 ->   "*"
              | 4 ->   "/"
              | 5 ->   "%"
	      |	6 ->   "#"
              | _ ->   "^"
	  )
	  ^string_of_msg true i2^
        if inExpr
        then
          ")"
	else ""
 | Logic(f,i1,i2) ->
        (
	  if inExpr
          then
            "("
	  else 
	    ""	
	)  
        ^string_of_msg true i1^
          (
	    match f
            with 
		1 ->   "_Rcrypt_"
              | 2 ->   "_And_"
              | 3 ->   "_Or_"
              | 4 ->   "_Nand_"
              | _ ->   "_Nor_"
	  )
	  ^string_of_msg true i2^
        if inExpr
        then
          ")"
	else ""
   in
     string_of_msg false
;;

(* ----------------
   print_msg: val: msg -> unit
   Input: message
   ---------------- *)
let print_msg =
   let rec print_msg inExpr = function
      Id(0) ->
           print_string "?"
    | Id(i) ->
           print_ident i
    | Int(i) ->
           print_int i
    | Pair(t1,t2) ->
           print_msg false t1;
           print_string ",";
           print_msg false t2
    | Func(0,t) ->
           print_string "?(";
           print_msg false t;
           print_string ")"
    | Func(i,t) ->
           print_ident i;
           print_string "(";
           print_msg false t;
           print_string ")"
    | Crypt(_,(Id(_) as i),t) ->
           print_string "{";
           print_msg false t;
           print_string "}";
           print_msg false i
    | Crypt(_,Int(i),t) ->
           print_string "{";
           print_msg false t;
           print_string "}";
           print_int i
    | Crypt(_,k,t) ->
           print_string "{";
           print_msg false t;
           print_string "}(";
           print_msg false k;
           print_string ")"
    | Arith(f,i1,i2) ->
           if inExpr
             then
               print_string "(";
           print_msg true i1;
           (match f
            with 1 -> print_string "+"
               | 2 -> print_string "-"
               | 3 -> print_string "*"
               | 4 -> print_string "/"
               | 5 -> print_string "%"
	       | 6 -> print_string "#"
               | _ -> print_string "^");
           print_msg true i2;
           if inExpr
             then
               print_string ")"
  | Logic(f,i1,i2) ->
           if inExpr
             then
               print_string "(";
           print_msg true i1;
           ( match f
            with 1 -> print_string " - "
               | 2 -> print_string " and "
               | 3 -> print_string " or "
               | 4 -> print_string " nand "
               | _ -> print_string " nor ");
           print_msg true i2;
           if inExpr
             then
               print_string ")"
   in
     print_msg false
;;


(* ----------------
   print_msglist : unit -> unit
   Input:
   Output:
   Role:
   Use:
   Rem:
   ---------------- *)
let print_msglist () =
  List.iter (fun (no,((idFrom,idTo),msge)) ->
               print_string "#  ";
               print_int no;
               print_string ".  ";
               print_ident idFrom;
               print_string " -> ";
               print_ident idTo;
               print_string ":  ";
               print_msg msge;
               print_newline ())
    !msg_list
;;


(* ----------------
 val string_of_term_list : string -> term list -> string
 Role: convert a list of terms in a chain of characters
 Use: val string_of_term : term -> string
   ---------------- *)
let rec string_of_term_list s = function
      [] -> "error"
    | [t] -> string_of_term t
    | t::r -> (string_of_term t)^s^(string_of_term_list s r)


(* ----------------
 val string_of_term : term -> string
 Role: convert a term in a chain of characters
   ---------------- *)
and string_of_term = function
      Empty -> ""
    | Cons(s) -> s
    | Var(s) -> "x"^s
    | Op("mr",l) -> string_of_term_list "" l
    | Op(".",l) -> string_of_term_list "." l
    | Op(s,l) -> s^"("^(string_of_term_list "," l)^")"
;;

(* ----------------
 val print_term_dotlist :
 Role: allows one to print the terms in a list separated by a chain.(generally ".") 
 Rem: used in print_term
   ---------------- *)
let rec print_term_dotlist s = function
    [] -> (raise (Call "print_term"))
  | [t] -> print_term t;
  | t::r ->
       print_term t;
      (print_string s);
      (print_term_dotlist s r)


(* ----------------
   val print_term_arglist : string -> term list -> unit
   Role: used to print a list of terms in form of arguments (separation =",")
   ---------------- *)
and print_term_arglist s = function
    [] -> (raise (Call "print_term"))
  | [t] -> 
      print_term t

  | t::r -> 	
      (print_term t);
      (print_string s);
      (print_term_arglist s r)


(* ----------------
   val print_term : term -> unit
   Role: print of terms
   Use: val print_term_arglist : string -> term list -> unit
   val print_term_dotlist : string -> term list -> unit
   ---------------- *)
and print_term = function
    Empty -> (print_string "")
  | Cons(s) -> (print_string s)
  | Var(s) ->
      if (!flag_init=false or s = "Time") then (print_string "x");
      (print_string s);
  | Op("mr",[t]) -> if (!flag_para=true or !flag_init=true or !flag_goal=true) then (print_string("mr(");print_term t;print_string(")")) else print_term t;
  | Op(".",l) -> (print_term_dotlist "." l)
  | Op("prim",[t]) ->
      (print_term t);
      (print_string "'")
  | Op("prim",l) ->
      (raise (Call "print_term (case: prim)"))
(* print cipher in pk *)
  | Op("pk",[Cons(s)]) ->
      let newStr =ref (String.sub s 0 ((length s)-1)) in
      (print_string ("pk"^"(")) ;
      if (contains s '\'') then  (print_string (!newStr^")"))  else (print_string (s^")"));

(* print terms in xor *)
  | Op(s,[t;Op("rcrypt",[t1;t2])])->
      print_string ("c(" ^ s ^ "(");
      print_term t;
      print_string ",";
      print_term (Op("rcrypt",[t1;t2]));
      print_string (" - x" ^ (string_of_int !xor_suffix) ^ " - x" ^ (string_of_int !xor_suffix) ^ "),x" ^ (string_of_int !xor_suffix) ^")");
      incr(xor_suffix);

  | Op("rcrypt",[t1;t2]) ->
      print_term t1;
      print_string (" - ");
      print_term t2;

  | Op(s,l) ->
      (print_string s);
      (print_string "(");
      (print_term_arglist "," l);
      (print_string ")");
;;


(* ----------------
 val print_rule : rule -> unit
 Role: print a rewrite rule
 Use: val print_term : term -> unit
   ---------------- *)
let print_rule = function 
    (Rule(s,left,Empty)) ->
      print_endline s;
      print_term left
  | (Rule(s,Empty,right)) ->
      print_endline s;
      print_term right
  | (Rule(s,left,right)) ->
      print_endline s;
      print_term left;
      print_string "\n=>\n";
      print_term right
;;


(* ----------------
 print_para_rules
 Role: print the rules //
 Use:val print_term_dotlist : string ->term list -> unit
   ---------------- *)
let rec print_para_rules=function
    (h1,h2)::tail ->print_string("message(");
      print_term_dotlist "." h1 ;
      print_string(",");
      print_term_dotlist "." h2 ;
      print_endline(",ii)");
      print_para_rules tail;
  |_ -> print_newline();
      ;;

(* ----------------
   print_knowledge:val: unit -> unit
   Role: print the list of the knowledges
   ---------------- *)
let print_knowledge step =
   List.iter (fun (u,l1) ->
     List.iter ( fun (i,l2)-> 
                 print_string "\n#  ";
                 print_ident u; print_string " knows at step ";print_int(i);print_string(" ");
       List.iter( fun (msg,b)->
	 print_msg (msg);print_string(",");
		 )(List.rev l2);
		)(List.rev l1);
print_newline();
	     )(List.rev !knowledge);
;;

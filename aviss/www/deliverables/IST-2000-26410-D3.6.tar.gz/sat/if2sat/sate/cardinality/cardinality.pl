:- use_module(library(lists)).
:- ensure_loaded('../../sate/state.pl').
:- ensure_loaded('../../sate/operators.pl').
:- ensure_loaded('../../sate/instantiators.pl').
:- ensure_loaded('../../sate/newload.pl').
:- ensure_loaded('../../config.pl').
:- retractall(sort_cardinality(_,_)).

:- dynamic sort_cardinality/2,
	   action_counter/1.

:- set(term_depth_bound,7).

write_cardinalities(F_IN) :-
	load_problems_file(F_IN),
	cardinalities(Cs),
	format("\n%%% Cardinalities:\n\n",[]),	
	write_list(Cs),
	retractall(sort(_)),
	retractall(super_sort(_)),
	retractall(constant(_,_)),
	retractall(invariants(_)),
	retractall(static(_)),
	retractall(monotone(_)),
	retractall(facts(_)),
	retractall(action(_,_,_,_,_)),
	retractall(goal(_)),
	retractall(sort_cardinality(_,_)),
	retractall(action_counter(_)).

write_list([]).
write_list([S-C|Cs]) :-
	format("~p : ~p\n",[S,C]),
	write_list(Cs).

cardinalities(Cs) :-
	findall(S,sort(S),Ss),
	cardinalities(Ss,Cs).

cardinalities([],[]).
cardinalities([S|Ss],[S-Tot|Cs]) :-
	sort_cardinality(S,Tot,[]),
	cardinalities(Ss,Cs).

	
% sort_cardinality(time,Tot) :-
% 	set(term_depth_bound,Tot),!.

% sort_cardinality(session,Tot) :-
%  	findall(C,
% 	        (
% 		    constant(C,session),
% 		    (atom(C);number(C))
% 		),
% 		Cs),
% 	same_length(Cs,Cs,N),
% 	set(term_depth_bound,D),
% 	Tot is N * D,!.

sorts_cardinality_sum([],Tot,Tot,_).
sorts_cardinality_sum([S|Ss],Curr,Tot,Fs) :-
	sort_cardinality(S,TMP,Fs), Next is Curr + TMP,
	sorts_cardinality_sum(Ss,Next,Tot,Fs).

sorts_cardinality_multiply(_,0,0,_) :- !.
sorts_cardinality_multiply([],Tot,Tot,_).
sorts_cardinality_multiply([S|Ss],Curr,Tot,Fs) :-
	sort_cardinality(S,TMP,Fs),
	Next is Curr * TMP,
	sorts_cardinality_multiply(Ss,Next,Tot,Fs).

sort_cardinality(S,Tot,_) :-
	sort_cardinality(S,Tot),!.
sort_cardinality(action,Tot,_) :-
	!,
	findall(Act,constant(Act,action),Acts),
	constant_cardinality_actions(Acts,Tot),
	assert(sort_cardinality(action,Tot)).
sort_cardinality(S,Tot,Fs) :-
	\+sort_cardinality(S,_),
	(member(S,Fs) ->
	    format("Ricorsione su: ~p.\nTrace: ~p\n\n",[S,[S|Fs]]),
	    halt
	;
	    true
	),
 	findall(C,constant(C,S),Cs),
	constants_cardinality_sum(Cs,0,TMP1,[S|Fs]),
 	findall(SubS,super_sort(S,SubS),SubSs),
	sorts_cardinality_sum(SubSs,0,TMP2,[S|Fs]),
	Tot is TMP1 + TMP2,
	assert(sort_cardinality(S,Tot)),
	!.

constant_cardinality_actions([],0).
constant_cardinality_actions([Act|Acts],Tot) :-
	assert(action_counter(0)),
	constant_cardinality_action(Act),
	retract(action_counter(Tot1)),
	format("~4|~w : ~w\n",[Act,Tot1]),	
	constant_cardinality_actions(Acts,Tot2),
	Tot is Tot1 + Tot2.

constant_cardinality_action(OpConst) :-
	functor(OpConst,OpName,Arity),
	functor(Op,OpName,Arity),
	predicate(action,Op),
	action(Op,C,Pre,Add,Del),
	call(C),
	append(Pre,Add,TmpList),
	append(TmpList,Del,List),
	check_action_fluents(List),
%	format("~8|~w\n",[Op]),	
	retract(action_counter(N)),
	M is N + 1,
	assert(action_counter(M)),
	fail.
constant_cardinality_action(_).

check_action_fluents([]).
check_action_fluents([F|Fs]) :-
	predicate(fluent,F),!,
	check_action_fluents(Fs).

constants_cardinality_sum([],Tot,Tot,_).
constants_cardinality_sum([C|Cs],Curr,Tot,Fs) :-
	constant_cardinality(C,TMP,Fs),
	format("~4|~w : ~w\n",[C,TMP]),	
	Next is Curr + TMP,
	constants_cardinality_sum(Cs,Next,Tot,Fs).

constant_cardinality(C,1,_) :-
	atom(C),!.
constant_cardinality(C,Tot,Fathers) :-
	\+atom(C),
	check_invariants(C,INVs),
	C=..[_|Ss],
	(INVs == [] ->
	    sorts_cardinality_multiply(Ss,1,Tot,Fathers)
	;
	    sorts_cardinality_multiply(Ss,1,Tot1,Fathers),
	    !,
	    rewrite_wrt_invariants(C,Tot2,INVs),
	    Tot is Tot1 - Tot2
	).

% constant_cardinality(C,Tot,Fathers) :-
% 	\+atom(C),
% 	check_invariants(C,INVs),
% 	C=..[_|Ss],
% 	sorts_cardinality_multiply(Ss,1,Tot1,Fathers),
% 	rewrite_wrt_invariants(C,Tot2,INVs),
% 	Tot is Tot1 - Tot2.
% %	constant_cardinality_wrt_invs(C,Tot,Fathers,INVs).

% % Useful to check invariants rewriting
% rewrite_wrt_invariants(C,Tot,INVs) :-
% 	C=..[F|Ss],
% 	findall(GC-RW,
% 		(	
% 		    tuple(Ss,Ts),
% 		    GC=..[F|Ts],
% 		    (rewrite_wrt_invariants(GC,INVs) ->
% 			RW = true;
% 			RW = false
% 		    )
% 		),
% 		TMPs),
% 	findall(GC,
% 	        member(GC-true,TMPs),
% 		GCs),
% 	same_length(GCs,GCs,Tot).

rewrite_wrt_invariants(C,Tot,INVs) :-
	C=..[F|Ss],
	findall(GC,
		(	
		    tuple(Ss,Ts),
		    GC=..[F|Ts],
		    rewrite_wrt_invariants(GC,INVs)
		),
		GCs),
%	remove_duplicates(TMPGCs,GCs),
	same_length(GCs,GCs,Tot).

rewrite_wrt_invariants(GC,INVs) :-
	member(GC,INVs).
rewrite_wrt_invariants(GC,INVs) :-
	member(~GC,INVs).

% invariants_satisfaction(_,[]).
% invariants_satisfaction(GC,[INV|INVs]) :-
% 	invariant_satisfaction(GC,INV),
% 	!,
% 	invariants_satisfaction(GC,INVs).

% invariant_satisfaction(GC,INV) :-
% 	INV=..[~,NOTINV],
% 	!,
% 	NOTINV\=GC.
% invariant_satisfaction(GC,INV) :-
% 	\+INV=..[~|_],
% 	!,
% 	INV=GC.

% constant_cardinality_wrt_inv(C,Tot,_,INV) :-
% 	INV=..[~,NOTINV],
% 	C=..[F|Ss],
% 	findall(GC,
% 		(	
% 		    tuple(Ss,Ts),
% 		    GC=..[F|Ts],
% 		    NOTINV\=GC
% %		    write(GC),nl
% 		),
% 		GCs),
% 	write(GCs),nl,
% 	same_length(GCs,GCs,Tot).

% constant_cardinality_wrt_inv(C,Tot,_,INV) :- \+INV=..[~|_],
% 	C=..[F|Ss], findall(GC, ( tuple(Ss,Ts), GC=..[F|Ts], INV=GC ),
% 	GCs), write(GCs),nl, same_length(GCs,GCs,Tot).


check_invariants(C,INVs) :-
	findall(INV,
	        (
		    invariant(INV),
		    check_invariant1(INV,C)
		),
		INVs).
	
check_invariant1((~INV),C) :-
	!,
	check_invariant1(INV,C).
check_invariant1(INV,C) :-
	INV=..[OP,INV1,INV2],
	op(_,_,OP),
	!,
	(
	    check_invariant1(INV1,C);
	    check_invariant1(INV2,C)
	).
check_invariant1(INV,C) :-
	C=..[F|CSs],
	INV=..[F|ISs],
	same_length(CSs,ISs,_).


predicate_complete(S,P) :-
	predicate(S,P).

predicate_complete(S,P) :-
	super_sort(S,SubS),
	predicate_complete(SubS,P).

prova_cardinality :-
	predicate(fluent,i(K)),
	write(i(K)),
	nl,
	fail.
prova_cardinality.
:- use_module(library(lists)).
:- use_module(library(system)).
:- use_module(library(charsio)).

:- ensure_loaded('../sate/state.pl').

:- ensure_loaded('../config.pl').

% if2sate(Pb) :-
%      This predicate translates the IF problem Pb 
%      (name of the file without extention) into the 
%      equivalent SATE problem
if2sate(Pb) :-
	set_prolog_flag(redefine_warnings,off),
	% IF2PIF
	ensure_loaded('if2sate/if2pif/if2pif.pl'),
	value(problems_dir,PBsDIR),	
	format_to_chars('~w/~w.if',[PBsDIR,Pb],CF_IF),
	format_to_chars('~w/~w.pif',[PBsDIR,Pb],CF_PIF),
	atom_chars(F_IF,CF_IF),
	atom_chars(F_PIF,CF_PIF),
	if2pif(F_IF,F_PIF),
        format("~n~nFile ~p.pif generated...~n~n",[Pb]),
	% PIF2SATE
	ensure_loaded('if2sate/pif2sate/pif2sate.pl'),
	format_to_chars('~w/~w.sate',[PBsDIR,Pb],CF_SATE),
	atom_chars(F_SATE,CF_SATE),
	pif2sate(F_PIF,F_SATE),
        format("~n~nFile ~p.sate generated...~n~n",[Pb]),
	set_prolog_flag(redefine_warnings,on),
	halt.




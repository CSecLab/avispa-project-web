:- use_module(library(ordsets)).

solver_invocation_command(sato,FN_DIMACS,LOGFILE,CHARS) :-
	value(sato_executable,SOLVER_PATH),
	format_to_chars('~w ~w > ~w',[SOLVER_PATH,FN_DIMACS,LOGFILE],CHARS).
solver_invocation_command(chaff,FN_DIMACS,LOGFILE,CHARS) :-
	value(chaff_executable,SOLVER_PATH),
	value(chaff_configfile,SOLVER_CONFIGFILE),
	format_to_chars('~w ~w ~w ~w > /dev/null',
			[SOLVER_PATH,FN_DIMACS,LOGFILE,SOLVER_CONFIGFILE],CHARS).

print_output :-
	parse_log(Ans,Time),
	( Ans=unsat ->
	    format('\nNo plan found in ~w sec\n\n',[Time]),
	    ( value(sound,on) ->
		system('play sound/fail.wav') ;
		true ) ;
	    format('\nPlan found in ~w sec:\n\n',[Time]),
	    print_models(Ans),
	    (value(sound,on) ->
		system('play sound/success.wav') ;
		true )).

atomof(N,T) :-
	numof(A,N),
	atom_codes(A,Cs),
	append(Cs,".",CsDot),
	read_from_chars(CsDot,T).

print_models([]).
print_models([Ns|Ms]) :-
	setof(A,N^(member(N,Ns), atomof(N,A)),As),
	print_model(As),
	print_models(Ms).

print_model(As) :-
	value(time,I),
	setof(S,(member(I:S,As), predicate(fluent,S)),Ss),
	format('~w \n',[Ss]),
	value(steps,Steps),
	( I<Steps -> print_action(I,As) ),
	fail.
print_model(_).

print_action(I,As) :-
	setof(S,(member(I:S,As), predicate(action,S)),Ss), !,
	format('\nStep ~w: ~w\n\n',[I,Ss]).
print_action(I,_) :-
	format('\nStep ~w: ~w\n\n',[I,null]).

parse_log(Ans,Time) :-
	file_name(log,LOGFILE),
	see(LOGFILE),
	read2string(Cs),
	seen,
	value(solver,Solver),
	parse_log(Solver,Cs,Ans,Time).

read2string(Cs) :-
	get_code(C),
	( C== -1 ->
	    Cs=[] ;
	    Cs=[C|Cs1],
	    read2string(Cs1) ).

% user:portray(Cs) :- codes(Cs), atom_codes(A,Cs), format('"~w"',[A]).

codes([]).
codes([C|Cs]) :- number(C), codes(Cs).

parse_log(sato,Cs,Ans,Time) :- sato_log(Ans,Time,Cs,[]).
parse_log(chaff,Cs,Ans,Time) :- chaff_log(Ans,Time,Cs,[]).

sato_log(Ans,Time) --> sato_preamble, sato_rest(Ans,Time).
sato_preamble --> lines(10).
lines(1) --> line, !.
lines(N) --> line, {N1 is N-1}, lines(N1).
line --> [C], {C=\="\n"}, !, line.
line --> "\n".
sato_rest(unsat,Time) -->
	"The clause set is unsatisfiable.\n",
	sato_failure_postamble(Time).
sato_rest([Ns],Time) -->
	"Model #1: (indices of true atoms)\n",
	sep0, sato_model(Ns), sep0,
	"The number of found models is 1.\n",
	sato_success_postamble(Time).

sato_model([N|Ns]) --> number(N), sep0, sato_model(Ns), !.
sato_model([N]) --> number(N).

sato_failure_postamble(Time) -->
	lines(4),
	"run time (seconds)", sep0,
	number(Time),
	lines(6).
sato_success_postamble(Time) -->
	lines(7), 
	"run time (seconds)", sep0,
	number(Time),
	lines(6).

% CHAFF
chaff_log(unsat,Time) -->
	"unsat", sep,
	chaff_postamble(Time).
chaff_log([Ns],Time) -->
	"\"[", chaff_model(Ns), "]\"", sep,
	chaff_postamble(Time).

chaff_postamble(Time) -->
	string, sep,
	"\"", float(Time), "\"", sep,
	number(_), sep,
	number(_), sep0.

%Parsing clauses
chaff_model(Ns) --> chaff_model(Ns,1).
chaff_model(Ns,N) --> "0", {N1 is N+1}, chaff_model(Ns,N1).
chaff_model([N|Ns],N) --> "1", {N1 is N+1}, chaff_model(Ns,N1).
chaff_model([],_) --> [].

float(F) --> signed_number(M), "e", !, signed_number(E), {F is M*(10**E)}.
float(F) --> signed_number(F).

integer(N1) --> "-", !, pnat(N), {N1 is -N}.
integer(N) --> "+", !, pnat(N).
integer(N) --> pnat(N).

signed_number(N1) --> "-", !, number(N), {N1 is -N}.
signed_number(N) --> "+", !, number(N).
signed_number(N) --> number(N).

pnat(N) --> digit(C), digit_multi(Cs), !, {number_codes(N,[C|Cs])}.
pnat(N) --> digit(C), {number_codes(N,[C])}. 

number(N) --> digit_or_dot(C), digit_or_dot_multi(Cs), !, {number_codes(N,[C|Cs])}.
number(N) --> digit_or_dot(C), {number_codes(N,[C])}. 

digit(C) --> [C], {("0"=<C, C=<"9")}.

digit_multi([C|Cs]) --> digit(C), digit_multi(Cs), !.
digit_multi([C]) --> digit(C).
	
digit_or_dot(C) --> [C], {[C]="."}.
digit_or_dot(C) --> digit(C).

digit_or_dot_multi([C|Cs]) --> digit_or_dot(C), digit_or_dot_multi(Cs), !.
digit_or_dot_multi([C]) --> digit_or_dot(C).

sep0 --> sep.
sep0 --> [].

sep --> sep_char, sep, !.
sep --> sep_char.

sep_char --> " ".
sep_char --> "\n".
sep_char --> "\t".

string --> "\"", char_multi, "\"".
char_multi --> [C], {\+[C]="\""}, char_multi, !.
char_multi --> [].


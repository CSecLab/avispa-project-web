/***************************************************
 *
 *  TYPE Declaration
 *
 ***************************************************/

struct trie { /* trie of clauses */
  char psign, esign; 
  short key;
  struct trie *bro;
  struct trie *pos, *neg;
  struct trie *par;
  struct links *link;
};

struct links {
  struct trie *lin;
  struct trie *back;
  struct cap *stamp;
};

struct cap { 
  struct trie *tr;
};

struct var3 { 
  int key;
  struct trie *push, *pull;
  struct trie **pos, **neg;
  struct cap *both, *poss, *negs;
  struct cap *pposs, *pnegs;
  struct var3 *next;
};

struct var2 { 
  short key;
  short pos_extra;
  short neg_extra;
  short level;
  short pos2;
  short neg2;
  int pure;
  int pos_count;
  int neg_count;
  struct trie *frozen, *force;
  struct trie **pos, **neg;
  struct var2 *next;
};

/**********************
  MACROS
***********************/
#define HAS_POS_CL(no) (no->pos == CLAUSE3)
#define HAS_NEG_CL(no) (no->neg == CLAUSE3)

#define trie2_propagate(a,b,c) \
  ((b)? trie2_propagate_true(a,c) : trie2_propagate_false(a,c))

#define count_of_clause(cl) cl->key
#define active_clause(cl) cl->neg == NULL
#define frozen_lin(cl) cl->neg

#define binary_lin(cl) cl->pos
#define unit_lin(cl) cl->link->back

#define level_of(it) it->level
#define mark_of(it) it->force
#define frozen_cls(it) it->frozen

#define free_trie_cell(no) \
  if (no->key == -1) { \
     printf("re-free a cell\n"); bug(4);\
  } else { no->key = -1; \
    no->bro = Trie_avail; \
    Trie_avail = no;\
    Trie_avails++; \
  }\
  Trie_frees++
	 
/**********************
  VARIABLES
***********************/

long unsigned Trie_frees, Trie_avails, Trie_gets, Trie_news;
struct trie *Trie_avail;

struct trie *CLAUSE3;
struct trie *Root3;
struct trie *NHtrie;
struct trie *CLtrie;

struct var3 **V3;
struct var3 *Top_var3;

struct var2 **V2;
struct var2 *Top_var2;

struct trie **Trie2_Ucl;
int Trie2_Ucl_idx;

/* memory of variables in this file: 8x4+4x11 = 76 bytes */


/* Following use of TRIE_PUSH_BROTHERS is identical to trie_push_brothers(top_no). 
   struct trie *tr = top_no;
   TRIE_PUSH_BROTHERS
*/
#define TRIE_PUSH_BROTHERS \
  struct trie *bros[MAX_SHORT];\
  struct trie *no;\
  int i;\
  int esign;\
  int vi;\
  int idx;\
  struct var3 *it;\
  idx = 1;\
  bros[0] = tr;\
  while (idx > 0) {\
    tr = bros[--idx];\
    while (tr != NULL) {\
      no = tr;\
      i = no->key;\
      esign = no->esign;\
      vi = Value[i];\
      it = V3[i];\
      if (esign == TT) {\
	if (vi == DC) {\
	  trie_assign_value(i, TT);\
	} else if (vi == FF) {\
	  return handle_fail_end();\
	}\
	if (tr->bro != NULL) bros[idx++] = tr->bro;\
	tr = no->neg;\
      } else if (esign == FF) {\
	if (vi == DC) {\
	  trie_assign_value(i, FF);\
	} else if (vi == TT) {\
	  return handle_fail_end();\
	}\
	if (tr->bro != NULL) bros[idx++] = tr->bro;\
	tr = no->pos;\
      } else { /* esign == DC */ \
	if (vi == TT) {\
	  if (tr->bro != NULL) bros[idx++] = tr->bro;\
	  tr = no->neg;\
	} else if (vi == FF) {\
	  if (tr->bro != NULL) bros[idx++] = tr->bro;\
	  tr = no->pos;\
	} else {  /* vi == DC */ \
	  struct cap *cp;\
	  if (no->neg == NULL) {\
	    if (no->pos != NULL) {\
	      cp = it->poss;\
	      no->link->lin = cp->tr;\
	      cp->tr = no;\
	      if (Backup_idx) {\
		no->link->stamp = cp;\
		no->link->back = Top_var3->push;\
		Top_var3->push = no;\
	      }\
	    }\
	  } else if (no->pos == NULL) {\
	    cp = it->negs;\
	    no->link->lin = cp->tr;\
	    cp->tr = no;\
	    if (Backup_idx) {\
	      no->link->stamp = cp;\
	      no->link->back = Top_var3->push;\
	      Top_var3->push = no;\
	    }\
	  } else {\
	    cp = it->both;\
	    no->link->lin = cp->tr;\
	    cp->tr = no;\
	    if (Backup_idx) {\
	      no->link->stamp = cp;\
	      no->link->back = Top_var3->push;\
	      Top_var3->push = no;\
	    }\
	  }\
	  tr = tr->bro;\
	}\
      }\
    }\
  }

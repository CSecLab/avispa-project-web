#!/bin/bash

#
# A bash script to run a backend on a selected
# problem. This script is supposed to be invoked from within
# run_tests_AVISPA, but it can also probably stand on its own legs.
#
# Only requirement is: ALL and ONLY the meaningful output of this
# very script must go to the standard output (NOT to stderr!!), as
# it will be so gathered by run_tests_AVISPA. If you do not respect
# this requirement, run_tests_AVISPA might produce unexpected results.
#
# Parameters:
# <backend>.csh <problem filename> <time limit in secs> <memory limit in kbs>
#
# Claudio Castellini,
# November 2003
#

# set timeout
ulimit -t $2

# set memoryout (on virtual memory)
ulimit -v $3

# start tool on required problem
pushd /home/friends/drwho/work/AVISPA/AVISPA-FET-EU-02/unige/src/satmc >/dev/null
satmc $1
popd >/dev/null

#!/ee/bin/perl 

$wamt = 100;

if ( @ARGV > 0) {

  $wamt = $ARGV[0];
}

$foo = <STDIN>;
while ( <STDIN> ) {
  ($var, $foo) = split();  
  print( "$var $wamt -$var $wamt\n" );
}


(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* interfacing with stdout *)
open String;;
open Types;;
open Globals;;
open Utilities;;

let pdb messageToPrint =
  print_endline messageToPrint;
  flush Pervasives.stdout
;;

let print_type_var = function
   User -> print_string "User"
 | FrSyKey -> print_string "Symmetric_Key"
 | SyKey -> print_string "Symmetric_Key"
 | FrPcKey(_) -> print_string "Public_Key"
 | PcKey(_) -> print_string "Public_Key"
 | FrPeKey(_) -> print_string "Private_Key"
 | PeKey(_) -> print_string "Private_Key"
 | Number -> print_string "Number"
 | Table -> print_string "Table"
 | Function -> print_string "Function"
;;

let print_ident = function
   0 -> print_string "?"
 | identifierNumber -> print_string (fst (List.assoc identifierNumber !Globals.ident_list));
;;

let print_ident_list ()=
  List.iter(fun identifierNumber->
    print_string (fst(snd(identifierNumber)) ^ ":");
    print_string ("\tN�: ");print_int(fst(identifierNumber));print_newline();
    print_string ("\tType: ");print_type_var(snd(snd(identifierNumber)));print_newline();
)!Globals.ident_list
;;

let rec print_list printFunction separator =function
      [] -> ()
    | [head] -> printFunction head
    | head::tail -> printFunction head; print_string separator; print_list printFunction separator tail
;;

let print_init_knowledge () =
   List.iter (fun (userNumber,knownIdentifierList) ->
                 print_string "##  ";
                 print_ident userNumber;
                 print_string " knows ";
                 print_list print_ident ", " knownIdentifierList;
                 print_newline ())
             !Globals.ident_knowledge
;;

let rec string_of_term term =
  let alter t = 
    if (String.contains t '\'') then
      let i = (String.index t '\'') in
      let tprim =(String.sub t 0 ((String.length t) -1) ) in
	tprim
    else
      t
  in
  let rec string_of_term_list termlist op =
    match termlist with
	[] -> ""
      | [term] -> (string_of_term term)
      | term::tail -> (string_of_term term)^op^(string_of_term_list tail op)
  in
    match term with
	Empty -> ""
      | Var(t) -> "VAR"^(alter t)
      | Cons(t) -> "c"^(alter t)
      | Op(s,l) ->
	  s^"LB"^(
	    match s with
		"." -> (string_of_term_list l "DOT")
	      | _ -> (string_of_term_list l "CM")
	  )^"RB"
;;

let string_of_msg mesg =
  let term = (Utilities.to_term mesg) in
    "_ct_"^(string_of_term term);;
(*
let string_of_msg =
   let rec string_of_msg isInfixed = function
      Id(0) ->
        "?"
    | Id(identifierNumber) ->
         let identifierName = Utilities.get_identifier_name identifierNumber in
         if (contains identifierName '\'')
              then
                  (String.sub identifierName 0 ((length identifierName)-1))^"_prim"
              else
                  identifierName
    | Int(number) ->
        string_of_int number
    | Pair(messagePart1,messagePart2) ->
        string_of_msg false messagePart1
        ^(!underscore)^
        string_of_msg false messagePart2
    | Func(0,functionParameter) ->
        "?("^
        string_of_msg false functionParameter^
        ")"
    | Func(functionNumber,functionParameter) ->
        (Utilities.get_identifier_name functionNumber)^
        (!underscore)^
        string_of_msg false functionParameter
   | TableElement(tableNumber,tableUser,isPrivate) ->
        (Utilities.get_identifier_name tableNumber)^
        (!underscore)^
        string_of_msg false (Id(tableUser)) ^
       (if (isPrivate) then (!underscore)^"prim" else "")
    | Crypt(_,(Id(_) as keyIdentifier),cryptedMessage) ->
           (!underscore)^
        string_of_msg false cryptedMessage^
        (!underscore)^
        string_of_msg false keyIdentifier
    | Crypt(_,keyIdentifier,cryptedMessage) ->
        (!underscore)^
        string_of_msg false cryptedMessage^
        (!underscore)^
        string_of_msg false keyIdentifier
    | Arith(operator,operand1,operand2) ->
        (
	  if isInfixed
          then
            "("
	  else 
	    ""	
	)  
        ^string_of_msg true operand1^
          (
	    match operator
            with 
		1 ->   "+"
              | 2 ->   "-"
              | 3 ->   "*"
              | 4 ->   "/"
              | 5 ->   "%"
	      |	6 ->   "#"
              | _ ->   "^"
	  )
	  ^string_of_msg true operand2^
        if isInfixed
        then
          ")"
	else ""
 | Logic(operator,operand1,operand2) ->
        (
	  if isInfixed
          then
            "("
	  else
	    ""
	)
        ^string_of_msg true operand1^
          (
	    match operator
            with 
		1 ->   "_Rcrypt_"
              | 2 ->   "_And_"
              | 3 ->   "_Or_"
              | 4 ->   "_Nand_"
              | _ ->   "_Nor_"
	  )
	  ^string_of_msg true operand2^
        if isInfixed
        then
          ")"
	else ""
   in
     string_of_msg false
;;
*)

let print_msg =
   let rec print_msg inExpr = function
      Id(0) ->
           print_string "?"
    | Id(identifierNumber) ->
           print_ident identifierNumber
    | Int(number) ->
           print_int number
    | Pair(messagePart1,messagePart2) ->
           print_msg false messagePart1;
           print_string ",";
           print_msg false messagePart2
    | Func(0,functionParameter) ->
           print_string "?(";
           print_msg false functionParameter;
           print_string ")"
  | Func(functionNumber,functionParameter) ->
           print_ident functionNumber;
           print_string "(";
           print_msg false functionParameter;
           print_string ")"
    | TableElement(tableNumber,tableUser,isPrivate) ->
           print_ident tableNumber;
           print_string "(";
           print_ident tableUser;
           print_string ")";
	   if (isPrivate) then print_string ("'")
    | Crypt(_,(Id(_) as keyIdentifier),cryptedMessage) ->
           print_string "{";
           print_msg false cryptedMessage;
           print_string "}";
           print_msg false keyIdentifier
    | Crypt(_,keyIdentifier,cryptedMessage) ->
           print_string "{";
           print_msg false cryptedMessage;
           print_string "}(";
           print_msg false keyIdentifier;
           print_string ")"
    | Arith(operator,operand1,operand2) ->
           if inExpr
             then
               print_string "(";
           print_msg true operand1;
           (match operator
            with 1 -> print_string "+"
               | 2 -> print_string "-"
               | 3 -> print_string "*"
               | 4 -> print_string "/"
               | 5 -> print_string "%"
	       | 6 -> print_string "#"
               | _ -> print_string "^");
           print_msg true operand2;
           if inExpr
             then
               print_string ")"
  | Logic(operator,operand1,operand2) ->
           if inExpr
             then
               print_string "(";
           print_msg true operand1;
           ( match operator
            with 1 -> print_string " - "
               | 2 -> print_string " and "
               | 3 -> print_string " or "
               | 4 -> print_string " nand "
               | _ -> print_string " nor ");
           print_msg true operand2;
           if inExpr
             then
               print_string ")"
   in
     print_msg false
;;
let print_msglist () =
  List.iter (fun (messageNumber,((senderIdentifier,receiverIdentifier),message)) ->
               print_string "##  ";
               print_int messageNumber;
               print_string ".  ";
               print_ident senderIdentifier;
               print_string " -> ";
               print_ident receiverIdentifier;
               print_string ":  ";
               print_msg message;
               print_newline ())
  !Globals.msg_list
;;
let print_translation = function
      ("prim") ->
	if (!Globals.print_for_prolog) then
	  ("inv")
	else
	  ("'")
    | ("v") -> ("i")
    | ("j") -> ("i")
    | ("I") -> 
	if (!Globals.print_for_prolog) then
	  ("intruder")
	else
	  ("I")	  
    | a_string -> 
	if not((String.get a_string ((String.length a_string) -1)) = '\'') then
	  (a_string)
	else 
	  (String.sub a_string 0 ((String.length a_string)-1))
;;

let var_prefix () =
  if (!Globals.print_for_prolog) then
    ("X")
  else
    ("x")
;;

let cons_prefix () =
    if (!Globals.print_for_prolog) then
    ("cons")
  else
    ("")
;;

let rec print_term_list separator = function
    [] -> ErrorHandler.printExceptionMessage (Failure "print_term") "Interface" "print_term_list";raise (Failure "print_term")
  | [head] -> print_term head;
  | [head;Empty] ->
      print_term head
  | Empty::tail ->
      (print_term_list separator tail)
  | head::tail ->
       print_term head;
      (print_string separator);
      (print_term_list separator tail)

and print_term = function
    Empty -> ()
  | Cons(consValue) -> 
      if (consValue = "true") then
   	(print_string consValue)
      else
      	(print_string ((cons_prefix ())^(print_translation consValue)))
  | Var(varValue) -> 
      (print_string ((var_prefix ())^(print_translation varValue)))
  | Op(".",termList) -> (print_term_list "." termList)
  | Op("prim",termlist) -> 
      begin
	match termlist with
	    [Op("prim",termlist2)] -> print_term_list "," termlist2 
	  | _ -> (print_term_list "," termlist; print_string (print_translation "prim"))
      end
  | Op(operator,termlist) ->
      match termlist with
	  [Var(name)] ->
	    if not (!Globals.flag_typed) then
	      begin
		match operator with
		    "mr" -> (print_term (Var(name)))
		  | "nonce" -> (print_term (Var(name)))
		  | "sk" -> (print_term (Var(name)))
		  | "pk" -> (print_term (Var(name)))
		  | "table" -> (print_term (Var(name)))
		  | "fu" -> (print_term (Var(name)))
		  | _ -> (
		      print_string ((print_translation operator)^"(");
	    	      print_term (Var(name));
		      print_string ")"
		    )
	      end
	    else
	      (
		print_string ((print_translation operator)^"(");
	    	print_term (Var(name));
		print_string ")"
	      );
	| _ ->
	    (
	      print_string ((print_translation operator)^"(");
	      print_term_list "," termlist;
	      print_string ")"
	    )
;;



let print_rule = function 
    (Rule(label,left,Empty)) ->
      print_endline label;
      print_term left
  | (Rule(label,Empty,right)) ->
      print_endline label;
      print_term right
  | (Rule(label,left,right)) ->
      print_endline label;
      print_term left;
      print_string "\n=>\n";
      print_term right
;;

let rec print_para_term_list = function 
    []-> ignore();
  | [head]-> print_term head
  | head::tail ->  print_string "(";print_term head;print_string ",";print_para_term_list tail; print_string ")"
;;



let use_datalog_solver rulesList =  
  let parallel_rule_list = ref ([] : rule list) in
    if (rulesList<> []) then 
      ( 
      	flush stdout;
      	let fd= Unix.openfile "datalog.input" [Unix.O_CREAT;Unix.O_RDWR;Unix.O_TRUNC] 999 in
      	let old_stdout= Unix.dup Unix.stdout in
      	let datalogInput = Unix.stdout in
      	  Unix.dup2 fd datalogInput;
      	  print_string "initialization([";(*print_para_term_list rulesList;*)
	  print_for_prolog := true;
      	    List.iter 
	      ( fun ruleTerm ->  
		  if not((List.hd rulesList)==ruleTerm ) then print_string "," ;
		  match ruleTerm with
		      Op ("datalogrule",termList)-> print_string "datalogrule";print_para_term_list termList;
		    |_ ->ignore();
			 print_term ruleTerm;
	      )
	      rulesList;
	    print_for_prolog := false;
      	      print_string "]).\ndatalog.";
      	      flush stdout;
      	      Unix.dup2 old_stdout datalogInput;
      	      Unix.close fd;
      	      let fd= Unix.openfile "datalog.output" [Unix.O_CREAT;Unix.O_RDWR;Unix.O_TRUNC] 999 in
      	      let datalogOutput = Unix.stdout in
	  	Unix.dup2 fd datalogOutput;
	  	let status=Unix.system "cat datalog.input | ./datalog" in
		  Unix.dup2 old_stdout datalogOutput;
		  Unix.close fd;
		  let fd= Unix.openfile "datalog.output" [Unix.O_RDWR] 999 in
		    Unix.dup2 fd Unix.stdin;
		    (* skipping gnu prolog comments *)
		    ignore(read_line ());
		    ignore(read_line ());
		    ignore(read_line ());
		    ignore(read_line ());
		    ignore(read_line ());
		    let rulesCounter = ref 1 in
		    let s= ref "=" in
	  	      while (String.contains (!s) '=') do
		  	try(
			  s:=read_line();
			  if (String.contains (!s) '=') then 
			    let rule_name = "\n\n# lb=para_"^(string_of_int !rulesCounter)^", type=Parallel" in
		      	      parallel_rule_list := [(Utilities.polish_form_parser !s rule_name)]@(!parallel_rule_list);
		      	      incr(rulesCounter)
		  	)
		  	with End_of_file -> (s := "");
	  	      done;
	  	      Unix.close fd;
    	    );
      !parallel_rule_list
;;


let print_para_rules list_of_rules = 
  (List.iter
     (fun x ->
	print_rule x
     )
     list_of_rules
  )
;;


let print_ident_knowledge userNumber=

    if ((get_identifier_name userNumber = "I")) 
    then 
      (
	print_string "##  I knows at step 0 ";
	List.iter (fun knowledgeElement -> print_term knowledgeElement;print_string(","))(!intruder_knowledge);
	print_newline()
      )
    else
      begin

	let userKnowledge = List.assoc userNumber !knowledge in
	  List.iter ( fun (protocolStep,knowledgeList)-> 
			print_string "\n##  ";
			print_ident userNumber; print_string " knows at step ";print_int(protocolStep);print_string(" ");
			List.iter( fun (message,b)->
				     print_msg (message);print_string(",");
				 )(List.rev knowledgeList);
		    )(List.rev userKnowledge);
	  print_newline();
      end
      ;;

let print_knowledge () =
  Utilities.for_all_user print_ident_knowledge
;;

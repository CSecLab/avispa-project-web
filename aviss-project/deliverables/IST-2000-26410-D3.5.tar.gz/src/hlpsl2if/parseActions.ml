(***********************************************************************)
(*                                                                     *)
(*                                 Casrul                              *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(***********************************************************************)
(* Parser definition: yacc grammar rules and associated actions *)

open Types;;
open Globals;;
open Utilities;;

(* local variables *)
let declared_instances = ref ([] : (string * type_var) list);;
(*
  list of couples (instance,variable type) used to check instances
  declared in intruder_knowledge section
*)
let got_msg_know = ref ([] : msg  list) ;;
(* 
   val got_msg_know : Types.msg list ref
   list of messages declared as initial knowledge of principals 
*)
let add_msg messageNumber senderNumber receiverNumber message =
   incr Globals.nbMsgs;
   if (messageNumber <> !Globals.nbMsgs)
     then
       (print_string "WARNING: message ";
        print_int messageNumber;
        print_endline " reindexed ");
   Globals.msg_list := !msg_list @ [(!Globals.nbMsgs,((senderNumber,receiverNumber),message))];
;;
let add_ident_knowledge userNumber identifierList =
  let rec add_ident_know_rec = function
      [] -> [(userNumber,identifierList)]
    | (identifierNumber,userKnowledge as head)::tail ->
        if (userNumber = identifierNumber)
        then
          (userNumber, interleave identifierList userKnowledge)::tail
        else
          if (userNumber < identifierNumber)
          then
            (userNumber,identifierList)::tail
          else
            head::(add_ident_know_rec tail)
  in
    Globals.ident_knowledge := add_ident_know_rec !ident_knowledge
;;
let add_ident identifierName identifierType =
  incr Globals.cpt_id;
  Hashtbl.add Globals.ident_table identifierName !Globals.cpt_id;
  Globals.ident_list := !ident_list @ [(!Globals.cpt_id,(identifierName,identifierType))];
  if identifierType = User
  then
    add_ident_knowledge !Globals.cpt_id [!cpt_id]
;;

(* Add the intruder *)
add_ident "I" User;;

(* checking elements produced by parse rules and adding them into data structures used by rules generators *)

let check_new_vars variableType =
  List.iter (fun identifierName ->
               if (Hashtbl.mem Globals.ident_table identifierName)
               then
                 ErrorHandler.handleSemanticError 1 identifierName
               else
                 add_ident identifierName variableType;
	       match variableType with
		   FrPcKey(_) -> add_ident (identifierName^"'") (FrPeKey(!Globals.cpt_id))(* FrPeKey(associated public key number) *)
		 | _-> ignore()
	    )
;;
let check_new_pckey =
   List.iter (fun identifierName ->
                if (Hashtbl.mem  Globals.ident_table identifierName)
                then
                     ErrorHandler.handleSemanticError 1 identifierName
                else
		  (
		    add_ident identifierName (FrPcKey(!Globals.cpt_id+2));(* FrPcKey(associated private key number) *)
                    add_ident (identifierName^"'") (FrPeKey(!Globals.cpt_id))))(* FrPeKey(associated public key number) *)
;;
let check_new_knowledge identifierName =
  try (let identifierNumber = Hashtbl.find Globals.ident_table identifierName
       in
         match snd (List.assoc identifierNumber !Globals.ident_list)
         with FrPcKey(idPe) ->
           Globals.ident_list := [(identifierNumber,(identifierName,PcKey(idPe)));(idPe,(identifierName^"'",PeKey(identifierNumber)))]
                                  @ (List.remove_assoc identifierNumber (List.remove_assoc idPe !Globals.ident_list));
           [identifierNumber]
           | FrSyKey ->
               Globals.ident_list := (identifierNumber,(identifierName,SyKey))::(List.remove_assoc identifierNumber !Globals.ident_list);
               [identifierNumber]
           | _ -> [identifierNumber])
   with Not_found ->
     ( ErrorHandler.handleSemanticError 2 identifierName;
       [])
;;
let  add_new_knowledge lNewId =
  List.iter (fun id ->
               try (add_ident_knowledge (Hashtbl.find Globals.ident_table id) lNewId)
               with Not_found ->
                 ErrorHandler.handleSemanticError 2 id;)
;;
let add_new_msg_knowledge  users =
  if ( !got_msg_know <> [])
  then
    List.iter (fun id ->
      Globals.init_msg_knowledge:=!Globals.init_msg_knowledge @ [((Hashtbl.find Globals.ident_table id),!got_msg_know)])users;
  got_msg_know:=[];
;;
let check_new_para identifierName =
   try (let identifierNumber = Hashtbl.find Globals.ident_table identifierName in
          match snd (List.assoc identifierNumber !Globals.ident_list)
          with User -> [identifierNumber]
	    | _ ->
        	     (ErrorHandler.handleSemanticError 5 identifierName;
        	      []))
   with Not_found ->
     (ErrorHandler.handleSemanticError 6 identifierName;
      [])
;;
let add_new_secret identifierList =
  List.iter (fun identifierName ->
               secret_ident_list:= !secret_ident_list@[identifierName]) identifierList
;;
let check_user_id name =
  try (let id = Hashtbl.find Globals.ident_table name
       in
         match (snd (List.assoc id !Globals.ident_list))
         with User ->
           id
             | _ -> (ErrorHandler.handleSemanticError 4 name;
                     0))
  with Not_found ->
    (ErrorHandler.handleSemanticError 8 name;
              0)
;;
let check_new_message messageNumber senderName receiverName =
  let senderNumber = check_user_id senderName 
  and receiverNumber = check_user_id receiverName in
     add_msg messageNumber senderNumber receiverNumber
;;
let check_func_identifier identifierName =
  try (let identifierNumber = Hashtbl.find Globals.ident_table identifierName
       in
         match (snd (List.assoc identifierNumber !Globals.ident_list))
         with Function ->
           identifierNumber
           | _ -> (ErrorHandler.handleSemanticError 4 identifierName;
                   0))
   with Not_found ->
     (ErrorHandler.handleSemanticError 12 identifierName;
      0)
;;
let check_non_funcId identifierName =
  try (let identifierNumber= Hashtbl.find Globals.ident_table identifierName
        in
         match (snd (List.assoc identifierNumber !Globals.ident_list))
         with User | FrSyKey | SyKey | Number | FrPcKey(_) | FrPeKey(_) | PcKey(_) | PeKey(_) | Function->
           Id(identifierNumber)
             | _ -> (ErrorHandler.handleSemanticError 4 identifierName;
                 Id(0)))
  with Not_found ->
    ( ErrorHandler.handleSemanticError 9 identifierName;
              Id(0))
;;
let check_table_id identifierName =
  try (let identifierNumber = Hashtbl.find Globals.ident_table identifierName
        in
         match (snd (List.assoc identifierNumber !Globals.ident_list))
         with Table -> identifierNumber
           | _ -> (ErrorHandler.handleSemanticError 4 identifierName;
                     0))
  with Not_found ->
    (ErrorHandler.handleSemanticError 9 identifierName;
     0)
;;
let check_table_elt tableName userName reversed=
  let tableNumber = check_table_id tableName
  and userNumber = check_user_id userName
   in
    if (tableNumber <> 0) && (userNumber <> 0)
    then
      TableElement(tableNumber, userNumber, reversed)
     else Id(0)
;;
let check_peKey_number peKeyName =
  try (let  peKeyNumber= Hashtbl.find Globals.ident_table peKeyName
       in
          match (snd (List.assoc peKeyNumber !Globals.ident_list))
          with FrPcKey(idPe) ->
            Id(idPe)
             | _ -> (ErrorHandler.handleSemanticError 10 peKeyName;
                     Id(0)))
  with Not_found ->
    (ErrorHandler.handleSemanticError 10 peKeyName;
     Id(0))
;;
let check_encryption message identifierName =
  try (let identifierNumber = Hashtbl.find Globals.ident_table identifierName
       in
         match (snd (List.assoc identifierNumber !Globals.ident_list))
         with FrSyKey | SyKey | Number | User -> Crypt(3,Id(identifierNumber),message)
           | FrPcKey(_) | PcKey(_)  ->  Crypt(1,Id(identifierNumber),message)
	   | FrPeKey(_) | PeKey(_)  ->  Crypt(2,Id(identifierNumber),message)
           | _ -> (ErrorHandler.handleSemanticError 13 identifierName;
                   Crypt(3,Id(0),message)))
  with Not_found ->
    (ErrorHandler.handleSemanticError 14 identifierName;
     Crypt(3,Id(0),message))
;; 
let check_instance identifierName instance =
  try (let identifierNumber = Hashtbl.find Globals.ident_table identifierName
       in
         try (let type_instance = List.assoc instance !declared_instances
              in
                match (snd (List.assoc identifierNumber !Globals.ident_list), type_instance)
                with (FrPcKey(i'), FrPcKey(_)) ->
                  [(identifierNumber,instance);(i',instance^"'")]
                  | (PcKey(i'), PcKey(_)) ->
                      [(identifierNumber,instance);(i',instance^"'")]
                  | (identifierType, _) ->
                      if (identifierType = type_instance)
                      then
                        [(identifierNumber,instance)]
                      else
                        (ErrorHandler.handleSemanticError 15 instance;
                         []))
         with Not_found ->
	   
           (let identifierType = snd (List.assoc identifierNumber !Globals.ident_list)
            in
              declared_instances := (instance,identifierType)::!declared_instances;
              match identifierType
              with FrPcKey(i') -> declared_instances:=(instance^"'",FrPeKey(i'))::!declared_instances;
		[(identifierNumber,instance);(i', instance^"'")]
		| PcKey(i') ->declared_instances:=(instance^"'",PeKey(i'))::!declared_instances;
                    [(identifierNumber,instance);(i', instance^"'")]
		| _ -> [(identifierNumber,instance)]))
  with Not_found ->
    (ErrorHandler.handleSemanticError 16 identifierName;
     [])
;;
let check_ident_instance identifierInstance number2term =
  try (number2term (List.assoc  identifierInstance !declared_instances))
  with Not_found ->
    (ErrorHandler.handleSemanticError 17 identifierInstance;
     Empty)
;;
let check_role_list roleList =
  List.iter(fun (sessionCounter,(userNumber,instanceCoupleList))->
	      let userKnowledgeList=List.assoc userNumber !ident_knowledge in
		ignore (List.map (fun x -> 
				    try ( List.assoc x instanceCoupleList)
				    with Not_found  -> ErrorHandler.handleSemanticError 24 (Utilities.get_identifier_name x );""
				 ) userKnowledgeList); (* verifies values *)
	   )roleList;
;;

:- ensure_loaded(sate).

%-----------------------------------------------------------------------
%        BEGIN: DEBUG CONFLICT AXIOMs
%

conflict :-
	['/backup/compa/test/nov2001/conflict-optimization/nspk/conflict.nspk.typed.step_1-10.sate'],
%	% Memory allocation fault
%	['/backup/compa/test/nov2001/conflict-optimization/eke/conflict.EKE.typed.step_1-11.goal_2.sate'],
	set(version,'1.0'),
	prova_conflict_exclusion_axiom(AXs10,RT10),
	format("Conflict Axioms Generation using version 1.0 in ~w\n",[RT10]),	
	set(version,'1.1'),
	table(conflict_exclusion_axiom),
	prova_conflict_exclusion_axiom(AXs12,RT12),
	format("Conflict Axioms Generation using version 1.2 in ~w\n",[RT12]),	
	list_diff(AXs12,AXs10,L1L2,L2L1),
	same_length(L1L2,L1L2,NL1L2),
	same_length(L2L1,L2L1,NL2L1),
	format("| AXs.1.2 - AXs.1.0 | = ~w\n",[NL1L2]),
	format("AXs.1.2 - AXs.1.0 =\n  ~w\n\n",[L1L2]),
	format("| AXs.1.0 - AXs.1.2 | = ~w\n",[NL2L1]),
	format("AXs.1.0 - AXs.1.2 =\n  ~w\n",[L2L1]).

prova_conflict_exclusion_axiom(RT) :-
	statistics(runtime,[_,_]),	
	prova_conflict_exclusion_axiom1,
	statistics(runtime,[_,RT]).

prova_conflict_exclusion_axiom1 :-
	encode(conflict_exclusion_axiom,I,_,~(I:_ & I:_)),
	fail.
prova_conflict_exclusion_axiom1.

prova_conflict_exclusion_axiom :-
	encode(conflict_exclusion_axiom,I,_,~(I:Op1 & I:Op2)),
	format("not(I:~w & I:~w)\n",[Op1,Op2]),
	fail.
prova_conflict_exclusion_axiom.

prova_conflict_exclusion_axiom(AXs,RT) :-
	statistics(runtime,[_,_]),
	findall(~(Op1 & Op2),
		encode(conflict_exclusion_axiom,I,_,~(I:Op1 & I:Op2)),
		AXs),
	statistics(runtime,[_,RT]).

% PROVA
instantiate_action_domain(RT) :-
	statistics(runtime,[_,_]),
	instantiate_action_domain,
	statistics(runtime,[_,RT]).
instantiate_action_domain :-
	action(Op1,_,_,_,_),
	Op1=..[Act|_],
	action(Op2,_,_,_,_),
	Op2=..[Act|_],	
	predicate(action,Op1),
	predicate(action,Op2),
%	format("actions:\n  ~w\n  ~w\n",[A1,A2]),
	fail.
instantiate_action_domain.

instantiate_action_pairs(RT) :-
	statistics(runtime,[_,_]),
	instantiate_action_pairs,
	statistics(runtime,[_,RT]).
instantiate_action_pairs :-
	action(A1,_,_,_,_),
	action(A2,_,_,_,_),
	predicate(action,A1),
	predicate(action,A2),
%	format("actions:\n  ~w\n  ~w\n",[A1,A2]),
	fail.
instantiate_action_pairs.

%
%          END: DEBUG CONFLICT AXIOMs
%-----------------------------------------------------------------------

explanatory_1_0(F) :-
	tell(F),
	table(explanatory_frame_axiom),
	explanatory_1_0a,
	told.
explanatory_1_0a :-
	encode(explanatory_frame_axiom,0,1,W),
% 	table_explanatory_frame_axiom(F-Add-Del),
% 	format("~w ~w ~w\n",[F,Add,Del]),
	format("ax(~w).\n",[W]),
	fail.
explanatory_1_0a.

explanatory_1_2(F) :-
	tell(F),
	ape_axiom_1_2,
	explanatory_1_2a,
	told.
explanatory_1_2a :-
	encode(explanatory_frame_axiom,0,1,W),
% 	table_explanatory_frame_axiom(F-Add-Del),
% 	format("~w ~w ~w\n",[F,Add,Del]),
	format("ax(~w).\n",[W]),
	fail.
explanatory_1_2a.

ape_axiom_1_2 :-
	encode(ape_axiom,_,_,_),
	fail.
ape_axiom_1_2.

encode1(explanatory_frame_axiom,I,I1,W) :-
	P=i(scrypt(sk(idp),nonce(c(idNa,fresh)))),
	predicate(fluent,P),
	\+value(explanatory_fluent_done,P),		
	assertz(value(explanatory_fluent_done,P)),
	explanatory_frame_axiom(P,I,I1,W).



(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                                main.ml                              *)
(*                                 Loria                               *)
(*                         programme principal                         *)
(***********************************************************************)
open Rules;;
open Interface;;
open Globals;;
open Parallel;;
open Intruder;;
open Goal;;

let main () =
  let filename      = ref "" in
  let path          = ref "" in
    (Arg.parse 
	 [("--intruder",Arg.Set(Globals.flag_intru)," (print intruder rules)");
	  ("--rules",Arg.Set(Globals.flag_rules),"    (print protocol rules)");
	  ("--typed",Arg.Set(Globals.flag_typed),"    (print typed protocol rules)");
	  ("--init",Arg.Set(Globals.flag_init),"     (print initial state)");
	  ("--goal",Arg.Set(Globals.flag_goal),"     (print goal)");
	  ("--ident",Arg.Set(Globals.flag_ident),"    (print identifiers list)");
	  ("--simplif",Arg.Set(Globals.flag_simplif),"  (print simplification rules)");
	  ("--para",Arg.Set(Globals.flag_para),"  (print parallel rules)");
	  ("--knowledge",Arg.Set(Globals.flag_knowledge),"  (print knowledge of users at different protocol steps)");
	  ("--all",Arg.Set(Globals.flag_all),"      (print everything)");
	  ("-l",Arg.String(fun s -> (path := s)),"path     (path for the input file)")
	 ]
	 (fun s -> (filename := s))
	 "Usage: hlpsl2if [options] [file]\n Options:");
    (* Input parsing and errors handling *)
    let file = ((!path)^(!filename)) in
    let channel = 
      if (file = "")
      then stdin
      else 
      	try (open_in file)
       	with Sys_error(f) -> (ErrorHandler.handleSystemError(f)
       	)  in
     let parse = Rules.call_parser channel in    
     if (parse <> 0)
      then  exit 0;
     if (!flag_NuMSV_compatibility) then
	underscore := "";
      Rules.comp_fresh();
      Rules.compute_know();
      Rules.check_protocol();
      if (!Globals.flag_typed) then
	print_string "# option=typed\n"
      else
	print_string "# option=untyped\n";
      if ((not !Globals.flag_intru) && (not !Globals.flag_rules) && (not !Globals.flag_init) && (not !Globals.flag_goal) && (not !Globals.flag_ident)&&(not !Globals.flag_para)&&(not !flag_ident)&&(not !Globals.flag_knowledge)&&(not !Globals.flag_typed))
      then 
      	begin
	  (* Prints the main characteristics of the protocol *)
    	  print_newline ();
    	  print_endline "## Knowledge:";
    	  Interface.print_init_knowledge ();
    	  print_newline ();  
    	  print_endline "## List of messages:";
    	  Interface.print_msglist ();
    	  print_newline ();
	  if (parse = 0) then print_endline "### This protocol is correct ! ###";
      	end;

    (* identifiers list generation *)
      if (!Globals.flag_ident)
      then
	(
	 print_endline("## identifiers list");
	Interface.print_ident_list();
	);

      
    (* user rules generation *)
      if (!Globals.flag_rules or !Globals.flag_all )
      then 
      	begin	  
	  (* print_endline "# Protocol rules"; *)
	  List.iter (fun x -> Interface.print_rule x;print_newline();print_newline()) (Rules.build_user_rules ());
	  print_newline();
      	end;

    (* simplification rules generation *)
      if (!Globals.flag_simplif or !Globals.flag_all)
      then 
      	begin	  
	  (* print_endline "# Protocol simplification rules"; *)
	  List.iter (fun x -> Interface.print_rule x;print_newline();print_newline()) Rules.build_simplification_rules;
	  print_newline();
	  (* print_endline "# Intruder simplification rules"; *)
	  List.iter (fun x -> Interface.print_rule x;print_newline();print_newline()) Intruder.build_intruder_simplification_rules;
	  print_newline();
	end;
      
    (* parallel rules generation *)
      if (!Globals.flag_para or !Globals.flag_all)
      then 
      	begin	  
	  Interface.print_para_rules (Parallel.build_para_rules ());
	  print_newline();
	end;

      (* intruder's rules generation *)      
      if (!Globals.flag_intru or !Globals.flag_all)
      then
	begin
	  (* print_endline "# Intruder rules";	  *)
	  Interface.print_rule (Intruder.build_memo_rules ());
	  print_newline();
	  print_newline();
	  if List.mem 1 !Globals.intruder_cases  
	  then List.iter (fun x -> Interface.print_rule x;print_newline();print_newline()) (Intruder.build_divert_rules ()); 
	  print_newline();
	  if List.mem 2 !Globals.intruder_cases  
	  then List.iter (fun x -> Interface.print_rule x;print_newline();print_newline()) (Intruder.build_eavesdropping_rules ()); 
	  print_newline();
	  if List.mem 3 !Globals.intruder_cases  
	  then List.iter (fun x -> Interface.print_rule x;print_newline();print_newline()) (Intruder.build_impersonate_rules ()); 
	  print_newline();
      	end;
      
      (* initial state generation *)
      if (!Globals.flag_init or !Globals.flag_all)
      then
	begin
	  Globals.flag_init_ok := true ;
	  let old_flag_typed = ref !flag_typed in 
	    Globals.flag_typed := true ;
	    Interface.print_rule  (Rules.build_init_state ());
	    if (!old_flag_typed) then
	      print_string ".i(nonce(c(ni,ni))).i(sk(c(ni,ni))).i(pk(c(ni,ni))').i(pk(c(ni,ni)))"
	    else
	      print_string ".i(pk(c(ni,ni))').i(pk(c(ni,ni)))";
	    print_newline(); 
	    Globals.flag_typed := !old_flag_typed;
	    Globals.flag_init_ok := false;
      	end;      

      (* knowledge display generation *)
      if (!Globals.flag_knowledge or !Globals.flag_all)
      then
	begin
	  Interface.print_knowledge();
	  print_newline();
      	end;	
      
      (* goal generation *)
      if (!Globals.flag_goal or !Globals.flag_all)
      then
	begin
	  List.iter (fun x -> Interface.print_rule x;print_newline();print_newline()) (Goal.build_goal ());
	  print_newline();
    	end;;
main();;

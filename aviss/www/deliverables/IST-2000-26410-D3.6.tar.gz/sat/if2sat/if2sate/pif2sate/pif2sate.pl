:- use_module(library(lists)).
:- use_module(library(charsio)).

:- multifile portray/1.
:- dynamic portray/1.

%:- ensure_loaded(newload).
%:- ensure_loaded('../../sate/instantiators.pl').

% TODO: Directory structure
%:- ensure_loaded(category_labels).

:- retractall(syntax(_)).

:- dynamic sate2prolog_maps_var/2,
	   internal_counter/1,
	   msg_depth_counter/1,
%	   msg_width_counter/2,
	   msg_width_counter/1,	   	   
	   decompose_counter/1,
	   decrypt_public_key_counter/1,
	   decrypt_private_key_counter/1,
	   decrypt_symmetric_key_counter/1,
	   redundant_declaration/1,
	   decompose/1.

pre_declarations(
	[
	 % Fluents and actions
	 comment('Fluents and actions'),
         sort(fluent),
	 sort(action),
	 % Sessions
	 comment('Sessions'),
	 sort(session),
	 sort(session_base),
	 sort(session_without_rep_1),	 
	 % Freshness
	 comment('Freshness'),	 
	 sort(fresh_property),
	 sort(fresh_const),
	 super_sort(fresh_const,fresh_public_key),
	 super_sort(fresh_const,fresh_symmetric_key),
	 super_sort(fresh_const,fresh_nonce),
%	 super_sort(fresh_const,fresh_intruder_const),
	 constant(fresh,fresh_property),
	 constant(not_used(fresh_const),fluent),
	 % Users
	 comment('Users'),	 	 
	 sort(mr),
	 sort(mr_honest),
	 sort(mr_intruder),
	 sort(user),
	 sort(user_honest),
	 sort(user_intruder),
	 super_sort(mr,mr_honest),
	 super_sort(mr,mr_intruder),
	 super_sort(user,user_honest),
	 super_sort(user,user_intruder),
 	 constant(mr(user_honest),mr_honest),
	 constant(mr(user_intruder),mr_intruder),
	 % Knowledge
	 comment('Knowledge'),
	 sort(knw_el),
	 sort(knw_el_empty),
	 constant(etc,knw_el_empty),
	 % Public and Private Key
	 comment('Public and Private Key'),	 	 
	 sort(ped),
	 sort(pk),
	 sort(pkinv),
	 sort(public_key),
	 sort(public_key_id),
	 sort(fresh_public_key),
	 sort(fresh_public_key_id),
	 super_sort(ped,pk),
	 super_sort(ped,pkinv),
	 super_sort(public_key,public_key_id),
	 super_sort(public_key,fresh_public_key),
	 super_sort(public_key,fresh_intruder_const),
	 constant(c(fresh_public_key_id,fresh_property),fresh_public_key),
	 constant(pk(public_key),pk),
	 constant(primed(pk),pkinv),
         % Symmetric Key
	 comment('Symmetric Key'), 
	 sort(sk),
	 sort(symmetric_key),
	 sort(symmetric_key_id),
	 sort(fresh_symmetric_key),
	 sort(fresh_symmetric_key_id),
	 super_sort(symmetric_key,symmetric_key_id),
	 super_sort(symmetric_key,fresh_symmetric_key),
	 super_sort(symmetric_key,fresh_intruder_const),
	 constant(c(fresh_symmetric_key_id,fresh_property),fresh_symmetric_key), 
	 constant(sk(symmetric_key),sk),
	 % Nonces
	 comment('Nonces'),
	 sort(nonce),
	 sort(fresh_nonce),
	 sort(fresh_nonce_id),
	 super_sort(fresh_nonce,fresh_intruder_const),
	 constant(nonce(fresh_nonce),nonce),
	 constant(nonce(nonce_id),nonce),
	 constant(c(fresh_nonce_id,fresh_property),fresh_nonce), 
	 % Intruder
	 comment('Intruder'),
	 sort(fresh_intruder_const),
	 sort(intruder_const),
	 constant(c(intruder_const,intruder_const),fresh_intruder_const),
	 % Initial knowledge
%	 comment('Initial knowledge'),
%	 constant(inknw(mr_honest,inknw_el,inknw_index,session_base),fluent),
%	 sort(inknw_index),
%	 sort(inknw_el),
	 % OLD
	 comment('OLD'),
%	 sort(wstep),
	 sort(mstep),
% 	 % Only if there is a term secrecy(..) in the PIF specification
% 	 sort(fsecrecy),
%	 constant(secret(knw_el,fsecrecy),fluent),
%	 constant(f(session),fsecrecy),	 
	 sort(fu),
         constant(fu(fu_term),fu),
	 sort(fu_term),
	 comment('Atoms'),
         super_sort(atom,mr),
	 super_sort(atom,pk),
	 super_sort(atom,sk),
	 super_sort(atom,nonce),
	 super_sort(atom,fu),
	 % Invariants and statics
	 comment('Invariants and statics'),
	 invariant(~(wk('_','A','A','_','_','_'))),
	 invariant(~(m('_','A','A','_'))),
 	 invariant(~(request('A','A','_','_'))),
 	 invariant(~(witness('A','A','_','_'))),
	 invariant(inknw('_','_','_','_')),
	 static(inknw('_','_','_','_')),
	 monotone(i('_')),
	 % Fluents
	 comment('Fluents'),
	 constant(i(knw_el),fluent)
%	 constant(inknw(mr_honest,inknw_el,inknw_index,session_base),fluent)
	]
).

% PREDEFINED SORTs
pre_sorts(
	[
	 % Fluents and actions
         sort(fluent),
	 sort(action),
	 % Session
	 sort(session),
	 % Freshness
	 sort(fresh_property),
	 sort(fresh_const),
	 % Users
	 sort(mr),
	 sort(mr_honest),
	 sort(mr_intruder),
	 sort(user),
	 sort(user_honest),
	 sort(user_intruder),
	 % Knowledge
	 sort(knw_el),
	 sort(knw_el_empty),
	 % Public and Private Key
	 sort(ped),
	 sort(pk),
	 sort(pkinv),
	 sort(public_key),
	 sort(public_key_id),
	 sort(fresh_public_key),
	 sort(fresh_public_key_id),
         % Symmetric Key
	 sort(sk),
	 sort(symmetric_key),
	 sort(fresh_symmetric_key),
	 sort(fresh_symmetric_key_id),
	 % Nonces
	 sort(nonce),
	 sort(fresh_nonce),
	 sort(fresh_nonce_id),
	 % Intruder
	 sort(fresh_intruder_const),
	 sort(intruder_const),
	 
	 % OLD
%	 sort(wstep),
	 sort(mstep),
% 	 % Only if there is a term secrecy(..) in the PIF specification
% 	 sort(fsecrecy),
	 sort(fu),
	 sort(fu_symbol)
        ]
).

pre_super_sorts(
	[
	 % Freshness
	 super_sort(fresh_const,fresh_public_key),
	 super_sort(fresh_const,fresh_symmetric_key),
	 super_sort(fresh_const,fresh_nonce),
	 super_sort(fresh_const,fresh_intruder_const),
	 % Users
	 super_sort(mr,mr_honest),
	 super_sort(mr,mr_intruder),
	 super_sort(user,user_honest),
	 super_sort(user,user_intruder),
	 % Public Key
	 super_sort(ped,pk),
	 super_sort(ped,pkinv),
	 super_sort(public_key,public_key_id),
	 super_sort(public_key,fresh_public_key),
	 super_sort(public_key,fresh_intruder_const),
	 % symmetric Key
	 super_sort(symmetric_key,symmetric_key_id),
	 super_sort(symmetric_key,fresh_symmetric_key),
	 super_sort(symmetric_key,fresh_intruder_const),
	 % Nonces
	 super_sort(fresh_nonce,fresh_intruder_const),
	 
	 % OLD
         super_sort(atom,mr),
	 super_sort(atom,pk),
	 super_sort(atom,sk),
	 super_sort(atom,nonce),
	 super_sort(atom,fu)
]
).

pre_invariants(
	[
	 invariant(~(wk('_','A','A','_','_','_'))),
	 invariant(~(m('_','_','A','A','_')))
	]
).

pre_constants(
	[
	 % Freshness
	 constant(fresh,fresh_property),
	 constant(not_used(fresh_const),fluent),
	 % Knowledge
	 constant(etc,knw_el_empty),
	 % Public Key
	 constant(c(fresh_public_key_id,fresh_property),fresh_public_key), % New idea
	 constant(pk(public_key),pk),
	 constant(primed(pk),pkinv),
	 % Symmetric Key
	 constant(c(fresh_symmetric_key_id,fresh_property),fresh_symmetric_key), % New idea	
	 constant(sk(symmetric_key),sk),
	 % Nonces
	 constant(nonce(fresh_nonce),nonce),
	 constant(c(fresh_nonce_id,fresh_property),fresh_nonce), % New idea
	 % Intruder
	 constant(c(intruder_const,intruder_const),fresh_intruder_const), % super_sort(fresh_intruder_const,intruder_const).
	 % Fluents
	 constant(i(intr_knw_el),fluent)
%	 constant(secret(knw_el,fsecrecy),fluent),
%	 constant(f(session),fsecrecy),	 
% 	 % Boolean
% 	 constant(true,bool),
% 	 constant(false,bool),
        ]
).

% PIF2SATE COMPILER
pif2sate(F_PIF,F_SATE) :-
	compile(F_PIF),!,
	problem(OPTs,LRR1s),
	(value(multi_fresh_term,on) ->
	    multi_fresh_consts(problem(OPTs,LRR1s),problem(OPTs,LRR2s))
% 	    % DEBUG 
%  	    build_sort(F_PIF,'new.pif',F_PIF2),
%  	    open(F_PIF2,write,STREAM,[eof_action(eof_code)]),
%  	    write_pif(STREAM,problem(OPTs,LRR2s)),
%  	    close(STREAM)
	;
	    LRR2s=LRR1s
	),
	(OPTs=[typed] ->
	    true;
	    format("The IF specification file must be compiled with the --typed option during the translation from HLPSL to IF.\n",[]),
	    halt
	),
	!,
	pre_declarations(PreDs),
	preprocess(problem(OPTs,LRR2s),PreDs,PPDs),
	(value(relax_conflict,on) ->
	    D1s = [is_not_conflict_fluent(wk(_,_,_,_,_,_)),
		   is_not_conflict_fluent(m(_,_,_,_))|PPDs]
	;
	    D1s = PPDs
	),
	!,
 	remove_intruder_knowledge_redundancies(PreDs,D1s,D2s),
	!,
	append(PreDs,D2s,D3s),
	facts(problem(OPTs,LRR2s),D3s,D4s),
	!,
	append(D3s,D4s,D5s),
	actions(problem(OPTs,LRR2s),D5s,D6s),
	!,
	append(D5s,D6s,D7s),
	goals(problem(OPTs,LRR2s),D7s,D8s),
	!,
	append(D2s,D4s,TDs),
	append(TDs,D6s,TTDs),
	append(TTDs,D8s,Ds),
	post_pif2sate(Ds,NewDs),
	tell(F_SATE),
	write_declarations(NewDs),
%	write_session_condition,
	write_operator_splitting_invariant,	
	told.

%-----------------------------------------------------------------------
%        BEGIN: POST PIF2SATE
%

post_pif2sate(Ds,Ds).
	
% TODO
% post_pif2sate(Ds,NewDs) :-
% 	sate2prolog_declarations(Ds,PrologDs),
% 	assert_declaration_list(PrologDs),
% 	post_pif2sate,
% 	get_sate_assertions(PrologNewDs),
% 	prolog2sate_declarations(PrologNewDs,NewDs),
% 	retractall_declarations.

% TODO
% post_pif2sate :-
% 	post_freshness.

%
%          END: POST PIF2SATE
%-----------------------------------------------------------------------
	
%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS 
%

% NOTE: Ds contains only the new declarations
preprocess(problem(_,LRRs),D1s,Ds) :-
	preprocess_rules(LRRs,D1s,D2s),
	remove_duplicates(D2s,D3s),
	append(D1s,D3s,D4s),

 	preprocess_initial_state(LRRs,D4s,D5s),
	remove_duplicates(D5s,D6s),
	append(D4s,D6s,D7s),

	preprocess_principals(LRRs,D7s,D8s),
	remove_duplicates(D8s,D9s), 
	append(D7s,D9s,D10s),

	preprocess_messages(LRRs,D10s,D11s),
	remove_duplicates(D11s,D12s),
	append(D10s,D12s,D13s),

	preprocess_authentication(LRRs,D13s,D14s),
	remove_duplicates(D14s,D15s),
	append(D13s,D15s,D16s),
	
	preprocess_secrecy(LRRs,D16s,D17s),
	remove_duplicates(D17s,D18s),	
	
	append([comment('Preprocess Rules')|D3s],[comment('Preprocess Principal Terms')|D6s],TDs),
	append(TDs,[comment('Preprocess Initial State')|D9s],TTDs),
	append(TTDs,[comment('Preprocess Messages')|D12s],TTTDs),
	append(TTTDs,[comment('Authentication fluents')|D15s],TTTTDs),
	append(TTTTDs,[comment('Secrecy fluents')|D18s],TTTTTDs),		
	remove_duplicates(TTTTTDs,Ds).

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS RULES
%

% preprocess_rules(LRRs,D1s,Cs) :-
%       Analize each PIF rule to add the basic
%       constant declarations (e.g. a and b are users,
%       ka and kb are keys, etc.)
preprocess_rules([],_,[]).
preprocess_rules([LRR|LRRs],D1s,Cs) :-
	preprocess_rule(LRR,D1s,C1s), 
	preprocess_rules(LRRs,D1s,C2s),
	append(C1s,C2s,Cs).

preprocess_rule(lrr(_,_,LHS,RHS),D1s,Cs) :-
	preprocess_terms(LHS,D1s,C1s),
	preprocess_terms(RHS,D1s,C2s),
	append(C1s,C2s,Cs).

% TODO: make the predicate preprocess_term(T,C1s)
%       ternary adding the parameter D1s
preprocess_terms([],_,[]).
preprocess_terms([T|Ts],D1s,Cs) :-
	preprocess_term(T,D1s,C1s),
	preprocess_terms(Ts,D1s,C2s),
	append(C1s,C2s,Cs).

% Users
preprocess_term(mr(intruder),_,[constant(intruder,user_intruder)]) :- !.
preprocess_term(mr(C),_,[constant(C,user_honest)]):-
	C\==intruder,
	is_constant(C),!.
% Public key
preprocess_term(primed(pk(C)),_,[constant(C,public_key_id)]):-
	is_constant(C),!.
preprocess_term(pk(C),_,[constant(C,public_key_id)]):-
	is_constant(C),!.
preprocess_term(primed(pk(c(C,xTime))),_,[constant(C,fresh_public_key_id)]):-
	is_constant(C),!.
preprocess_term(pk(c(C,xTime)),_,[constant(C,fresh_public_key_id)]):-
	is_constant(C),!.
% Symmetric key
preprocess_term(sk(C),_,[constant(C,symmetric_key_id)]):-
	is_constant(C),!.
preprocess_term(sk(c(C,xTime)),_,[constant(C,fresh_symmetric_key_id)]):-
	is_constant(C),!.
% Nonces
preprocess_term(nonce(c(C,xTime)),_,[constant(C,fresh_nonce_id)]):-
	is_constant(C),!.
preprocess_term(nonce(C),_,[constant(C,nonce_id)]):-
	is_constant(C),!.
% Function Symbol
preprocess_term(fu(C),_,[constant(C,fu_term)]):-
	is_constant(C),!.
% Intruder Constant
preprocess_term(c(C,C),_,[constant(C,intruder_const)]):-
	value(intruder_const,on),
	is_constant(C),!.
% % [LC]: TODO allow disabilitation of intruder
% %       constant
preprocess_term(c(C,C),_,[]):-
	\+value(intruder_const,on),
	is_constant(C),!.
preprocess_term(V,_,[]):-
	is_var(V),!.
preprocess_term(T,Ds,Cs):-
	T=..[_|Ts],
%	\+is_var(F),
	preprocess_terms(Ts,Ds,Cs).
%
%          END: PREPROCESS RULES
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS PRINCIPAL TERMS
%
preprocess_principals(LRRs,PreDs,Ds) :-
 	category_label(CIS,init),
 	findall(w(STEP_IN,S_IN,R_IN,AK_IN,IK_IN,B_IN,SES_IN),
 		(
		  member(lrr(_,CIS,LHS_IN,[]),LRRs),
		  member(w(STEP_IN,S_IN,R_IN,AK_IN,IK_IN,B_IN,SES_IN),LHS_IN)
		),
 		TmpW_INs),
	remove_duplicates(TmpW_INs,W_INs),
 	findall(WSTEP_IN,
 		(
		  member(w(WSTEP_IN,_,_,_,_,_,_),W_INs)
		),
 		TmpWSTEP_INs),
	remove_duplicates(TmpWSTEP_INs,WSTEP_INs),
 	preprocess_principal_terms(init,W_INs,PreDs,D1s),
 	category_label(CRR,rules),
 	findall(w(STEP,S,R,AK,IK,B,SES),
 		(
		  member(lrr(_,CRR,LHS,RHS),LRRs),
		  (
 		      member(w(STEP,S,R,AK,IK,B,SES),LHS)
 		    ;
		      member(w(STEP,S,R,AK,IK,B,SES),RHS)
		  ),
		  \+member(STEP,WSTEP_INs)
% 		  % DEBUG
% 		  STEP = 4
		),
 		TmpWs),
	remove_duplicates(TmpWs,Ws),
 	preprocess_principal_terms(rules,Ws,PreDs,D2s),
	append(D1s,D2s,Ds).
% 	% DEBUG
% 	assert_declaration_list(D1s),
% 	assert_declaration_list(Ds),!,
% 	fail.

preprocess_principal_terms(_,[],_,[]).
preprocess_principal_terms(CAT,[W|Ws],D1s,D4s) :-
	preprocess_principal_term(CAT,W,D2s),
	preprocess_principal_terms(CAT,Ws,D1s,D3s),
	append(D2s,D3s,TMPD4s),
	remove_duplicates(TMPD4s,D4s).
preprocess_principal_term(CAT,w(STEP,S,R,AK,IK,_,SES),[comment(COMM),sort(SWS),constant(STEP,SWS)|Ds]) :-
	number(STEP),
	% WSTEP
	build_sort('wstep',STEP,SWS),
	format_to_chars("Principal Term ~w",[STEP],CCOMM),
	atom_chars(COMM,CCOMM),
	preprocess_knw(CAT,w(STEP,S,R,AK,IK,_,SES),Ds).

% Acquired knowledge is a variable
preprocess_knw(_,w(_,_,_,AKs,_,_,_),[]) :-
	is_var(AKs), !.
% Acquired knowledge empty
preprocess_knw(CAT,w(STEP,Sender,Receiver,[],_,_,Ses),
	       [sort(knw_index_1),constant(1,knw_index_1),
		sort(SKE),super_sort(SKE,knw_el_empty),
		constant(wk(SWS,SenderSort,ReceiverSort,SKE,knw_index_1,SessionSort),fluent)|D1s]) :-
	build_sort('wstep',STEP,SWS),
	build_sort('knw_el',STEP,TSKE),
	build_sort(TSKE,1,SKE),
	(((Sender=mr(SenderUser),is_var(SenderUser));is_var(Sender)) ->
	    SenderSort = mr,
	    SenderCs = [],
	    SenderSs = []
	;
	    build_sort('wsender',STEP,SWSender),
	    preprocess_msg(Sender,SWSender,SenderSort,SenderCs-SenderSs-_)
	),
	(((Receiver=mr(ReceiverUser),is_var(ReceiverUser));is_var(Receiver)) ->
	    ReceiverSort = mr_honest,
	    ReceiverCs = [],
	    ReceiverSs = []
	;
	    build_sort('wreceiver',STEP,SWReceiver),
	    preprocess_msg(Receiver,SWReceiver,ReceiverSort,ReceiverCs-ReceiverSs-_)
	),
	pif2sate_gsession(Ses,SesBase),
	(is_var(SesBase) ->
	    (
	      CAT==init,
	      SessionSort = session
	    ;
	      CAT==rules,
	      SessionSort = session_without_rep_1
	    )
	;
	    (
	      CAT==rules,
	      count_repetition(Ses,Rep),
	      (Rep = 0 ->
		  build_sort('session_base',SesBase,SessionSort)
	      ;
		  build_sort('session',SesBase,TmpSessionSort),
		  build_sort('rep',Rep,TmpRepSession),
		  build_sort(TmpSessionSort,TmpRepSession,SessionSort)
	      )
	    ;
	      CAT==init,
	      build_sort('session',SesBase,SessionSort)
	    )
	),
	append(SenderCs,SenderSs,TD1s),
	append(TD1s,ReceiverCs,TTD1s),
	append(TTD1s,ReceiverSs,D1s),
	!.
% Acquired knowledge is not empty
preprocess_knw(CAT,w(STEP,S,R,[AK|AKs],IK,_,SES),Ds) :-
	preprocess_knw(CAT,w(STEP,S,R,[AK|AKs],IK,_,SES),[AK|AKs],1,Ds).
preprocess_knw(_,w(_,_,_,_,_,_,_),[],_,[]).
preprocess_knw(CAT,w(STEP,S,R,AKs,_,_,SES),[K|Ks],N,Ds) :-
	preprocess_knw_el(CAT,w(STEP,S,R,AKs,_,_,SES),K,N,D1s),
	M is N + 1,
	preprocess_knw(CAT,w(STEP,S,R,AKs,_,_,SES),Ks,M,D2s),
	append(D1s,D2s,Ds).
preprocess_knw_el(CAT,w(STEP,Sender,Receiver,_,_,_,Ses),AK,N,
		  [sort(SKI),constant(N,SKI),
		   sort(SKE),super_sort(SKE,SORT),
		   constant(wk(SWS,SenderSort,ReceiverSort,SKE,SKI,SessionSort),fluent)|D1s]) :-
	build_sort('wstep',STEP,SWS),
	build_sort('knw_index',N,SKI),
	build_sort('knw_el',STEP,TSKE),
	build_sort(TSKE,N,SKE),
	preprocess_msg(AK,SKE,SORT,MCs-MSs-MSPSs),
	(((Sender=mr(SenderUser),is_var(SenderUser));is_var(Sender)) ->
	    SenderSort = mr,
	    SenderCs = [],
	    SenderSs = []
	;
	    build_sort('wsender',STEP,SWSender),
	    preprocess_msg(Sender,SWSender,SenderSort,SenderCs-SenderSs-_)
	),
	(((Receiver=mr(User),is_var(User));is_var(Receiver)) ->
	    ReceiverSort = mr_honest,
	    ReceiverCs = [],
	    ReceiverSs = []
	;
	    build_sort('wreceiver',STEP,SWReceiver),
	    preprocess_msg(Receiver,SWReceiver,ReceiverSort,ReceiverCs-ReceiverSs-_)
	),
	pif2sate_gsession(Ses,SesBase),
	(is_var(SesBase) ->
	    (
	      CAT==init,
	      SessionSort = session
	    ;
	      CAT==rules,
	      SessionSort = session_without_rep_1
	    )
	;
	    (
	      CAT==rules,
	      count_repetition(Ses,Rep),
	      (Rep = 0 ->
		  build_sort('session_base',SesBase,SessionSort)
	      ;
		  build_sort('session',SesBase,TmpSessionSort),
		  build_sort('rep',Rep,TmpRepSession),
		  build_sort(TmpSessionSort,TmpRepSession,SessionSort)
	      )
	    ;
	      CAT==init,
	      build_sort('session',SesBase,SessionSort)
	    )
	),
	append(MCs,MSs,TD1s),
	append(TD1s,MSPSs,TTD1s),
	append(TTD1s,SenderCs,TTTD1s),
	append(TTTD1s,SenderSs,TTTTD1s),
	append(TTTTD1s,ReceiverCs,TTTTTD1s),
	append(TTTTTD1s,ReceiverSs,D1s).

preprocess_in_index(K,[]) :-
	is_var(K).
preprocess_in_index(K,Cs) :-
	\+is_var(K),
	same_length(K,K,N),
	build_constants(1-N,in_index,Cs).

%
%          END: PREPROCESS PRINCIPAL
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS MESSAGES
%

preprocess_messages(LRRs,D1s,Ds) :-
 	category_label(CRR,rules),
% 	findall(m(STEP,_,_,_,MSG,_),
 	findall(m(STEP,RS,OS,R,MSG,SES),		
 		(
		    member(lrr(_,CRR,LHS,RHS),LRRs),
		    (
 			member(m(STEP,RS,OS,R,MSG,SES),LHS)
 		    ;
			member(m(STEP,RS,OS,R,MSG,SES),RHS)
		    )
		),
 		TmpMs),
	remove_duplicates(TmpMs,Ms),
	preprocess_messages_terms(Ms,D1s,D2s),
	remove_duplicates(D2s,D3s),
	remove_messages_redundancies(D1s,D3s,Ds).

remove_messages_redundancies(PreDs,D1s,D2s) :-
	assert_declaration_list(PreDs),
	assert_declaration_list(D1s),
	findall(Sort,
		(
		  sort(SuperSort),
		  atom_concat(msg_,_,SuperSort),
		  super_sort(SuperSort,Sort)
		),
		Sorts),
	value(term_depth_bound,N),
	assert_redundant_declarations(Sorts,N),
	get_redundant_declarations(RDs),
	delete_sublist(RDs,D1s,D2s),
	retractall_declarations.

preprocess_messages_terms([],_,[]).
preprocess_messages_terms([m(STEP,_,Sender,Receiver,MSG,_)|Ms],
			  D1s,Ds) :-

	(((Sender=mr(SenderUser),is_var(SenderUser));is_var(Sender)) ->
	    SenderSort = mr,
	    SenderCs = [],
	    SenderSs = []
	;
	    build_sort('msender',STEP,SMSender),
	    preprocess_msg(Sender,SMSender,SenderSort,SenderCs-SenderSs-_)
	),
	(((Receiver=mr(User),is_var(User));is_var(Receiver)) ->
	    ReceiverSort = mr,
	    ReceiverCs = [],
	    ReceiverSs = []
	;
	    build_sort('mreceiver',STEP,SMReceiver),
	    preprocess_msg(Receiver,SMReceiver,ReceiverSort,ReceiverCs-ReceiverSs-_)
	),

        preprocess_msg(MSG,STEP,SORT,Cs-Ss-SPSs),	
	build_sort('msg',STEP,SMSG),
	build_sort('mstep',STEP,SSTEP),
	format_to_chars("Message Term ~w",[STEP],CCOMM),
	atom_chars(COMM,CCOMM),
	append([comment(COMM),
		sort(SMSG),sort(SSTEP),
		super_sort(mstep,SSTEP),super_sort(SMSG,SORT),
		constant(STEP,SSTEP),
%		constant(m(SSTEP,mr,mr,mr,SMSG,session),fluent)],
		constant(m(SSTEP,SenderSort,ReceiverSort,SMSG),fluent)],		
	       Cs, TDs),
	append(SenderCs,SenderSs,SenderDs),
	append(ReceiverCs,ReceiverSs,ReceiverDs),
	append(TDs,Ss,TTDs),
	append(TTDs,SPSs,TTTDs), 
	append(TTTDs,SenderDs,TTTTDs), 
	append(TTTTDs,ReceiverDs,TTTTTDs),
	remove_duplicates(TTTTTDs,D2s),
	preprocess_messages_terms(Ms,D1s,D3s),
	append(D2s,D3s,Ds).

% preprocess_messages(LRRs,Cs-Ss-SPSs) :-
%  	category_label(CRR,rules),
%  	findall(m(STEP,RS,OS,R,MSG,SES),
%  		(
% 		    member(lrr(_,CRR,LHS,RHS),LRRs),
% 		    (
% 			member(m(STEP,RS,OS,R,MSG,SES),LHS)
% 		    ;
% 			member(m(STEP,RS,OS,R,MSG,SES),RHS)
% 		    )
% 		),
%  		Ms),
% 	preprocess_messages_terms(Ms,Cs-Ss-SPSs).

% preprocess_messages_terms([],[]-[]-[]).
% preprocess_messages_terms([m(STEP,_,_,_,MSG,_)|Ms],Cs-Ss-SPSs) :-
% 	preprocess_msg(MSG,STEP,SORT,MCs-MSs-MSPSs),	
% 	build_sort('msg',STEP,SMSG),
% 	build_sort('mstep',STEP,SSTEP),
% 	append([sort(SMSG),sort(SSTEP)], MSs, S1s),
% 	append([super_sort(mstep,SSTEP),super_sort(SMSG,SORT)],MSPSs,SPS1s),
% 	preprocess_messages_terms(Ms,C2s-S2s-SPS2s),
% 	append([constant(STEP,SSTEP),constant(m(SSTEP,mr,mr,mr,SMSG,session),fluent)|MCs],C2s,Cs),
% 	append(S1s, S2s, Ss),
% 	append(SPS1s,SPS2s,SPSs).

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS MESSAGE
%

% NEW
% VERSION 1.2
preprocess_msg(T,Lb,Sort,Cs-Ss-SPSs) :-
	retractall(msg_depth_counter(_)),
	retractall(msg_width_counter(_)),
	assert(msg_depth_counter(1)),
	assert(msg_width_counter(1)),
	!,
	preprocess_msg_1(T,Lb,Sort,Cs-Ss-SPSs),
	retractall(msg_depth_counter(_)),
	retractall(msg_width_counter(_)).

preprocess_msg_1(crypt(PK,MSG),Lb,Sort,
	       [constant(crypt(PKSort,SubSort),Sort)|Cs]-
	       [sort(Sort)|Ss]-
	       [super_sort(knw_el,Sort)|SPSs]) :-
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),
	build_sort(crypt,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(PK,Lb,PKSort,PKCs-PKSs-PKSPSs),
	% Right child
	RightChildWidth is Width * 2,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(RightChildWidth)),	
	preprocess_msg_1(MSG,Lb,SubSort,MCs-MSs-MSPSs),
	append(MCs,PKCs,Cs),
	append(MSs,PKSs,Ss),
	append(MSPSs,PKSPSs,SPSs).

preprocess_msg_1(scrypt(SK,MSG),Lb,Sort,
	       [constant(scrypt(SKSort,SubSort),Sort)|Cs]-
	       [sort(Sort)|Ss]-
	       [super_sort(knw_el,Sort)|SPSs]) :-
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(scrypt,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(SK,Lb,SKSort,SKCs-SKSs-SKSPSs),
	% Right child
	RightChildWidth is Width * 2,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(RightChildWidth)),	
	preprocess_msg_1(MSG,Lb,SubSort,MCs-MSs-MSPSs),
	append(MCs,SKCs,Cs),
	append(MSs,SKSs,Ss),
	append(MSPSs,SKSPSs,SPSs).

preprocess_msg_1(funct(FU,MSG),Lb,Sort,
	       [constant(funct(FUSort,SubSort),Sort)|Cs]-
	       [sort(Sort)|Ss]-
	       [super_sort(knw_el,Sort)|SPSs]) :-
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(funct,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(FU,Lb,FUSort,FUCs-FUSs-FUSPSs),
	% Right child
	RightChildWidth is Width * 2,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(RightChildWidth)),	
	preprocess_msg_1(MSG,Lb,SubSort,MCs-MSs-MSPSs),
	append(MCs,FUCs,Cs),
	append(MSs,FUSs,Ss),
	append(MSPSs,FUSPSs,SPSs).

preprocess_msg_1(c(MSG1,MSG2),Lb,Sort,
	       [constant(c(SubSort1,SubSort2),Sort)|MCs]-
	       [sort(Sort)|MSs]-
	       [super_sort(knw_el,Sort)|MSPSs]) :-
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(pair,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(MSG1,Lb,SubSort1,MC1s-MS1s-MSPS1s),
	% Right child
	RightChildWidth is Width * 2,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(RightChildWidth)),	
	preprocess_msg_1(MSG2,Lb,SubSort2,MC2s-MS2s-MSPS2s),
	append(MC1s,MC2s,MCs),
	append(MS1s,MS2s,MSs),
	append(MSPS1s,MSPS2s,MSPSs).

preprocess_msg_1(rcrypt(MSG1,MSG2),Lb,Sort,
	       [constant(rcrypt(SubSort1,SubSort2),Sort)|MCs]-
	       [sort(Sort)|MSs]-
	       [super_sort(knw_el,Sort)|MSPSs]) :- 
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(rcrypt,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,	
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(MSG1,Lb,SubSort1,MC1s-MS1s-MSPS1s),
	% Right child
	RightChildWidth is Width * 2,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(RightChildWidth)),	
	preprocess_msg_1(MSG2,Lb,SubSort2,MC2s-MS2s-MSPS2s),
	append(MC1s,MC2s,MCs),
	append(MS1s,MS2s,MSs),
	append(MSPS1s,MSPS2s,MSPSs).

preprocess_msg_1(primed(pk(c(C,xTime))),Lb,Sort,
		 [constant(primed(SubSort),Sort)|Cs]-
		 [sort(Sort)|Ss]-
		 [super_sort(knw_el,Sort)|SPSs]) :-
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(fresh_pkinv,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),	
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(pk(c(C,xTime)),Lb,SubSort,Cs-Ss-SPSs).

% F(c(C,xTime))
preprocess_msg_1(T,Lb,Sort,
		 [constant(TC,Sort)|Cs]-
		 [sort(Sort)|Ss]-
		 [super_sort(knw_el,Sort)|SPSs]) :-
	T=..[F,FreshTerm],
	FreshTerm = c(_,xTime),
	member(F,[pk,sk,nonce]),
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(F,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_fresh_term(F,FreshTerm,Lb,SubSort,Cs-Ss-SPSs),
	TC=..[F,SubSort].

preprocess_msg_1(primed(pk(c(PKC,PKC))),Lb,Sort,
	       [constant(primed(SubSort),Sort)|Cs]-
	       [sort(Sort)|Ss]-
	       [super_sort(knw_el,Sort)|SPSs]) :-
	atom(PKC),
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(pkinv_fresh_intruder_const,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),	
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(pk(c(PKC,PKC)),Lb,SubSort,Cs-Ss-SPSs).

% F(c(xC,xC))
preprocess_msg_1(T,Lb,Sort,
	       ConstDs-[sort(Sort)]-[super_sort(knw_el,Sort)]) :-
	T=..[F,c(C,C)],
	is_var(C),
	member(F,[pk,sk,nonce]),
	(
	  (F==pk,TSort=pk_fresh_intruder_const);
	  (F==sk,TSort=sk_fresh_intruder_const);
	  (F==nonce,TSort=nonce_fresh_intruder_const)
	),!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),
	build_sort(TSort,Lb,TTSort),
	build_sort(TTSort,Depth,TTTSort),
	build_sort(TTTSort,Width,Sort),
	TC=..[F,fresh_intruder_const],
	(value(intruder_const,on) ->
	    TC=..[F,fresh_intruder_const],
	    ConstDs = [constant(TC,Sort)];
	    ConstDs = []
	).

% F(c(C,C))
preprocess_msg_1(T,Lb,Sort,
	       ConstDs-
	       [sort(Sort),sort(SubSort),sort(SubSubSort)]-
	       [super_sort(knw_el,Sort)]) :-
	T=..[F,c(C,C)],
	\+is_var(C),
	atom(C),
	member(F,[pk,sk,nonce]),
	(
	  (F==pk,TSort=pk_fresh_intruder_const);
	  (F==sk,TSort=sk_fresh_intruder_const);
	  (F==nonce,TSort=nonce_fresh_intruder_const)
	),!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),
	build_sort(TSort,Lb,TTSort),
	build_sort(TTSort,Depth,TTTSort),
	build_sort(TTTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	build_sort(fresh_intruder_const,Lb,TSubSort),
	build_sort(TSubSort,NextDepth,TTSubSort),
	build_sort(TTSubSort,LeftChildWidth,SubSort),
	NextNextDepth is NextDepth + 1,
	LeftGrandChildWidth is (LeftChildWidth * 2) - 1,
	build_sort(intruder_const,Lb,TSubSubSort),
	build_sort(TSubSubSort,NextNextDepth,TTSubSubSort),
	build_sort(TTSubSubSort,LeftGrandChildWidth,SubSubSort),
	TC=..[F,SubSort],
	(value(intruder_const,on) ->
	    ConstDs = [
		       constant(TC,Sort),
		       constant(c(SubSubSort,SubSubSort),SubSort),
		       constant(C,SubSubSort)]
	;
	    ConstDs = [
		       constant(TC,Sort),
		       constant(c(SubSubSort,SubSubSort),SubSort)]
	).

	

% % TODO: Make precise language 
% preprocess_msg_1(nonce(c(NC,NC)),_,nonce,
% 	       []-[]-[super_sort(knw_el,nonce)]) :-
% %	value(intruder_const,on),
% 	atom(NC),
% 	!,
% 	retract(msg_depth_counter(_)),
% 	retract(msg_width_counter(_)).

% preprocess_msg_1(sk(c(SKC,SKC)),_,sk,
% 	       []-[]-[super_sort(knw_el,sk)]) :-
% %	value(intruder_const,on),
% 	atom(SKC),
% 	!,
% 	retract(msg_depth_counter(_)),
% 	retract(msg_width_counter(_)).

% preprocess_msg_1(pk(c(PKC,PKC)),_,pk,
% 	       []-[]-[super_sort(knw_el,pk)]) :-
% %	value(intruder_const,on),
% 	atom(PKC),
% 	!,
% 	retract(msg_depth_counter(_)),
% 	retract(msg_width_counter(_)).

preprocess_msg_1(mr(C),_,mr,[]-[]-[super_sort(knw_el,mr)]) :- 
	is_var(C),!,
	retract(msg_depth_counter(_)),
	retract(msg_width_counter(_)).
preprocess_msg_1(pk(C),_,pk,[]-[]-[super_sort(knw_el,pk)]) :-
	is_var(C),!,
	retract(msg_depth_counter(_)),
	retract(msg_width_counter(_)).

preprocess_msg_1(primed(pk(C)),_,pkinv,[]-[]-[super_sort(knw_el,pkinv)]) :-
	is_var(C),!,
	retract(msg_depth_counter(_)),
	retract(msg_width_counter(_)).

preprocess_msg_1(sk(C),_,sk,[]-[]-[super_sort(knw_el,sk)]) :-
	is_var(C),!,
	retract(msg_depth_counter(_)),
	retract(msg_width_counter(_)).
preprocess_msg_1(fu(C),_,fu,[]-[]-[super_sort(knw_el,fu)]) :-
	is_var(C),!,
	retract(msg_depth_counter(_)),
	retract(msg_width_counter(_)).
preprocess_msg_1(nonce(C),_,nonce,[]-[]-[super_sort(knw_el,nonce)]) :-
	is_var(C),!,
	retract(msg_depth_counter(_)),
	retract(msg_width_counter(_)).
preprocess_msg_1(primed(pk(C)),Lb,Sort,
		 [constant(primed(SubSort),Sort)|Cs]-
		 [sort(Sort)|Ss]-
		 [super_sort(knw_el,Sort)|SPSs]) :-
	\+is_var(C),
	atom(C),
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(pkinv,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	assert(msg_depth_counter(NextDepth)),
	assert(msg_width_counter(LeftChildWidth)),
	preprocess_msg_1(pk(C),Lb,SubSort,Cs-Ss-SPSs).

% F(C) where F can be [pk,sk,nonce,fu,mr]
preprocess_msg_1(T,Lb,Sort,
		 [constant(TC,Sort),
		  constant(C,SubSort)]-
		 [sort(Sort),sort(SubSort)]-
		 [super_sort(knw_el,Sort)]) :-
	T=..[F,C],
	\+is_var(C),
	atom(C),
	(
	  (F==pk,LbSubSort=public_key_id);
	  (F==sk,LbSubSort=symmetric_key_id);
	  (F==nonce,LbSubSort=nonce_id);
	  (F==fu,LbSubSort=fu_term);
	  (F==mr,LbSubSort=user)		  
	),
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),		
	build_sort(F,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	LeftChildWidth is (Width * 2) - 1,
	build_sort(LbSubSort,Lb,TSubSort),
	build_sort(TSubSort,NextDepth,TTSubSort),
	build_sort(TTSubSort,LeftChildWidth,SubSort),
	TC=..[F,SubSort].

preprocess_msg_1(MSG,_,atom,[]-[]-[super_sort(knw_el,atom)]) :- 
	is_var(MSG),!,
	retract(msg_depth_counter(_)),
	retract(msg_width_counter(_)).

preprocess_fresh_term(Type,c(C,xTime),Lb,Sort,
		      [constant(c(SubSort,fresh_property),Sort)]-
		      [sort(Sort)]-
		      []) :-		     
	is_var(C),
	(
	  (Type==pk,SubSort=fresh_public_key_id);
	  (Type==sk,SubSort=fresh_symmetric_key_id);
	  (Type==nonce,SubSort=fresh_nonce_id)
	),!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),
	build_sort(fresh_term,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort).
	
preprocess_fresh_term(Type,c(C,xTime),Lb,Sort,
		      [constant(c(SubSort,fresh_property),Sort),
		       constant(C,SubSort)]-
		      [sort(Sort),sort(SubSort)]-
		      []) :-		     		     
	\+is_var(C),
	atom(C),
	(
	  (Type==pk,LbSubSort=fresh_public_key_id);
	  (Type==sk,LbSubSort=fresh_symmetric_key_id);
	  (Type==nonce,LbSubSort=fresh_nonce_id)
	),
	!,
	retract(msg_depth_counter(Depth)),
	retract(msg_width_counter(Width)),	
	build_sort(fresh_term,Lb,TSort),
	build_sort(TSort,Depth,TTSort),
	build_sort(TTSort,Width,Sort),
	NextDepth is Depth + 1,
	% Left Child
	LeftChildWidth is (Width * 2) - 1,
	build_sort(LbSubSort,Lb,TSubSort),
	build_sort(TSubSort,NextDepth,TTSubSort),
	build_sort(TTSubSort,LeftChildWidth,SubSort).

% % VERSION 1.1
% preprocess_msg(T,Lb,Sort,Cs-Ss-SPSs) :-
% 	retractall(msg_depth_counter(_)),
% 	retractall(msg_width_counter(_,_)),
% 	assert(msg_depth_counter(1)),
% 	assert(msg_width_counter(1,1)),
% 	!,
% 	preprocess_msg_1(T,Lb,Sort,Cs-Ss-SPSs),
% 	retractall(msg_depth_counter(_)),
% 	retractall(msg_width_counter(_,_)).

% preprocess_msg_1(crypt(PK,MSG),Lb,Sort,
% 	       [constant(crypt(PKSort,SubSort),Sort)|Cs]-
% 	       [sort(Sort)|Ss]-
% 	       [super_sort(knw_el,Sort)|SPSs]) :-
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(crypt,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_msg_1(PK,Lb,PKSort,PKCs-PKSs-PKSPSs),
% 	% Right child
% 	assert(msg_depth_counter(NextDepth)),
% 	preprocess_msg_1(MSG,Lb,SubSort,MCs-MSs-MSPSs),
% 	append(MCs,PKCs,Cs),
% 	append(MSs,PKSs,Ss),
% 	append(MSPSs,PKSPSs,SPSs).

% preprocess_msg_1(scrypt(SK,MSG),Lb,Sort,
% 	       [constant(scrypt(SKSort,SubSort),Sort)|Cs]-
% 	       [sort(Sort)|Ss]-
% 	       [super_sort(knw_el,Sort)|SPSs]) :-
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(scrypt,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_msg_1(SK,Lb,SKSort,SKCs-SKSs-SKSPSs),
% 	assert(msg_depth_counter(NextDepth)),
% 	preprocess_msg_1(MSG,Lb,SubSort,MCs-MSs-MSPSs),
% 	append(MCs,SKCs,Cs),
% 	append(MSs,SKSs,Ss),
% 	append(MSPSs,SKSPSs,SPSs).

% preprocess_msg_1(funct(FU,MSG),Lb,Sort,
% 	       [constant(funct(FUSort,SubSort),Sort)|Cs]-
% 	       [sort(Sort)|Ss]-
% 	       [super_sort(knw_el,Sort)|SPSs]) :-
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(funct,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_msg_1(FU,Lb,FUSort,FUCs-FUSs-FUSPSs),
% 	assert(msg_depth_counter(NextDepth)),
% 	preprocess_msg_1(MSG,Lb,SubSort,MCs-MSs-MSPSs),
% 	append(MCs,FUCs,Cs),
% 	append(MSs,FUSs,Ss),
% 	append(MSPSs,FUSPSs,SPSs).

% preprocess_msg_1(c(MSG1,MSG2),Lb,Sort,
% 	       [constant(c(SubSort1,SubSort2),Sort)|MCs]-
% 	       [sort(Sort)|MSs]-
% 	       [super_sort(knw_el,Sort)|MSPSs]) :-
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(pair,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_msg_1(MSG1,Lb,SubSort1,MC1s-MS1s-MSPS1s),
% 	assert(msg_depth_counter(NextDepth)),
% 	preprocess_msg_1(MSG2,Lb,SubSort2,MC2s-MS2s-MSPS2s),
% 	append(MC1s,MC2s,MCs),
% 	append(MS1s,MS2s,MSs),
% 	append(MSPS1s,MSPS2s,MSPSs).

% preprocess_msg_1(rcrypt(MSG1,MSG2),Lb,Sort,
% 	       [constant(rcrypt(SubSort1,SubSort2),Sort)|MCs]-
% 	       [sort(Sort)|MSs]-
% 	       [super_sort(knw_el,Sort)|MSPSs]) :- 
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(rcrypt,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_msg_1(MSG1,Lb,SubSort1,MC1s-MS1s-MSPS1s),
% 	assert(msg_depth_counter(NextDepth)),
% 	preprocess_msg_1(MSG2,Lb,SubSort2,MC2s-MS2s-MSPS2s),
% 	append(MC1s,MC2s,MCs),
% 	append(MS1s,MS2s,MSs),
% 	append(MSPS1s,MSPS2s,MSPSs).

% preprocess_msg_1(primed(pk(c(C,xTime))),Lb,Sort,
% 		 [constant(primed(SubSort),Sort)|Cs]-
% 		 [sort(Sort)|Ss]-
% 		 [super_sort(knw_el,Sort)|SPSs]) :-
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(fresh_pkinv,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),	
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_msg_1(pk(c(C,xTime)),Lb,SubSort,Cs-Ss-SPSs).

% % F(c(C,xTime))
% preprocess_msg_1(T,Lb,Sort,
% 		 [constant(TC,Sort)|Cs]-
% 		 [sort(Sort)|Ss]-
% 		 [super_sort(knw_el,Sort)|SPSs]) :-
% 	T=..[F,FreshTerm],
% 	FreshTerm = c(_,xTime),
% 	member(F,[pk,sk,nonce]),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(F,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_fresh_term(F,FreshTerm,Lb,SubSort,Cs-Ss-SPSs),
% 	TC=..[F,SubSort].

% % TODO: Make precise language 
% preprocess_msg_1(nonce(c(NC,NC)),_,nonce,
% 	       []-[]-[super_sort(knw_el,nonce)]) :-
% %	value(intruder_const,on),
% 	atom(NC),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).

% preprocess_msg_1(sk(c(SKC,SKC)),_,sk,
% 	       []-[]-[super_sort(knw_el,sk)]) :-
% %	value(intruder_const,on),
% 	atom(SKC),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).

% preprocess_msg_1(pk(c(PKC,PKC)),_,pk,
% 	       []-[]-[super_sort(knw_el,pk)]) :-
% %	value(intruder_const,on),
% 	atom(PKC),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).

% preprocess_msg_1(primed(pk(c(PKC,PKC))),_,pk,
% 	       []-[]-[super_sort(knw_el,pk)]) :-
% %	value(intruder_const,on),
% 	atom(PKC),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).

% preprocess_msg_1(mr(C),_,mr,[]-[]-[super_sort(knw_el,mr)]) :- 
% 	is_var(C),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).
% preprocess_msg_1(pk(C),_,pk,[]-[]-[super_sort(knw_el,pk)]) :-
% 	is_var(C),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).
% preprocess_msg_1(primed(pk(C)),_,pkinv,[]-[]-[super_sort(knw_el,pkinv)]) :-
% 	is_var(C),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width1)),
% 	Width2 is Width1 + 1,
% 	assert(msg_width_counter(Depth,Width2)).
% preprocess_msg_1(sk(C),_,sk,[]-[]-[super_sort(knw_el,sk)]) :-
% 	is_var(C),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).
% preprocess_msg_1(fu(C),_,fu,[]-[]-[super_sort(knw_el,fu)]) :-
% 	is_var(C),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).
% preprocess_msg_1(nonce(C),_,nonce,[]-[]-[super_sort(knw_el,nonce)]) :-
% 	is_var(C),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).
% preprocess_msg_1(primed(pk(C)),Lb,Sort,
% 		 [constant(primed(SubSort),Sort)|Cs]-
% 		 [sort(Sort)|Ss]-
% 		 [super_sort(knw_el,Sort)|SPSs]) :-
% 	\+is_var(C),
% 	atom(C),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(pkinv,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	assert(msg_depth_counter(NextDepth)),
% 	(\+msg_width_counter(NextDepth,_) ->
% 	    assert(msg_width_counter(NextDepth,1))
% 	;
% 	    true
% 	),
% 	preprocess_msg_1(pk(C),Lb,SubSort,Cs-Ss-SPSs).

% % F(C) where F can be [pk,sk,nonce,fu,mr]
% preprocess_msg_1(T,Lb,Sort,
% 		 [constant(TC,Sort),
% 		  constant(C,SubSort)]-
% 		 [sort(Sort),sort(SubSort)]-
% 		 [super_sort(knw_el,Sort)]) :-
% 	T=..[F,C],
% 	\+is_var(C),
% 	atom(C),
% 	(
% 	  (F==pk,LbSubSort=public_key_id);
% 	  (F==sk,LbSubSort=symmetric_key_id);
% 	  (F==nonce,LbSubSort=nonce_id);
% 	  (F==fu,LbSubSort=fu_term);
% 	  (F==mr,LbSubSort=user)		  
% 	),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(F,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	(retract(msg_width_counter(NextDepth,NextDepthWidth)) ->
% 	    true
% 	;
% 	    NextDepthWidth = 1
% 	),
% 	build_sort(LbSubSort,Lb,TSubSort),
% 	build_sort(TSubSort,NextDepth,TTSubSort),
% 	build_sort(TTSubSort,NextDepthWidth,SubSort),
% 	TC=..[F,SubSort],
% 	NextDepthNextWidth is NextDepthWidth + 1,
% 	assert(msg_width_counter(NextDepth,NextDepthNextWidth)).

% preprocess_msg_1(MSG,_,atom,[]-[]-[super_sort(knw_el,atom)]) :- 
% 	is_var(MSG),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)).

% preprocess_fresh_term(Type,c(C,xTime),Lb,Sort,
% 		      [constant(c(SubSort,fresh_property),Sort)]-
% 		      [sort(Sort)]-
% 		      [super_sort(knw_el,Sort)]) :-
% 	is_var(C),
% 	(
% 	  (Type==pk,SubSort=fresh_public_key_id);
% 	  (Type==sk,SubSort=fresh_symmetric_key_id);
% 	  (Type==nonce,SubSort=fresh_nonce_id)
% 	),!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(fresh_term,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	(retract(msg_width_counter(NextDepth,NextDepthWidth)) ->
% 	    true
% 	;
% 	    NextDepthWidth = 1
% 	),
% 	NextDepthNextWidth is NextDepthWidth + 2,
% 	assert(msg_width_counter(NextDepth,NextDepthNextWidth)).
	
% preprocess_fresh_term(Type,c(C,xTime),Lb,Sort,
% 		      [constant(c(SubSort,fresh_property),Sort),
% 		       constant(C,SubSort)]-
% 		      [sort(Sort),sort(SubSort)]-
% 		      [super_sort(knw_el,Sort)]) :-
% 	\+is_var(C),
% 	atom(C),
% 	(
% 	  (Type==pk,LbSubSort=fresh_public_key_id);
% 	  (Type==sk,LbSubSort=fresh_symmetric_key_id);
% 	  (Type==nonce,LbSubSort=fresh_nonce_id)
% 	),
% 	!,
% 	retract(msg_depth_counter(Depth)),
% 	retract(msg_width_counter(Depth,Width)),	
% 	NextWidth is Width + 1,
% 	assert(msg_width_counter(Depth,NextWidth)),
% 	build_sort(fresh_term,Lb,TSort),
% 	build_sort(TSort,Depth,TTSort),
% 	build_sort(TTSort,Width,Sort),
% 	NextDepth is Depth + 1,
% 	(retract(msg_width_counter(NextDepth,NextDepthWidth)) ->
% 	    true
% 	;
% 	    NextDepthWidth = 1
% 	),
% 	build_sort(LbSubSort,Lb,TSubSort),
% 	build_sort(TSubSort,NextDepth,TTSubSort),
% 	build_sort(TTSubSort,NextDepthWidth,SubSort),
% 	NextDepthNextWidth is NextDepthWidth + 2,
% 	assert(msg_width_counter(NextDepth,NextDepthNextWidth)).

% % OLD VERSION: without analysis of bacis terms with constants
% preprocess_msg(T,LB,SORT,Cs-Ss-SPSs) :-
% 	assert(internal_counter(1)),
% 	!,
% 	preprocess_msg_1(T,LB,SORT,Cs-Ss-SPSs),
% 	retractall(internal_counter(_)).
	
% preprocess_msg_1(crypt(_,MSG),LB,SORT,
% 	       [constant(crypt(pk,SUBSORT),SORT)|MCs]-
% 	       [sort(SORT)|MSs]-
% 	       [super_sort(knw_el,SORT)|MSPSs]) :- 
% 	build_sort(crypt,LB,TmpSORT),
% 	retract(internal_counter(N)),
% 	build_sort(TmpSORT,N,SORT),
% 	M is N + 1,
% 	assert(internal_counter(M)),
% 	preprocess_msg_1(MSG,LB,SUBSORT,MCs-MSs-MSPSs).

% preprocess_msg_1(scrypt(_,MSG),LB,SORT,
% 	       [constant(scrypt(sk,SUBSORT),SORT)|MCs]-
% 	       [sort(SORT)|MSs]-
% 	       [super_sort(knw_el,SORT)|MSPSs]) :- 
% 	build_sort(scrypt,LB,TmpSORT),
% 	retract(internal_counter(N)),
% 	build_sort(TmpSORT,N,SORT),
% 	M is N + 1,
% 	assert(internal_counter(M)),
% 	preprocess_msg_1(MSG,LB,SUBSORT,MCs-MSs-MSPSs).

% preprocess_msg_1(funct(_,MSG),LB,SORT,
% 	       [constant(funct(fu,SUBSORT),SORT)|MCs]-
% 	       [sort(SORT)|MSs]-
% 	       [super_sort(knw_el,SORT)|MSPSs]) :- 
% 	build_sort(funct,LB,TmpSORT),
% 	retract(internal_counter(N)),
% 	build_sort(TmpSORT,N,SORT),
% 	M is N + 1,
% 	assert(internal_counter(M)),
% 	preprocess_msg_1(MSG,LB,SUBSORT,MCs-MSs-MSPSs).

% preprocess_msg_1(c(MSG1,MSG2),LB,SORT,
% 	       [constant(c(SUBSORT1,SUBSORT2),SORT)|MCs]-
% 	       [sort(SORT)|MSs]-
% 	       [super_sort(knw_el,SORT)|MSPSs]) :- 
% 	build_sort(pair,LB,TmpSORT),
% 	retract(internal_counter(N)),
% 	build_sort(TmpSORT,N,SORT),
% 	M is N + 1,
% 	assert(internal_counter(M)),
% 	preprocess_msg_1(MSG1,LB,SUBSORT1,MC1s-MS1s-MSPS1s),
% 	preprocess_msg_1(MSG2,LB,SUBSORT2,MC2s-MS2s-MSPS2s),
% 	append(MC1s,MC2s,MCs),
% 	append(MS1s,MS2s,MSs),
% 	append(MSPS1s,MSPS2s,MSPSs).

% preprocess_msg_1(rcrypt(MSG1,MSG2),LB,SORT,
% 	       [constant(rcrypt(SUBSORT1,SUBSORT2),SORT)|MCs]-
% 	       [sort(SORT)|MSs]-
% 	       [super_sort(knw_el,SORT)|MSPSs]) :- 
% 	build_sort(rcrypt,LB,TmpSORT),
% 	retract(internal_counter(N)),
% 	build_sort(TmpSORT,N,SORT),
% 	M is N + 1,
% 	assert(internal_counter(M)),
% 	preprocess_msg_1(MSG1,LB,SUBSORT1,MC1s-MS1s-MSPS1s),
% 	preprocess_msg_1(MSG2,LB,SUBSORT2,MC2s-MS2s-MSPS2s),
% 	append(MC1s,MC2s,MCs),
% 	append(MS1s,MS2s,MSs),
% 	append(MSPS1s,MSPS2s,MSPSs).

% preprocess_msg_1(nonce(c(NC,xTime)),_,nonce,
%    	       []-[]-[super_sort(knw_el,nonce)]) :-
% 	atom(NC),!.

% preprocess_msg_1(sk(c(SKC,xTime)),_,sk,
% 	       []-[]-[super_sort(knw_el,sk)]) :-
% 	atom(SKC),!.

% preprocess_msg_1(pk(c(PKC,xTime)),_,pk,
% 	       []-[]-[super_sort(knw_el,pk)]) :-
% 	atom(PKC),!.

% preprocess_msg_1(primed(pk(c(PKC,xTime))),_,pk,
% 	       []-[]-[super_sort(knw_el,pk)]) :-
% 	atom(PKC),!.

% preprocess_msg_1(nonce(c(NC,NC)),_,nonce,
% 	       []-[]-[super_sort(knw_el,nonce)]) :-
% 	atom(NC),!.

% preprocess_msg_1(sk(c(SKC,SKC)),_,sk,
% 	       []-[]-[super_sort(knw_el,sk)]) :-
% 	atom(SKC),!.

% preprocess_msg_1(pk(c(PKC,PKC)),_,pk,
% 	       []-[]-[super_sort(knw_el,pk)]) :-
% 	atom(PKC),!.

% preprocess_msg_1(primed(pk(c(PKC,PKC))),_,pk,
% 	       []-[]-[super_sort(knw_el,pk)]) :-
% 	atom(PKC),!.

% % TODO: MANAGE THE TYPED VERSION: add case for 'mr',etc

% preprocess_msg_1(mr(C),_,mr,[]-[]-[super_sort(knw_el,mr)]) :- 
% 	atom(C).
% preprocess_msg_1(pk(C),_,pk,[]-[]-[super_sort(knw_el,pk)]) :-
% 	atom(C).
% preprocess_msg_1(primed(pk(C)),_,pk,[]-[]-[super_sort(knw_el,pk)]) :-
% 	atom(C).
% preprocess_msg_1(sk(C),_,sk,[]-[]-[super_sort(knw_el,sk)]) :-
% 	atom(C).
% preprocess_msg_1(fu(C),_,fu,[]-[]-[super_sort(knw_el,fu)]) :-
% 	atom(C).	

% preprocess_msg_1(nonce(_),_,nonce,[]-[]-[super_sort(knw_el,nonce)]).

% preprocess_msg_1(MSG,_,atom,[]-[]-[super_sort(knw_el,atom)]) :- 
% 	is_var(MSG).

%
%          END: PREPROCESS MESSAGE
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS INITIAL STATE 
%

preprocess_initial_state(LRRs,D1s,Ds) :-
 	category_label(CRR,init),
 	findall(w(_,_,R,_,IK,_,SES), % (R-IK-1-SES),
 		(
		    member(lrr(_,CRR,LHS,[]),LRRs),
		    member(w(_,_,R,_,IK,_,SES),LHS)
		),
 		Ws),
	preprocess_initial_state_terms(Ws,D1s,D2s),
%	remove_duplicates(D2s,Ds).
	remove_duplicates(D2s,D3s),	
	append(D1s,D3s,D4s),
 	findall(IIK,
 		(
		    member(lrr(_,CRR,LHS,[]),LRRs),
		    member(i(IIK),LHS)
		),
 		IIKs),
	preprocess_intruder_initial_knowledge(IIKs,D4s,D5s),
	append(D3s,D5s,Ds).

preprocess_initial_state_terms([],_,[]).
% Initial knowledge empty
preprocess_initial_state_terms(
	   [w(_,_,mr(R),_,[],_,SES)|Ws],D1s,Ds) :-
	pif2sate_gsession(SES,TSES),
	pif2sate_gterm(R,TR),
	build_repetition_session(TSES,DRepSes),
	build_sort('session_base',TSES,SortSessionBase),
	build_sort('session',TSES,SortSession),
	% session_i_without_rep_j
	build_sort('session',TSES,TSortSessionWithoutLast),
	build_sort(TSortSessionWithoutLast,'without_rep_1',SortSessionWithoutLast),
	% inknw_i_el_1
	build_sort('inknw',TR,Tmp1),
	build_sort(Tmp1,TSES,Tmp2),
	build_sort(Tmp2,'el_1',IK_EL),
	build_sort('mr',TR,MR),	
	build_sort('user',TR,USER),
	D2s= [
	      sort(USER),constant(TR,USER),
	      sort(MR),constant(mr(USER),MR),	      	      
	      sort(IK_EL),super_sort(IK_EL,knw_el_empty),
	      sort(inknw_index_1),constant(1,inknw_index_1),
	      constant(inknw(MR,IK_EL,inknw_index_1,SortSessionBase),fluent),
	      sort(SortSessionBase),
	      constant(TSES,SortSessionBase),
      	      sort(SortSessionWithoutLast),
	      super_sort(SortSessionWithoutLast,SortSessionBase),
      	      super_sort(session_without_rep_1,SortSessionWithoutLast),
      	      super_sort(SortSessionWithoutLast,SortSessionBase),	      
	      sort(SortSession),
	      super_sort(session,SortSession),
	      super_sort(SortSession,SortSessionBase),
	      super_sort(session_base,SortSessionBase)
	      |DRepSes],
	preprocess_initial_state_terms(Ws,D1s,D3s),
	append(D2s,D3s,Ds).
% Initial knowledge not empty
preprocess_initial_state_terms(
	   [w(_,_,R,_,[IK|IKs],_,SES)|Ws],D1s,
           Ds) :-
	preprocess_initial_state_term(w(_,_,R,_,[IK|IKs],_,SES),D1s,D2s),
	preprocess_initial_state_terms(Ws,D1s,D3s),
	append(D2s,D3s,Ds).

preprocess_initial_state_term(w(_,_,mr(R),_,IKs,_,SES),D1s,Ds) :-
	pif2sate_gsession(SES,TSES),
	pif2sate_gterm(R,TR),
	build_repetition_session(TSES,DRepSes),
	build_sort('session_base',TSES,SortSessionBase),
	% session_i_without_rep_j
	build_sort('session',TSES,TSortSessionWithoutLast),
	build_sort(TSortSessionWithoutLast,'without_rep_1',SortSessionWithoutLast),
	build_sort('session',TSES,SortSession),
	build_sort('mr',TR,MR),	
	build_sort('user',TR,USER),
	D2s= [
	      sort(USER),constant(TR,USER),
	      sort(MR),constant(mr(USER),MR),	      	      
	      sort(SortSessionBase),
	      constant(TSES,SortSessionBase),
	      sort(SortSession),
	      super_sort(session,SortSession),
      	      sort(SortSessionWithoutLast),	      
      	      super_sort(session_without_rep_1,SortSessionWithoutLast),
      	      super_sort(SortSessionWithoutLast,SortSessionBase),	      
	      super_sort(SortSession,SortSessionBase),
	      super_sort(session_base,SortSessionBase)
	      |DRepSes],
	preprocess_initial_knowledge(w(_,_,mr(R),_,IKs,_,SES),1,D1s,D3s),
	append(D2s,D3s,Ds).

preprocess_initial_knowledge(w(_,_,_,_,[],_,_),_,_,[]).
preprocess_initial_knowledge(w(_,_,mr(R),_,[IK|IKs],_,SES),N,D1s,Ds) :-
%	preprocess_msg(IK,inknw,SORT,C1s-S1s-SPS1s),
%	append(C1s,S1s,D2s),
%	append(D2s,SPS1s,D3s),
	pif2sate_gterm(R,TR),
	pif2sate_gsession(SES,TSES),
	build_sort('session_base',TSES,SortSessionBase),	
	build_sort('mr',TR,MR),
	build_sort('inknw_index',N,INDEX),
	build_sort('inknw',TR,Tmp1),
	build_sort(Tmp1,TSES,Tmp2),
	build_sort(Tmp2,'el',Tmp3),
	build_sort(Tmp3,N,Lb),
	%
	preprocess_msg(IK,Lb,IK_EL,IKCs-IKSs-IKSPSs),
	append(IKCs,IKSs,TIKDs),
	append(TIKDs,IKSPSs,D4s),
	%
% 	build_language_term(IK,Lb,IK_EL,D2s),
% 	findall(SubS,member(sort(SubS),D2s),SubSs),
% 	build_super_sort('knw_el',SubSs,D3s),
% 	append(D2s,D3s,D4s),
	%
	D5s = [
	       sort(INDEX),constant(N,INDEX),
	       constant(inknw(MR,IK_EL,INDEX,SortSessionBase),fluent),
	       super_sort(inknw_el,IK_EL)|D4s],
	M is N + 1,
	preprocess_initial_knowledge(w(_,_,mr(R),_,IKs,_,SES),M,D1s,D6s),
	append(D5s,D6s,Ds).

preprocess_intruder_initial_knowledge(IIKs,D1s,Ds) :-
	preprocess_intruder_initial_knowledge(IIKs,D1s,1,Ds).
preprocess_intruder_initial_knowledge([],_,_,[]).
preprocess_intruder_initial_knowledge([IIK|IIKs],D1s,N,Ds) :-
	build_sort('intruder_initial_knowledge',N,Lb),
	%
	preprocess_msg(IIK,Lb,_,IIKCs-IIKSs-IIKSPSs),
	append(IIKCs,IIKSs,TIIKDs),
	append(TIIKDs,IIKSPSs,D4s),
	%
% 	build_language_term(IIK,Lb,_,D2s),
% 	findall(SubS,member(sort(SubS),D2s),SubSs),
% 	build_super_sort('knw_el',SubSs,D3s),
% 	append(D2s,D3s,D4s),
	M is N + 1,
	preprocess_intruder_initial_knowledge(IIKs,D1s,M,D5s),
	append(D4s,D5s,Ds).
	

%
%          END: PREPROCESS INITIAL STATE 
%-----------------------------------------------------------------------

%
%          END: PREPROCESS MESSAGES 
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: BUILD INTRUDER KNOWLEDGE LANGUAGE
%

remove_intruder_knowledge_redundancies(PreDs,D1s,D2s) :-
	value(term_depth_bound,N),
	assert_declaration_list(PreDs),
	assert_declaration_list(D1s),
	assert_redundant_declarations(knw_el,N),
	get_redundant_declarations(RDs),
	delete_sublist(RDs,D1s,D2s),
	retractall_declarations.

%-----------------------------------------------------------------------
%        BEGIN: REDUNDANT DECLARATIONS
%

assert_redundant_declarations([],_).
assert_redundant_declarations([Sort|Sorts],N) :-
	assert_redundant_declarations(Sort,N),
	assert_redundant_declarations(Sorts,N).

assert_redundant_declarations(Sort,N) :-
	\+is_list(Sort),
	findall(SubSort,
		(
		  (
		    constant(CD,Sort),
		    CD=..[_|TmpSubSorts],
		    member(SubSort,TmpSubSorts)
		  )
		;
		  super_sort(Sort,SubSort)
		),
		TmpSubSorts
	       ),
	M is N - 1,
	remove_duplicates(TmpSubSorts,SubSorts),
	assert_redundant_declarations(SubSorts,M),
	findall(constant(CD,Sort),
		constant(CD,Sort),
		CDs),
	findall(super_sort(Sort,SPSD),
		super_sort(Sort,SPSD),
		SPSDs),
	append(CDs,SPSDs,Ds),
	assert_redundant_declarations(Sort,Ds,N).

% % Version 1.0
% assert_redundant_declarations(Sort,N) :-
% 	\+is_list(Sort),
% 	findall(constant(CD,Sort),
% 		constant(CD,Sort),
% 		CDs),
% 	findall(super_sort(Sort,SPSD),
% 		super_sort(Sort,SPSD),
% 		SPSDs),
% 	append(CDs,SPSDs,Ds),
% 	assert_redundant_declarations(Sort,Ds,N).

% % Version 1.1
% assert_redundant_declarations(_,[],_).
% assert_redundant_declarations(Sort,[constant(C,Sort)|Ds],N) :-
% 	retract(constant(C,Sort)),
% 	C=..[F|Ss],
% 	M is N - 1,
% 	findall(CT,
% 		(
% 		  tuple(Ss,M,Ts),
% 		  CT=..[F|Ts]
% 		),
% 		TmpCTs),
% 	!,
% 	remove_duplicates(TmpCTs,CTs),
% 	(terms_redundant(Sort,CTs,N) ->
% % 	    % DEBUG
% % 	    format("constant(~w,~w)\n",[C,Sort]),
% % 	    %
% 	    assert(redundant_declaration(constant(C,Sort)))
% 	;
% 	    assert(constant(C,Sort))
% 	),
% 	assert_redundant_declarations(Sort,Ds,N).
% assert_redundant_declarations(Sort,[super_sort(Sort,S)|Ds],N) :-
% 	retract(super_sort(Sort,S)),
% 	M is N - 1,
% 	findall(T,
% 		(
% 		  term(S,M,T) % ERROR: PUT N INSTEAD OF M
% 		),
% 		TmpTs),
% 	remove_duplicates(TmpTs,Ts),!,
% 	(terms_redundant(Sort,Ts,N) ->
% % 	    % DEBUG
% % 	    format("super_sort(~w,~w)\n",[Sort,S]),
% % 	    %
% 	    assert(redundant_declaration(super_sort(Sort,S)))
% 	;
% 	    assert(super_sort(Sort,S))
% 	),
% 	assert_redundant_declarations(Sort,Ds,N).

% Version 1.2
assert_redundant_declarations(_,[],_).
assert_redundant_declarations(Sort,[constant(C,Sort)|Ds],N) :-
	retract(constant(C,Sort)),
	(is_not_redundant_declaration(constant(C,Sort),N) ->
	    assert(constant(C,Sort))	    
	;
% 	    % DEBUG
% 	    format("constant(~w,~w)\n",[C,Sort]),
% 	    %
	    assert(redundant_declaration(constant(C,Sort)))
	),
	assert_redundant_declarations(Sort,Ds,N).

assert_redundant_declarations(Sort,[super_sort(Sort,S)|Ds],N) :-
	retract(super_sort(Sort,S)),
	(is_not_redundant_declaration(super_sort(Sort,S),N) ->
	    assert(super_sort(Sort,S))
	;
% 	    % DEBUG
% 	    format("super_sort(~w,~w)\n",[Sort,S]),
% 	    %
	    assert(redundant_declaration(super_sort(Sort,S)))
	),
	assert_redundant_declarations(Sort,Ds,N).

is_not_redundant_declaration(constant(C,Sort),N) :-
	C=..[F|Ss],
	M is N - 1,
	!,
	tuple(Ss,M,Ts),
	CT=..[F|Ts],
	\+term(Sort,N,CT).

is_not_redundant_declaration(super_sort(Sort,S),N) :-
	term(S,N,CT),
	\+term(Sort,N,CT).

get_redundant_declarations([RD|RDs]) :-
	retract(redundant_declaration(RD)),
	get_redundant_declarations(RDs).
get_redundant_declarations([]) :- !.
	
terms_redundant(_,[],_).
terms_redundant(Sort,[T|Ts],N) :-
	term(Sort,N,T),
	terms_redundant(Sort,Ts,N).

%
%          END: REDUNDANT DECLARATIONS
%-----------------------------------------------------------------------


% Build a precise intruder knowledge language.
% NO EFFICIENT during the SAT Encoding!
build_intruder_knowledge(Ds,IKs) :-
	assert_declaration_list(Ds),
	value(term_depth_bound,N),
	findall(KT,term(knw_el,N,KT),TmpKTs),
	remove_duplicates(TmpKTs,KTs),
	build_language_terms(KTs,intr_knw_el,1,Ss,IK1s),
	build_super_sort(intr_knw_el,Ss,IK2s),
	append(IK1s,IK2s,IKs),
	retractall_declarations.

%
%          END: BUILD INTRUDER KNOWLEDGE LANGUAGE
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS AUTHENTICATION TERMS
%

% [LC]: Assumption: for each witness(A,B,ID,T) we define
%       only one request(B,A,ID,T)
preprocess_authentication(LRRs,D1s,Ds) :-
 	category_label(CAT,rules),	
 	findall(witness(A,B,ID,MSG),
 		(
		  member(lrr(_,CAT,LHS,RHS),LRRs),
		  append(LHS,RHS,LIST),
		  member(witness(A,B,ID,MSG),LIST)
		),
 		TmpTs
	       ),
%  	findall(T,
%  		(
% 		  member(lrr(_,CAT,LHS,RHS),LRRs),
% 		  append(LHS,RHS,LIST),
% 		  member(T,LIST),		  
%  		  (
%  		    T=witness(A,B,ID,MSG)
%   		  ;
%   		    T=request(B,A,ID,MSG)
%  		  )
% 		),
%  		TmpTs
% 	       ),
	remove_duplicates(TmpTs,Ts),
	(Ts \= [] ->
	    set(authenticate_fluents,on)
	; 
	    set(authenticate_fluents,off)
	),
	preprocess_authentication_terms(Ts,1,D1s,TmpDs),
	remove_duplicates(TmpDs,Ds).

preprocess_authentication_terms([],_,_,[]).
preprocess_authentication_terms([T|Ts],N,PreDs,Ds) :-
	preprocess_authentication_term(T,N,PreDs,D1s),
	M is N + 1,
	preprocess_authentication_terms(Ts,M,PreDs,D2s),
	append(D1s,D2s,Ds).

preprocess_authentication_term(witness(_,_,ID,T),N,
			       _,
			       [constant(witness(mr_honest,mr,SortID,SortT),fluent),
				constant(request(mr,mr_honest,SortID,SortT),fluent),
				constant(ID,SortID),
				sort(SortID),
				sort(SortT),
				sort(authentication_term),
				sort(authentication_id),				
				super_sort(authentication_term,SortT),
				super_sort(authentication_id,SortID)
				|Ds]
			      ) :-
	is_constant(ID),
	build_sort(authentication_id,N,SortID),
	build_sort(authentication_term,N,TmpSortT),
	preprocess_msg(T,TmpSortT,SortT,Cs-Ss-SPSs),
	append(Cs,Ss,TmpDs),
	append(TmpDs,SPSs,Ds).

% preprocess_authentication_term(request(_,_,ID,T),N,
% 			       PreDs,
% 			       [constant(request(mr,mr_honest,SortID,SortT),fluent),
% 				sort(SortID),
% 				sort(SortT)|Ds]
% 			      ) :-
% 	is_constant(ID),
% 	build_sort(authentication_id,N,SortID),
% 	build_sort(authentication_term,N,TmpSortT),
% 	preprocess_msg(T,TmpSortT,SortT,Cs-Ss-SPSs),
% 	append(Cs,Ss,TmpDs),
% 	append(TmpDs,SPSs,Ds).

%
%          END: PREPROCESS AUTHENTICATION TERMS
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS SECRECY TERMS
%

% [LC]: Assumption: for each secret(T,f(Ses)) we define:
%              secret(T,SesBase) and
%              give(T,SesBase)
%       where SesBase is the basic session of Ses
preprocess_secrecy(LRRs,D1s,Ds) :-
 	category_label(CAT,rules),	
 	findall(secret(T,SES),
 		(
		  member(lrr(_,CAT,LHS,RHS),LRRs),
		  append(LHS,RHS,LIST),
		  member(secret(T,SES),LIST)
		),
 		TmpTs
	       ),
	remove_duplicates(TmpTs,Ts),
	(Ts \= [] ->
	    set(secrecy_fluents,on)
	; 
	    set(secrecy_fluents,off)
	),
	preprocess_secrecy_terms(Ts,1,D1s,TmpDs),
	remove_duplicates(TmpDs,Ds).	

preprocess_secrecy_terms([],_,_,[]).
preprocess_secrecy_terms([T|Ts],N,PreDs,Ds) :-
	preprocess_secrecy_term(T,N,PreDs,D1s),
	M is N + 1,
	preprocess_secrecy_terms(Ts,M,PreDs,D2s),
	append(D1s,D2s,Ds).

preprocess_secrecy_term(secret(T,FSes),N,
			       _,
			       [constant(secret(SortT,SortSessionBase),fluent),
				constant(give(SortT,SortSessionBase),fluent),
				sort(SortT),
				sort(secrecy_term),
				super_sort(secrecy_term,SortT)|Ds]
			      ) :-
	(
	  FSes=f(Ses)
	;
	  FSes=Ses
	),
	pif2sate_gsession(Ses,SesBase),
	(is_var(SesBase) ->
	    SortSessionBase = session_base
	;
	    build_sort(session_base,SesBase,SortSessionBase)
	),
	build_sort(secrecy_term,N,TmpSortT),
	preprocess_msg(T,TmpSortT,SortT,Cs-Ss-SPSs),
	append(Cs,Ss,TmpDs),
	append(TmpDs,SPSs,Ds).

%
%          END: PREPROCESS SECRECY TERMS
%-----------------------------------------------------------------------

%
%          END: PREPROCESS
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: FACTs
%

facts(problem(_,LRRs),Ds,Fs) :-
 	category_label(CRR,init),
 	findall(lrr(_,CRR,LHS,[]),
	        member(lrr(_,CRR,LHS,[]),LRRs),
 		ISs),
	pif2sate_initial_states(ISs,Ds,Fs).

pif2sate_initial_states([],_,[]).
pif2sate_initial_states([IS|ISs],Ds,[F|Fs]) :-
	pif2sate_initial_state(IS,Ds,F),
	pif2sate_initial_states(ISs,Ds,Fs).

pif2sate_initial_state(lrr(_,_,LHS,[]),Ds,facts(TLHS)) :-
	vars(lrr(_,_,LHS,[]),Xs),
	sorts(lrr(_,_,LHS,[]),Xs,MAPs),
	add_control_field(MAPs,CMAPs),
	freshness_initialization(Ds,FRs),
	append(LHS,FRs,LHS1),
	pif2sate_fluents(LHS1,CMAPs,_,TLHS).

%
%          END: FACTs
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: ACTIONs
%
actions(problem(_,LRRs),D1s,Ds) :-
 	category_label(CPRR,rules),
 	category_label(CIRR,intruder),
	category_label(CSIMPRR,simplification),
	(
	  (
	    value(authenticate_fluents,on)
	  ;
	    value(secrecy_fluents,on)
	  ) ->
	  set(simplification_rules,on)
	;
	  set(simplification_rules,off)
	),
%	category_label(CINVRR,invariants),
%	category_label(CDRR,decompositions),
 	findall(lrr(LB,CAT,LHS,RSH),
	        (
		  member(lrr(LB,CPRR,LHS,RSH),LRRs),
		  CAT = CPRR
		;
		  member(lrr(LB,CIRR,LHS,RSH),LRRs),
		  CAT = CIRR
		;
		  value(simplification_rules,on),
		  member(lrr(LB,CSIMPRR,LHS,RSH),LRRs),
		  CAT = CSIMPRR
% 		;
% 		  member(lrr(LB,CINVRR,LHS,RSH),LRRs),
%		  CAT = CINVRR
% 		;
% 		  member(lrr(LB,CDRR,LHS,RSH),LRRs),
% 		  CAT = CDRR
		),
 		LRR1s),
	!,
	pif2sate_actions(LRR1s,D1s,TmpDs),
	!,
	post_actions(D1s,TmpDs,Ds),
	retractall(value(simplification_rules,_)),
	retractall(value(authenticate_fluents,_)),
	retractall(value(secrecy_fluents,_)).

% actions(problem(_,LRRs),Cs-As) :-
%  	category_label(CPRR,rules),
%  	category_label(CIRR,intruder),
% %	category_label(CINVRR,invariants),
% 	category_label(CDRR,decompositions),
%  	findall(lrr(LB,_,LHS,RSH),
% 	        (
% 		    member(lrr(LB,CPRR,LHS,RSH),LRRs)
% 		;
% 		    member(lrr(LB,CIRR,LHS,RSH),LRRs)
% % 		;
% % 		    member(lrr(LB,CINVRR,LHS,RSH),LRRs)
% 		;
% 		    member(lrr(LB,CDRR,LHS,RSH),LRRs)
% 		),
%  		LRR1s),
% 	pif2sate_actions(LRR1s,Cs-As).

pif2sate_actions([],_,[]).
pif2sate_actions([LRR|LRRs],D1s,Ds) :- %[C|Cs]-[A|As]) :-
	pif2sate_action(LRR,D1s,D2s),
	pif2sate_actions(LRRs,D1s,D3s),
	append(D2s,D3s,Ds).

pif2sate_action(lrr(LB,CAT,LHS,RHS),D1s,Ds) :-
	% DEBUG
	vars(lrr(_,_,LHS,RHS),Xs),
	sorts(lrr(_,_,LHS,RHS),Xs,MAPs),
	add_control_field(MAPs,CMAP1s),
	pif2sate_fluents(LHS,CMAP1s,CMAP2s,TPRE),
	pif2sate_fluents(RHS,CMAP2s,CMAP3s,TADD),
	% DEL and ADD must to be disjoint
	remove_duplicates(TPRE,PRE),
	TDEL = PRE,
	remove_duplicates(TADD,TTADD),
	get_disjoint_lists(TDEL,TTADD,DEL,ADD),
	( bagof(V,ID^S^member(1-ID-V-S,CMAP3s),Vs) ->
	    true
	;
	    Vs = []
	),
	( bagof(S,ID^V^member(1-ID-V-S,CMAP3s),Ss) ->
	    true
	;
	    Ss = []
	),
	ActionName=..[LB|Vs],
	ActionDecl=..[LB|Ss],
	TmpAct = action(ActionName,true,PRE,ADD,DEL),
 	TmpC = constant(ActionDecl,action),
 	post_pif2sate_action(TmpAct,TmpC,D1s,CMAP3s,CAT,Ds).
% % 	C = constant(ActionDecl,action),
% % 	post_pif2sate_action(TmpAct,D1s,CMAP3s,CAT,Act).

post_pif2sate_action(Act1,Act1Const,D1s,CMAPs,CAT,Ds) :-
	post_pif2sate_action(Act1,Act1Const,D1s,CMAPs,CAT,Acts,ActConsts),
	append_alternation_element(ActConsts,Acts,Ds).

post_pif2sate_action(Act1,ActConst1,D1s,CMAPs,CAT,Acts,ActConsts) :-
	(relation_between_sessions(Act1,CMAPs,Act2) ->
	    true;
	    Act2 = Act1
	),
	(monotonic_fluents(Act2,D1s,Act3) ->
	    true
	;
	    Act3 = Act2
	),
	(freshness_fluents(Act3,D1s,Act4) ->
	    true
	;
	    Act4 = Act3
	),
	(special_purpose_alteration(Act4,ActConst1,CAT,Acts,ActConsts) ->
	    true
	;
	    Acts = [Act4],
	    ActConsts = [ActConst1]	
	).

% Add the freshness checking to the action
freshness_fluents(action(ActName,C,PRE,ADD,DEL),_,action(ActName,C,NewPRE,ADD,NewDEL)) :-
	get_fresh_const(ADD,FCs),
	findall(not_used(FC),
		member(FC,FCs),
		FFs),
	append(FFs,PRE,NewPRE),
	append(FFs,DEL,NewDEL).

get_fresh_const(T,FCs) :-
	get_fresh_const(T,[],FCs),
	!.

get_fresh_const([],_,[]).
get_fresh_const([F|Fs],DoneFCs,FCs) :-
	get_fresh_const(F,DoneFCs,FC1s),
	append(DoneFCs,FC1s,DoneFC1s),
	get_fresh_const(Fs,DoneFC1s,FC2s),
	append(FC1s,FC2s,FCs).

get_fresh_const(c(C,fresh),DoneFCs,[c(C,fresh)]) :-
	\+member(c(C,fresh),DoneFCs),
	!.
get_fresh_const(c(C,fresh),DoneFCs,[]) :-
	member(c(C,fresh),DoneFCs),
	!.
get_fresh_const(A,_,[]) :-
	atom(A),!.
get_fresh_const(N,_,[]) :-
	number(N),!.
get_fresh_const(F,DoneFCs,FCs) :-
	\+is_list(F),
	F=..[_|Args],
	get_fresh_const(Args,DoneFCs,FCs).
	
	
% Extend the intruder knowledge directly in the Protocol Rules 
special_purpose_alteration(action(ActName,C,PRE,ADD,DEL),
			   ActConst,
			   CAT,
			   [action(ActName,C,PRE,NADD,DEL)],
			   [ActConst]) :-
	category_label(CAT,rules),!,
	member(m(_,OS,REC,MSG),ADD),
	append(ADD,[i(OS),i(REC),i(MSG)],NADD).
% Don't consider the Memorize and Divert Rules
special_purpose_alteration(action(ActName,_,_,_,_),
			   _,
			   CAT,
			   [],
			   []) :-
	category_label(CAT,intruder),
	ActName=..[Name|_],
	(
	  atom_concat('divert',_,Name)
	;
	  atom_concat('memorize',_,Name)
	).
% Don't consider the Memorize and Divert Rules
special_purpose_alteration(action(ActName,_,_,_,_),
			   _,
			   CAT,
			   [],
			   []) :-
	category_label(CAT,intruder),
	ActName=..[Name|_],
	(
	  atom_concat('divert',_,Name)
	;
	  atom_concat('memorize',_,Name)
	).

% Uses the knowledge about the monotic fluents
monotonic_fluents(action(ActName,C,PRE,ADD,DEL),Ds,action(ActName,C,PRE,ADD,MDEL)) :- 
	findall(MF,
		(
		  member(monotone(STRMF),Ds),
 		  functor(STRMF,MFF,Arity),
 		  functor(MF,MFF,Arity),
 		  member(MF,DEL)
		),
		MFs),
	delete_sublist(MFs,DEL,MDEL).

% Build a relation between the session base and the session
relation_between_sessions(action(ActionName1,_,PRE1,ADD1,DEL1),
			  CMAPs,
			  action(ActionName1,C,PRE1,ADD1,DEL1)) :-
	ActionName1=..[_|Xs],
	member(SesX,Xs),
	member(SesBaseX,Xs),
	member(1-_-SesX-session,CMAPs),
	member(1-_-SesBaseX-session_base,CMAPs),
	append(PRE1,ADD1,TLIST),
	append(TLIST,DEL1,LIST),
	member(inknw(R,_,_,SesBaseX),LIST),
	(
	  member(wk(_,_,R,_,_,s(SesX)),LIST)
	;
	  member(wk(_,_,R,_,_,SesX),LIST)
	),
	build_relation_between_sessions_condition(C,SesX,SesBaseX),
% 	(member(wk(_,_,R,_,_,s(SesX)),LIST) ->
% 	    build_relation_between_sessions_condition(C,s(SesX),SesBaseX)
% 	;
% 	    member(wk(_,_,R,_,_,SesX),LIST),
% 	    build_relation_between_sessions_condition(C,SesX,SesBaseX)
% 	),
	!.

build_relation_between_sessions_condition(session_condition(SesX,SesBaseX),SesX,SesBaseX).

% build_relation_between_sessions_condition(C,SesX,SesBaseX) :-
% 	value(session_repetition,SesRep),
% 	(SesRep >= 1 ->
% 	    build_relation_between_sessions_condition(C,SesX,SesBaseX,'(',0-SesRep)
% 	;
% 	    C=true
% 	),!.
% build_relation_between_sessions_condition(C,SesX1,SesX2,TmpC,N-SesRep) :-
% 	N = SesRep,
% 	format_to_chars("~w~w = ~w)",[TmpC,SesX1,SesX2],CC),
% 	atom_chars(C,CC).
% build_relation_between_sessions_condition(C,SesX1,SesX2,TmpC,N-SesRep) :-
% 	N < SesRep,
% 	format_to_chars("~w~w = ~w;",[TmpC,SesX1,SesX2],CNewC),
% 	atom_chars(NewC,CNewC),
% 	M is N + 1,
% 	build_relation_between_sessions_condition(C,SesX1,s(SesX2),NewC,M-SesRep).
	
%-----------------------------------------------------------------------
%        BEGIN: POST ACTIONs
%

post_actions(PreDs,TmpDs,ActDs) :-
	append(PreDs,TmpDs,SateDs),
	sate2prolog_declarations(SateDs,PrologDs),
	assert_declaration_list(PrologDs),
	post_actions,
	get_actionbody_assertions(PrologActs),
	prolog2sate_declarations(PrologActs,Acts),
	get_actiondef_assertions(ActConsts),
	append_alternation_element(ActConsts,Acts,ActDs),
	retractall_declarations.
	
post_actions :-
	static_fluents_instantiate_actions,
	evaluate_session_condition_to_instantiate_actions,
	add_decomposition_actions.
%	apply_action_conditions.

%-----------------------------------------------------------------------
%        BEGIN: STATIC FLUENTs
%

static_fluents_instantiate_actions :-
	findall(action(Op,C,Pre,Add,Del),
		retract(action(Op,C,Pre,Add,Del)),
		Acts),
	static_fluents_instantiate_actions(Acts).
	
% TODO: the static fluents must be specified
%       in the initial state.
static_fluents_instantiate_actions(Acts) :-
 	% Initial states
 	findall(IS_SF,
 		(
 		  facts(IS),
		  member(IS_SF,IS),
		  static(IS_SF)
 		),
 		TmpIS_SFs),
	remove_duplicates(TmpIS_SFs,IS_SFs),!,
	static_fluents_instantiate_actions(Acts,IS_SFs).

static_fluents_instantiate_actions([],_).
static_fluents_instantiate_actions([Act|Acts],IS_SFs) :-
	retractall(internal_counter(_)),
	assert(internal_counter(1)),
	static_fluents_instantiate_action(Act,IS_SFs),
	static_fluents_instantiate_actions(Acts,IS_SFs).

static_fluents_instantiate_action(action(Op,C,Pre,Add,Del),IS_SFs) :-
	retract(sate2prolog_maps_var(action(Op,C,Pre,Add,Del),MAPs)),
	functor(Op,Name,Arity),
	functor(OpConst,Name,Arity),
	retract(constant(OpConst,action)),
	ActConst = constant(OpConst,action),
 	% Static fluents in the Precondition of the action
 	findall(SF,
 		(
 		  member(SF,Pre),
		  static(SF)
 		),
 		SFs),
	partial_instantiate_action(action(Op,C,Pre,Add,Del),SFs,IS_SFs),
	adjust_action(action(Op,C,Pre,Add,Del),ActConst,NewAct,NewActConst),
	adjust_maps_var(MAPs,NewMAPs),
	assert(NewActConst),	
	assert(NewAct),
	assert(sate2prolog_maps_var(NewAct,NewMAPs)),
	fail.
static_fluents_instantiate_action(_,_).

evaluate_session_condition_to_instantiate_actions :-
	retract(action(Op,session_condition(X,Y),Pre,Add,Del)),
	retractall(internal_counter(_)),
	assert(internal_counter(1)),
	retract(sate2prolog_maps_var(action(Op,session_condition(X,Y),Pre,Add,Del),MAPs)),
	functor(Op,Name,Arity),
	functor(OpConst,Name,Arity),
	retract(constant(OpConst,action)),
	ActConst = constant(OpConst,action),
	call(session_condition(X,Y)),
	adjust_action(action(Op,true,Pre,Add,Del),ActConst,NewAct,NewActConst),
	adjust_maps_var(MAPs,NewMAPs),
	assert(NewActConst),	
	assert(NewAct),
	assert(sate2prolog_maps_var(NewAct,NewMAPs)),
	fail.
evaluate_session_condition_to_instantiate_actions.	

partial_instantiate_action(_,[],_) :- !.
partial_instantiate_action(action(Op,C,Pre,Add,Del),[SF|SFs],IS_SFs) :-
	member(SF,Pre),
	member(SF,IS_SFs),
	partial_instantiate_action(action(Op,C,Pre,Add,Del),SFs,IS_SFs).

adjust_action(action(Op,C,Pre,Add,Del),constant(OpConst,action),
	      action(NewOp,C,Pre,Add,Del),constant(NewOpConst,action)) :-
	Op=..[OpF|Xs],
	OpConst=..[OpF|Ss],
	adjust_action_vars(Xs,Ss,NewXs,NewSs),
	retract(internal_counter(N)),
	M is N + 1,
	assert(internal_counter(M)),
	% Is not a sort construction 
	build_sort(OpF,N,NewOpF),
	NewOp=..[NewOpF|NewXs],
	NewOpConst=..[NewOpF|NewSs],!.

adjust_action_vars([],[],[],[]) :- !.
adjust_action_vars([X|Xs],[S|Ss],[X|NewXs],[S|NewSs]) :-
	var(X),
	adjust_action_vars(Xs,Ss,NewXs,NewSs).
adjust_action_vars([X|Xs],[_|Ss],NewXs,NewSs) :-
	\+var(X),
	adjust_action_vars(Xs,Ss,NewXs,NewSs).	

adjust_maps_var([],[]) :- !.
adjust_maps_var([ST-PT|MAPs],[ST-PT|NewMAPs]) :-
	var(PT),
	adjust_maps_var(MAPs,NewMAPs).
adjust_maps_var([_-PT|MAPs],NewMAPs) :-
	\+var(PT),
	adjust_maps_var(MAPs,NewMAPs).

%
%          END: STATIC FLUENTs
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: KNOWLEDGE DECOMPOSITION ACTIONs
%

add_decomposition_actions :-
	assert(decompose_counter(1)),
	assert(decrypt_public_key_counter(1)),
	assert(decrypt_private_key_counter(1)),
	assert(decrypt_symmetric_key_counter(1)),
	add_decomposition_actions(knw_el),
	fail.
add_decomposition_actions.

add_decomposition_actions(Sort) :-
	constant(T,Sort),
	add_term_decomposition_actions(T).
add_decomposition_actions(Sort) :-
	super_sort(Sort,SubSort),
	add_decomposition_actions(SubSort).

add_term_decomposition_actions(c(S1,S2)) :-
	\+is_basic_term(c(S1,S2)),
	\+decompose(c(S1,S2)),
	retract(decompose_counter(N)),
	build_sort('decompose',N,OpName),
	Op=..[OpName,X1,X2],
	OpConst=..[OpName,S1,S2],
	assert(constant(OpConst,action)),
	assert(action(Op,true,[i(c(X1,X2))],[i(X1),i(X2)],[])),
	assert(sate2prolog_maps_var(action(Op,true,[i(c(X1,X2))],[i(X1),i(X2)],[]),['X1'-X1,'X2'-X2])),
	M is N + 1,
	assert(decompose_counter(M)),
	assert(decompose(c(S1,S2))).
add_term_decomposition_actions(crypt(S1,S2)) :-
	\+decompose(crypt(S1,S2)),	
	value(term_depth_bound,D),
	term(S1,D,pk(_)),!,
	retract(decrypt_public_key_counter(N)),
	build_sort('decrypt_public_key',N,OpName),
	Op=..[OpName,X1,X2],
	OpConst=..[OpName,S1,S2],
	assert(constant(OpConst,action)),
	assert(action(Op,true,[i(crypt(X1,X2)),i(primed(X1))],[i(X2)],[])),
	assert(sate2prolog_maps_var(action(Op,true,[i(crypt(X1,X2)),i(primed(X1))],[i(X2)],[]),['X1'-X1,'X2'-X2])),
	M is N + 1,
	assert(decrypt_public_key_counter(M)),
	assert(decompose(crypt(S1,S2))).
add_term_decomposition_actions(crypt(S1,S2)) :-
	\+decompose(decrypt(S1,S2)),
	value(term_depth_bound,D),
	term(S1,D,primed(pk(_))),!,
	retract(decrypt_private_key_counter(N)),
	build_sort('decrypt_private_key',N,OpName),
	Op=..[OpName,X1,X2],
	OpConst=..[OpName,pk,S2],
	assert(constant(OpConst,action)),
	assert(action(Op,true,[i(crypt(primed(X1),X2)),i(X1)],[i(X2)],[])),
	assert(sate2prolog_maps_var(action(Op,true,[i(crypt(primed(X1),X2)),i(X1)],[i(X2)],[]),['X1'-X1,'X2'-X2])),
	M is N + 1,
	assert(decrypt_private_key_counter(M)),
	assert(decompose(decrypt(S1,S2))).
add_term_decomposition_actions(scrypt(S1,S2)) :-
	\+decompose(scrypt(S1,S2)),
	retract(decrypt_symmetric_key_counter(N)),
	build_sort('decrypt_symmetric_key',N,OpName),
	Op=..[OpName,X1,X2],
	OpConst=..[OpName,S1,S2],
	assert(constant(OpConst,action)),
	assert(action(Op,true,[i(scrypt(X1,X2)),i(X1)],[i(X2)],[])),
	assert(sate2prolog_maps_var(action(Op,true,[i(scrypt(X1,X2)),i(X1)],[i(X2)],[]),['X1'-X1,'X2'-X2])),
	M is N + 1,
	assert(decrypt_symmetric_key_counter(M)),
	assert(decompose(scrypt(S1,S2))).

is_basic_term(T) :-
	T=..[_,SubT],
	atom(SubT),!.
is_basic_term(T) :-
	T=..[_,SubT],
	SubT=c(_,fresh),!.
is_basic_term(T) :-
	T=..[_,SubT],
	SubT=c(C,C),
	atom(C),!.


%
%          END: KNOWLEDGE DECOMPOSITION ACTIONs
%-----------------------------------------------------------------------

% %-----------------------------------------------------------------------
% %        BEGIN: APPLY ACTION CONDITION AND INSTANTIATE NEW ACTIONS
% %

% apply_action_conditions :-
% 	findall(action(Op,C,Pre,Add,Del),
% 		retract(action(Op,C,Pre,Add,Del)),
% 		Acts),
% 	apply_action_conditions(Acts).
	
	
% %
% %          END: APPLY ACTION CONDITION AND INSTANTIATE NEW ACTIONS
% %-----------------------------------------------------------------------
%
%          END: POST ACTIONs
%-----------------------------------------------------------------------
%
%          END: ACTIONs
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: GOALs
%

goals(problem(_,LRRs),D1s,Gs) :-
 	category_label(CRR,goal),
 	findall(lrr(LB,CRR,LHS,[]),
	        member(lrr(LB,CRR,LHS,[]),LRRs),
 		GSs),
 	category_label(CIS,init),
 	findall(IS, % (R-IK-1-SES),
 		(
		    member(lrr(_,CIS,IS,[]),LRRs)
		),
 		ISs),
	pre_goals(GSs,ISs,TmpGSs),
	pif2sate_goal_states(TmpGSs,D1s,TmpGs),
	post_goals(TmpGs,D1s,Gs).

post_goals(Gs,PreDs,NewGs) :-
	append(PreDs,Gs,SateDs),
	sate2prolog_declarations(SateDs,PrologDs),
	assert_declaration_list(PrologDs),
	post_goals,
	get_goal_assertions(NewGs),
	% [LC]: To translate the name of the variable
	%       we have to use a triple <LB,Cond,Fs>
	%       for each goal
%	get_goal_assertions(PrologGs),
%	!,
%	prolog2sate_declarations(PrologGs,NewGs),
	retractall_declarations.

post_goals :-
	static_fluents_instantiate_goals,
	evaluate_session_condition_to_instantiate_goals.

static_fluents_instantiate_goals :-
	findall(goal(C,G),
		retract(goal(C,G)),
		Gs),
	static_fluents_instantiate_goals(Gs).
	
% TODO: the static fluents must be specified
%       in the initial state.
static_fluents_instantiate_goals(Gs) :-
 	% Initial states
 	findall(IS_SF,
 		(
 		  facts(IS),
		  member(IS_SF,IS),
		  static(IS_SF)
 		),
 		TmpIS_SFs),
	remove_duplicates(TmpIS_SFs,IS_SFs),!,
	static_fluents_instantiate_goals(Gs,IS_SFs).

static_fluents_instantiate_goals([],_).
static_fluents_instantiate_goals([G|Gs],IS_SFs) :-
	static_fluents_instantiate_goal(G,IS_SFs),
	static_fluents_instantiate_goals(Gs,IS_SFs).

% static_fluents_instantiate_goals([G|Gs],IS_SFs) :-
% 	retract(sate2prolog_maps_var(G,MAPs)),
% 	static_fluents_instantiate_goal(G,MAPs,IS_SFs),
% 	static_fluents_instantiate_goals(Gs,IS_SFs).

static_fluents_instantiate_goal(goal(C,Fs),IS_SFs) :-
 	% Static fluents in the goal
 	findall(SF,
 		(
 		  member(SF,Fs),
		  static(SF)
 		),
 		SFs),
	partial_instantiate_goal(goal(C,Fs),SFs,IS_SFs),
	assert(goal(C,Fs)),
	fail.
static_fluents_instantiate_goal(_,_).

% static_fluents_instantiate_goal(goal(C,Fs),MAPs,IS_SFs) :-
%  	% Static fluents in the goal
%  	findall(SF,
%  		(
%  		  member(SF,Fs),
% 		  static(SF)
%  		),
%  		SFs),
% 	partial_instantiate_goal(goal(C,Fs),SFs,IS_SFs),
% 	adjust_maps_var(MAPs,NewMAPs),
% 	assert(goal(C,Fs)),
% 	assert(sate2prolog_maps_var(goal(C,Fs),NewMAPs)),
% 	fail.
% static_fluents_instantiate_goal(_,_,_).

partial_instantiate_goal(_,[],_) :- !.
partial_instantiate_goal(goal(C,Fs),[SF|SFs],IS_SFs) :-
	member(SF,Fs),
	member(SF,IS_SFs),
	partial_instantiate_goal(goal(C,Fs),SFs,IS_SFs).

get_goal_assertions(Gs) :-
	findall(goal(C,G),
		goal(C,G),
		Gs).

evaluate_session_condition_to_instantiate_goals :-
	retract(goal(session_condition(X,Y),Fs)),
	call(session_condition(X,Y)),
	assert(goal(true,Fs)),
	fail.
evaluate_session_condition_to_instantiate_goals.	

pre_goals([],_,[]).
pre_goals([GS|GSs],ISs,NewGSs) :-
	pre_goal(GS,ISs,NewGS1s),
	pre_goals(GSs,ISs,NewGS2s),
	append(NewGS1s,NewGS2s,NewGSs).

pre_goal(_,[],[]).
pre_goal(lrr(LB,_,LHS,[]),[IS|ISs],NewGSs) :-
	findall(lrr(LB,_,NewLHS,[]),
		initial_knowledge_goal_instantiation(LHS,IS,NewLHS),
		NewGS1s),
	pre_goal(lrr(LB,_,LHS,[]),ISs,NewGS2s),
	append(NewGS1s,NewGS2s,NewGSs).

initial_knowledge_goal_instantiation([],_,[]).
% TODO: note that we invert the AcqKnw with the InKnw because there was an error in the IF
% initial_knowledge_goal_instantiation([w(Step,Sender,Receiver,InitKns,AcqKns,Bool,Session1)|Fs],
% 				     IS,
% 				     [w(Step,Sender,Receiver,AcqKns,NewInitKns,Bool,Session1)|NewFs]) :-
initial_knowledge_goal_instantiation([w(Step,Sender,Receiver,AcqKns,InitKns,Bool,Session1)|Fs],
				     IS,
				     [w(Step,Sender,Receiver,AcqKns,NewInitKns,Bool,Session1)|NewFs]) :-
	((\+is_empty_knowledge_var(InitKns),is_var(InitKns)) ->
	    member(w(_,_,Receiver,_,NewInitKns,_,Session2),IS),
	    pif2sate_gsession(Session1,Session),
	    (\+is_var(Session) ->
		pif2sate_gsession(Session2,Session)
	    ;
		true
	    )
	;
	    NewInitKns = InitKns
	),
	initial_knowledge_goal_instantiation(Fs,IS,NewFs).
	
initial_knowledge_goal_instantiation([F|Fs],IS,[F|NewFs]) :-
	\+F=..[w|_],
	initial_knowledge_goal_instantiation(Fs,IS,NewFs).
	

pif2sate_goal_states([],_,[]).
pif2sate_goal_states([IS|ISs],Ds,Gs) :-
	pif2sate_goal_state(IS,Ds,G1s),
	pif2sate_goal_states(ISs,Ds,G2s),
	append(G1s,G2s,Gs).

%pif2sate_goal_state(lrr(_,_,LHS,[]),_,[sate2prolog_maps_var(G,CMAP2s),G]) :
pif2sate_goal_state(lrr(_,_,LHS,[]),_,[G]) :-
	vars(lrr(_,_,LHS,[]),Xs),
	sorts(lrr(_,_,LHS,[]),Xs,MAPs),
	add_control_field(MAPs,CMAP1s),
	pif2sate_fluents(LHS,CMAP1s,CMAP2s,TLHS),
	post_pif2sate_goal_state(goal(true,TLHS),CMAP2s,G).

post_pif2sate_goal_state(G1,CMAPs,G3) :-
	(goal_relation_between_sessions(G1,CMAPs,G2) ->
	    true;
	    G2 = G1
	),
	(patch_authentication_goal(G2,G3) ->
	    true;
	    G3 = G2
	).
	

% Build a relation between the session base and the session
goal_relation_between_sessions(goal(_,G),CMAPs,goal(C,G)) :-
	member(_-_-SesX-session,CMAPs),
	member(_-_-SesBaseX-session_base,CMAPs),
	member(inknw(R,_,_,SesBaseX),G),
	(
	  member(wk(_,_,R,_,_,s(SesX)),G)
	;
	  member(wk(_,_,R,_,_,SesX),G)
	),
	build_relation_between_sessions_condition(C,SesX,SesBaseX),
	!.

patch_authentication_goal(goal(C,G),goal(C,[~(witness(Sender,Receiver,ID,Term))|G])) :-
	member(request(Receiver,Sender,ID,Term),G).
	
% % Version useful for the post_goals predicate
% pif2sate_goal_states([],_,[]).
% pif2sate_goal_states([IS|ISs],Ds,[GConst,GDef,G|Gs]) :-
% 	pif2sate_goal_state(IS,Ds,G,GConst,GDef),
% 	pif2sate_goal_states(ISs,Ds,Gs).

% pif2sate_goal_state(lrr(LB,_,LHS,[]),_,goal(TLHS),constant(OpDecl,goal),goal_def(OpName,TLHS)) :-
% 	vars(lrr(_,_,LHS,[]),Xs),
% 	sorts(lrr(_,_,LHS,[]),Xs,MAPs),
% 	add_control_field(MAPs,CMAP1s),
% 	pif2sate_fluents(LHS,CMAP1s,CMAP2s,TLHS),
% 	( bagof(V,ID^S^member(1-ID-V-S,CMAP2s),Vs) ->
% 	    true
% 	;
% 	    Vs = []
% 	),
% 	( bagof(S,ID^V^member(1-ID-V-S,CMAP2s),Ss) ->
% 	    true
% 	;
% 	    Ss = []
% 	),
% 	OpName=..[LB|Vs],
% 	OpDecl=..[LB|Ss].


%
%          END: GOALs
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: FLUENTs AND TERMs TRANSLATION
%

pif2sate_fluents([],CMAPs,CMAPs,[]).
pif2sate_fluents([F|Fs],CMAP1s,CMAP2s,Ts) :-
	pif2sate_fluent(F,CMAP1s,CMAP3s,T1s),
	pif2sate_fluents(Fs,CMAP3s,CMAP2s,T2s),
	append(T1s,T2s,Ts).

pif2sate_fluent(h(_),CMAP1s,CMAP1s,[]).
%	variable_elimination(T,CMAP1s,CMAP2s).

pif2sate_fluent(i(primed(pk(c(C,C)))),CMAP1s,CMAP1s,[]) :-
	\+value(intruder_const,on),
	\+is_var(C),
	atom(C),
	!.
pif2sate_fluent(i(T),CMAP1s,CMAP1s,[]) :-
	\+value(intruder_const,on),
	T=..[_,c(C,C)],
	\+is_var(C),
	atom(C),
	!.
pif2sate_fluent(i(T),CMAP1s,CMAP2s,[i(TX)]) :-
	pif2sate_term(T,CMAP1s,CMAP2s,TX).

pif2sate_fluent(not_used(FRC),CMAP1s,CMAP2s,[not_used(TFRC)]) :-
	pif2sate_term(FRC,CMAP1s,CMAP2s,TFRC).

pif2sate_fluent(m(Step,_,OfficialSender,Receiver,Content,_),
	    CMAP1s,
	    CMAP2s,
	    [m(StepX,OfficialSenderX,ReceiverX,ContentX)]) :-
	pif2sate_term(Step,CMAP1s,CMAP3s,StepX),
	pif2sate_term(OfficialSender,CMAP3s,CMAP4s,OfficialSenderX),
	pif2sate_term(Receiver,CMAP4s,CMAP5s,ReceiverX),
	pif2sate_term(Content,CMAP5s,CMAP2s,ContentX).
% pif2sate_fluent(m(Step,RealSender,OfficialSender,Receiver,Content,Session),
% 	    MAPs,
% 	    [m(StepX,RealSenderX,OfficialSenderX,ReceiverX,ContentX,SessionX)]) :-
% 	pif2sate_term(Step,MAPs,StepX),
% 	pif2sate_term(RealSender,MAPs,RealSenderX),
% 	pif2sate_term(OfficialSender,MAPs,OfficialSenderX),
% 	pif2sate_term(Receiver,MAPs,ReceiverX),
% 	pif2sate_term(Content,MAPs,ContentX),
% 	pif2sate_term(Session,MAPs,SessionX).

pif2sate_fluent(w(Step,Sender,Receiver,AcqKns,InitKns,_,Session),
	    CMAP1s,
	    CMAP2s,
	    FLs) :-
%	variable_elimination(Bool,CMAP1s,CMAP2s),
	pif2sate_term(Step,CMAP1s,CMAP3s,StepX),
	((number(Step),Step==0) ->
	    SenderX=mr(intruder),
	    CMAP4s = CMAP3s;
	    pif2sate_term(Sender,CMAP3s,CMAP4s,SenderX)
	),
	pif2sate_term(Receiver,CMAP4s,CMAP5s,ReceiverX),
	% TODO: error in goals generation
	(is_empty_knowledge_var(InitKns) -> 
	    InitKnsX = [],
	    CMAP6s = CMAP5s;
	    pif2sate_terms(InitKns,CMAP5s,CMAP6s,InitKnsX)
	),
	% TODO: error in goals generation	
	(is_empty_knowledge_var(AcqKns) -> 
	    AcqKnsX = [],
    	    CMAP7s = CMAP6s;
	    pif2sate_terms(AcqKns,CMAP6s,CMAP7s,AcqKnsX)
	),
	pif2sate_session(Session,CMAP7s,CMAP8s,SessionX),
	pif2sate_session_base(Session,CMAP8s,CMAP2s,SessionBaseX),
	(InitKnsX=[] -> 
	    IKs=[inknw(ReceiverX,etc,1,SessionBaseX)];
	    findall(inknw(ReceiverX,InitKnX,InIndex,SessionBaseX),
		    nth(InIndex,InitKnsX,InitKnX),
		    IKs)
	),
	(AcqKnsX=[] -> 
	    WKs=[wk(StepX,SenderX,ReceiverX,etc,1,SessionX)];
	    findall(wk(StepX,SenderX,ReceiverX,AcqKnX,AcqIndex,SessionX),
		    nth(AcqIndex,AcqKnsX,AcqKnX),
		    WKs)
	),
	append(IKs,WKs,FLs).
% pif2sate_fluent(w(Step,Sender,Receiver,AcqKns,InitKns,Bool,Session),
% 	    MAPs,
% 	    FLs) :-
% 	pif2sate_term(Step,MAPs,StepX),
% 	pif2sate_term(Sender,MAPs,SenderX),
% 	pif2sate_term(Receiver,MAPs,ReceiverX),
% 	% TODO: error in goals generation
% 	(is_var(InitKns) -> 
% 	    InitKnsX = [];
% 	    pif2sate_terms(InitKns,MAPs,InitKnsX)
% 	),
% 	% TODO: error in goals generation	
% 	(is_var(AcqKns) -> 
% 	    AcqKnsX = [];
% 	    pif2sate_terms(AcqKns,MAPs,AcqKnsX)
% 	),
% 	pif2sate_term(Bool,MAPs,BoolX),
% 	pif2sate_term(Session,MAPs,SessionX),
% 	pif2sate_session_base(Session,MAPs,SessionBaseX),
% 	(InitKnsX=[] -> 
% 	    IKs=[inknw(ReceiverX,etc,1,SessionBaseX)];
% 	    findall(inknw(ReceiverX,InitKnX,InIndex,SessionBaseX),
% 		    nth(InIndex,InitKnsX,InitKnX),
% 		    IKs)
% 	),
% 	(AcqKnsX=[] -> 
% 	    WKs=[wk(StepX,SenderX,ReceiverX,etc,1,BoolX,SessionX)];
% 	    findall(wk(StepX,SenderX,ReceiverX,AcqKnX,AcqIndex,BoolX,SessionX),
% 		    nth(AcqIndex,AcqKnsX,AcqKnX),
% 		    WKs)
% 	),
% 	append(IKs,WKs,FLs).

pif2sate_fluent(secret(MSG,FSession),
	    CMAP1s,
	    CMAP2s,
	    [secret(MSGX,SessionBaseX)]) :-
	pif2sate_term(MSG,CMAP1s,CMAP3s,MSGX),
	(
	  FSession = f(Session)
	;
	  Session = FSession
	),
	pif2sate_session_base(Session,CMAP3s,CMAP2s,SessionBaseX).

pif2sate_fluent(give(MSG,FSession),
	    CMAP1s,
	    CMAP2s,
	    [give(MSGX,SessionBaseX)]) :-
	pif2sate_term(MSG,CMAP1s,CMAP3s,MSGX),
	(
	  FSession = f(Session)
	;
	  Session = FSession
	),
	pif2sate_session_base(Session,CMAP3s,CMAP2s,SessionBaseX).

pif2sate_fluent(witness(Sender,Receiver,ID,Term),
	    CMAP1s,
	    CMAP2s,
	    [witness(SenderX,ReceiverX,IDX,TermX)]) :-
	pif2sate_term(Sender,CMAP1s,CMAP3s,SenderX),
	pif2sate_term(Receiver,CMAP3s,CMAP4s,ReceiverX),
	pif2sate_term(ID,CMAP4s,CMAP5s,IDX),
	pif2sate_term(Term,CMAP5s,CMAP2s,TermX).

pif2sate_fluent(request(Receiver,Sender,ID,Term),
	    CMAP1s,
	    CMAP2s,
	    [request(ReceiverX,SenderX,IDX,TermX)]) :-
	pif2sate_term(Receiver,CMAP1s,CMAP3s,ReceiverX),
	pif2sate_term(Sender,CMAP3s,CMAP4s,SenderX),
	pif2sate_term(ID,CMAP4s,CMAP5s,IDX),
	pif2sate_term(Term,CMAP5s,CMAP2s,TermX).

% TERMs
pif2sate_terms([],CMAPs,CMAPs,[]).
pif2sate_terms([T|Ts],CMAP1s,CMAP2s,[TT|TTs]):-
	pif2sate_term(T,CMAP1s,CMAP3s,TT),
	pif2sate_terms(Ts,CMAP3s,CMAP2s,TTs).

pif2sate_term(c(C,xTime),CMAPs,CMAPs,c(C,fresh)) :-
	\+is_var(C),!.

pif2sate_term(T,CMAP1s,[1-T-TT-Sort|CMAP2s],TT) :-
	atom(T),
	select(_-T-TT-Sort,CMAP1s,CMAP2s).
pif2sate_term(T,CMAPs,CMAPs,T) :-
	atom(T),
	\+member(_-T-_-_,CMAPs).
pif2sate_term(T,CMAPs,CMAPs,T) :-
	number(T).
pif2sate_term(T,CMAP1s,CMAP2s,TT) :-
	\+atom(T),
	T=..[F|Ts],
	pif2sate_terms(Ts,CMAP1s,CMAP2s,TTs),
	TT=..[F|TTs].
% pif2sate_terms([],_,[]).
% pif2sate_terms([T|Ts],CMAPs,[TT|TTs]):-
% 	pif2sate_term(T,CMAPs,TT),
% 	pif2sate_terms(Ts,CMAPs,TTs).

% pif2sate_term(T,CMAPs,TT) :-
% 	atom(T),
% 	member(_-T-TT-_,CMAPs).
% pif2sate_term(T,CMAPs,T) :-
% 	atom(T),
% 	\+member(_-T-_-_,CMAPs).
% pif2sate_term(T,_,T) :-
% 	number(T).
% pif2sate_term(T,CMAPs,TT) :-
% 	\+atom(T),
% 	T=..[F|Ts],
% 	pif2sate_terms(Ts,CMAPs,TTs),
% 	TT=..[F|TTs].

pif2sate_session(S,CMAP1s,[1-S-TS-session|CMAP2s],TS) :-
	atom(S),
	select(_-S-TS-session,CMAP1s,CMAP2s).
pif2sate_session(S,CMAPs,CMAPs,S) :-
	number(S).
pif2sate_session(S,CMAP1s,CMAP2s,TS) :-
	\+atom(S),
	S=s(PrevS),
	pif2sate_session(PrevS,CMAP1s,CMAP2s,TPrevS),
	TS=s(TPrevS).
	
	
pif2sate_session_base(s(S),CMAP1s,CMAP2s,TS) :-
	pif2sate_session_base(S,CMAP1s,CMAP2s,TS).
pif2sate_session_base(S,CMAP1s,CMAP2s,TTS) :-
	atom(S),
	member(_-S-TS-session,CMAP1s),
	atom_concat('NEW',TS,TTS),
	(member(_-S-TTS-session_base,CMAP1s) ->
	    CMAP2s = CMAP1s
	;
	    CMAP2s = [1-S-TTS-session_base|CMAP1s]
	).
pif2sate_session_base(S,CMAPs,CMAPs,S) :-
	number(S).

% GROUND TERM AND SESSION
pif2sate_gterm(T,T).

pif2sate_gsession(SES,SES) :- 
	atom(SES).
pif2sate_gsession(SES,SES) :- 
	number(SES).
pif2sate_gsession(s(SES),TSES) :- 
	pif2sate_gsession(SES,TSES).

%
%          END: FLUENTs AND TERMs TRANSLATION
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PIF VARS 
%
is_var(V) :-
	atom(V),
	atom_concat('x',_,V).

is_empty_knowledge_var(V) :-
	atom(V),
	atom_concat('xetc',_,V).

vars(lrr(_,_,LHS,RHS),Xs) :-
	vars_terms(LHS,[],X1s),
	vars_terms(RHS,X1s,Xs).

vars_terms([],Xs,Xs).
vars_terms([T|Ts],X1s,X2s) :-
	vars_term(T,X1s,TMPXs),
	vars_terms(Ts,TMPXs,X2s).

vars_term(T,X1s,X2s) :-
	atom(T),
	atom_concat('x',T0,T), !,
	( member(T-V,X1s) ->
	    V1=V,
	    X2s=X1s
	;
	    atom_concat('X',T0,V1),
	    X2s=[T-V1|X1s] 
	).
vars_term(T,X1s,X2s) :-
	T=..[_|Ts],
	vars_terms(Ts,X1s,X2s).

% Add a control field stating if either the variable
% is usefull or not. If the variable is useless then
% we can don't consider it.
add_control_field([],[]).
add_control_field([PifVar-SateVar-SateSort|MAPs],
		  [0-PifVar-SateVar-SateSort|ContrMAPs]) :-
	add_control_field(MAPs,ContrMAPs).

% Given a term T, marks all the variables occurring
% in T as useless.
variable_elimination(T,CMAP1s,CMAP2s) :-
	\+is_list(T),
	vars_term(T,[],TXs),
	variable_elimination(TXs,CMAP1s,CMAP2s).
variable_elimination([],CMAPs,CMAPs).
variable_elimination([PifX-SateX|TXs],CMAP1s,[0-PifX-SateX-SateSort|CMAP2s]) :-
	select(_-PifX-SateX-SateSort, CMAP1s, CMAP3s),
	variable_elimination(TXs,CMAP3s,CMAP2s).

%
%          END: PIF VARS
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: SATE VARS
%

is_sate_var(X) :-
	atom(X),
	\+var(X),
	atom_chars(X,CodeX),
	(
	  atom_chars('NEWX',VarPrefix)
	;
	  atom_chars('X',VarPrefix)
	),
	append(VarPrefix,_,CodeX).

sate_vars_terms([],Xs,Xs).
sate_vars_terms([T|Ts],X1s,X2s) :-
	sate_vars_term(T,X1s,TMPXs),
	sate_vars_terms(Ts,TMPXs,X2s).

sate_vars_term(T,X1s,X2s) :-
	is_sate_var(T),
	!,
	( member(T,X1s) ->
	    X2s=X1s
	;
	    X2s=[T|X1s] 
	).
sate_vars_term(T,X1s,X2s) :-
	T=..[_|Ts],
	sate_vars_terms(Ts,X1s,X2s).

%
%          END: SATE VARS
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: SORTs
%

sorts(lrr(_,_,LHS,RHS),Xs,MAPs) :-
	append(LHS,RHS,LR),
	sorts_vars(LR,Xs,MAPs).

sorts_vars(_,[],[]).
sorts_vars(LR,[X|Xs],[MAP|MAPs]) :-
	sort_var(LR,X,MAP),
	sorts_vars(LR,Xs,MAPs).

% TODO: CASE T=xTime AND h(s(xTime))
sort_var(LR,T-TX,T-TX-time) :-
	member(h(T),LR),!.
sort_var(LR,T-TX,T-TX-session) :-
	(
	  member(m(_,_,_,_,_,S),LR);
	  member(w(_,_,_,_,_,_,S),LR);
	  member(secret(_,S),LR);
	  member(give(_,S),LR)
	),
	vars_term(S,[],SX),
	member(T-_,SX),!.
sort_var(LR,T-TX,T-TX-bool) :-
	member(w(_,_,_,_,_,T,_),LR),!.
sort_var(LR,T-TX,T-TX-wstep) :-
	member(w(T,_,_,_,_,_,_),LR),!.
sort_var(LR,T-TX,T-TX-mstep) :-
	member(m(T,_,_,_,_,_),LR),!.

sort_var(LR,T-TX,T-TX-mr_intruder) :-
	member(w(0,T,_,_,_,_,_),LR),!.

sort_var(LR,T-TX,T-TX-mr_honest) :-
	(
	  member(w(_,_,T,_,_,_,_),LR)
	;
	  member(witness(T,_,_,_),LR)
	;
	  member(request(_,T,_,_),LR)
	),!.

sort_var(LR,T-TX,T-TX-mr) :-
	(
	  member(m(_,T,_,_,_,_),LR)
	;
	  member(m(_,_,T,_,_,_),LR)
	;
	  member(m(_,_,_,T,_,_),LR)
	;
	  member(w(_,T,_,_,_,_,_),LR)
	;
	  member(w(_,_,T,_,_,_,_),LR)
	;
	  member(witness(T,_,_,_),LR)
	;
	  member(witness(_,T,_,_),LR)
	;
	  member(request(T,_,_,_),LR)
	;
	  member(request(_,T,_,_),LR)
	),!.

% TYPED VERSION
sort_var(LR,T-TX,T-TX-user_intruder) :-
	member(w(0,mr(T),_,_,_,_,_),LR),!.

sort_var(LR,T-TX,T-TX-user_honest) :-
	(
	  member(w(_,_,mr(T),_,_,_,_),LR)
	;
	  member(witness(mr(T),_,_,_),LR)
	;
	  member(request(_,mr(T),_,_),LR)
	),!.

sort_var(LR,T-TX,T-TX-user) :-
	(
	  member(m(_,mr(T),_,_,_,_),LR)
	;
	  member(m(_,_,mr(T),_,_,_),LR)
	;
	  member(m(_,_,_,mr(T),_,_),LR)
	;
	  member(w(_,mr(T),_,_,_,_,_),LR)
	;
	  member(w(_,_,mr(T),_,_,_,_),LR)
	;
	  member(witness(mr(T),_,_,_),LR)
	;
	  member(witness(_,mr(T),_,_),LR)
	;
	  member(request(mr(T),_,_,_),LR)
	;
	  member(request(_,mr(T),_,_),LR)
	),!.

sort_var(LR,T-TX,T-TX-secrecy_term) :-
	(
	  member(secret(T,_),LR);
	  member(give(T,_),LR)
	),!.

sort_var(LR,T-TX,T-TX-authentication_term) :-
	(
	  member(witness(_,_,_,T),LR);
	  member(request(_,_,_,T),LR)
	),!.

sort_var(LR,T-TX,T-TX-authentication_id) :-
	(
	  member(witness(_,_,T,_),LR);
	  member(request(_,_,T,_),LR)
	),!.

sort_var(LR,T-TX,T-TX-SORT) :-
	member(m(_,_,_,_,MSG,_),LR),
	sort_var_msg(MSG,T,SORT),!.

sort_var(LR,T-TX,T-TX-inknw_el) :-
	member(w(_,_,_,_,InKnw,_,_),LR),
	member(T,InKnw),!.

sort_var(LR,T-TX,T-TX-SORT) :-
	member(w(_,_,_,_,InKnw,_,_),LR),
	member(IK,InKnw),
	sort_var_msg(IK,T,SORT),!.

sort_var(LR,T-TX,T-TX-knw_el) :-
	member(w(_,_,_,Knw,_,_,_),LR),
	member(T,Knw),!.

sort_var(LR,T-TX,T-TX-SORT) :-
	member(w(_,_,_,Knw,_,_,_),LR),
	member(K,Knw),
	sort_var_msg(K,T,SORT),!.

% TODO: clever heuristic
% If the other predicates fail then we suppose V 
% of know's sort
sort_var(_,T-TX,T-TX-knw_el).

%-----------------------------------------------------------------------
%        BEGIN: MESSAGE SORT
%

sort_var_msg(crypt(pk(K),MSG),T,SORT) :- 
	(K == T -> 
	    SORT = public_key
	;
	    sort_var_msg(MSG,T,SORT)
	),!.
sort_var_msg(crypt(primed(pk(K)),MSG),T,SORT) :- 
	(K == T -> 
	    SORT = private_key
	;
	    sort_var_msg(MSG,T,SORT)
	),!.

sort_var_msg(scrypt(sk(K),MSG),T,SORT) :- 
	(K == T -> 
	    SORT = symmetric_key
	;
	    sort_var_msg(MSG,T,SORT)
	),!.

sort_var_msg(funct(fu(K),MSG),T,SORT) :- 
	(K == T -> 
	    SORT = fu_term
	;
	    sort_var_msg(MSG,T,SORT)
	),!.


sort_var_msg(c(MSG1,MSG2),T,SORT) :- 
	( 
	    sort_var_msg(MSG1,T,SORT)
	;
	    sort_var_msg(MSG2,T,SORT)
	),!.

sort_var_msg(rcrypt(MSG1,MSG2),T,SORT) :- 
	( 
	    sort_var_msg(MSG1,T,SORT)
	;
	    sort_var_msg(MSG2,T,SORT)
	),!.

sort_var_msg(nonce(c(F,xTime)),T,fresh_nonce_id) :-
	F == T,!.
sort_var_msg(pk(c(F,xTime)),T,fresh_public_id) :-
	F == T,!.
sort_var_msg(primed(pk(c(F,xTime))),T,fresh_public_id) :- 
	F == T,!.
sort_var_msg(sk(c(F,xTime)),T,fresh_symmetric_id) :- 
	F == T,!.

% sort_var_msg(MSG,T,intruder_const) :- 
% 	MSG=..[_,c(T,T)], 
% 	!.

sort_var_msg(pk(T),T,public_key) :- !.
sort_var_msg(primed(pk(T)),T,public_key) :- !.
sort_var_msg(sk(T),T,symmetric_key) :- !.
sort_var_msg(fu(T),T,fu_term) :- !.
%TODO
sort_var_msg(nonce(T),T,fresh_nonce) :- !.
sort_var_msg(mr(T),T,user) :- !.

% UNTYPED VERSION
sort_var_msg(crypt(K,MSG),T,DOM) :- 
	(K == T -> 
	    DOM = pk
	;
	    sort_var_msg(MSG,T,DOM)
	),!.

sort_var_msg(scrypt(K,MSG),T,DOM) :- 
	(K == T -> 
	    DOM = sk
	;
	    sort_var_msg(MSG,T,DOM)
	),!.

sort_var_msg(funct(K,MSG),T,DOM) :- 
	(K == T -> 
	    DOM = fu
	;
	    sort_var_msg(MSG,T,DOM)
	),!.

% TODO 
% La variablile potrebbe trovarsi sia in MSG1 che in MSG2.
% Perche` MSG1 deve essere privilegiato rispetto a MSG2 => 
% li provo entrambi e prendo la sort minore => ordinamento 
% sulle sort !
sort_var_msg(c(MSG1,MSG2),T,DOM) :- 
	( (MSG1 == T; MSG2 == T) -> 
	    DOM = atom
	;
	    ( 
		sort_var_msg(MSG1,T,DOM);
		sort_var_msg(MSG2,T,DOM)
	    )
	),!.

sort_var_msg(rcrypt(MSG1,MSG2),T,DOM) :- 
	( (MSG1 == T; MSG2 == T) -> 
	    DOM = atom
	;
	    ( 
		sort_var_msg(MSG1,T,DOM);
		sort_var_msg(MSG2,T,DOM)
	    )
	),!.

sort_var_msg(MSG,_,atom) :-
	is_var(MSG),!.

%
%          END: MESSAGE SORT
%-----------------------------------------------------------------------

%
%          END: SORTs
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: FRESHNESS
%

% TODO: check the presence of some fresh constants in the initial knowledge.
%       This would mean that some previous sessions have been simulated.
%       Hence those fresh constants cannot be re-used.
freshness_initialization([],[]).
freshness_initialization([constant(C,FRSort)|Ds],[FR|FRs]) :-
	(
	  FRSort = fresh_public_key_id,
	  FR = not_used(c(C,fresh))
	;
	  FRSort = fresh_symmetric_key_id,
  	  FR = not_used(c(C,fresh))
	;
	  FRSort = fresh_nonce_id,
  	  FR = not_used(c(C,fresh))	
	;
	  value(intruder_const,on),	  
	  FRSort = intruder_const,
  	  FR = not_used(c(C,C))	
	),!,
	freshness_initialization(Ds,FRs).
freshness_initialization([_|Ds],FRs) :-
	freshness_initialization(Ds,FRs).

%
%          END: FRESHNESS
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: GENERIC 
%

is_constant(C) :-
	atom(C),
	\+atom_concat('x',_,C).

build_constants(N-TOT,_,[]) :-
	N > TOT.
build_constants(TOT-TOT,SORT,[constant(TOT,SORT)]).
build_constants(N-TOT,SORT,[constant(N,SORT)|Cs]) :-
	N < TOT,
	M is N + 1,
	build_constants(M-TOT,SORT,Cs).

% SORT is LB1_LB2
build_sort(LB1,LB2,SORT) :-
	\+number(LB2),
	atom_chars(LB2,CLB2),
	atom_chars(LB1,CLB1),
	atom_chars('_',[UNDER]),
	append(CLB1,[UNDER|CLB2],CSORT),
	atom_chars(SORT,CSORT).
% SORT is LB_N
build_sort(LB,N,SORT) :-
	number(N),
	number_chars(N,CN),
	atom_chars(LB,CLB),
	atom_chars('_',[UNDER]),
	append(CLB,[UNDER|CN],CSORT),
	atom_chars(SORT,CSORT).

% For each Ti in Ts build a sort Lb_i
build_sorts(Ts,Lb,Ss) :-
	build_sorts(Ts,Lb,1,Ss).
build_sorts([],_,_,[]).
build_sorts([_|Ts],Lb,N,[LbN|Ss]) :-
	build_sort(Lb,N,LbN),
	M is N + 1,
	build_sorts(Ts,Lb,M,Ss).

build_super_sort(_,[],[]).
build_super_sort(S,[SubS|SubSs],[super_sort(S,SubS)|SPSs]) :-
	build_super_sort(S,SubSs,SPSs).

count_repetition(T,N) :-
	count_repetition(T,0,N).
count_repetition(T,N,N) :-
	number(T),!.
count_repetition(T,N,N) :-
	atom(T),!.
count_repetition(s(T),Prev,N) :-
	Curr is Prev + 1,
	count_repetition(T,Curr,N).

%-----------------------------------------------------------------------
%        BEGIN: NEW FRESH CONSTANTS PER SESSION ITERATION 
%

% multi_fresh_consts(problem(OPTs,LRR1s),problem(OPTs,LRR2s)) :-
%       Evaluates the PIF rewriting rules LRR1s and extends them to allow
%       the use of each fresh constant one time for each session iteration.
multi_fresh_consts(problem(OPTs,LRRs),problem(OPTs,LRRs)) :-
	value(session_repetition,1),!.
multi_fresh_consts(problem(OPTs,LRR1s),problem(OPTs,LRR2s)) :-
%	get_sessions(LRR1s,SESs),
	get_fresh_consts_from_PIF_rules(FCs,LRR1s),
	insert_multi_fresh_consts_in_rules(FCs,LRR1s,LRR2s).
%	remove_rules_duplicates(TmpLRR2s,LRR2s).

get_sessions(LRRs,SESs) :-
	category_label(CAT,init),
	findall(SesBase,
		(
		  member(lrr(_,CAT,LHS,_),LRRs),
		  member(w(_,_,_,_,_,_,Ses),LHS),
		  pif2sate_gsession(Ses,SesBase),
		  number(SesBase)
		),
		SESs
	       ).
get_fresh_consts_from_PIF_rules(FCs,LRRs) :-
	findall(FC,
		(
		  member(lrr(_,CAT,_,RHS),LRRs),
		  category_label(CAT,rules),
		  member(m(_,_,_,_,MSG,_),RHS),
		  preprocess_term(MSG,[],Cs),
		  (
		     % [LC]: TODO extend with public and symmetric keys
%		     member(constant(FC,fresh_public_key_id),Cs);
%		     member(constant(FC,fresh_symmetric_key_id),Cs);
		     member(constant(FC,fresh_nonce_id),Cs)
		  ),
		  \+member(witness(_,_,FC,_),RHS),
		  \+member(request(_,_,FC,_),RHS),
		  member(w(_,_,_,_,_,_,Ses),RHS),
		  pif2sate_gsession(Ses,SesBase),
		  is_var(SesBase)
		),
		TmpFCs),
	remove_duplicates(TmpFCs,FCs).

insert_multi_fresh_consts_in_rules(_,[],[]).
insert_multi_fresh_consts_in_rules(FCs,[LRR1|LRR1s],LRR2s) :-
	    value(session_repetition,SesRep),
	    insert_multi_fresh_consts_in_rule(1-SesRep,FCs,LRR1,TmpLRR21s),
	    insert_multi_fresh_consts_in_rules(FCs,LRR1s,LRR22s),
	    remove_duplicates(TmpLRR21s,LRR21s),
	    append(LRR21s,LRR22s,LRR2s).

remove_rules_duplicates([],[]).
remove_rules_duplicates([lrr(_,CAT,LHS,RHS)|LRR1s],LRR2s) :-
	member(lrr(_,CAT,LHS,RHS),LRR1s),!,
	remove_rules_duplicates(LRR1s,LRR2s).
remove_rules_duplicates([lrr(Lb,CAT,LHS,RHS)|LRR1s],[lrr(Lb,CAT,LHS,RHS)|LRR2s]) :-
	\+member(lrr(_,CAT,LHS,RHS),LRR1s),!,
	remove_rules_duplicates(LRR1s,LRR2s).

insert_multi_fresh_consts_in_rule(N-SesRep,_,_,[]) :-
	N > SesRep.
insert_multi_fresh_consts_in_rule(N-SesRep,FCs,lrr(Lb,CAT,LHS,RHS),[lrr(Lb,CAT,LHS,RHS)|LRRs]) :-
	N =< SesRep,
	insert_multi_fresh_consts_in_rule(N,FCs,lrr(Lb,CAT,LHS,RHS),lrr(_,CAT,LHS,RHS)),
	!,
	M is N + 1,
	insert_multi_fresh_consts_in_rule(M-SesRep,FCs,lrr(Lb,CAT,LHS,RHS),LRRs).
insert_multi_fresh_consts_in_rule(N-SesRep,FCs,lrr(Lb,CAT,LHS,RHS),[lrr(Lb1,CAT,LHS1,RHS1)|LRRs]) :-
	N =< SesRep,
	insert_multi_fresh_consts_in_rule(N,FCs,lrr(Lb,CAT,LHS,RHS),lrr(Lb1,CAT,LHS1,RHS1)),
	(LHS1\=LHS;RHS1\=RHS),
	M is N + 1,
	insert_multi_fresh_consts_in_rule(M-SesRep,FCs,lrr(Lb,CAT,LHS,RHS),LRRs).

insert_multi_fresh_consts_in_rule(N,FCs,lrr(Lb,CAT,LHS,RHS),lrr(Lb,CAT,LHS,RHS)) :-
	number(N),
	build_new_fresh_consts(FCs,N,FC1s),
	substitute_fresh_consts_in_terms(FCs,FC1s,LHS,LHS),	
	substitute_fresh_consts_in_terms(FCs,FC1s,RHS,RHS),!.
insert_multi_fresh_consts_in_rule(N,FCs,lrr(Lb,CAT,LHS1,RHS1),lrr(Lb1,CAT,LHS2,RHS2)) :-
	number(N),
	build_sort(Lb,N,Lb1),
	build_new_fresh_consts(FCs,N,FC1s),
	substitute_fresh_consts_in_terms(FCs,FC1s,LHS1,TmpLHS1),	
	substitute_fresh_consts_in_terms(FCs,FC1s,RHS1,TmpRHS1),
	(N > 1 ->
	    substitute_session_terms(N,TmpLHS1,LHS2),
	    substitute_session_terms(N,TmpRHS1,RHS2)
	;
	    LHS2 = TmpLHS1,
	    RHS2 = TmpRHS1
	).

build_repetition_session_term(Ses,N1-N2,Ses) :-
	N1 >= N2.
build_repetition_session_term(Ses1,N1-N2,Ses2) :-
	N1 < N2,
	M1 is N1 + 1,
	build_repetition_session_term(s(Ses1),M1-N2,Ses2).
	
build_new_fresh_consts([],_,[]).
build_new_fresh_consts([FC|FCs],N,[FC1|FC1s]) :-
	build_sort(FC,N,FC1),
	build_new_fresh_consts(FCs,N,FC1s).

substitute_fresh_consts_in_terms(_,_,[],[]).
substitute_fresh_consts_in_terms(FC1s,FC2s,[T1|T1s],[T2|T2s]) :-
	substitute_fresh_consts_in_term(FC1s,FC2s,T1,T2),
	substitute_fresh_consts_in_terms(FC1s,FC2s,T1s,T2s).

substitute_fresh_consts_in_term(FC1s,FC2s,T1,T2) :-
	atom(T1),
	nth(N,FC1s,T1),
	nth(N,FC2s,T2),!.
substitute_fresh_consts_in_term(FC1s,_,T1,T1) :-
	atom(T1),
	\+member(T1,FC1s),!.
substitute_fresh_consts_in_term(FC1s,FC2s,T1,T2) :-
	\+atom(T1),
	T1=..[Funct|T1s],
	substitute_fresh_consts_in_terms(FC1s,FC2s,T1s,T2s),
	T2=..[Funct|T2s].

substitute_session_terms(_,[],[]).
substitute_session_terms(N,[w(Step,S,R,AK,IK,Bool,Ses1)|T1s],[w(Step,S,R,AK,IK,Bool,Ses2)|T2s]) :-
	!,
	build_repetition_session_term(Ses1,1-N,Ses2),
	substitute_session_terms(N,T1s,T2s).
substitute_session_terms(N,[m(Step,RS,OS,R,MSG,Ses1)|T1s],[m(Step,RS,OS,R,MSG,Ses2)|T2s]) :-
	!,
	build_repetition_session_term(Ses1,1-N,Ses2),
	substitute_session_terms(N,T1s,T2s).
substitute_session_terms(N,[secret(S,f(Ses1))|T1s],[secret(S,f(Ses2))|T2s]) :-
	!,
	build_repetition_session_term(Ses1,1-N,Ses2),
	substitute_session_terms(N,T1s,T2s).
substitute_session_terms(N,[give(S,f(Ses1))|T1s],[give(S,f(Ses2))|T2s]) :-
	!,
	build_repetition_session_term(Ses1,1-N,Ses2),
	substitute_session_terms(N,T1s,T2s).

substitute_session_terms(N,[T|T1s],[T|T2s]) :-
	number(N),
	substitute_session_terms(N,T1s,T2s).

%
%          END: NEW FRESH CONSTANTS PER SESSION ITERATION 
%-----------------------------------------------------------------------

build_repetition_session(SessionBase,DeclRepSes) :-
	value(session_repetition,SesRep),
	build_sort('session_base',SessionBase,SessionBaseSort),
	build_repetition_session(SessionBase,SessionBaseSort,1-SesRep,TmpDeclRepSes),
	remove_duplicates(TmpDeclRepSes,DeclRepSes).
build_repetition_session(_,_,N-SesRep,[]) :-
	N > SesRep.
build_repetition_session(SessionBase,
			 RepSessionSort,
			 N-SesRep,
			 [sort(NextSessionSort),
			  super_sort(SessionSort,NextSessionSort),
			  constant(s(RepSessionSort),NextSessionSort)|DeclRepSes]) :-
	N =< SesRep,
	build_sort('session',SessionBase,SessionSort),
	build_sort(SessionSort,'rep',TmpNextSessionSort),
	build_sort(TmpNextSessionSort,N,NextSessionSort),
	(N < SesRep ->
	    build_sort('session',N,TSessionWithoutLastSort),
	    build_sort(TSessionWithoutLastSort,'without_rep_1',SessionWithoutLastSort),
	    AddDeclRepSes = [
			     super_sort(session_without_rep_1,SessionWithoutLastSort),
			     super_sort(SessionWithoutLastSort,NextSessionSort)
			    ]
	;
	    AddDeclRepSes = []
	),
	M is N + 1,
	build_repetition_session(SessionBase,NextSessionSort,M-SesRep,DeclRepSes1),
	append(AddDeclRepSes,DeclRepSes1,DeclRepSes).

build_language_terms([],_,_,[],[]).
build_language_terms([T|Ts],Lb,N,[S|Ss],Ds) :-
	build_language_term(T,Lb,N,S,D1s),
	M is N + 1,
	build_language_terms(Ts,Lb,M,Ss,D2s),
	append(D1s,D2s,Ds).
	
build_language_term(T,Lb,Sort,Ds) :-	
	build_language_term(T,Lb,1,Sort,Ds).
build_language_term(xTime,_,_,fresh_property,[]) :-
	!.
build_language_term(T,Lb,N,LbN,[sort(LbN),constant(C,LbN)|Ds]) :-
	build_sort(Lb,N,LbN),
	T=..[F|Ts],
%	build_sorts(Ts,LbN,Ss),
	build_language_terms(Ts,LbN,1,Ss,Ds),
	C=..[F|Ss].

get_disjoint_lists([],L2s,[],L2s).
get_disjoint_lists([H1|T1s],L2s,[H1|D1s],D2s) :-
	\+syntactic_member(H1,L2s),
	!,
	get_disjoint_lists(T1s,L2s,D1s,D2s).
get_disjoint_lists([H1|T1s],L2s,D1s,D2s) :-
%	syntactic_member(H1,L2s),
	delete(L2s,H1,NL2s),
	get_disjoint_lists(T1s,NL2s,D1s,D2s).

syntactic_member(_,[]) :-
	fail.
syntactic_member(E,[H|T]) :-
	E\==H,
	!,
	syntactic_member(E,T).
syntactic_member(E,[H|_]) :-
	E==H,
	!.

% L is the alternate concatenation of the elements
% of L1 and L2
append_alternation_element(L1,L2,L) :-
	append_alternation_element(L1,L2,L,left).
append_alternation_element([],L2,L2,left).
append_alternation_element(L1,[],L1,right).
append_alternation_element([H1|T1],L2,[H1|L],left) :-
	append_alternation_element(T1,L2,L,right).
append_alternation_element(L1,[H2|T2],[H2|L],right) :-
	append_alternation_element(L1,T2,L,left).

% delete_sublist(L1,L2,L) :-
%       Delete the list L1 from the list L2 and the result is L.
delete_sublist([],L,L).
delete_sublist([H|T],L1,L2) :-
	delete(L1,H,L3),
	delete_sublist(T,L3,L2).

%
%          END: GENERIC
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PRINT 
%

write_operator_splitting_invariant :-
	format("% Operator Splitting invariant\n\n",[]),
	format("invariant(Action <=> SplittedActions) :-\n\t",[]),
	format("value(operator_splitting,on),\n\t",[]),
	format("action(Action,_,_,_,_),\n\t",[]),
	format("Action=..[Lb|[Arg|Args]],\n\t",[]),
	format("Args \\== [],\n\t",[]),	
	format("build_splitted_action(Lb,[Arg|Args],0,SplittedActions).\n",[]).

write_session_condition :-
	format("% Prolog Predicate Session Condition\n\n",[]),
	% First Clause
% 	session_condition(RepSes,Ses) :-
% 		value(session_repetition,NumberOfRepSes),
% 		session_condition(RepSes,Ses,0-NumberOfRepSes).
	format("session_condition(RepSes,Ses) :-\n\t",[]),
	format("value(session_repetition,NumberOfRepSes),\n\t",[]),
	format("session_condition(RepSes,Ses,0-NumberOfRepSes).\n",[]),
	% Second Clause
% 	session_condition(RepSes,Ses,N-NumberOfRepSes) :-
% 		N < NumberOfRepSes,
% 		(
% 		  RepSes = Ses;
% 		  M is N + 1,
% 		  session_condition(RepSes,s(Ses),M-NumberOfRepSes)
% 		).
	format("session_condition(RepSes,Ses,N-NumberOfRepSes) :-\n\t",[]),
	format("N < NumberOfRepSes,\n\t",[]),
	format("(\n\t\t",[]),
	format("RepSes = Ses;\n\t\t",[]),
	format("M is N + 1,\n\t\t",[]),
	format("session_condition(RepSes,s(Ses),M-NumberOfRepSes)\n\t",[]),	
	format(").\n",[]).

	
% DEBUG
write_declarations(Ds) :-
	assert(syntax(sate)),
	pre_declarations(PDs),
	write('% INDEPENDENT PART'),
	nl,nl,
	write_list(PDs),
	write('% DEPENDENT PART'),
        nl,
	write_list(Ds),
        nl,
	retract(syntax(sate)).

% Version 1.1
write_declarations(Cs-Ss-SPSs-INVs-Fs-As-Gs) :-
	format(":- dynamic \n\t",[]),
	format("sort/1,\n\t",[]),
	format("super_sort/2,\n\t",[]),
	format("constant/2,\n\t",[]),
	format("invariants/1,\n\t",[]),
	format("static/1,\n\t",[]),
	format("facts/1,\n\t",[]),
	format("action/5,\n\t",[]),
	format("goal/1.\n\n",[]),
	assert(syntax(sate)),
	pre_declarations(Ds),
	write('% INDEPENDANT PART'),
	nl,nl,
	write_list(Ds),
	write('% SORTs'),
        nl,
	write_list(Ss),
        nl,
	write('% SUPER_SORTs'),
        nl,
	write_list(SPSs),
        nl,
	write('% CONSTANTs'),
        nl,
	write_list(Cs),
        nl,
	write('% INVARIANTs'),
        nl,
	write_list(INVs),
        nl,
        nl,nl,
	write_list(Fs),
	write_list(As),
	write_list(Gs),
	retract(syntax(sate)).

% Version 1.0
% write_declarations(Cs-Ss-SPSs-INVs-Fs-As-Gs) :-
% 	format(":- dynamic \n\t
% 	   sort/1,\n\t
% 	   super_sort/2,\n\t
% 	   constant/2,\n\t
% 	   invariants/1,\n\t
% 	   static/1,\n\t
% 	   facts/1,\n\t
% 	   action/5,\n\t
% 	   goal/1.\n\n",[]),
% 	assert(syntax(sate)),
% 	pre_sorts(PRESs),
% 	pre_super_sorts(PRESPSs),
% 	pre_constants(PRECs),
% 	pre_invariants(PREINVs),
% 	append(PRESs,Ss,TTSs),
% 	append(PRESPSs,SPSs,TTSPSs),
% 	append(PRECs,Cs,TTCs),
% 	append(PREINVs,INVs,TINVs),
% 	remove_duplicates(TTSs,TSs),
% 	remove_duplicates(TTSPSs,TSPSs),
% 	remove_duplicates(TTCs,TCs),
% 	write('% SORTs'),
%         nl,
% 	write_list(TSs),
%         nl,
% 	write('% SUPER_SORTs'),
%         nl,
% 	write_list(TSPSs),
%         nl,
% 	write('% CONSTANTs'),
%         nl,
% 	write_list(TCs),
%         nl,
% 	write('% INVARIANTs'),
%         nl,
% 	write_list(TINVs),
%         nl,
%         nl,nl,
% 	write_list(Fs),
% 	write_list(As),
% 	write_list(Gs),
% 	retract(syntax(sate)).

% write_list(Ls) :-  
%       Write the list of facts Ls on the output stream
write_list([]).
write_list([L]):-
	print(L).
%	put_code(46).
write_list([L|Ls]) :-  
	print(L),
% 	put_code(46), 
% 	put_code(10), 
	write_list(Ls).

portray(comment(C)) :-
	syntax(sate),
	format('% ~w\n',[C]).

portray(monotone(M)) :-
	syntax(sate),
	format('monotone(~w).\n',[M]).

portray(static(S)) :-
	syntax(sate),
	format('static(~w).\n',[S]).

portray(is_not_conflict_fluent(F)) :-
	syntax(sate),
	format('is_not_conflict_fluent(~w).\n',[F]).

portray(sort(S)) :- 
	syntax(sate),
	format('sort(~w).\n',[S]).

portray(super_sort(SPS,S)) :- 
	syntax(sate),
	format('super_sort(~w,~w).\n',[SPS,S]).

portray(constant(C,S)) :- 
	syntax(sate),
	format('constant(~w,~w).\n',[C,S]).

portray(invariant(I)) :- 
	syntax(sate),
	format('invariant(~w).\n',[I]).

portray(facts(Fs)) :- 
	syntax(sate),
	format('%%% INITIAL STATE\nfacts(~p).\n\n',[lits(Fs)]).

portray(action(ActionName,C,Pre,Add,Del)) :- 
	syntax(sate),
	format('action(~w,\n\t~w,\n\t~p,\n\t~p,\n\t~p).\n\n',
	       [ActionName,C,lits(Pre),lits(Add),lits(Del)]).

portray(goal(C,Fs)) :- 
	syntax(sate),
	format('%%% GOAL STATE\ngoal(~w,\n\t~p).\n\n',[C,lits(Fs)]).

portray(lits(Ls)) :- 
	syntax(sate),
	print_lits(Ls).

print_lits([]) :- !, write('[]').%format('[]',[]).
%print_lits([inknw(_,_,_,_)]) :- !, format('[]',[]).
print_lits([L]) :- !, format('[~w]',[L]).
% print_lits([inknw(_,_,_,_)|Ls]) :- !,
% 	format('[~w',[L]),
% 	print_lits(Ls).
print_lits([L|Ls]) :- !,
	format('[~w',[L]),
	print_lits_rest(Ls).

print_lits_rest([]) :- format(']',[]).
% print_lits_rest([inknw(_,_,_,_)|Ls]) :-
% 	!,
% 	print_lits_rest(Ls).
print_lits_rest([L|Ls]) :-
	format(',\n\t ~w',[L]),
	print_lits_rest(Ls).

%
%          END: PRINT
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: ASSERTIONs and RETRACTs
%

assert_declaration_list([]).
assert_declaration_list([comment(_)|Ds]) :-
	!,assert_declaration_list(Ds).

assert_declaration_list([D|Ds]) :-
	assert(D),
	assert_declaration_list(Ds).

retract_declaration_list([]).
retract_declaration_list([comment(_)|Ds]) :-
	!,retract_declaration_list(Ds).
retract_declaration_list([D|Ds]) :-
	retract(D),
	retract_declaration_list(Ds).

retractall_sate_declarations :-
	retractall(sort(_)),
	retractall(super_sort(_,_)),
	retractall(constant(_,_)),
	retractall(invariants(_)),
	retractall(static(_)),
	retractall(monotone(_)),
	retractall(facts(_)),
	retractall(action(_,_,_,_,_)),
	retractall(goal(_,_)).

retractall_declarations :-
	retractall_sate_declarations,
	retractall(sate2prolog_maps_var(_,_)),
	retractall(internal_counter(_)),
	retractall(redundant_declaration(_)).	

% % TODO
% get_sate_assertions(Ds) :-
% 	findall(sort(S),
% 		sort(S),
% 		Ss),
% 	findall(constant(C,CS),
% 		constant(C,CS),
% 		Cs),
% 	findall(super_sort(SPS,SubS),
% 		super_sort(SPS,SubS),
% 		SPSs),


get_actionbody_assertions(Acts) :-
	findall(action(ActName,C,PRE,ADD,DEL),
		action(ActName,C,PRE,ADD,DEL),
		Acts).
get_actiondef_assertions(ActConsts) :-
	findall(constant(C,action),
		constant(C,action),
		ActConsts).

%
%          END: ASSERTIONs and RETRACTs
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: Terms translation from Sate to Prolog and viceversa
%

sate2prolog_declarations([],[]).
sate2prolog_declarations([SD|SDs],
			 [PD,sate2prolog_maps_var(PD,MAPs_VAR_SATE2PROLOG)|PDs]) :-
	sate2prolog_term(SD,[],MAPs_VAR_SATE2PROLOG,PD),
	sate2prolog_declarations(SDs,PDs).

sate2prolog_terms([],MAPs_VAR_SATE2PROLOG,MAPs_VAR_SATE2PROLOG,[]).
sate2prolog_terms([ST|STs],MAP1s_VAR_SATE2PROLOG,MAP3s_VAR_SATE2PROLOG,[PT|PTs]) :-
	sate2prolog_term(ST,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,PT),
	sate2prolog_terms(STs,MAP2s_VAR_SATE2PROLOG,MAP3s_VAR_SATE2PROLOG,PTs).

sate2prolog_term(ST,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,PT) :-
	is_sate_var(ST),!,
	(member(ST-PT,MAP1s_VAR_SATE2PROLOG) ->
	    MAP2s_VAR_SATE2PROLOG = MAP1s_VAR_SATE2PROLOG
	;
	    append([ST-PT],MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG)
	).
sate2prolog_term('_',MAPs_VAR_SATE2PROLOG,MAPs_VAR_SATE2PROLOG,_) :- !.
sate2prolog_term(T,MAPs_VAR_SATE2PROLOG,MAPs_VAR_SATE2PROLOG,T) :-
	\+is_sate_var(T),
	atom(T),!.
sate2prolog_term(ST,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,PT) :-
	\+atom(ST),
	ST=..[FT|SArgs],
	sate2prolog_terms(SArgs,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,PArgs),
	PT=..[FT|PArgs].

prolog2sate_declarations([],[]).
prolog2sate_declarations([PD|PDs],[SD|SDs]) :-
	sate2prolog_maps_var(PD,MAPs_VAR_SATE2PROLOG),
	prolog2sate_term(PD,MAPs_VAR_SATE2PROLOG,_,SD),
	prolog2sate_declarations(PDs,SDs).

prolog2sate_terms([],MAPs_VAR_SATE2PROLOG,MAPs_VAR_SATE2PROLOG,[]).
prolog2sate_terms([PT|PTs],MAP1s_VAR_SATE2PROLOG,MAP3s_VAR_SATE2PROLOG,[ST|STs]) :-
	prolog2sate_term(PT,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,ST),
	prolog2sate_terms(PTs,MAP2s_VAR_SATE2PROLOG,MAP3s_VAR_SATE2PROLOG,STs).

prolog2sate_term(PT,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,ST) :-
	var(PT),!,
	( (member(ST-PT1,MAP1s_VAR_SATE2PROLOG),PT1==PT) ->
	    MAP2s_VAR_SATE2PROLOG = MAP1s_VAR_SATE2PROLOG
	;
	    generate_sate_term(ST,MAP1s_VAR_SATE2PROLOG),
	    append([ST-PT],MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG)
	).
prolog2sate_term(T,MAPs_VAR_SATE2PROLOG,MAPs_VAR_SATE2PROLOG,T) :-
	\+var(T),
	atom(T),!.
prolog2sate_term(PT,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,ST) :-
	\+atom(PT),
	PT=..[FT|PArgs],
	prolog2sate_terms(PArgs,MAP1s_VAR_SATE2PROLOG,MAP2s_VAR_SATE2PROLOG,SArgs),
	ST=..[FT|SArgs].

generate_sate_term(ST,MAPs_VAR_SATE2PROLOG) :-
	generate_sate_term(ST,1,MAPs_VAR_SATE2PROLOG).
generate_sate_term(ST,N,MAPs_VAR_SATE2PROLOG) :-
	format_to_chars("A~w",[N],CST),
	atom_chars(ST,CST),
	(\+member(ST-_,MAPs_VAR_SATE2PROLOG) ->
	    true
	;
	    M is N + 1,
	    generate_sate_term(ST,M,MAPs_VAR_SATE2PROLOG)
	).

%
%          END: Terms translation from Sate to Prolog and viceversa
%-----------------------------------------------------------------------

% DEBUG

print_preprocessed_message(MSG) :-
	preprocess_msg(MSG,1,Sort,Cs-Ss-SPSs),
	nl,
	print_preprocessed_message(Sort,Cs,0),
	nl,
	nl,
	write(Ss),
	nl,
	write(SPSs).

print_preprocessed_message([],_,_).
print_preprocessed_message([Sort|Sorts],Cs,N) :-
	print_preprocessed_message(Sort,Cs,N),
	print_preprocessed_message(Sorts,Cs,N).

print_preprocessed_message(Sort,Cs,N) :-
	\+is_list(Sort),
	OFFSET is 5 * N,
	print_spaces(OFFSET),
	format("~w\n",[Sort]),
	(member(constant(C,Sort),Cs) ->
	    (
	      C=..[_|SubSorts],
	      M is N + 1,
	      print_preprocessed_message(SubSorts,Cs,M)
	    );
	    true
	).

print_spaces(0).
print_spaces(N) :-
	N > 0,
	write(' '),
	M is N - 1,
	print_spaces(M).
		
check_preprocess_messages(Ds,MSG) :-
	check_preprocess_messages(Ds),
	preprocess_msg(MSG,1,_,Cs-Ss-SPSs),
	append(Cs,Ss,TmpDs),
	append(TmpDs,SPSs,Ds),
	assert_declaration_list(Ds).

check_preprocess_messages(Ds) :-
	pre_declarations(PreDs),
	assert_declaration_list(PreDs),
	assert_declaration_list(Ds).
	
prova(ST,MAP2s) :-
	sate2prolog_term(action(divert_b('X5','X4','X3','X1'),
				true,
				[m('X1','X3','X4','X5')],
				[i(mr(b)),i('X3'),i('X4'),i('X5')],
				[m('X1','X3','X4','X5')]),
			 [],MAP1s,PT),
	assert(PT),
	action(N,C,PRE,ADD,DEL),
	prolog2sate_term(action(N,C,PRE,ADD,DEL),MAP1s,MAP2s,ST).


session_condition(RepSes,Ses) :-
	value(session_repetition,NumberOfRepSes),
	session_condition(RepSes,Ses,0-NumberOfRepSes).
session_condition(RepSes,Ses,N-NumberOfRepSes) :-
	N < NumberOfRepSes,
	(
		RepSes = Ses;
		M is N + 1,
		session_condition(RepSes,s(Ses),M-NumberOfRepSes)
	).

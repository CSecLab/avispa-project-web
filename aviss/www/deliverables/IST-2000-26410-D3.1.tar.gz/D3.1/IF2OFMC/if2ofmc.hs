{--------------------------------------------------------
| if2ofmc.hs                                            |
|--------------------------------------------------------
| Translator from IF to Haskell for on-the-fly model checking
|
| $Author: moedersh $
| $Revision: 1.1 $ of $Date: 2001/10/02 16:21:04 $
| [imported from personal repository 
|  on revision 1.17 at 2001/07/13]
|
| Overview:
| ---------
| (1) AST: Abstract Syntax Tree (for IF)
| (2) Parser for IF (Producing AST-type data)
| (3) Evaluations and transformations necessary on the AST
| (4) Pretty printer producing the Haskell code
|------------------------------------------------------}

infixl 5 >.>

--- GLOBAL OPTIONS:


exceptional_handling_of_xSe = False

{-------------------------------------
   PART (1): AST for IF
 -------------------------------------
 Note: We rely on the input consisting 
 of well-formed IF-Terms only.
 -------------------------------------}

--- *******************************************************
--- these definitions from Prelude.hs must be commented out
--- when running in HUGS
--- *******************************************************

isAlpha c              =  isUpper c  ||  isLower c
isDigit c              =  c >= '0'   &&  c <= '9'
isUpper c              =  c >= 'A'   &&  c <= 'Z'
isLower c              =  c >= 'a'   &&  c <= 'z'
isAlphanum c           =  isAlpha c  ||  isDigit c
toLower c | isUpper c  = toEnum (fromEnum c - fromEnum 'A' + fromEnum 'a')
          | otherwise  = c

--- *******************************************************

myAlphanum c = isAlphanum c || c=='_'

flatten = foldr (++) []

type Variable = String
type Atom     = String

data Message 
     = Variable Variable
     | Mr Atom
     | Pk Message
     | Pk' Message
     | Sk Message
     | Nonce Message
     | Crypt Message Message
     | Scrypt Message Message
     | C Message Message
     | End
     | Pre Message
     | SessionNr Int
     | SuccSession Message
     | Step Int
     | StepTerm Variable
     | Atom String
     | Etc
     deriving (Eq, Show)

data MBool = MTrue
           | MFalse
           | MVar String deriving (Eq,Show)

data Term 
     = W Message Message Message Message Message MBool Message
     | M Message Message Message Message Message Message
     | I Message 
     | Subst String String
     | Secret Message Message
     deriving (Eq, Show)

type State = [Term]

data Rule
     = Initial State
     | MsgRule State State
     | Flaw State 
     deriving (Eq, Show)

{-------------------------------------
   PART (2): Parser: IF -> AST
 -------------------------------------}

type Parser t = String -> (t, String)

predchar :: (Char -> Bool) -> Parser Char
predchar p (x:xs) = if (p x) then (x,xs) else error ("Something else expected")
predchar p [] = error "Unexpected EOF"

keychar :: Char -> Parser Char
keychar c l = predchar (== c) l

mklistparser :: Parser t -> Parser [t]
mklistparser pa str = let (p,str') = pa str in ([p],str')

pconcat :: Parser [t] -> Parser [t] -> Parser [t]
pconcat p1 p2 str = 
       let (p1',str') = p1 str in 
	   let (p2', str'') = p2 str' in
	       ((p1'++p2'),str'')

keyword :: String -> Parser String
keyword key = foldl pconcat (\x -> ([],x)) (map (mklistparser . keychar) key)

consume :: String -> String -> String
consume key str = let (_,rest) = keyword key str in rest

parse_after :: Parser t -> String -> String -> (t,String)
parse_after  p eingabe key = let (ps,rest) = p eingabe in 
                             (ps, consume key rest)

ifkey :: String -> String -> Bool
ifkey [] _ = True
ifkey (x:xs) [] = False
ifkey (x:xs) (y:ys) = (x==y) && (ifkey xs ys)

aslongas :: (Char -> Bool) -> Parser String
aslongas p [] = ([],[])
aslongas p (x:xs) = 
	 if (p x) then let (str,rest) = aslongas p xs in (x:str, rest)
	 else ([], x:xs)

pAtom :: Parser Atom
pAtom str = 
  let str' = if (ifkey "id" str) then consume "id" str else str in
  aslongas (\x -> myAlphanum x || x=='\'') str'

pVariable :: Parser Variable
pVariable = pconcat (keyword "x") pAtom

applFrst :: Parser t -> (t->s) -> Parser s
applFrst p f inp = let (ps,r)= p inp in (f ps, r)

pMessage :: Parser Message
pMessage inp =
  if (ifkey "x" inp) then applFrst pVariable Variable inp
  else if (ifkey "mr" inp) then parse_after (applFrst pAtom Mr) (consume "mr(" inp) ")" 
  else if (ifkey "pk" inp) then 
         let (ps,rest)=parse_after pMessage (consume "pk(" inp) ")" in
	   if (ifkey "'" rest) then
	    (Pk' ps, consume "'" rest)
	    else (Pk ps,rest)
  else if (ifkey "sk" inp) then 
         parse_after (applFrst pMessage Sk) (consume "sk(" inp) ")"	 
  else if (ifkey "nonce" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "nonce(" inp) ")" in
        (Nonce msg1, rest)
  else 
    if (ifkey "crypt" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "crypt(" inp) "," in
        (parse_after (applFrst pMessage (\x -> Crypt msg1 x)) rest ")")
  else 
    if (ifkey "scrypt" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "scrypt(" inp) "," in
        (parse_after (applFrst pMessage (\x -> Scrypt msg1 x)) rest ")")
  else
    if (ifkey "c" inp) then 
      let (msg1,rest) = parse_after pMessage (consume "c(" inp) "," in
        (parse_after (applFrst pMessage (\x -> C msg1 x)) rest ")")
  else if (ifkey "etc2" inp) then (Etc,(consume "etc2" inp)) 
  else if (ifkey "etc" inp) then (Etc,(consume "etc" inp)) 
  else
    let (atom,rest)=pAtom inp in
      (Variable atom,rest)

pInt :: Parser Int
pInt str = let (num,rest) = aslongas isDigit str in (read num, rest)

pIntT :: Parser Message
pIntT str = 
  if (ifkey "x" str) then
    let (var,rest) = pVariable str in (Variable var,rest)
  else let (num,rest) = aslongas isDigit str 
       in ( (bin2un (read num)), rest)

pSession :: Parser Message
pSession inp =
  if (ifkey "x" inp) then 
    let (var,rest) = pVariable inp in 
      (Variable var,rest)
  else if (ifkey "s" inp) then
    let (term,rest)=pSession (consume "s(" inp) in
      (SuccSession term, consume ")" rest)  
  else applFrst pInt SessionNr inp

pSecret :: Parser Message
pSecret inp =
  if (ifkey "f" inp) then
    let (msg,rest) = pSecret (consume "f(" inp) in 
      (msg,consume ")" rest)   
  else if (ifkey "x" inp) then 
    let (var,rest) = pVariable inp in 
      (Variable var,rest)
  else if (ifkey "s" inp) then
    let (term,rest)=pSecret (consume "s(" inp) in
      (SuccSession term, consume ")" rest)  
  else applFrst pInt SessionNr inp

bin2un :: Int -> Message
bin2un 0 = End
bin2un (n+1) = Pre (bin2un n)

pStep :: Parser Message
pStep str = 
  if (ifkey "x" str) then
    let (var,rest) = pVariable str in (StepTerm var,rest)
  else let (num,rest) = aslongas isDigit str 
       in (Step (read num), rest)

pBool :: Parser MBool
pBool str =
  if (ifkey "true" str) then (MTrue,consume "true" str)
  else if (ifkey "false" str) then (MFalse,consume "false" str)
       else if (ifkey "x" str) then 
                  let (name,rest) = pAtom str in (MVar name, rest)
            else error "Corrupted Bool"

pTerm :: Parser Term
pTerm inp =
  if (ifkey "w" inp) then 
    let (step,rest)=pStep (consume "w(" inp) in
    let (sender,rest2)=pMessage (consume "," rest) in
    let (receiver,rest3)=pMessage (consume "," rest2) in
    let (acknow,rest4)=pMessage (consume "," rest3) in
    let (know,rest5)=pMessage (consume "," rest4) in
    let (bool,rest6)=pBool (consume "," rest5) in
    let (sc,rest7)=pSession (consume "," rest6) in
    (W step sender receiver acknow know bool sc, consume ")" rest7)
  else if (ifkey "m" inp) then 
    let (step,rest)=pStep (consume "m(" inp) in
    let (rlsender,rest2)=pMessage (consume "," rest) in
    let (ofsender,rest3)=pMessage (consume "," rest2) in
    let (receiver,rest4)=pMessage (consume "," rest3) in
    let (contents,rest5)=pMessage (consume "," rest4) in
    let (sc,rest6)=pSession (consume "," rest5) in
    (M step rlsender ofsender receiver contents sc, consume ")" rest6)
  else if (ifkey "i" inp) then
    let (know,rest)=pMessage (consume "i(" inp) in
    (I know, consume ")" rest)
  else if ifkey "secret" inp then
    let (secterm,rest) = pMessage (consume "secret(" inp) in
    let (sessterm,rest') = pSecret (consume "," rest) in
    (Secret secterm sessterm, consume ")" rest')
  else error "The parser is very confused now."

pState :: Parser State
pState inp =
  let (fact,rest)=pTerm inp in
  if (ifkey "." rest) then 
     let (state,rest2)=pState (consume "." rest) in (fact:state,rest2)
  else ([fact],rest)

pk_scan :: Rule -> Rule
pk_scan rule = handle_privates (map remlast (cont_priv rule)) rule

remlast [x] = []
remlast (x:xs) = x:(remlast xs)

handle_privates :: [String] -> Rule -> Rule
handle_privates [] r = r
handle_privates (x:xs) rule = 
  let rule' = if (contains rule x) 
              then (substitute (substitute rule x (Pk (Variable x))) (x++"'") (Pk' (Variable x)))
	      else rule 
  in handle_privates xs rule'

cont_priv :: Rule -> [String]
cont_priv (Initial state) = flatten (map contTermpriv state)
cont_priv (MsgRule lhs rhs) = flatten ((map contTermpriv lhs )
				 ++ (map contTermpriv  rhs))
cont_priv (Flaw state) = cont_priv (Initial state)

contTermpriv :: Term -> [String]
contTermpriv (W _ _ _ m4 m5 _ _) = (contMsgPriv m4) ++ (contMsgPriv m5)
contTermpriv (M _ _ _ _ m5 _) = (contMsgPriv m5)
contTermpriv (I m) = (contMsgPriv m)
contTermpriv (Subst t1 t2) = []
contTermpriv (Secret m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)

privname :: String -> Bool
privname [] = False
privname "'" = True
privname (x:xs) = privname xs

contMsgPriv :: Message -> [String]
contMsgPriv (Variable v) = if (privname v) then [v] else []
contMsgPriv (Mr v) =  if (privname v) then [v] else []
contMsgPriv (Pk v) =  contMsgPriv v --- if (privname v) then [v] else []
contMsgPriv (Pk' v) =  contMsgPriv v --- if (privname v) then [v] else []
contMsgPriv (Sk v) =  contMsgPriv v --- if (privname v) then [v] else []
contMsgPriv (Crypt m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (Scrypt m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv (C m1 m2) = (contMsgPriv m1) ++ (contMsgPriv m2)
contMsgPriv End = []
contMsgPriv (Pre m) = contMsgPriv m
contMsgPriv (SessionNr m) = []
contMsgPriv (SuccSession m) = contMsgPriv m
contMsgPriv (Step m) = []
contMsgPriv (StepTerm m) = []
contMsgPriv _ = []

contains :: Rule -> String -> Bool
contains (Initial state) term = (filter (contTerm term) state)/=[]
contains (MsgRule lhs rhs) term = (filter (contTerm term) lhs)/=[] 
				  || (filter (contTerm term) rhs)/=[]
contains (Flaw state) term = contains (Initial state) term

contTerm :: String -> Term -> Bool
contTerm term (W _ _ _ m4 m5 _ _) = (contMsg term m4) || (contMsg term m5)
contTerm term (M _ _ _ _ m5 _) = (contMsg term m5)
contTerm term (I m) = (contMsg term m)
contTerm term (Subst t1 t2) = False
contTerm term (Secret m1 m2) = (contMsg term m1) || (contMsg term m2)

contMsg :: String -> Message -> Bool
contMsg s (Variable v) = s==v
contMsg s (Mr m) = s==m
contMsg s (Pk p) = contMsg s p
contMsg s (Pk' p) = contMsg s p
contMsg s (Sk s') = contMsg s s'
contMsg s (Crypt m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (Scrypt m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s (C m1 m2) = (contMsg s m1) || (contMsg s m2)
contMsg s End = False
contMsg s (Pre m) = contMsg s m
contMsg s (SessionNr m) = False
contMsg s (SuccSession m) = contMsg s m
contMsg s (Step m) = False
contMsg s (StepTerm m) = False
contMsg _ _ = False

substitute :: Rule -> String -> Message -> Rule
substitute (Initial state) str term = Initial (map (substTerm str term) state)
substitute (MsgRule lhs rhs) str term =  
  MsgRule (map (substTerm str term) lhs)(map (substTerm str term) rhs)
substitute (Flaw state) str term = Flaw (map (substTerm str term) state)

substTerm :: String -> Message -> Term -> Term
substTerm str term (W m1 m2 m3 m4 m5 m6 m7) = 
  W m1 m2 m3 (substMsg str term m4) (substMsg str term m5) m6 m7
substTerm str term (M m1 m2 m3 m4 m5 m6) = 
  M m1 m2 m3 m4 (substMsg str term m5) m6
substTerm str term (I m) = I (substMsg str term m)
substTerm str term (Subst t1 t2) = (Subst t1 t2)
substTerm str term (Secret m1 m2) = 
  Secret (substMsg str term m1) (substMsg str term m2)

substMsg :: String -> Message -> Message -> Message
substMsg s t (Variable v) = if (s==v) then t else (Variable v)
substMsg s t (Crypt m1 m2) = Crypt (substMsg s t m1) (substMsg s t m2)
substMsg s t (Scrypt m1 m2) = Scrypt (substMsg s t m1) (substMsg s t m2)
substMsg s t (C m1 m2) = C (substMsg s t m1) (substMsg s t m2)
substMsg s t (Pre m) = Pre (substMsg s t m)
substMsg s t (SuccSession m) = Pre (substMsg s t m)
substMsg _ _ m = m

pRule :: [String] -> String -> ([String],[String]) -> (Rule,([String],[String]),[String])
pRule (inp:lines) name (rulez,goalz) =
  if (ifkey "h(xTime)." inp) then 
    let (state,"") = pState (consume "h(xTime)." inp) in
    (pk_scan (Initial state), (rulez,goalz), lines)
  else if (ifkey "h(s(xTime))." inp) then 
    let (lhs, "") = pState (consume "h(s(xTime))." inp) in
    let "=>":(l:ls) = lines in
    let (rhs, "") = pState (consume "h(xTime)." l) in
    (pk_scan (MsgRule lhs rhs),(name:rulez,goalz),ls)
  else 
    let (state,"") = pState inp in 
    (pk_scan (Flaw state), (rulez,name:goalz), lines)

{------------------------
 PART (3): AST -> Haskell 
 ------------------------}

type Reuse = ([String]) --- List of used variable names

subst :: String -> [String] -> String
subst v l  --- find something like v not in list (v is already in list)
 = if (v++"_") `elem` l then subst (v++"_") l else v++"_"

rewMsg :: String -> Reuse -> (String -> Message) -> (Message,[Term],Reuse)
rewMsg v used con =
 if (head v)=='x' then
   if v `elem` used then
     let v'=subst v used in
       (con v', [Subst v v'], (v':used))
   else
     (con v,[], (v:used))
 else (con v,[], used)

lMsg :: (Message,Reuse) -> (Message,[Term],Reuse)
lMsg (Variable v, reuse) = rewMsg v reuse Variable
lMsg (Mr v, reuse) = rewMsg v reuse Mr
lMsg (Pk msg, reuse) =
  let (msg', sub, reuse') = lMsg (msg,reuse) in
  (Pk msg', sub, reuse')
lMsg (Pk' msg, reuse) =
  let (msg', sub, reuse') = lMsg (msg,reuse) in
  (Pk' msg', sub, reuse')
lMsg (Sk msg, reuse) =
  let (msg', sub, reuse') = lMsg (msg,reuse) in
  (Sk msg', sub, reuse')
lMsg (Nonce msg, reuse) =
  let (msg', sub, reuse') = lMsg (msg,reuse) in
  (Nonce msg', sub, reuse')
lMsg (Crypt msg1 msg2, reuse) =
  let (msg1',sub1,reuse')=lMsg (msg1,reuse) in
  let (msg2',sub2,reuse'')=lMsg (msg2,reuse') in
  (Crypt msg1' msg2', sub1++sub2, reuse'')
lMsg (Scrypt msg1 msg2, reuse) =
  let (msg1',sub1,reuse')=lMsg (msg1,reuse) in
  let (msg2',sub2,reuse'')=lMsg (msg2,reuse') in
  (Scrypt msg1' msg2', sub1++sub2, reuse'')
lMsg (C msg1 msg2, reuse) =
  let (msg1',sub1, reuse')=lMsg (msg1,reuse) in
  let (msg2',sub2, reuse'')=lMsg (msg2,reuse') in
  (C msg1' msg2', sub1++sub2,reuse'')
lMsg (Pre x,reuse)=
  let (x',s,reuse')=lMsg (x,reuse) in
  (Pre x',s,reuse')
lMsg (SuccSession x,reuse)=
  let (x',s,reuse')=lMsg (x,reuse) in
  (SuccSession x',s,reuse')
lMsg (a,b)=(a,[],b)

lBool :: (MBool,Reuse) -> (MBool,[Term],Reuse)
lBool (MVar str,reuse)= 
  if str `elem` reuse then
     let str'=subst str reuse in
       (MVar str', [Subst str str'], (str':reuse))
   else
     (MVar str,[], (str:reuse))
lBool (b,reuse)=(b,[],reuse)

lTerm :: (Term,Reuse) -> (Term,[Term],Reuse)
lTerm (W i m1 m2 m3 m4 b m5, reuse)=
  let (m1',s1,reuse1)=lMsg (m1,reuse )in
  let (m2',s2,reuse2)=lMsg (m2,reuse1) in
  let (m3',s3,reuse3)=lMsg (m3,reuse2) in
  let (m4',s4,reuse4)=lMsg (m4,reuse3) in
  let (b',s5,reuse5)=lBool (b,reuse4) in
  let (m5',s6,reuse6)=lMsg (m5,reuse5) in
  (W i m1' m2' m3' m4' b' m5', s1++s2++s3++s4++s5++s6, reuse6)
lTerm (M i m1 m2 m3 m4 m5, reuse)=
  let (m1',s1,reuse1)=lMsg (m1,reuse )in
  let (m2',s2,reuse2)=lMsg (m2,reuse1) in
  let (m3',s3,reuse3)=lMsg (m3,reuse2) in
  let (m4',s4,reuse4)=lMsg (m4,reuse3) in
  let (m5',s5,reuse5)=lMsg (m5,reuse4) in
  (M i m1' m2' m3' m4' m5', s1++s2++s3++s4++s5, reuse5)
lTerm (I (Variable m), reuse)=
  let (m',s,reuse1)=lMsg (Variable m,reuse) in
  (I m',s, reuse1)
lTerm (I (m), reuse)=
  let (m',s,reuse1)=lMsg (m,reuse) in
  (I m',s, reuse1)
lTerm (Secret a b, reuse)=
  let (a',s1,reuse1)=lMsg (a,reuse) in
  let (b',s2,reuse2)=lMsg (b,reuse1) in
  (Secret a' b',s1++s2,reuse2)

lState :: (State,Reuse) -> (State,Reuse)
lState ([],reuse) = ([],reuse)
lState ((x:xs),reuse) = 
       let (x',s1,reuse')=lTerm (x,reuse) in
       let (xs',reuse'')=lState (xs,reuse') in
       (x':(s1++xs'),reuse'')

condAtom :: String -> String -> String
condAtom str msg =
    if ifkey "x" msg then "("++str++" "++msg++")"
    else "("++str++" (Atomic \""++msg++"\"))"

cMsg :: Message -> String
cMsg (Variable v) = condAtom "" v
cMsg (Mr atom) = condAtom "Mr " atom
cMsg (Pk atom) = "(Pk "++(cMsg atom)++")"
cMsg (Sk atom) = "(Sk "++(cMsg atom)++")"
cMsg (Pk' atom) = "(Pk' "++(cMsg atom)++")"
cMsg (Nonce atom)= "(Nonce "++(cMsg atom)++")"
cMsg (Crypt msg1 msg2) = "(Crypt "++(cMsg msg1)++" "++(cMsg msg2)++")"
cMsg (Scrypt msg1 msg2) = "(Scrypt "++(cMsg msg1)++" "++(cMsg msg2)++")"
cMsg (C msg1 msg2) = "(C "++(cMsg msg1)++" "++(cMsg msg2)++")"
cMsg (End) = "End"
cMsg (Pre t) = "(Pre "++(cMsg t)++")"
cMsg (SessionNr n)= "(SessionNr "++(show n)++")"
cMsg (SuccSession msg)="(Pre "++(cMsg msg)++")"
cMsg (Step n)="(Step "++(show n)++")"
cMsg (StepTerm v)=v
cMsg (Atom string)= string
cMsg Etc = "Etc"

cBool :: MBool -> String
cBool MTrue = "True"
cBool MFalse = "False"
cBool (MVar str) = str

cStep :: Message -> String
cStep step = (cMsg step) ++" " 

cTerm :: Term -> String
cTerm (W step sender receiver acKno kno b se) 
  = "(W "++(cMsg step)        ++" "
         ++(cMsg sender)      ++" "
	 ++(cMsg receiver)    ++" "
	 ++(cMsg acKno)	      ++" "
	 ++(cMsg kno)	      ++" "
	 ++(cBool b)          ++" "
	 ++(cMsg se)	      ++")"
cTerm (M step realsender sender receiver message se) 
  = "(M "++(cStep step)
         ++(cMsg realsender)  ++" "
         ++(cMsg sender)      ++" "
	 ++(cMsg receiver)    ++" "
	 ++(cMsg message)     ++" "
	 ++(cMsg se)	      ++")"
cTerm (I msg) = "(IK "++(cMsg msg)++")"
cTerm (Secret x f) = "(Secret "++(cMsg x)++" "++(cMsg f)++")"
cTerm (Subst a b) = a++"=="++b

trimPair :: Message -> Message -> Message
trimPair (C msg1 msg2) msg3 = C msg1 (trimMsg (C msg2 msg3))
trimPair msg1 msg2 = C msg1 (trimMsg msg2)

trimMsg :: Message -> Message
trimMsg msg = 
  case msg of
    C msg1 msg2      -> let msg1' = trimMsg msg1
		        in trimPair msg1' msg2
    Pre msg1         -> Pre (trimMsg msg1)
    SuccSession msg1 -> SuccSession (trimMsg msg1)
    Crypt msg1 msg2  -> Crypt (trimMsg msg1) (trimMsg msg2)
    Scrypt msg1 msg2 -> Scrypt (trimMsg msg1) (trimMsg msg2)
    otherwise        -> msg

trimTerm :: Term -> Term
trimTerm (W m1 m2 m3 m4 m5 b m6) = W (trimMsg m1)(trimMsg m2)(trimMsg m3)(trimMsg m4)(trimMsg m5) b (trimMsg m6)
trimTerm (M m1 m2 m3 m4 m5 m6) = M (trimMsg m1)(trimMsg m2)(trimMsg m3)(trimMsg m4)(trimMsg m5)(trimMsg m6)
trimTerm (I m1) = I (trimMsg m1)
trimTerm (Secret m1 m2) = Secret (trimMsg m1)(trimMsg m2)
trimTerm (Subst a b) = (Subst a b)

trimState :: State -> State
trimState = map trimTerm

isNtSubst :: Term -> Bool
isNtSubst (Subst _ _) = False
isNtSubst _ = True

isik :: Term -> Bool
isik (I (Variable _)) = False
isik (I _) = True
isik _ = False

cState :: State -> String
cState' [] = error "Empty State!"
cState' [x] = cTerm x
cState' (x:xs) = (cTerm x) ++ ", " ++ (cState' xs)
cState s = cState' (trimState (filter isNtSubst s))

cStateLHS :: State -> String
cStateLHS' [] = error "Empty State!"
cStateLHS' [x] = if (isNtSubst x) then cTerm x ++ "<- state" else cTerm x
cStateLHS' (x:xs) = 
  if (isNtSubst x) then 
    (cTerm x) ++ "<- state, " ++ (cStateLHS' xs)
  else 
    (cTerm x) ++ ", " ++ (cStateLHS' xs) 
cStateLHS s = cStateLHS' (trimState s)

transSubs [] = ""
transSubs ((u,v):rest) = ", "++u++"=="++v++(transSubs rest)

cRule :: (Rule,String)  -> String
cRule ((Initial state),_) = "initial_state n = [ H  (bin2un n)," ++ (cState state) ++ "]"
cRule ((MsgRule lhs rhs), name)
  = let (lhs',_)=lState (lhs, []) in
     name ++ " state = [ diff ( [ H  xTime, "++ (cState rhs) ++ "] ++state ) [" 
      ++ (cState lhs) ++ 
      ", H (Pre xTime) ] | H (Pre xTime) <- state, " ++ (cStateLHS lhs') ++  "]"
cRule ((Flaw state),name) 
  = let (state',_)=lState (state,[]) in
     name ++ " state = [ [" ++ (cState state) ++ "] | " ++ (cStateLHS state') ++ "]" 


--------------------- Main Routine(s) ----------------

f >.> g = \x -> g (f x)

looping :: String -> [String] -> ([String],[String]) -> [String]
looping name [] (rulez,goalz) =
 ["allrules = [ "++(tail (flatten (map (\x -> ",("++x++",\""++x++"\")") rulez)))++" ]\n"++
  "goal state = []==([]"++(flatten (map (\x -> "++("++x++" state)") goalz))++")"]
looping name (x:xs) env
  =  if (ifkey "#" x) && (not (ifkey "##" x)) then 
       let (name',_) = if (ifkey "# lb=" x) then
			  pAtom (consume "# lb=" x)
		       else pAtom (consume "# " x) in
       let name''= if isLower (head name') then name'
		   else (toLower (head name')):(tail name') in
         looping name'' xs env
     else
       if (x=="" || (ifkey "Fresh" x)) then looping name xs env
       else
         let (rule,env',rest) = pRule (x:xs) name env in 
	 (cRule (rule,name)):(looping "No name given" rest env')

interacter = lines >.> tail >.> (\x -> (("module Rules where\nimport Lazylib\n"):(looping "" x ([],[])))) >.> unlines

main = interact interacter


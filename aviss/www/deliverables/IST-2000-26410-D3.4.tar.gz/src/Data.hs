module Data where
import Stddef

--- Basic Data Types and Functions

type Atomtype = String

type Vartype  = Int

data Msg = Atom Atomtype
	 | Mr Msg
	 | Nonce Msg
	 | Pk Msg
	 | Pk' Msg
	 | Sk Msg
         | Crypt Msg Msg
	 | Scrypt Msg Msg
         | C Msg Msg
         | Var Vartype 
	 | Session Int
	 | Succsession Msg 
	 | Table Msg
	 | Tb Msg Msg
	 | Tb' Msg Msg
	 | Fu Msg
	 | Funct Msg Msg
	 | Rcrypt Msg Msg
	 deriving Eq

instance Show Msg where
  showsPrec _ e = 
    showString 
    (case e of 
       (Atom a) -> a
       (Mr m) -> show m
       (Pk (C m1 m2)) -> (show m1)++"("++(show m2)++")"
       (Pk m) -> show m
       (Pk' (C m1 m2)) -> (show m1)++"'"++"("++(show m2)++")"
       (Pk' m) -> (show m)++"'"
       (Sk (C m1 m2)) -> (show m1)++"("++(show m2)++")"
       (Sk m) -> show m
       (Crypt k m) -> "{"++(show m)++"}"++(show k)
       (Scrypt k m) -> "{"++(show m)++"}"++(show k)
       (C m1 m2) -> (show m1)++","++(show m2)
       (Var v) -> "x"++(show v)
       (Session i) -> "("++(show i)++")"
       (Succsession m) -> "s("++(show m)++")"
       (Nonce (C m1 m2)) -> (show m1)++"("++(show m2)++")"
       (Nonce m) -> show m
       (Fu m) -> show m
       (Funct m1 m2) -> (show m1)++"("++(show m2)++")"
       (Table m) -> show m
       (Tb t k) -> (show t)++"["++(show k)++"]"
       (Tb' t k) -> (show t)++"["++(show k)++"]'"
       (Rcrypt t k) -> (show t)++" XOR "++(show k) )

inv :: Msg -> Msg
inv (Pk a) = (Pk' a)
inv (Pk' a) = (Pk a)
inv (Tb t a) = (Tb' t a)
inv (Tb' t a)= (Tb  t a)
inv msg = error ("Can't inverse "++(show msg))

isInvertible :: Msg -> Bool
isInvertible (Pk a) = True
isInvertible (Pk' a) = True
isInvertible (Tb _ _) = True
isInvertible (Tb' _ _) = True
isInvertible msg = False

isVar :: Msg -> Bool
isVar (Var _) = True
isVar _ = False

isTypedVar :: Msg -> Bool
--- to allow nonce(xNi) as variable, too.
isTypedVar (Var _) = True
isTypedVar (Mr (Var _)) = True
isTypedVar (Pk (Var _)) = True
isTypedVar (Pk' (Var _)) = True
isTypedVar (Sk (Var _)) = True
isTypedVar (Nonce (Var _)) = True
isTypedVar (Fu (Var _)) = True
isTypedVar (Table (Var _)) = True
isTypedVar _ = False

--- Constraint Representation for the Lazy Intruder

type Constraint = ([Msg],[Msg])
--- constraint what items the intruder has to generate from IK

type Rho = [Constraint]

show_rho :: Rho -> String 
show_rho rho = flatten (map (\ (ts,ik) -> (show ts)++" from "++(show ik)) rho)

type Substitution = [(Vartype,Msg)]

type Possibilities = [(Rho,Substitution)]



type Time = Int
type Step = Int

data Fact = M Step Msg Msg Msg Msg Msg
	  | W Step Msg Msg Msg Msg Msg
	  | Secret Msg Msg 
	  | Give Msg Msg
	  | Request Msg Msg Msg Msg
	  | Witness Msg Msg Msg Msg  
	  deriving Eq

instance Show Fact where
  showsPrec p e = 
    case e of
    (M i o s r m c) 
     -> showString ((show i)++"."++( case o of
					  (Var _) -> (show (Atom ("I")))
						     ++ "("++(show s)++")" 
				          (Mr (Atom "xr"))  -> 
					   (show (Atom ("I"))) ++ "("++(show s)++")" 
					  _ -> (show s)) ++ "->" 
		    ++(show r)++":"++(show m)) --- ++"/"++(show c))
    (W i s r st l c) 
     -> showString ("W "++(show i)++" "++(show s)++"->"++(show r)++": "++(show st)++";"++(show l)++"/"++(show c))
    (Secret atom session)
     -> showString ("Secret "++(show atom)++" in "++(show session))
    (Give atom session)
     -> showString ("Give "++(show atom)++" in "++(show session))
    (Request a b c d) 
     -> showString ("Request "++(show a)++(show b)++(show c)++(show d))
    (Witness a b c d) 
     -> showString ("Witness "++(show a)++(show b)++(show c)++(show d))

show_factlist :: [Fact] -> String
show_factlist [] = ""
show_factlist (x:xs) = (show x)++"\n"++(show_factlist xs)

isWTerm (W _ _ _ _ _ _) = True
isWTerm _ = False

isMTerm (M _ _ _ _ _ _) = True
isMTerm _ = False

isSecret (Secret _ _) = True
isSecret _ = False

isGTerm (Give _ _) = True
isGTerm _ = False

isWitness (Witness _ _ _ _) = True
isWitness _ = False

isRequest (Request _ _ _ _) = True
isRequest _ = False

isNIRequest (Request _ (Mr (Atom "I")) _ _) = False
isNIRequest (Request _ _ _ _) = True
isNIRequest _ = False

type State = (Time,[Fact],[Msg],Rho,[Fact])
--- [Msg] is the current intruder knowledge

showState :: State -> String
showState (time,facts,ik,rho,hist) = 
  flatten (map (\ f -> (show f)++"\n") hist)



type Rule = ([Fact],[Fact])
--- LHS RHS

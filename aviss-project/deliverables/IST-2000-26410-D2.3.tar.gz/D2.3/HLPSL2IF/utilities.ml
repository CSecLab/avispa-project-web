(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* utilities *)
open Types;;
open Globals;;

let get_identifier_name identifierNumber = fst (List.assoc identifierNumber !Globals.ident_list)
;;
let rec get_identifier_number identifierName identifierList=
  match identifierList with
    (number,(name,identifierType))::tail ->if (identifierName=name)
    then  number
    else
      (get_identifier_number identifierName tail);
    |_-> ErrorHandler.printExceptionMessage Not_found "Utilities" "getId";raise(Not_found);
;;
let get_identifier_type identifierNumber = snd (List.assoc identifierNumber !Globals.ident_list)
;;
let rec findtype  identifierName identifierlist notifyNotFound=
  match identifierlist with
      [] -> if notifyNotFound then ErrorHandler.printExceptionMessage Not_found "Utilities" "findtype";
	raise Not_found;
  | head::tail -> if fst (snd head) == identifierName then snd (snd head) else findtype identifierName tail notifyNotFound
;;
let fresh_var protocolStep = List.assoc protocolStep !fresh;;

let oph timeTerm =  Op("h",[timeTerm]);;
let opprim privateKeyTerm = Op("prim",[privateKeyTerm]);;
let opmr userTerm =  Op("mr",[userTerm]);;
let oppk publicKeyTerm =  Op("pk",[publicKeyTerm]);;
let opsk secretKeyTerm =  Op("sk",[secretKeyTerm]);;
let opfu functionTerm =  Op("fu",[functionTerm]);;

let opnonce nonceTerm =  Op("nonce",[nonceTerm]);;
let oppair termPart1 termPart2 = Op("c",[termPart1;termPart2]);;
let opcrypt keyTerm cryptedTerm = Op("crypt",[keyTerm;cryptedTerm]);;
let opscrypt key cryptedTerm = Op("scrypt",[key;cryptedTerm]);;
let opfunct functionTerm parameterTerm = Op("funct",[functionTerm;parameterTerm]);;

let opsum operandTerm1 operandTerm2 = Op("sum",[operandTerm1;operandTerm2]);;
let opminus operandTerm1 operandTerm2 = Op("minus",[operandTerm1;operandTerm2]);;
let opmult operandTerm1 operandTerm2 = Op("mult",[operandTerm1;operandTerm2]);;
let opdiv operandTerm1 operandTerm2 = Op("div",[operandTerm1;operandTerm2]);;
let opmod operandTerm1 operandTerm2 = Op("mod",[operandTerm1;operandTerm2]);;
let oppow operandTerm1 operandTerm2 = Op("pow",[operandTerm1;operandTerm2]);;

let oprcrypt operandTerm1 operandTerm2 = Op("rcrypt",[operandTerm1;operandTerm2]);;
let opand operandTerm1 operandTerm2 = Op("and",[operandTerm1;operandTerm2]);;
let opor operandTerm1 operandTerm2 = Op("or",[operandTerm1;operandTerm2]);;
let opnand operandTerm1 operandTerm2 = Op("and",[operandTerm1;operandTerm2]);;
let opnor operandTerm1 operandTerm2 = Op("nor",[operandTerm1;operandTerm2]);;

let opw step sender receiver acqKnowledge initialKnowledge boolean session  
  = Op("w",[ step; sender; receiver; acqKnowledge; initialKnowledge; boolean; session]);;
let opm step realsender officialSender receiver contents session 
  = Op("m",[step;realsender;officialSender;receiver;contents;session]);; 
let opi knownTerm = Op("i",[knownTerm]);; 
let opsecret t1 t2 =  Op("secret",[t1;t2]);; 
let ops sessionCounter =  Op("s",[sessionCounter]);;
let opf sessionCounter =  Op("f",[sessionCounter]);;

let optable tableTerm elementTerm = Op("table",[tableTerm;elementTerm]);; 
let optb tableTerm =  Op("tb",[tableTerm]);;

let op_of_type typ =
  match typ with
      User -> opmr
    | SyKey -> opsk
    | FrSyKey -> opsk
    | PcKey(_) -> oppk
    | FrPcKey(_) -> oppk
    | PeKey(_) -> (fun t -> opprim (oppk t))
    | FrPeKey(_) -> (fun t -> opprim (oppk t))
    | Table -> optb
    | Function -> opfu
    | Number -> opnonce
    | PcTable(_,_,_) -> ErrorHandler.printExceptionMessage (Failure("Tables not implemented yet")) "Utilities" "op_of_type";raise(Failure("Tables not implemented yet"))
    | PeTable(_,_,_) -> ErrorHandler.printExceptionMessage (Failure("Tables not implemented yet")) "Utilities" "op_of_type";raise(Failure("Tables not implemented yet"))
;;
let oparith_of_nb = function
    1 -> opsum
  | 2 -> opminus
  | 3 -> opmult
  | 4 -> opdiv
  | 5 -> opmod
  | 6 -> oprcrypt (* not clear why here *)
  | _ -> oppow
;;
let oplogic_of_nb = function 
    1 -> oprcrypt
  | 2 -> opand
  | 3 -> opor
  | 4 -> opnand
  | _ -> opnor
;;


(* list managing functions *)

let rec union l1 l2 = match l1 with
    [] -> l2
  | head::tail -> if List.mem head l2 then union tail l2 else union tail (head::l2)
;; 
let rec sub l1 l2 = match l1 with
    [] -> []
  | head::tail -> if (List.mem head l2) then sub tail l2 else head::(sub tail l2)
;;
let rec remove element list =
	if (element=List.hd list)
		then
			List.tl list
		else
			[(List.hd list)]@(remove element (List.tl list))
;;
let rec interleave = function (* not clear *)
   [] ->
        (fun l -> l)
 | (a1::l1) as a1_l1 -> (function
        [] -> a1_l1
      | (a2::l2) as a2_l2 ->
             if (a1 > a2)
               then
                 a2::(interleave a1_l1 l2)
             else
               if (a1 = a2)
                 then
                   a1::(interleave l1 l2)
               else
                 a1::(interleave l1 a2_l2))
;;
let list_product l1 l2 =
let res = ref [] in
List.iter(fun x -> 
  List.iter(fun y -> res:=!res@[x@y])l2
    ) l1;
!res
;;
let for_all_user functionToApply =
  List.iter (fun (identifierNumber,(identifierName,identifierType)) -> match identifierType with
                | User -> (functionToApply identifierNumber)
                | _ -> ())
    !Globals.ident_list
;;
let get_sender protocolStep =
  try(fst (fst (List.assoc protocolStep !Globals.msg_list)))
  with not_found -> 0
;;
let get_receiver protocolStep =
  if protocolStep == 0
  then
    get_sender 1
  else
    snd (fst (List.assoc protocolStep !Globals.msg_list))
;;
let get_msg protocolStep =
  snd (List.assoc protocolStep !Globals.msg_list)
;;
let firstS userNumber =
  let protocolStep = ref 1
  in
    while (get_sender !protocolStep <> userNumber && !protocolStep <= !Globals.nbMsgs) do
      incr protocolStep
     done;
    !protocolStep
;;
let add_keys identifierList = match identifierList with
    [] -> []
  | head::tail ->
      match (get_identifier_type head)
      with FrPcKey(frPeKeyNumber) -> [head;frPeKeyNumber]@tail
            | FrPeKey(frPcKeyNumber) -> [head;frPcKeyNumber]@tail 
            | _ -> identifierList
;;
let infers_for_know lstmsgs =
  let newElement = ref false
  and messageList = ref lstmsgs
  in
(*
  add_knowledge:
  Role: Add an elt to the known messages list if it is not a number.
  Updates the decomposed and list_changed tag
*)
  let add_knowledge = function
      Int(_) -> ()
    | message ->
	newElement := true;
	if not (List.mem_assoc message !messageList)
	then
          messageList := (message,false)::!messageList
  in
(*
    is_decomposed:
    Input: message
    Role: set the corresponding tag to true
*) 
  let is_decomposed message =   
     messageList := (message,true)::(List.remove_assoc message !messageList)
  in
(*
   handle_cipher:
   Input: encrypted message , unencrypted message, key
   Role: updates the flag saying the crypted message is decomposed and adds the
   crypted message to the knowledge if the key is ok.
*) 
  let handle_cipher cipher message key =
    if List.mem_assoc key !messageList
    then
      begin
	is_decomposed cipher;
	add_knowledge message;
      end
  in
    (* 
       decompose_msg:
       Input: a message
       Role: updates the flag saying that the  message is  decomposed
       and add its componants to the knowledge list.
    *) 
  let rec decompose_msg = function
    | Pair(m1,m2) as message ->
      	add_knowledge m1;
      	add_knowledge m2;
      	is_decomposed message
    | Logic(1,m1,m2) as message -> (* XOR *)
	if ((  List.mem_assoc m1 !messageList ) or(  List.mem_assoc m2 !messageList ))
	then 
	  (  	  
	    decompose_msg m1;
	    decompose_msg m2;	
	    is_decomposed message;	  
	  )	
	else
	  is_decomposed message;
    | Crypt(1,Id(identifierNumber),message) as cipher -> (* public key encryption *)
      	(
	  match get_identifier_type(identifierNumber) with 
	    | FrPcKey(peId) ->
		handle_cipher cipher message (Id(peId))
	    | PcKey(peId) ->
		handle_cipher cipher message (Id(peId))
	    | PcTable(_,_,peId) ->
		handle_cipher cipher message (Id(peId))
	    | _ -> is_decomposed cipher
	)
    | Crypt(2,Id(identifierNumber),message) as cipher -> (* private key encryption *)
      	(
	  match get_identifier_type(identifierNumber) with 
	    | FrPeKey(pcId) ->
		handle_cipher cipher message (Id(pcId))
	    | PeKey(pcId) ->
		handle_cipher cipher message (Id(pcId))
	    | PeTable(_,_,pcId) ->
		handle_cipher cipher message (Id(pcId))
	    | _ -> is_decomposed cipher
	)
    | Crypt(3,Id(identifierNumber),message) as cipher ->(* symmetric key encryption *)
        (
	  match get_identifier_type(identifierNumber) with 
	    | SyKey ->
		handle_cipher cipher message (Id(identifierNumber))	
	    | FrSyKey ->
		handle_cipher cipher message (Id(identifierNumber))
	    | _ -> is_decomposed cipher
	)
    | message -> is_decomposed message
  in
(*
   decompose_msgs:
   Role: recursively decompose the message list
   Uses: decompose_msg
*)
  let rec decompose_msgs () =
    newElement := false;
    List.iter (function (message,false) -> decompose_msg message | _ -> ())
      !messageList;
    if !newElement then decompose_msgs ();
  in
    decompose_msgs();
    !messageList
;;
let rec compute_know_of_user userNumber = function
    (* Initial knowledge  *)
    0 ->
      (try( [(0,infers_for_know(( List.map (fun x -> (Id(x),true)) (List.assoc userNumber !Globals.ident_knowledge))
				@(List.map (fun x ->(x,false))(List.assoc userNumber !Globals.init_msg_knowledge))))])
       with not_found->
	 [(0,( List.map (fun identifierNumber -> (Id(identifierNumber),true)) (List.assoc userNumber !Globals.ident_knowledge)))])
  | protocolStep -> let previousKnowledge = compute_know_of_user userNumber (protocolStep-1)
         and ((sender,receiver),msg) = List.assoc protocolStep !Globals.msg_list
    in
    let lastKnowledge = ref (List.assoc (protocolStep-1) previousKnowledge)
    in
      (let add_if_unknown message isDecomposed =
         if not (List.mem_assoc message !lastKnowledge)
         then
           lastKnowledge := (message,isDecomposed)::!lastKnowledge
       in
         if userNumber = receiver then
	   (add_if_unknown (Id(sender)) false;
            add_if_unknown msg false)
         else
           if userNumber = sender
           then
             List.iter (fun identifierNumber ->
                          add_if_unknown (Id(identifierNumber)) true)
               (add_keys (fresh_var protocolStep)));
      (protocolStep, infers_for_know (!lastKnowledge))::previousKnowledge
;;
let get_instance identifierNumber sessionInstances=
  try
    List.assoc identifierNumber sessionInstances;
  with 
	Not_found -> get_identifier_name identifierNumber
;;
let key_of msg = match msg with
    Id(u) ->
      (
        match (get_identifier_type u) with
          | FrSyKey -> msg
          | SyKey -> msg
          | FrPcKey(i) -> (Id(i))
          | FrPeKey(i)-> (Id(i))
          | PcKey(i)  -> (Id(i))
          | PeKey(i)-> (Id(i))
          | PcTable(_,_,i) -> (Id(i))
          | PeTable(_,_,i) -> (Id(i))
          | _ ->
              print_endline "Error message was not coded with a key";
              exit(-1)
      )
  | _ ->
      print_endline "Error message was not coded with a key";
      exit(-1)
;;

let rec replace_by_instance termToInstantiate instance=
    match termToInstantiate with
    Op(operator,[term]) ->Op(operator,[(replace_by_instance term instance)])
  | Op(operator,[term1;term2]) ->Op(operator,[(replace_by_instance term1 instance);(replace_by_instance term2 instance)])
  | Cons(name) ->Cons(get_instance (get_identifier_number name !Globals.ident_list) instance)
  | Var(name) ->Var(get_instance (get_identifier_number name !Globals.ident_list) instance )
  | x ->x
;;
let rec to_term message  =
  match message with
      Pair(part1,part2) ->
      	oppair (to_term part1) (to_term part2 )
    | Crypt(3,key,cryptedMessage) ->
	opscrypt (to_term key ) (to_term cryptedMessage)
    | Crypt(_,key,cryptedMessage) ->
	opcrypt (to_term key) (to_term cryptedMessage)
    | Arith (operatorNumber,operand1,operand2) -> 
	(oparith_of_nb operatorNumber) (to_term operand1) (to_term operand2)
    | Logic (operatorNumber,operand1,operand2) ->
	(oplogic_of_nb operatorNumber)(to_term operand1) (to_term operand2)
    | Func(identifierNumber,parameter) ->
	opfunct (to_term (Id(identifierNumber))) (to_term parameter)
    | Int(number) -> Cons(string_of_int number)
    | Id(identifierNumber) -> 
	  (try
	     let identifiertype = findtype (get_identifier_name identifierNumber) !Globals.ident_list true
	     in
	       ((op_of_type identifiertype) (Var(get_identifier_name identifierNumber)))
	   with Not_found -> (Var(get_identifier_name identifierNumber)))
;;

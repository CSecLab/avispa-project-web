:- use_module(library(lists)).

% remove_possible_duplicates(L1,L2) :-
%    L2 is the list L1 without duplicates.
%    Two elements E1 and E2 are duplicates
%    if and only if E1 = E2.
remove_possible_duplicates([],[]).
remove_possible_duplicates([H|T1],L2) :-
	member(H,T1),!,
	remove_possible_duplicates(T1,L2).
remove_possible_duplicates([H|T1],[H|T2]) :-
	\+member(H,T1),
	remove_possible_duplicates(T1,T2).


% list_diff(L1,L2,L1L2,L2L1) :-
% 	L1L2 is the list of elements containing in L1 and not in L2.
% 	L2L1 is the list of elements containing in L2 and not in L1.
list_diff(L1,L2,L1L2,L2L1) :-
	list_diff_left(L1,L2,L1L2,L2L1),
	list_diff_right(L1,L2,L1L2,L2L1),
	!.
list_diff_left([],_,[],_).
list_diff_left([H|T1],L2,T2,L2L1) :-
	select(H,L2,NL2),
	list_diff_left(T1,NL2,T2,L2L1).
list_diff_left([H|T1],L2,[H|T2],L2L1) :-
	\+select(H,L2,_),
	list_diff_left(T1,L2,T2,L2L1).
list_diff_right(_,[],_,[]).
list_diff_right(L1,[H|T1],L1L2,T2) :-
	select(H,L1,NL1),
	list_diff_right(NL1,T1,L1L2,T2).
list_diff_right(L1,[H|T1],L1L2,[H|T2]) :-
	\+select(H,L1,_),
	list_diff_right(L1,T1,L1L2,T2).

(***********************************************************************)
(*                                                                     *)
(*                                 Casrul                              *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                                types.ml                             *)
(*                                 Loria                               *)
(*                     sp�cification des types � utiliser              *)
(***********************************************************************)
(* ----------------
   Main types.
   ---------------- *)

(* ----------------
 types we use (unary)
   ---------------- *)

type type_var =
    User                 (* user id *)
  | FrSyKey              (* fresh symmetric key *)
  | SyKey                (* symmetric key *)
  | FrPcKey of int       (* fresh public key: private key *)
  | FrPeKey of int       (* fresh private key: public key *)
  | PcKey of int         (* public key: private key *)
  | PeKey of int         (* private key: public key *)
  | PcTable of int * int * int   (* table * user * private elt *)
  | PeTable of int * int * int   (* table * user * public elt *)
  | Table                (* table name *)
  | Number               (* number (can be a nonce) *)
  | Function             (* function (never decoded) *)
;;


(* ----------------
 type message (binary constructors)
   ---------------- *)
type msg =
    Id of int (* a message may be an integer identifier *)
  | Int of int (* an integer *)
  | Func of int * msg (* a function *)
  | Crypt of int * msg * msg  (* a cifer with 1: public key, 2: private key, 3: symmetric key *)
  | Arith of int * msg * msg (* an arithmetic operation *)
  | Logic of int * msg * msg (* a logic operation*)
  | Pair of msg * msg (* a  couple *)
;;


(* ----------------
   type term 
   ---------------- *)

type term = 
    Empty (* empty element *)
  | Var of string (* variable *)
  | Cons of string (* constant *)
  | Op of string * (term list) (* operation defined with  string:mr,fu,tb,pk,sk,nonce... and 
applied to a list of terms *)
;;


(* ----------------
type rule = Rule of string * Infos.term * Infos.term
rule's description * LHS * RHS
   ---------------- *)

type rule =
   Rule of (string) * (term) * (term)
;;

      
(* ----------------
type goal that corresponds to the type of flaw we're looking for...
   ---------------- *)
type goal_type =
    Secrecy_of of string
  | Corresp_between of string * string
;;




predicates(T,Ps) :- predicates1(Ps,T).
predicates1([],_).
predicates1([P|Ps],T) :-
	predicate(T,P),
	predicates1(Ps,T).

predicate(action,P) :- !,
	constant(Arity,action),
	Arity=..[F|Ss],
	functor(Arity,F,N),
	functor(P,F,N),
	P=..[F|Ts],
	tuple(Ss,Ts).
% % Instantiate only valid actions
% predicate(action,P) :- !,
% 	constant(Arity,action),
% 	Arity=..[F|Ss],
% 	functor(Arity,F,N),
% 	functor(P,F,N),
% 	P=..[F|Ts],
% 	tuple(Ss,Ts),
% 	action(P,C,Pre,Add,Del),
% 	call(C),
% 	append(Pre,Add,TmpFluents),
% 	append(TmpFluents,Del,AllFluents),
% 	remove_duplicates(AllFluents,Fluents),
% 	predicates(fluent,Fluents).

predicate(S,P) :-
	constant(Arity,S),
	Arity=..[F|Ss],
	functor(Arity,F,N),
	functor(P,F,N),
	P=..[F|Ts],
	tuple(Ss,Ts).

is_well_formed(action,Op) :-
	ground(Op),
	action(Op,Cond,Pre,Add,Del),
 	call(Cond),
 	append(Pre,Add,TmpFluents),
 	append(TmpFluents,Del,AllFluents),
 	remove_duplicates(AllFluents,Fluents),
 	predicates(fluent,Fluents),!.

is_not_well_formed(action,Op) :-
	ground(Op),
	action(Op,Cond,Pre,Add,Del),
 	call(Cond),
 	append(Pre,Add,TmpFluents),
 	append(TmpFluents,Del,AllFluents),
 	remove_duplicates(AllFluents,Fluents),
 	member(F,Fluents),
	\+predicate(fluent,F),!.

tuple(Ss,Ts) :-
	value(term_depth_bound,D),
	tuple(Ss,D,Ts).

term(S,D,T) :-
	D>0,
	constant(Arity,S),
	% DEBUG
%	write(S),nl,
	%
	Arity=..[F|Ss],
	functor(Arity,F,N),
	functor(T,F,N),
	D1 is D-1,
	T=..[F|Ts],
	tuple(Ss,D1,Ts).
term(S,D,T) :-
	super_sort(S,S0),
	% DEBUG	
%	write(S),nl,
	%
	term(S0,D,T).

tuple([],_,[]).
tuple([S|Ss],D,[T|Ts]) :-
	term(S,D,T),
	tuple(Ss,D,Ts).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% To load the input file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load_problems_file(F) :-
	open(F,read,STR),
	assert_read_terms(STR),
	close(STR).

% Assert every terms of the input file %%%%%%%%%%%%%%%%%%%%%%%%%% 
assert_read_terms(STR) :-
	read(STR,T),
	(T\==end_of_file ->
	    assert(T),
	    assert_read_terms(STR)
	;
	    true
	).

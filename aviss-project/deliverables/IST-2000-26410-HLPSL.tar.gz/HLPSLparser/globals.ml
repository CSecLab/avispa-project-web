(***********************************************************************)
(*                                                                     *)
(*                                 HLPSL                               *)
(*                                                                     *)
(*                     AVISS Project IST 2000-26410                    *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(*                                                                     *)
(*                              globals.ml                             *)
(*                                Loria                                *)
(*                    declaration of global variables                  *)
(***********************************************************************)

open Types;;

exception Pas_trouve;; (* used in Newproto.ajoute_type_def (v) *)

exception Call of string;; (* to signal exceptions *)

(* Parsing of the arguments of the command line *)
  let flag_intru    = ref false ;;
  let flag_rules    = ref false ;;
  let flag_init     = ref false ;;
  let flag_para     = ref false ;;
  let flag_goal     = ref false ;;
  let flag_ident    = ref false ;;
  let flag_simplif  = ref false ;;
  let flag_knowledge  = ref false ;;
  let flag_all      = ref false ;;

(* table of indentifiers
   initialization:(* [Hashtbl.create n] creates a new, empty hash table, with
   initial size [n].  For best results, [n] should be on the
   order of the expected number of elements that will be in
   the table.  The table grows as needed, so [n] is just an
   initial guess. *)*)
let ident_table = ((Hashtbl.create 13) : (string, int) Hashtbl.t);; (*TODO 13?*)

let ident_list = ref ([] : (int * (string * type_var)) list )

let ident_knowledge = ref ([] : (int * int list) list);;(* val ident_knowledge : (user * identifiers list) list ref *)

(* List of messages declared in the initial knowledge of the users *)
let init_msg_knowledge = ref ([] : (int *  msg list)list);;

let intruder_knowledge = ref ([] : term list);;

(* message: index, from, to, msg *)
let msg_list = ref ([] : (int * ((int * int) * msg)) list);;

(* identifier number *)
let cpt_id = ref 0;; 

let cpt_err = ref 0;; (* used in parser_proto.mly to signal compilation errors *)

let no_err = ref 0;; (* used in parser_proto.mly to signal compilation errors *)

let cpt_line = ref 1;; (* used in parser_proto.mly to signal compilation errors *)

let proto_name = ref "noname";; (* protocol name *)

let intruder_cases = ref ([] : int list);;

let goal_case = ref "";;

let nbMsgs = ref 0;;

let init_knowledge = ref ([] : (int * string) list);;

let knowledge_instances = ref ([] : (string * type_var) list);;

let session_instances = ref ([[]] : ((int * string) list) list);;

let init_msgs_per_session = ref ([] : (int * int) list);;

let secret_goal = ref 0;;

let correspondence_goal = ref (0,0);;

let goal_type = ref 0;; (* 0 :  1 :*)

let fresh = ref ([] : (int * int list) list);; 

let knowledge = ref ([] : (int * (int * (msg * bool) list) list) list);;

(* list of users whose rules are generated // if the option --para is specified in the command line *)
let para_ident_list=ref ([] : int list);;

(* list of instances of parallel sessions *)
let para_session_instances = ref ([[]] : ((int * string) list) list);;

(* list of identifiers (in particular keys)  *)
let secret_ident_list=ref ([] : string list);;

(* list of rules // as result *)
let para_res = ref ([] : (term list * term list) list );;

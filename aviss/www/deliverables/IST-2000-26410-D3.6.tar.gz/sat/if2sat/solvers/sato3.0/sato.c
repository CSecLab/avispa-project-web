/*********************************************************************
; Copyright 1992-97, The University of Iowa (UI).  All rights reserved. 
; By using this software the USER indicates that he or she has read, 
; understood and will comply with the following:
;
; --- UI hereby grants USER nonexclusive permission to use, copy and/or
; modify this software for internal, noncommercial, research purposes only.
; Any distribution, including commercial sale or license, of this software,
; copies of the software, its associated documentation and/or modifications
; of either is strictly prohibited without the prior consent of UI.  Title
; to copyright to this software and its associated documentation shall at
; all times remain with UI.  Appropriate copyright notice shall be placed
; on all software copies, and a complete copy of this notice shall be
; included in all copies of the associated documentation.  No right is
; granted to use in advertising, publicity or otherwise any trademark,
; service mark, or the name of UI.  Software and/or its associated
; documentation identified as "confidential," if any, will be protected
; from unauthorized use/disclosure with the same degree of care USER
; regularly employs to safeguard its own such information.
;
; --- This software and any associated documentation is provided "as is," and
; UI MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
; THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
; USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL
; NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL
; PROPERTY RIGHTS OF A THIRD PARTY.  UI, the University of Iowa,
; its Regents, officers, and employees shall not be liable under any
; circumstances for any direct, indirect, special, incidental, or
; consequential damages with respect to any claim by USER or any third
; party on account of or arising from the use, or inability to use, this
; software or its associated documentation, even if UI has been advised
; of the possibility of those damages.
*********************************************************************/
#include "main.h"
#include "clocks.h" 
GLOB struct clock Clocks[ MAX_CLOCKS ];

/* #define TP_ALLOC_SIZE 32700 */
#define TP_ALLOC_SIZE MAX_SHORT
#define ARG_TYPE unsigned

static char *Alloc_block;    /* location returned by most recent malloc */
static char *Alloc_pos;      /* current position in block */
static unsigned long Branch_mark = 1;

/* the main function of sato: return 1 if satisfiable; 0 otherwise.  */
int sato (file)
     FILE *file;
{
  int i = 0;

  check_stop(0);
  clock_init();

  while (!Stop) {
    CLOCK_START(BUILD_TIME)
    i = build(file);
    CLOCK_STOP(BUILD_TIME)

    if (i != 0) {
      i = 0;
      Branch_num = Branch_fail = 1;
    } else if (OUTPUT > 1) 
      return 1;
    else {
      CLOCK_START(SEARCH_TIME)
#ifdef MORETRACE
      if (TRACE > 1)  fprintf(Sato_fp, "\nStarting the search ...\n"); 
#endif

      if (DATA == 1) {
 	if (TRACE > 1) printf("Using the list structure for clauses.\n");
	i = list_search();
      } else {
 	if (TRACE > 1) printf("Using the trie structure for clauses.\n");
	i = trie_search();
      }
      CLOCK_STOP(SEARCH_TIME)
    } 
 
    if (OUTPUT < 2) p_stats(Sato_fp);
    if (Branch_succ && Backup_idx > 0) print_guide_path(stdout);
    print_times(Sato_fp);

    return i;
  }
}

int build (file)
     FILE *file;
{
  int j;

  Alloc_block = NULL;
  Alloc_pos = NULL;
  Clause_num = Subsume_num = Unit_num = 0;
  Tdc_idx = 0;
  if (TRACE > 5) fprintf(Sato_fp, "\nInput clauses are:\n\n");

  if (OUTPUT > 3 && OUTPUT != 6) 
    printf("p cnf %d %ld\n", Max_atom, Max_clause);

  if (DATA == 1) init_list(Max_atom); else init_trie();

  /* read input file and build tree */
  j = 0;

#ifdef BENCHMARK
  if (RANDOM) {
    j = random_ksat_cls(QGROUP, PMD);
  } else if (PMD) {
    j = pmd_clauses();
  } else if (OARRAY) {
    j = oarray_clauses();
  } else if (QGROUP > 0) {
    if ((QUEEN == 4 || QUEEN == 14) && 
	(((QGROUP-INCOMPLETE)*(QGROUP-3*INCOMPLETE-1)) % 4 != 0)) {
      printf("Warning: (v-n)(v-3n-1) mod 4 = %d != 0\n",
	     ((QGROUP-INCOMPLETE)*(QGROUP-3*INCOMPLETE-1)) % 4);
    }
    if (CYCLIC)
      j = cyclic_qgroup_clauses();
    else
      j = qgroup_clauses();
  } else if (RAMSEY > 0) 
    j = ramsey_clauses();
  else if (PIGEON > 0)
    j = pigeonhole_clauses();
  else if (QUEEN > 0)
    j = queen_clauses();
  else 
#endif 
  {
    j = input_clauses ( file );
    if (file != stdin) fclose ( file );
  }

  if (OUTPUT > 3 && OUTPUT != 6 && Printed_clause != Max_clause) {
    fprintf(stderr, "ATTENTION!: the number of clauses should be %ld instead of %ld, i.e,\n", 
	    Printed_clause, Max_clause);
    fprintf(stderr, "p cnf %d %ld\n", Max_atom, Printed_clause);
  } else if (OUTPUT < 2) p_input_stats(Sato_fp);
  fflush(Sato_fp);
  return j;
}

void p_input_stats(f)
     FILE *f;
{
  if (Clause_num == 0) {
    fprintf(f, "There are no input clauses.\n\n");
    exit(0);
   } else if ((Clause_num - Subsume_num) == 1) {
    fprintf(f, "There is only one input clause.\n\n");
    exit(0);
  } else if (Subsume_num > 0)
    fprintf(f, "There are %ld input clauses (%ld unit, %ld subsumed, %ld retained).\n", 
	    Clause_num, Unit_num, Subsume_num, Clause_num+Unit_num-Subsume_num);
  else 
    fprintf(f, "There are %d input clauses.\n", Clause_num );

  fprintf(f, "The maximal index of propositional variables is %d.\n",
	  Max_atom);
  fprintf(f, "The mallocated memory is %10.2f Kbytes.\n", Memory_count / 1024.0);
}

void p_paras ( )
{
  if (MODEL == 0) 
    printf ( "Search for all models.\n" );
  else if (MODEL == 1)    
    printf ( "Search only one model.\n" );
  else
    printf ( "Search for %d models.\n", MODEL );

  if (SELECT == 0) 
    printf ( "Branch on the atom with the minimal indices.\n" );
  else if (SELECT == 1) 
    printf ( "Branch on an atom of the shortest positive clauses.\n" );
  else if (SELECT == 2) 
    printf ( "Branch on an atom of the shortest negative clauses.\n" );

  printf ( "Set the trace level to %d.\n", TRACE );

  if (TRACE > 0)
    printf ( "Print at most %d atoms per line in a model.\n",
	    LINE );
  printf("\n");
}

void p_stats (f)
     FILE *f;
{
  if (Branch_succ > 0) 
    fprintf(f, "\nThe number of found models is %ld.\n", Branch_succ);
  else if (Branch_num == Branch_fail) 
    fprintf(f, "\nThe clause set is unsatisfiable.\n");
  else
    fprintf(f, "\nThe search for unsatisfiability is incomplete.\n");

  if (Branch_num == 1)
    fprintf(f, "\nThere is only one branch (%ld succeeded, %ld failed).\n", 
	   Branch_succ, Branch_fail);
  else 
    fprintf(f, "\nThere are %d branches (%ld succeeded, %ld failed).\n", 
	   Branch_num, Branch_succ, Branch_fail);

  if (TRACE > 2 && DATA != 1) p_trie_info(f);
}

int check_stop (flag)
     int flag;
{
  static long initial;
  static long previous;
  static long finish;

  if (flag == 0) {
    initial = time_in_second;
    finish = 3600*HOURS;
    previous = 0;
    return 0;
  } else {

    int two14 = 16383;   /* 2^14-1 */
    int two15 = 32767;   /* 2^15-1 */

    if (HOURS == 0) return 1;
    if ((Branch_fail & two15) == 0) {
      long current = time_in_second-initial;
      if (current < 0) return 1;
      if (current >= finish) return 1;
      if ((current - previous) > 21600) {
	/* print out the guide pathing every 6 hours */ 
	previous = current;
	print_guide_path(stdout);
	printf("branches = %d     %s", Branch_fail, get_time());
	fflush(stdout);
      }
    }
    return 0;
  }
}

void print_model (f)
     FILE *f;
{
  SATOINT i, col, row;

#ifdef BENCHMARK
  if (!RANDOM && PMD) {
    print_pmd_model(f);
  } else if (OARRAY) {
    print_oarray_model(f);
  } else if (!RANDOM && QGROUP) {
    if (CYCLIC)
      print_cyclic_model(f); 
    else 
      print_qgroup_model(f); 
  } else 
#endif
 {

    fprintf(f, "\nModel #%ld:", Branch_succ);
    if (TRACE < 5) 
      fprintf(f, " (indices of true atoms)\n\n    " );
    else 
      fprintf(f, "\n\n    " );

    if (LINE <= 1) {
      for (i = 1; i <= Max_atom; i++)
	if (TRACE < 5) {
	  if (Value[i] == TT)
	    fprintf(f, "%d  ", i);
	} else fprintf(f, "%d  ", (Value[i] == TT)? 1 : 0);
    } else {
      col = row = 0;
      for (i = 1; i <= Max_atom; i++) {
	if (TRACE < 5) {
	  if (Value[i] == TT) { 
	    fprintf(f, "%d  ", i);
	    ++col; 
	  }
	} else { 
	  fprintf(f, "%d  ", (Value[i] == TT)? 1 : 0); 
	  ++col; 
	}

	if ( col == LINE ) {
	  col = 0;  fprintf(f, "\n    " );
	  if ( ++row == LINE ) { 
	    row = 0; 
	    if (i < Max_atom) fprintf(f, "\n    " ); 
	  }
	}
      }
    }
    fprintf(f, "\n");
  }
}

int handle_succ_end ()
{
  Branch_succ++;

#ifdef MORETRACE
  if (TRACE == 2) fprintf(Sato_fp, "S%d\n", Branch_succ);
#endif
  if (TRACE) print_model(Sato_fp);
  else if (MODEL == 0 && Branch_succ == Branch_mark) {
    fprintf(Sato_fp, "\nThe %dth model is found!\n", Branch_succ);
    Branch_mark *= 10;
  }
  return ((MODEL && Branch_succ >= MODEL)? 0 : 
	  ((DATA == 1)? list_prev_key(1) : 
	   (DATA == 2)? trie2_prev_key(2) : trie_prev_key()));
}

int handle_fail_end ()
{
  Branch_fail++;
  if (Backup_idx < 3) Lookahead_level = Backup_idx;
  else Lookahead_level = Backup_idx-3;

#ifdef MORETRACE
  if (TRACE == 2) fprintf(Sato_fp, "F%ld\n", Branch_fail);
  else if (TRACE > 8 || TRACE == 3 || TRACE == 4)  
    fprintf(Sato_fp, "      an empty clause is found.\n"); 
#endif

  if (Stop = check_stop(1)) {
    int i, k, last;

    last = Backup_idx-1;
    while (last >= 0 && Backup[last] < 0) last--;
    if (last >= 0) { 
      i = Backup[last]; 
      Backup[last] = -i; 
      Value[i] = NEG(Value[i]);
    }
    Backup_idx = last+1;

    fprintf(Sato_fp, "\nThe search is aborted and the current search tree path is:\n");
    output_guide_path(Sato_fp);
    fprintf(Sato_fp, "\n");
  }

  return UNSAT;
}

void bug (i)
     int i;
{
#ifdef PRIVATE
  printf("<<<<<<<<<<<<<<<<<<< BUG%d >>>>>>>>>>>>>>>>>>>>\n", i);
#else
  i = 1;
#endif
}

int strategy0()
     /* the least unsigned variable */
{
  int i; 
  
  for (i = 1; (i <= Max_atom); i++) 
    if (Value[i] == DC) return i;
  return 0;
}


int strategy00()
     /* read one from the stdin */
{
  int i = 0; 

  while (scanf("%d", &i) != EOF) {
    printf(" %d", i);
    if (i > 0) {
      if (Value[i] == DC) 
	return i;
      else
	printf("try again!\n");
    } else if (i < 0) {
      ;
    }
  }

  return trie_strategy2();
}


/*************
 *    OTTER's Function:
 *
 *    char *tp_alloc(n)
 *
 *    Allocate n contiguous bytes, aligned on pointer boundry.
 *
 *************/

#define scale sizeof(int *)

char *tp_alloc(n)
     int n;
{
  char *return_block;

  /* if n is not a multiple of sizeof(int *), then round up so that it is */
  /*if (n % scale != 0)	n += (scale - (n % scale));*/

  if (Alloc_block == NULL || Alloc_block + TP_ALLOC_SIZE - Alloc_pos < n) {
    /* try to malloc a new block */
    if (n > TP_ALLOC_SIZE) {
      fprintf(stderr, "tp_alloc, request too big: %d\n", n);
      exit(0);
    } else {
      Alloc_pos = Alloc_block = (char *) malloc((ARG_TYPE) TP_ALLOC_SIZE);
      if (Alloc_pos == NULL) {
	fprintf(stderr, "ABEND, malloc returns NULL (out of memory).\007\n");
	fprintf(stderr, "%ld K has been mallocated.\007\n", Memory_count/1042);
	exit(0);
      }
      Memory_count += TP_ALLOC_SIZE;
    }
  }

  return_block = Alloc_pos;
  Alloc_pos += n;
  return(return_block);
}  /* tp_alloc */

void print_guide_path (f)
     FILE *f;
{
  if (!Backup_idx) 
    fprintf(f, "\nThe search tree path is empty.\n");
  else {
    fprintf(f, "\nThe search tree path is:\n ");
    output_guide_path(f);
    fprintf(f, "\n");
    fflush(f);
  }
}

void output_guide_path (f)
     FILE *f;
{
  int i, k;

  fprintf(f, "( ");

  for (i = 0; i < Backup_idx; i++) {
    k = Backup[i];
    if (k > 0) { fprintf(f, "f"); }
    else { fprintf(f, "s"); k = -k; }

    if (Value[k] == FF) 
      fprintf(f, "-%d ", k);
    else 
      fprintf(f, "%d ", k);
  }
  fprintf(f, ")");
}

int read_guide_path ( f, keys, choices )
     FILE *f;
     int keys[], choices[];
{
  int total, key;
  int ch;
  
  total = 0;
  while (1) {
    ch = getc ( f );  

    while (ch != EOF && ch != 'f' && ch != 's' && ch != ')') 
      ch = getc ( f );  
    if (ch == EOF) return 0;
    if (ch == ')') {
      skip_chars_until( f, '\n' ); 
      return total;
    }
    fscanf(f, "%d", &key);
    keys[total] = key;
    choices[total++] = (ch == 'f')? TT : FF;
  }
}

void print_read_guide_path (keys, choices, total)
     int keys[], choices[], total;
{
  int i;
  printf("( ");
  for (i = 0; i < total; i++) {
    if (choices[i] == TT) 
      printf("f"); 
    else
      printf("s");
    printf("%d ", keys[i]);
  }
  printf(")\n");
}


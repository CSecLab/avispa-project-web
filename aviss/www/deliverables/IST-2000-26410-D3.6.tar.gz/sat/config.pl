% Setting up the defaults

:- set(encoding,[ape_axiom,
		 explanatory_frame_axiom,
		 conflict_exclusion_axiom]).

:- set(term_depth_bound,12).

:- set(debug,off).
:- set(dimacs,on).
:- set(solver,chaff).

:- set(sound,off).
:- set(sato_executable,'if2sat/solvers/sato3.0/sato').
:- set(chaff_executable,'if2sat/solvers/chaff-spelt3/Chaff2').
:- set(chaff_configfile,'if2sat/solvers/chaff-spelt3/cherry.smj').
:- set(sim_executable,'if2sat/solvers/sim-dll/simdll').
:- set(sim_options,'').
:- set(hash_table,on).

:- set(steps,1).
:- set(session_repetition,1).
:- set(multi_fresh_term,off).
:- set(relax_conflict,on).
:- set(well_formed_actions_preprocessing,on).
:- set(intruder_const,off).
:- set(constraint_metavariables,off).
:- set(hlpsl2if,'hlpsl2if').
%:- set(output,html).
%:- set(output,planning).
:- set(output,standard).

:- dynamic sort/1,
	   super_sort/2,
	   constant/2,
	   invariant/1,
	   static/1,
	   monotone/1,
	   is_not_conflict_fluent/1,
	   facts/1,
	   action/5,
	   goal/2.










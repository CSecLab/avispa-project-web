(***********************************************************************)
(*                                                                     *)
(*                                 hlpsl2if                            *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* protocol rules generator *)
open Globals;;
open Types;;
open Utilities;;
open Knowledge;;
open Interface;;

let rec msg_to_atoms = function
   Pair(couplePart1,couplePart2) -> union (msg_to_atoms couplePart1) (msg_to_atoms couplePart2)
 | Crypt(_,keyIdentifier,cryptedMessage) -> union (msg_to_atoms keyIdentifier) (msg_to_atoms cryptedMessage)
 | Func(functionNumber,functionParameter) -> union (msg_to_atoms (Id(functionNumber))) (msg_to_atoms functionParameter)
 | TableElement(tableNumber,userNumber,isPrivate) -> union (msg_to_atoms (Id(tableNumber)))(msg_to_atoms (Id(userNumber)))
 | Arith(_,operand1,operand2) -> union (msg_to_atoms operand1) (msg_to_atoms operand2)
 | Logic(_,operand1,operand2) -> union (msg_to_atoms operand1) (msg_to_atoms operand2)
 | Int(number) -> []
 | Id(identifierNumber) -> [Id(identifierNumber)]
;;



let nbofId = function
   Id(identifierNumber) -> identifierNumber
 | _ -> ErrorHandler.printExceptionMessage (Failure("input is not an ident")) "Rules" "nbofId";exit(-1)
;;

let comp_fresh () =
  let persistentVarList = ref[] in
  let initialPersistentAtoms =
    ref (List.fold_left 
	   (fun identifierNumberList (_,userKnownIdentifiers) -> identifierNumberList@userKnownIdentifiers) 
	   [] 
	   !Globals.ident_knowledge
	)
  in
  let to_ident mesg_list = (List.flatten
			      (List.map
				 (fun message -> 
				    (List.map
				       (fun atom -> (nbofId atom))
				       (msg_to_atoms message)
				    )
				 )
				 mesg_list
			      )
			   ) in 
  let initialPersistentMesssages =
    ref (List.fold_left
	   (fun identifierNumberList (_,userKnownMessages) -> identifierNumberList@(to_ident userKnownMessages))
	   []
	   !Globals.init_msg_knowledge
	)
  in
  let initialPersistent = ref ((!initialPersistentAtoms)@(!initialPersistentMesssages)) in
    List.iter 
      (fun persistantIdNumber -> (* adding to the public:private fresh keys their associated ones *)
	 match (Utilities.get_identifier_type persistantIdNumber) with
             PcKey(pvKeyNumber) -> persistentVarList:=!persistentVarList@[persistantIdNumber]@[pvKeyNumber];
           | FrPcKey(frPeKeyNumber) -> persistentVarList:=!persistentVarList@[persistantIdNumber]@[frPeKeyNumber];
           | PeKey(pcKeyNumber) -> persistentVarList:=!persistentVarList@[persistantIdNumber]@[pcKeyNumber];
           | FrPeKey(frPcKeyNumber) -> persistentVarList:=!persistentVarList@[persistantIdNumber]@[frPcKeyNumber];
           | _ ->persistentVarList:=!persistentVarList@[persistantIdNumber]
      )
      !initialPersistent;
    fresh := [(0,[])];(*initialisation of fresh variables list*)
    for protocolStep=1 to !Globals.nbMsgs do
      let msg = snd (List.assoc protocolStep !Globals.msg_list) (* message of step protocolStep *)
      in
      let stepfreshIds =
        List.fold_left (fun identifierList identifierNumber ->
			  if List.mem identifierNumber !persistentVarList (* already persistant *)
			  then identifierList
			  else
			    match (Utilities.get_identifier_type identifierNumber)
			    with PcKey(pvKeyNumbe) -> identifierNumber::pvKeyNumbe::identifierList
			      | FrPcKey(frPeKeyNumber) -> identifierNumber::frPeKeyNumber::identifierList
			      | PeKey(pcKeyNumber) -> identifierNumber::pcKeyNumber::identifierList
			      | FrPeKey(frPcKeyNumber) -> identifierNumber::frPcKeyNumber::identifierList
			      | _ -> identifierNumber::identifierList)
          [] (List.map nbofId (msg_to_atoms msg))
      in
(* FOR DEBUG print_string "Fresh in msg "; print_int i; print_string ":  "; List.iter (fun n -> print_ident n; print_string " ") fr; print_newline();*)
      	fresh := (protocolStep,stepfreshIds)::!fresh;
	persistentVarList := stepfreshIds@(!persistentVarList)
    done      
;;

let rec add_type_def protocolStep = function
    Op(s,[l]) -> Op(s,[l])
  | Op(s,l) -> Op(s, (List.map (add_type_def protocolStep) l))
  | Var(varName) -> (
      if (varName=="etc") 
      then (Cons(varName))
      else
	(try 
	   let varType = Utilities.findtype varName !Globals.ident_list false in
	   let nextStep = if protocolStep < !Globals.nbMsgs then  protocolStep+1 else  protocolStep in
	     if (nextStep> protocolStep) && (List.mem varName (List.map Utilities.get_identifier_name (fresh_var nextStep)))
	     then
	       (op_of_type varType) (Op("c",[Cons(varName);Var("Time")])) (* typing fresh variables *)
 	     else
	       ((op_of_type varType) (Var(varName))) (* if not fresh and type found *)
	 with Not_found -> Var(varName)) (* if the type was not found *)
    )
  | x ->  x
;;
let check_receiver protocolStep senderNumber receiverNumber =
  if not (know (Id(receiverNumber))senderNumber protocolStep) then
    begin
      let errorMessage="Message "^string_of_int(protocolStep)^": "^get_identifier_name(senderNumber)^" does not know "^get_identifier_name(receiverNumber) in
      ErrorHandler.printExceptionMessage (Failure(errorMessage)) "Rules" "check_receiver";
      exit 0
    end
;;
let check_compose = function protocolStep,((senderNumber , receiverNumber), messageToCompose) ->
  check_receiver protocolStep senderNumber receiverNumber;
  if not (check_know_components protocolStep senderNumber  messageToCompose) then
    begin
      let errorMessage="Message "^string_of_int(protocolStep)^" can not be composed by "^get_identifier_name senderNumber^"." in
	ErrorHandler.printExceptionMessage (Failure(errorMessage)) "Rules" "check_compose";
	print_string ("Message component:");Interface.print_msg(messageToCompose);print_newline();
	print_string ("Knowledge dump:");Interface.print_ident_knowledge senderNumber;
	exit 0
    end
;;
let check_authenticate goalList =
  List.iter(fun ((firstUserNumber, secondUserNumber),identifierNumberList) ->
	      List.iter(fun identifierNumber ->
			  if not(know (Id(identifierNumber)) firstUserNumber (!Globals.nbMsgs))
			  then (ErrorHandler.handleSemanticError 25 (get_identifier_name identifierNumber); exit (-1))
		       )identifierNumberList;
  List.iter(fun identifierNumber ->
			  if not(know (Id(identifierNumber)) secondUserNumber (!Globals.nbMsgs))
			  then (ErrorHandler.handleSemanticError 25 (get_identifier_name identifierNumber); exit (-1))
		       )identifierNumberList
	   )!Globals.authenticate_goal_list
;;

let check_protocol () =
  List.iter check_compose !Globals.msg_list;
  check_authenticate !Globals.authenticate_goal_list;
;;

let rec compose userNumber messageToCompose protocolStep =
  match messageToCompose with
      Pair(couplePart1,couplePart2) ->
	oppair (compose userNumber couplePart1 protocolStep) (compose userNumber couplePart2 protocolStep)
    | _ -> try (match messageToCompose with
		    Crypt(3,key,cryptedMessage) -> (* symmetric key encryption *)
		      opscrypt (compose userNumber key protocolStep) (compose userNumber cryptedMessage protocolStep)
		  | Crypt(_,key,cryptedMessage) ->
		      opcrypt (compose userNumber key protocolStep) (compose userNumber cryptedMessage protocolStep)
		  | Arith (operator,operand1,operand2) -> 
		      (oparith_of_nb operator) (compose userNumber operand1 protocolStep) (compose userNumber operand2 protocolStep)
		  | Logic (operator,operand1,operand2) -> 
		      (oplogic_of_nb operator) (compose userNumber operand1 protocolStep) (compose userNumber operand2 protocolStep)
		  | Func(functionNumber,parameterMessage) -> 
		      opfunct (compose userNumber (Id(functionNumber)) protocolStep) (compose userNumber parameterMessage protocolStep)
		  | TableElement(tableNumber,tableUser,isPrivate) -> 
		      if not(isPrivate)
		      then opTableElement(to_term (Id(tableNumber))) (to_term (Id(tableUser)))
		      else opprim (opTableElement(to_term (Id(tableNumber))) (to_term (Id(tableUser))))
		  | Int(number) -> Cons(string_of_int number)
		  | Id(identifierNumber) -> 
		      if ((know messageToCompose userNumber protocolStep)or(!Globals.flag_init_ok)) (* flag_init_ok: for messages decomposition in initial knowledge *)
		      then
			add_type_def protocolStep (Var(Utilities.get_identifier_name identifierNumber))
		      else
			if (List.mem identifierNumber (fresh_var (protocolStep+1)))
			then
			  add_type_def protocolStep (Var(Utilities.get_identifier_name identifierNumber))
			else raise Not_found
		  | _ -> raise Not_found)
      with Not_found ->
	if ((know messageToCompose userNumber protocolStep)or(!Globals.flag_init_ok)) then(* flag_init_ok: for messages decomposition in initial knowledge *)
	  begin
	    add_type_def protocolStep (Var(Interface.string_of_msg messageToCompose))
	  end
	else (raise Not_found)
;;
let rec see userNumber message protocolStep =
  match message with
      Pair(couplePart1,couplePart2) ->
	oppair (see userNumber couplePart1 protocolStep) (see userNumber couplePart2 protocolStep)
    | Crypt(3,key,cryptedMessage) -> (* case of symmetric key *)
	if (check_know_components protocolStep userNumber key) then
          opscrypt (see userNumber key protocolStep) (see userNumber cryptedMessage protocolStep)
	else
	  add_type_def protocolStep (Var(Interface.string_of_msg message))
    | Crypt(_,key,cryptedMessage) ->
	if (check_know_components protocolStep userNumber (key_of (key))) then
	  opcrypt (opprim (see userNumber (key_of key) protocolStep)) (see userNumber cryptedMessage protocolStep)
        else
	  Var(Interface.string_of_msg message)
    | Func(functionNumber,parameterMessage) ->
	if (check_know_components protocolStep userNumber (Id(functionNumber)) && check_know_components protocolStep userNumber parameterMessage) then
      	  opfunct (see userNumber (Id(functionNumber)) protocolStep) (see userNumber parameterMessage protocolStep)
	else
	  (Var(Interface.string_of_msg message))
    | TableElement (tableNumber,tableUser,isPrivate) ->
	if (check_know_components protocolStep userNumber message ) then
	  if not(isPrivate) 
	  then opTableElement (see userNumber (Id(tableNumber)) protocolStep) (see userNumber (Id(tableUser)) protocolStep)
	  else opprim(opTableElement (see userNumber (Id(tableNumber)) protocolStep) (see userNumber (Id(tableUser)) protocolStep))
	else
	  (Var(Interface.string_of_msg message))
    | Arith(operator,operand1,operand2) ->
	(oparith_of_nb operator) (see userNumber operand1 protocolStep) (see userNumber operand2 protocolStep)
    | Logic(1,operand1,operand2) ->(* XOR handling here *)
	if ( (check_know_components protocolStep userNumber operand1) or (check_know_components protocolStep userNumber operand2))
	then
	  (oplogic_of_nb 1) (see userNumber operand1 protocolStep) (see userNumber operand2 protocolStep)
	else
	  add_type_def protocolStep (Var(Interface.string_of_msg message))
    | Logic(operator,operand1,operand2) ->(oplogic_of_nb operator) (see userNumber operand1 protocolStep) (see userNumber operand2 protocolStep)
    | Int(number) ->
	Cons(string_of_int number)
    | Id(identifierNumber) ->
	add_type_def protocolStep (Var(Utilities.get_identifier_name identifierNumber))
;;

let k protocolStep =
  let nextStep = ref (protocolStep+1) in
    while (!nextStep <= !Globals.nbMsgs) && ((get_receiver !nextStep) <> (get_receiver protocolStep)) 
    do
      incr nextStep
    done;
    if !nextStep > !Globals.nbMsgs then
      begin
	if get_receiver protocolStep = get_sender 1 then 0 else
	  begin
      	    let previousStep= ref 1 in
      	      while ((get_receiver !previousStep) <> (get_receiver protocolStep))
      	      do
		incr previousStep
      	      done;
	      !previousStep
	  end
      end
    else
      !nextStep
;;

let invk protocolStep =
  let result = ref 0 in
    while k !result <> protocolStep
    do
      incr result
    done;
    !result
;;

let rec termlist_of_list = function
    [] -> Cons("etc") (* etc2: to mark the end of a list*)
  | [head] -> oppair head (Cons("etc"))(* etc: to mark the end of the list *)
  | head::tail -> oppair head (termlist_of_list tail)
;;
(* ex lknow_init *)

let initial_knowledge_terms userNumber =
  add_type_def 1 (termlist_of_list ((List.map (fun i ->
						 (Var((Utilities.get_identifier_name i)))) (List.assoc userNumber !Globals.ident_knowledge))
				    @ (List.map (fun message ->compose userNumber message  0) (try(List.assoc userNumber !Globals.init_msg_knowledge) with Not_found->[] ))))
;;
(* ex lknow_aux *)

let rec get_user_knowledge_aux userNumber usedStep = function
    0 -> []
  | 1 ->  if userNumber <> (get_sender 1)
    then []
    else
      List.map (fun identifierNumber ->
                  Var(Utilities.get_identifier_name identifierNumber))
        (fresh_var 1)
  | protocolStep ->
      if userNumber <> (get_sender protocolStep) then
	get_user_knowledge_aux userNumber usedStep (protocolStep-1)
      else
	(get_user_knowledge_aux userNumber usedStep (protocolStep-1))
        @ (sub [ (Var(Utilities.get_identifier_name (get_sender (protocolStep-1)))); (see userNumber (get_msg (protocolStep-1)) usedStep)]
             ((get_user_knowledge_aux userNumber usedStep (protocolStep-1))
              @ (List.map (fun identifierNumber ->
                             Var(Utilities.get_identifier_name identifierNumber))
                   (List.assoc userNumber !Globals.ident_knowledge))
	      @(List.map (fun message ->compose userNumber message  0) (try(List.assoc userNumber !Globals.init_msg_knowledge) with Not_found->[] ))
	     ))
        @ (List.map (fun identifierNumber ->
                       Var(Utilities.get_identifier_name identifierNumber))
             (fresh_var protocolStep))
;;
(* ex lknow *)

let get_user_knowledge userNumber usedStep protocolStep =
  termlist_of_list (Utilities.suppr_double (get_user_knowledge_aux userNumber usedStep protocolStep))
;;

let find_first_send_with_user user message =
  let mesg = Id(message) in
  let result = ref 0 in
    (
      let list_of_knowledge = compute_know_of_user user !nbMsgs in
      let current_step = ref 1 in
      let continue = ref true in 
    	while ((!current_step <= !Globals.nbMsgs) && !continue) do
	  let current_knowledge = (List.map (fun (a,b) -> a) (List.assoc !current_step list_of_knowledge)) in
	  let known_at_step = (List.mem mesg current_knowledge) in
	  let sent_at_step = ((List.mem mesg (msg_to_atoms (get_msg !current_step)))&&(user = (get_sender !current_step))) in
	    if (sent_at_step && known_at_step) then
	      begin
	    	result := !current_step;
	    	continue := false
	      end
	    else
	      incr current_step
    	done;
	!result
    )
;;

let find_first_send message =
  let mesg = Id(message) in
  let result = ref (!nbMsgs +1) in
    (
      List.iter
       (fun user ->
	  let list_of_knowledge = compute_know_of_user user !nbMsgs in
	  let current_step = ref 1 in
	  let continue = ref true in 
    	    while ((!current_step <= !Globals.nbMsgs) && !continue) do
	      let current_knowledge = (List.map (fun (a,b) -> a) (List.assoc !current_step list_of_knowledge)) in
	      let known_at_step = (List.mem mesg current_knowledge) in
	      let sent_at_step = (List.mem mesg (msg_to_atoms (get_msg !current_step))) in
	    	if (sent_at_step && known_at_step&&(!current_step < !result)) then
	    	  result := !current_step;
		incr current_step
    	    done;
       )
       (get_user_list !Globals.msg_list);
      !result
    )
;;

let find_last_received message =
  let mesg = Id(message) in
  let result = ref 0 in
    (
      List.iter
       (fun user ->
	  let current_step = ref 1 in
    	    while (!current_step <= !Globals.nbMsgs) do
	      let received_at_step = (List.mem mesg (msg_to_atoms (get_msg !current_step))) in
	    	if (received_at_step && (!current_step > !result)) then
	    	  result := !current_step;
		incr current_step
    	    done;
       )
       (get_user_list !Globals.msg_list);
      !result
    )
;;

let build_secret_add_on () =
  let list_of_alterations =  ref ([] : (int * (Types.term list))list) in
    ( 
      for protocolStep = 0 to !Globals.nbMsgs do
      	list_of_alterations := (protocolStep,[])::!list_of_alterations
      done;      
      List.iter
      	(fun secret ->
	   let creation_step = find_first_send secret in
	   let type_it = (add_type_def (creation_step-1)) in
	   let step_former_add_ons = (List.assoc (creation_step-1) !list_of_alterations) in
	   let step_new_add_ons =
	     (opsecret
		(type_it (Var(get_identifier_name secret)))
		(Op("f",[Var("c")]))
	     )::step_former_add_ons in
	   let new_list = ((creation_step - 1 ),step_new_add_ons)::(List.remove_assoc (creation_step-1) !list_of_alterations) in
	     list_of_alterations := new_list
      	)
       	((!Globals.secret_goal_list)@(!Globals.stSecret_goal_list))
      ;
      !list_of_alterations
    )
;;


let find_if_created secret =
  let creation_step = find_first_send secret in
  let creator = (get_sender creation_step) in
    (not(!Globals.session_instances = [])||(List.exists (fun (id,list_of_instance) -> (id=creator)) !Globals.role_list))
;;

let build_short_term_secret_add_on_RHS () =
  let list_of_alterations =  ref ([] : (int * (Types.term list))list) in
    ( 
      for protocolStep = 1 to !Globals.nbMsgs do
      	list_of_alterations := (protocolStep,[])::!list_of_alterations
      done;      
      List.iter
      	(fun secret ->
	   (* 
	      one has to change the next definition (find_last_received) in order to change the way the step after
	      which the term is now longer secret 
	   *)
	   if (find_if_created secret) then
	     let last_step = find_last_received secret in
	     let type_it = (add_type_def last_step) in
	     let step_former_add_ons = (List.assoc last_step !list_of_alterations) in
	     let step_new_add_ons =
	       (
		 (Op("give",
		    [(type_it (Var(get_identifier_name secret)));(Op("f",[Var("c")]))]
		   ))
	       )::step_former_add_ons in 
	     let new_list = (last_step,step_new_add_ons)::(List.remove_assoc last_step !list_of_alterations) in
	       list_of_alterations := new_list
      	)
       	!Globals.stSecret_goal_list
      ;
      !list_of_alterations
    )
;;

let build_short_term_secret_add_on_LHS () =
  let list_of_alterations =  ref ([] : (int * (Types.term list))list) in
    ( 
      for protocolStep = 1 to !Globals.nbMsgs do
      	list_of_alterations := (protocolStep,[])::!list_of_alterations
      done;
      !list_of_alterations
    )
;;
  
(*
let build_short_term_secret_add_on_LHS () =
  let list_of_alterations =  ref ([] : (int * (Types.term list))list) in
    ( 
      for protocolStep = 1 to !Globals.nbMsgs do
      	list_of_alterations := (protocolStep,[])::!list_of_alterations
      done;      
      List.iter
      	(fun secret ->
	   if (find_if_created secret) then
	     let last_step = find_last_received secret in
	     let type_it = (add_type_def last_step) in
	     let step_former_add_ons = (List.assoc last_step !list_of_alterations) in
	     let step_new_add_ons =
	       (opsecret
		  (type_it (Var(get_identifier_name secret)))
		  (Op("f",[Var("c")]))
	       )::step_former_add_ons in  
	     let new_list = (last_step,step_new_add_ons)::(List.remove_assoc last_step !list_of_alterations) in
	       list_of_alterations := new_list
      	)
       	!Globals.stSecret_goal_list
      ;
      !list_of_alterations
    )
;;*)



(*
  Functions for the authenticate goal
I guess this is the way it should have been done earlier :
we add terms in a list indexed by the steps (from 0 to nbMesgs) of the protocol
During build_user_rules, we add the part of this list in the RHS of the rule.
It seems it can easily be extended to secret list (may we could rewrite this part ?),
short term secrecy (just add terms in a list) and, in general, to every change we would 
want to make on a rule. In this case, we would have a list :
(step : int * (LHS : Types.term list) * (RHS : Types.term list) ) and build_user_rules 
would just put some Op(".", ) and some Rule() around  it.
*)

let build_authenticate_add_on ()=
  let list_of_alterations = ref ([] : (int * (Types.term list))list) in
    (
      for protocolStep = 0 to !Globals.nbMsgs do
      	list_of_alterations := (protocolStep,[])::!list_of_alterations
      done;
      List.iter
	(
	  fun ((authenticator,authenticated),list_of_terms) ->
	    (
	      List.iter
	       (fun i ->
		  let step = find_first_send_with_user authenticated i in
		  let type_it = (add_type_def (step-1)) in
		  let step_former_add_ons = (List.assoc (step-1) !list_of_alterations) in
		  let step_new_add_ons =
		    (opwitness 
		       (type_it (Var(get_identifier_name authenticated))) 
		       (type_it (Var(get_identifier_name authenticator)))  
		       (Cons(get_identifier_name i)) 
		       (type_it (Var(get_identifier_name i))) 
		    )::step_former_add_ons in
		  let new_list = ((step - 1 ),step_new_add_ons)::(List.remove_assoc (step-1) !list_of_alterations)in
		    list_of_alterations := new_list
	       )
	       list_of_terms;
	      let last_authenticator_step = Utilities.last_received_message authenticator in
	      let type_it = (add_type_def last_authenticator_step) in
	      let step_former_add_ons = (List.assoc last_authenticator_step !list_of_alterations) in
	      let step_new_add_ons = 
		(List.map
		   (fun message ->
		      oprequest 
			(type_it (Var(get_identifier_name authenticator)))
			(type_it (Var(get_identifier_name authenticated)))
			(Cons(get_identifier_name message))
			(type_it (Var(get_identifier_name message)))
		   )
		   list_of_terms
		)@step_former_add_ons in
	      let new_list = (last_authenticator_step,step_new_add_ons)::(List.remove_assoc last_authenticator_step !list_of_alterations) in
		list_of_alterations := new_list
	    )
	)!Globals.authenticate_goal_list;
      !list_of_alterations
    )
;;

(* returns a list of instances *)
let find_all_instances_of user_number =
  let instances_in_roles = (List.map
			      (fun (x,(y,z)) -> (x,z))
			      (List.filter 
				 (function 
				      (_,(role_id,other)) -> 
					((role_id = user_number)&& (not((List.exists (function (role_id2,"I") -> (role_id2 = user_number) | _ -> false) other))))
				 )
				 !Globals.role_list
			      )
			   ) 
in
let result =
  if ( !Globals.session_instances = []) then
    (instances_in_roles)
  else
    (instances_in_roles)@(!Globals.session_instances)
in
let remove_intruder_instances a_list_of_list =
  (List.filter
     (fun (sessionCounter,instance) ->
	(List.for_all (function (the_ID,"I") -> not(the_ID = user_number) | _ -> true) instance)
     )
     a_list_of_list
  )
in
  (remove_intruder_instances result) 
;; 

let rec add_instance an_instance a_term =
  match a_term with
      Empty -> Empty
    |  Cons(s) -> Cons(s)
    |Op(s,list_of_args) -> Op(s,(List.map (fun x -> add_instance an_instance x) list_of_args))
    | Var("etc") -> Cons("etc")
    | Var(name) ->
	(
	  if (List.exists (fun (x,(y,z)) -> (y = name)) !Globals.ident_list) then
	    (
	      let name_id = get_identifier_number name !Globals.ident_list in
	      let is_there a_list =
	      	(List.exists (fun (x,y) -> (x = name_id)) a_list)
	      in
	      	if (is_there an_instance) then
	    	  let type_of_name =  Utilities.findtype name !Globals.ident_list false in
	    	  let instance_of_name = (List.assoc name_id an_instance) in
		      (Cons(instance_of_name))
		else
		  (Var(name))
	    )
	  else
	    (Var(name))
	)
;;

let build_first_rule add_on_RHS =
  let receiver = get_sender 1 in
  let instances_list = find_all_instances_of receiver in
  let iprim0 = if k 0 > 0 then 1 else 0 in
    (List.map
       (function
	    (_,[]) -> Rule("",Empty,Empty)
	  | (sessionCounter,an_instance) ->
	      let wl = (opw 
			  (Cons("0")) (* step *)
			  (Op("mr",[Cons("I")])) (* sender *)
			  (opmr(Var(Utilities.get_identifier_name receiver))) (* receiver *)
			  (add_type_def 0 (get_user_knowledge receiver 0 0)) (* AcqKnowledge *)
			  (initial_knowledge_terms receiver) (* InitialKnowledge *)
			  (Cons("true")) (* boolean *)
			  (Var("c")) (* session *)
		       ) in
	      let leftRuleMember = Op(".",[ (oph (ops (Var("Time")))); wl]) in
	    	
	      (* rigth rule member building *)
	      let sender =  (if k 0 = 0 then Op("mr",[Cons("I")]) else (compose receiver (Id(get_sender (k 0)))0)) in
	      let cprim = if  ((k 0) > 0) then Var("c") else ops(Var("c")) in
	      let wr = (opw
			  (Cons(string_of_int (k 0)))(* Step *)
			  (sender)
			  (opmr(Var(Utilities.get_identifier_name (get_receiver (k 0))))) (* receiver *)
			  (add_type_def 0 (get_user_knowledge receiver iprim0 iprim0)) (* AcqKnowledge *)
			  (initial_knowledge_terms receiver) (* InitialKnowledge *)
			  (Cons("true")) (* boolean *)
			  cprim (* session *)
		       ) in
	      let mr = (opm
			  (Cons("1")) (* step *)
			  (opmr(Var(Utilities.get_identifier_name receiver))) (* RealSender *)
			  (opmr(Var(Utilities.get_identifier_name receiver))) (* Officialsender *)
			  (compose receiver (Id(get_receiver 1)) 0) (* Receiver *)
			  (compose receiver (get_msg 1) 0) (* contents *)
			  (Var("c")) (* session *)
		       ) in
	    	(*    print_term( compose receiver (get_msg 1) 0);*)
	    	
	      let rightRuleMember = Op(".", [ (oph (Var("Time"))); mr; wr]@(add_on_RHS)) in
	    	(Rule(("# lb=Step_0_"^(string_of_int sessionCounter)^", type=Protocol_Rules"),
		      (add_instance an_instance leftRuleMember),
		      (add_instance an_instance rightRuleMember))
	    	)
       )
       instances_list)
;;



let build_a_protocol_rule step add_on_LHS add_on_RHS =
  match (List.assoc step !Globals.msg_list) with (sender,receiver),msg ->
    let instances_list = find_all_instances_of receiver in
      (List.map
	 (function
	      (_,[])          -> Rule("",Empty,Empty)
	    | (sessionCounter,an_instance) ->
		let next_rec_step = (k step) in
	    	let next_msg_step = (step+1) in
	    	let prev_step = if (invk step) >= step then 0 else (invk step)+1 in
	    	let wlSender= if (know (Id(sender)) receiver prev_step) then (opmr(Var(Utilities.get_identifier_name sender))) else (opmr (Cons"I")) in
	    	let wl = (opw 
		 	    (Cons(string_of_int step)) (* step *)
		 	    wlSender (* sender *)
		 	    (opmr(Var(get_identifier_name receiver))) (* Receiver *)
		 	    (add_type_def step (get_user_knowledge receiver (step+1) prev_step)) (* AcqKnowledge *) 
		 	    (initial_knowledge_terms receiver) (* InitialKnowledge *)
		 	    (Var("bool")) (* boolean *)
		 	    (Var("c")) (*session *)
			 ) in
	    	let ml = (opm 
		 	    (Cons(string_of_int step)) (* step *)
		 	    (opmr(Var("r"))) (* RealSender *)
		 	    wlSender (* OfficialSender *)
		 	    (opmr(Var(get_identifier_name receiver))) (* receiver *)
		 	    (see receiver msg (step+1)) (* Contents *)
		 	    (Var("c2")) (* session *)
			 ) in
	    	let leftRuleMember = Op(".", [ (oph (ops (Var("Time")))); ml; wl]@(add_on_LHS)) in	 
	    	let cprim = if  (next_rec_step > step) then Var("c") else ops(Var("c")) in
		let knowledge_step = if (next_rec_step == 0) then 0 else (next_rec_step-1) in
		let sender_name_right = (Utilities.get_sender next_rec_step) in
	    	let wrSender = 
		  if (know (Id(sender_name_right)) receiver knowledge_step) then
		    (opmr(Var(Utilities.get_identifier_name sender_name_right))) 
		  else 
		    (opmr(Cons"I"))
		in
	    	let wr = (opw
		 	    (Cons(string_of_int (next_rec_step))) (* step *)
		 	    (wrSender) (* sender *)
		 	    (opmr(Var(Utilities.get_identifier_name receiver))) (*receiver *)
		 	    (add_type_def step (get_user_knowledge receiver (step+1) next_rec_step)) (* AcqKnowledge *)
		 	    (initial_knowledge_terms receiver)(* InitialKnowledge *)
		 	    (Cons ("true")) (*boolean *)
		 	    cprim (* session *)
			 ) in
	    	let mr = (opm 
		 	    (Cons(string_of_int (next_msg_step))) (* step *)
		 	    (opmr(Var(Utilities.get_identifier_name receiver))) (* RealSender *)
		 	    (opmr(Var(get_identifier_name receiver))) (* OfficialSender *)
		 	    (compose receiver (Id(get_receiver (next_msg_step))) step) (* Receiver *)
		 	    (compose receiver (get_msg (next_msg_step)) step) (* contents *)
		 	    (Var("c2")) (* session *)
			 ) in
	    	let rightRuleMember = Op(".",  [ (oph(Var("Time"))); mr; wr]@(add_on_RHS)) in
		  (* Rule insertion *)
		  (Rule(("# lb=Step_"^(string_of_int step))^"_"^(string_of_int sessionCounter)^", type=Protocol_Rules",
		    	(add_instance an_instance leftRuleMember),
		    	(add_instance an_instance rightRuleMember)
		       )
		  )
	 )
	 instances_list
      )
;; 

let build_last_user_rule add_on_LHS add_on_RHS =
  match List.assoc !Globals.nbMsgs !Globals.msg_list with (sender,receiver),message ->
    let instances_list = find_all_instances_of receiver in
      (List.map
	 (function
	      (_,[]) -> Rule("",Empty,Empty)
	    | (sessionCounter,an_instance) ->
	    	(* left rule member building *)
	    	let step = !Globals.nbMsgs in
	    	let prev_step = if (invk step) >= step then 0 else (invk step)+1 in
	    	let next_step = k step in
		let sender_name_left = Utilities.get_sender step in
		let sender_name_right = Utilities.get_sender next_step in
		let wlSender = 
		  if (know (Id(sender_name_left)) receiver prev_step) then 
		    (opmr(Var(Utilities.get_identifier_name sender_name_left))) 
		  else 
		    (opmr (Cons"I")) 
		in
		let wrSender =  
		  if (know (Id(sender_name_right)) receiver 0) then 
		    (opmr(Var(Utilities.get_identifier_name sender_name_right))) 
		  else 
		    (opmr(Cons"I")) 
		in
	    	let wl = (opw 
		   	    (Cons(string_of_int step)) (* step *)
		   	    (wlSender) (* sender *)
		   	    (opmr(Var(Utilities.get_identifier_name receiver))) (* receiver *)
		   	    (add_type_def step (get_user_knowledge receiver step prev_step)) (* AcqKnowledge *)
		   	    (initial_knowledge_terms receiver) (* Initial knowledge *)
		   	    (Var("bool")) (* Boolean *)
		   	    (Var("c")) (*session *)
			 ) in
	    	let ml = (opm
		   	    (Cons(string_of_int step)) (* step *)
		   	    (opmr(Var("r"))) (* RealSender *)
		   	    (wlSender) (* OfficialSender *)
		   	    (opmr(Var(get_identifier_name receiver))) (* receiver *)
		   	    (see receiver message step) (* contents *)
		   	    (Var("c2")) (* session *)
			 ) in
	    	let leftRuleMember = Op(".",[ (oph( ops (Var("Time")))); ml; wl]@(add_on_LHS)) in
		  (* Right rule member building *)
	    	let wr = (opw
		   	    (Cons(string_of_int (next_step))) (* step *)
			    (wrSender)
		   	    (opmr(Var(Utilities.get_identifier_name receiver))) (* Receiver *)
		   	    (add_type_def step (get_user_knowledge receiver next_step next_step)) (* AcqKnowldge *)
		   	    (initial_knowledge_terms receiver) (* initial knowledge *)
		   	    (Cons("true")) (* boolean *)
		   	    (ops(Var("c"))) (* session *)
			 ) in
	    	let rightRuleMember = Op(".",[ (oph (Var("Time"))); wr]@(add_on_RHS)) in
      		  (
		    Rule(
		      ("# lb=Step_"^(string_of_int step))^"_"^(string_of_int sessionCounter)^", type=Protocol_Rules",
		      (add_instance an_instance leftRuleMember),
		      (add_instance an_instance rightRuleMember)
		    )
		  )
	 )
	 instances_list
      )
;;

let  build_user_rules () =
  let remove_empty_rules a_list =
    (List.filter (function Rule("",Empty,Empty) -> false | _ -> true) a_list)
  in
  let userRuleList = ref []  in
  let authenticate_add_ons = build_authenticate_add_on() in
  let secret_add_ons = build_secret_add_on() in
  let short_term_secret_add_on_RHS = build_short_term_secret_add_on_RHS () in
  let short_term_secret_add_on_LHS = build_short_term_secret_add_on_LHS () in
  let add_on_RHS = (Utilities.merge authenticate_add_ons (Utilities.merge secret_add_ons short_term_secret_add_on_RHS)) in
  let add_on_LHS = short_term_secret_add_on_LHS in
    (***  first rule generation  ***)
  let first_step_add_on_LHS = (List.assoc 0 add_on_RHS) in
    userRuleList := (build_first_rule first_step_add_on_LHS);
    (*** case receive step i from 1 to n-1 ***)
    for i=1 to (!Globals.nbMsgs-1) 
    do
      let this_step_add_on_LHS = (List.assoc i add_on_LHS) in
      let this_step_add_on_RHS = (List.assoc i add_on_RHS) in
	userRuleList := !userRuleList@(build_a_protocol_rule i this_step_add_on_LHS this_step_add_on_RHS);
    done;
    (*** Last rule generation *)
    let last_step_add_on_LHS = (List.assoc !Globals.nbMsgs add_on_LHS) in
    let last_step_add_on_RHS = (List.assoc !Globals.nbMsgs add_on_RHS) in
      userRuleList := !userRuleList@(build_last_user_rule last_step_add_on_LHS last_step_add_on_RHS);
    (remove_empty_rules !userRuleList)
;;


let for_all_user_except_intruder functionToApply = 
    List.iter
      ( fun (identifierNumber,(identifierName,identifierType)) ->
	match identifierType with
      	  | User -> 
	      begin
		try
		  if (identifierName <> "I")
		  then (functionToApply identifierNumber) 
		  else ()
		with Not_found -> ()
	      end
      	  | _ -> ()  
    )
      !Globals.ident_list
;;


let  build_init_state () =
  let wTermList = ref [] in
    (* building w terms unsing role section *)
    List.iter
      (fun (sessionCounter,(userNumber,instanceCoupleList)) ->
	 let firstReceiptStep = firstS userNumber - 1 in (* step at which the first message is received  *)
	   (* put in [knownInstances] the list of typed instances of user's knowledge  *)
	 let knowInstances = List.map (fun x -> ((op_of_type (Utilities.get_identifier_type x)) (Cons (List.assoc x instanceCoupleList)) )) (List.assoc userNumber !Globals.ident_knowledge) in
	   (* Intruder receives the knowledge of a user he is an instance of  *)
	   if ((List.assoc userNumber instanceCoupleList)="I")
	   then
	     List.iter (fun x -> 
			  if not((x = Empty)||(List.mem (opi(x)) !Globals.intruder_knowledge)) 
			  then intruder_knowledge:=!intruder_knowledge @ [opi(x)]
		       ) knowInstances ;
	   let receiver =
	     if firstReceiptStep<>0
	     then Cons (List.assoc (get_receiver firstReceiptStep) instanceCoupleList)
	     else Cons (List.assoc (get_sender 1) instanceCoupleList) in
	     match receiver with
		 Cons "I" -> ()
	       | _ -> (
		   let sender = 
		     if firstReceiptStep<>0
		     then
		       try
			 let intended_sender = (List.assoc (get_sender firstReceiptStep) instanceCoupleList) in
			   if (Knowledge.know (Id(get_sender firstReceiptStep)) userNumber 0) then
			     (
			       Cons(intended_sender)
			     )
			   else
			     Cons("I")
		       with  (* case the sender is not specified ? *)
			   Not_found -> Cons("I")
		     else (* first message, no variables *)
		       Cons("I")
		   in
		   let w = (opw
			      (Cons(string_of_int firstReceiptStep)) (* step *)
			      (opmr(sender)) (* Sender *)
			      (opmr(receiver)) (* Receiver *)
			      (Cons("etc")) (* AcqKnowledge *)
			      (termlist_of_list (knowInstances @ 
						 (List.map (fun message ->replace_by_instance(Utilities.to_term message)instanceCoupleList)
						    (try(List.assoc userNumber !Globals.init_msg_knowledge) with Not_found->[] )
						 )
						)
			      ) (* InitialKnowledge *)
			      (Cons("true")) (* Boolean *)
			      (Cons(string_of_int sessionCounter)) (* session *)
			   ) in
		     wTermList := w::!wTermList
		 )
      )
      !Globals.role_list;
    (* building w terms using session_instances section *)
    List.iter
      (fun (sessionCounter,inst) -> for_all_user_except_intruder 
	 (
	   fun userNumber ->
	     let firstReceiptStep = firstS userNumber - 1 in (* step at which the first message is received  *)
	       
	     (* put in [knownInstances] the list of typed instances of user's knowledge  *)
	     let knowInstances = List.map (fun x -> ((op_of_type (Utilities.get_identifier_type x)) (Cons (List.assoc x inst)) )) (List.assoc userNumber !Globals.ident_knowledge) in
	       (* Intruder receives the knowledge of a user he is an instance of  *)
	       if ((List.assoc userNumber inst)="I")
	       then
		 List.iter (fun x -> 
			      if (List.mem (opi(x)) !Globals.intruder_knowledge = false) 
			      then intruder_knowledge:=!intruder_knowledge @ [opi(x)]
			   ) knowInstances ;
	       let receiver =
		 if firstReceiptStep<>0
		 then Cons (List.assoc (get_receiver firstReceiptStep) inst)
		 else Cons (List.assoc (get_sender 1) inst) in
		 match receiver with
		     Cons "I" -> ()
		   | _ -> (
		       let sender = 
			 if firstReceiptStep<>0
			 then
			   try
			     let intended_sender = (List.assoc (get_sender firstReceiptStep) inst) in
			       if (Knowledge.know (Id(get_sender firstReceiptStep)) userNumber 0) then
				 (
				   Cons(intended_sender)
				 )
			       else
				 Cons("I")
			   with  (* case the sender is not specified ? *)
			       Not_found -> Cons("I")
			 else (* first message, no variables *)
			   Cons("I")
		       in
		       let w = (opw
				  (Cons(string_of_int firstReceiptStep)) (* step *)
				  (opmr(sender)) (* Sender *)
				  (opmr(receiver)) (* Receiver *)
				  (Cons("etc")) (* AcqKnowledge *)
				  (termlist_of_list (knowInstances @ (List.map (fun message ->replace_by_instance(Utilities.to_term message) inst)(try(List.assoc userNumber !Globals.init_msg_knowledge) with Not_found->[])))) (* InitialKnowledge *)
				  (Cons("true")) (* Boolean *)
				  (Cons(string_of_int sessionCounter)) (* session *)
			       ) in
			 wTermList := w::!wTermList)
	 )
      )
      !Globals.session_instances;
    (* secret terms for parallel *)
    let instanceCouple = ref (0,"") in (* session couple associated to the parallel secret instance *)
    let typedSecretInstances =List.map(fun instance->
					 List.iter (fun instanceCoupleList ->
 						      try (instanceCouple := List.find (fun x -> instance = snd x ) instanceCoupleList)
						      with Not_found -> ignore()
						   )(!para_session_instances);
					 try ((op_of_type (List.assoc instance !ParseActions.declared_instances)) (Cons(instance))) 
					 with Not_found -> try ((op_of_type (get_identifier_type (get_identifier_number instance !Globals.ident_list))) (Cons(instance))) 
					 with Not_found -> (ErrorHandler.printExceptionMessage (Failure "undeclared secret") "Rules" "build_init_state";raise (Failure "build_init_state"))
				      )(!Globals.secret_ident_list) in
    let secretTermList = ref [] in
      List.iter (fun typedInstance -> secretTermList:=!secretTermList @ [opsecret typedInstance (Op("f",[Cons("para")]))])typedSecretInstances;
      Rule("# lb=Initial_state, type=Init",
	   Empty,
	   (Op (".", ((oph (Var("Time")))::!wTermList)@(List.filter (function (Op("i",[x])) -> not(x = Empty) | _ -> true) !Globals.intruder_knowledge)@(!secretTermList)))
	  )
;;

let build_simplification_rules = 
  [ (Rule
       ("# lb=Idempotence, type=Invariant_Rules",
	(Op(".",[ (Var "1"); (Var "1") ])),
	(Var "1")));
    (Rule
       ("# lb=for_Secrecy_goal, type=Invariant_Rules",
	(opf (ops (Var "1"))),
	(opf (Var "1"))));
    (Rule("# lb=No_authentication_of_intruder, type=Simplification",
	  (oprequest (opmr(Var("1"))) (opmr(Cons("I"))) (Var("2")) (Var("3"))),
	  (Empty)));
    (Rule("# lb=Witness_matches_request, type=Simplification",
	  (Op(".",
	      [
        	oprequest 
		 (opmr(Var(!underscore^"authenticator"))) 
		 (opmr(Var(!underscore^"authenticated"))) 
		 (Var(!underscore^"identifier")) 
		 (Var(!underscore^"value"))
		; 
        	opwitness 
		  (opmr(Var(!underscore^"authenticated"))) 
		  (opmr(Var(!underscore^"authenticator"))) 
		  (Var(!underscore^"identifier")) 
		  (Var(!underscore^"value"))
	      ])), 
	  (Empty)
	 ));
    (Rule("# lb=Give_Short_Term_Secret, type=Simplification",
	  (Op(".",
	     [opsecret (Var("secret")) (Var("session"));
	      (Op("give",[(Var("secret"));(Var("session"))]))
	     ]
	     )
	  ),
	  opi (Var("secret"))
	 )
    )
  ]
;;
let call_parser channel =
  (try (let lexbuf = Lexing.from_channel channel
	in
	  ParseGrammar.protocol Lexer.token lexbuf)
   with Parsing.Parse_error ->
     ErrorHandler.handleParseError()); 
  !ErrorHandler.errorsCounter
;;

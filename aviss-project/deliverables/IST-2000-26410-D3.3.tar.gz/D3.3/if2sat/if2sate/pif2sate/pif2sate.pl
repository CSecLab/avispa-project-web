:- use_module(library(lists)).

% TODO: Directory structure
:- ensure_loaded(category_labels).

% PREDEFINED SORTs
pre_sorts(
	[
         sort(fluent),
	 sort(action),
	 sort(time),
	 sort(session),
	 sort(inknw_el),
	 sort(knw_el),
	 sort(in_index),
	 sort(acq_index),
	 sort(fsecrecy),
	 sort(pkinv),
	 sort(fresh_nonce),
	 sort(fresh_intruder_const),
%	 sort(binary),
%	 sort(unary),
% 	 sort(pair),
% 	 sort(scrypt),
% 	 sort(rcrypt),
% 	 sort(funct),
% 	 sort(crypt),
	 % TODO
%	 sort(msg),
	 sort(wstep),
	 sort(bool),
	 sort(atom),
	 sort(mr),
	 sort(pk),
	 sort(sk),
	 sort(nonce),
	 sort(fu),
	 sort(user),
	 sort(public_key),
	 sort(private_key),
	 sort(symmetric_key),
	 sort(fu_symbol),
	 sort(fresh_nonce_id),
	 sort(fresh_symmetric_id),
	 sort(fresh_public_id),
	 sort(fresh_private_id),
	 sort(intruder_const)
        ]
).

pre_super_sorts(
	[
         super_sort(atom,mr),
	 super_sort(atom,pk),
	 super_sort(atom,sk),
	 super_sort(atom,nonce),
	 super_sort(atom,fu)
% 	 super_sort(binary,pair),
% 	 super_sort(binary,rcrypt),
% 	 super_sort(binary,scrypt),
% 	 super_sort(binary,crypt),
% 	 super_sort(binary,funct),
% 	 super_sort(msg,binary),
% 	 super_sort(msg,unary),
% 	 super_sort(unary,mr),super_sort(unary,pk),
% 	 super_sort(unary,sk),super_sort(unary,fu),
% 	 super_sort(unary,nonce),
% 	 super_sort(know,msg)
]
).

pre_invariants(
	[invariant(~(wk('_','A','A','_','_','_','_'))),
	 invariant(~(m('_','_','A','A','_','_')))]
).

pre_constants(
	[
         constant(h(time),fluent),
	 constant(wk(wstep,mr,mr,knw_el,acq_index,bool,session),fluent),
	 constant(inknw(mr,inknw_el,in_index,session),fluent),
	 constant(i(knw_el),fluent),
	 constant(secret(knw_el,fsecrecy),fluent),

	 constant(0,time),
	 constant(s(time),time),
	 constant(true,bool),
	 constant(false,bool),
	 constant(s(session),session),
	 constant(f(session),fsecrecy),

	 constant(etc,inknw_el),
	 constant(etc,knw_el),	 

	 constant(pk(public_key),pk),
	 constant(pk(private_key),pkinv),
	 constant(primed(pkinv),pk),
	 constant(sk(symmetric_key),sk),
	 constant(fu(fu_symbol),fu),
	 constant(mr(user),mr),
	 constant(nonce(fresh_nonce),nonce),

	 constant(pk(fresh_public_key),pk),
	 constant(pk(fresh_private_key),pkinv),
	 constant(sk(fresh_symmetric_key),sk),
	 constant(pk(fresh_intruder_const),pk),
	 constant(pk(fresh_intruder_const),pkinv),
	 constant(sk(fresh_intruder_const),sk),
	 constant(nonce(fresh_intruder_const),nonce),


	 constant(c(fresh_public_id,time),fresh_public_key),
	 constant(c(fresh_private_id,time),fresh_private_key),
	 constant(c(fresh_symmetric_id,time),fresh_symmetric_key),
	 constant(c(fresh_nonce_id,time),fresh_nonce),
	 constant(c(intruder_const,intruder_const),fresh_intruder_const),

	 constant(ni,intruder_const) % TODO: CHECK,,
        ]

).

% PIF2SATE COMPILER
pif2sate(F_PIF,F_SATE) :-
	compile(F_PIF),!,
	% TODO: Analize the OPTs
%	problem(OPTs,LRRs),
	problem(_,LRRs),
	preprocess(LRRs,Cs-Ss-SPSs),
	tell(F_SATE),
	write_prefix(Cs-Ss-SPSs),
	% Initial state
	category_label(CIS,init),
	member(lrr(_,CIS,IS,[]),LRRs),
	pif2sate_initial_state(lrr(_,CIS,IS,[])),
	!,
	% Protocol Rewriting Rules
	category_label(CPRR,rules),
	findall(lrr(LB,CPRR,LHS,RHS),
		member(lrr(LB,CPRR,LHS,RHS),LRRs),
		PRRs),
	!,
	pif2sate_rules(PRRs),
	!,
	category_label(CINTRR,intruder),
	findall(lrr(LB,CINTRR,LHS,RHS),
		member(lrr(LB,CINTRR,LHS,RHS),LRRs),
		INTRRs),
	!,
	pif2sate_rules(INTRRs),
	!,
	category_label(CGOAL,goal),
	findall(lrr(_,CGOAL,G,[]),
		member(lrr(_,CGOAL,G,[]),LRRs),
		Gs),
	pif2sate_goals(Gs),
	!,
	told.

write_prefix(Cs-Ss-SPSs) :-
	pre_sorts(PRESs),
	pre_super_sorts(PRESPSs),
	pre_constants(PRECs),
	pre_invariants(PREINVs),
	append(PRESs,Ss,TTSs),
	append(PRESPSs,SPSs,TTSPSs),
	append(PRECs,Cs,TTCs),
	remove_duplicates(TTSs,TSs),
	remove_duplicates(TTSPSs,TSPSs),
	remove_duplicates(TTCs,TCs),

	write('% SORTs'),
        nl,
	write_facts(TSs),
        nl,
	write('% SUPER_SORTs'),
        nl,
	write_facts(TSPSs),
        nl,
	write('% CONSTANTs'),
        nl,
	write_facts(TCs),
        nl,
	write('% INVARIANTs'),
        nl,
	write_facts(PREINVs),
        nl,
        nl,nl.

% write_prefix(Cs-Ss-SPSs) :-
% 	write('% PROTOCOL INDEPENDED'),
%         nl,
%         nl,
% 	pre_sorts(PRESs),
% 	pre_super_sorts(PRESPSs),
% 	pre_constants(PRECs),
% 	pre_invariants(PREINVs),
% 	write('% PROTOCOL INDEPENDED: SORTs'),
%         nl,
% 	write_facts(PRESs),
%         nl,
% 	write('% PROTOCOL INDEPENDED: SUPER_SORTs'),
%         nl,
% 	write_facts(PRESPSs),
%         nl,
% 	write('% PROTOCOL INDEPENDED: CONSTANTs'),
%         nl,
% 	write_facts(PRECs),
%         nl,
% 	write('% PROTOCOL INDEPENDED: INVARIANTs'),
%         nl,
% 	write_facts(PREINVs),
%         nl,
%         nl,
% 	write('% PROTOCOL DEPENDED'),
%         nl,
%         nl,
% 	write('% PROTOCOL DEPENDED: SORTs'),
%         nl,
% 	write_facts(Ss),
%         nl,
% 	write('% PROTOCOL DEPENDED: SUPER_SORTs'),
%         nl,
% 	write_facts(SPSs),
%         nl,
% 	write('% PROTOCOL DEPENDED: CONSTANTs'),
%         nl,
% 	write_facts(Cs),
%         nl,nl.

preprocess(LRRs,Cs-Ss-SPSs) :-
 	category_label(CRR,rules),
 	findall(m(STEP,RS,OS,R,MSG,SES),
 		(member(lrr(_,CRR,_,RHS),LRRs),member(m(STEP,RS,OS,R,MSG,SES),RHS)),
 		Ms),
	!,
	% Message terms' constants and knowledge's constants
	% TODO : maybe we have to analize the impersonate msgs
	%        (are more general) and not the normal msgs..
	preprocess_msg_terms(Ms,TMCs-TMSs-TMSPSs),
	remove_duplicates(TMCs,MCs),
	remove_duplicates(TMSs,MSs),
	remove_duplicates(TMSPSs,MSPSs),

	% Acquired knowledge
 	findall(w(Wstep,Wsend,Wrec,AK,IK,Wbool,Wses),
 		(
		    member(lrr(_,CRR,LHS1,RHS1),LRRs),
		    (
			member(w(Wstep,Wsend,Wrec,AK,IK,Wbool,Wses),LHS1);
			member(w(Wstep,Wsend,Wrec,AK,IK,Wbool,Wses),RHS1)
		    )
		),
 		Ws),
	!,
	preprocess_principal_terms(Ws,TWCs-[]-[]),
	remove_duplicates(TWCs,WCs),

	% initial state
	category_label(CIS,init),
	!,
	findall(lrr(_,CIS,LHS,[]),
		member(lrr(_,CIS,LHS,[]),LRRs),
		ISs),
	preprocess_initial_state(ISs,TISCs-TISSs-TISSPSs),
	remove_duplicates(TISCs,ISCs),
	remove_duplicates(TISSs,ISSs),
	remove_duplicates(TISSPSs,ISSPSs),

	% Merge of the constant
	append(MCs,WCs,TCs),
	append(TCs,ISCs,Cs),

	append(MSs,ISSs,Ss),
	append(MSPSs,ISSPSs,SPSs).

preprocess_principal_terms([],[]-[]-[]).
preprocess_principal_terms([W|Ws],Cs-Ss-SPSs) :-
	preprocess_principal_term(W,C1s-S1s-SPS1s),
	preprocess_principal_terms(Ws,C2s-S2s-SPS2s),
	append(C1s,C2s,Cs),
	append(S1s,S2s,Ss),
	append(SPS1s,SPS2s,SPSs).

preprocess_principal_term(w(STEP,_,_,AKs,IKs,_,_),Cs-Ss-SPSs) :-
	same_length(AKs,AKs,MaxAcqIndex),
	same_length(IKs,IKs,MaxInIndex),
	build_constants(1-MaxAcqIndex,acq_index,CAIs),
	build_constants(1-MaxInIndex,in_index,CIIs),
	append(CAIs,CIIs,CIs),
	Cs = [constant(STEP,wstep)|CIs],
	Ss = [],
	SPSs = [].
	
%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS INITIAL STATE
%

% TODO: At now we accept just one initial state: two initial 
%       states mean two different simulation
preprocess_initial_state([lrr(_,_,LHS,[])],ISCs-ISSs-ISSPSs):-
	preprocess_init_terms(LHS,ISCs-ISSs-ISSPSs).

preprocess_init_terms([],[]-[]-[]).
preprocess_init_terms([T|Ts],Cs-Ss-SPSs) :-
	preprocess_init_term(T,C1s-S1s-SPS1s),
	preprocess_init_terms(Ts,C2s-S2s-SPS2s),
	append(C1s,C2s,Cs),
	append(S1s,S2s,Ss),
	append(SPS1s,SPS2s,SPSs).
	
preprocess_init_term(w(_,S,R,[],INKNWs,_,SES),
	             Cs-IKSs-IKSPSs) :-
	preprocess_user(S,SC),
	preprocess_user(R,RC),
	preprocess_inknw(INKNWs,IKCs-IKSs-IKSPSs),
	append([SC,RC,constant(SES,session)],
	       IKCs,Cs).

preprocess_init_term(i(KNW),
	             Cs-[]-[]) :-
	preprocess_element(KNW,Cs).

preprocess_init_term(h(xTime),
	             []-[]-[]).

preprocess_init_term(secret(MSG,_),
	             Cs-[]-[]) :-
	preprocess_element(MSG,Cs).

% TODO: Strange situation. Probably useless
preprocess_init_term(m(_,_,_,_,_,_),
	             []-[]-[]).

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS USER
%
preprocess_user(mr(A),constant(A,user)) :-
	atom(A),!.
% TODO: MAYBE USELESS
preprocess_user(A,constant(A,user)) :-
	atom(A),!.

%
%          END: PREPROCESS USER
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS INITIAL KNOWLEDGE
%

preprocess_inknw([],[]-[]-[]).
preprocess_inknw([IK|IKs],IKCs-IKSs-IKSPSs) :-
	preprocess_inknw_element(IK,_,IKC1s-IKS1s-IKSPS1s),
	preprocess_inknw(IKs,IKC2s-IKS2s-IKSPS2s),
	append(IKC1s,IKC2s,IKCs),
	append(IKS1s,IKS2s,IKSs),
	append(IKSPS1s,IKSPS2s,IKSPSs).

preprocess_inknw_element(crypt(_,MSG),crypt,
	       [constant(crypt(pk,SUBSORT),crypt),
	        constant(crypt(pk,SUBSORT),inknw_el),
	        constant(crypt(pk,SUBSORT),knw_el)|MCs]-MSs-MSPSs) :- 
	preprocess_inknw_element(MSG,SUBSORT,MCs-MSs-MSPSs).

preprocess_inknw_element(scrypt(_,MSG),scrypt,
	       [constant(scrypt(sk,SUBSORT),scrypt),
	        constant(scrypt(sk,SUBSORT),inknw_el),
	        constant(scrypt(sk,SUBSORT),knw_el)|MCs]-MSs-MSPSs) :- 
	preprocess_inknw_element(MSG,SUBSORT,MCs-MSs-MSPSs).

preprocess_inknw_element(funct(_,MSG),funct,
	       [constant(funct(fu,SUBSORT),funct),
	        constant(funct(fu,SUBSORT),inknw_el),
	        constant(funct(fu,SUBSORT),knw_el)|MCs]-MSs-MSPSs) :- 
	preprocess_inknw_element(MSG,SUBSORT,MCs-MSs-MSPSs).

preprocess_inknw_element(c(MSG1,MSG2),pair,
	       [constant(c(SUBSORT1,SUBSORT2),pair),
	        constant(c(SUBSORT1,SUBSORT2),inknw_el),
	        constant(c(SUBSORT1,SUBSORT2),knw_el)|MCs]-MSs-MSPSs) :- 
	preprocess_inknw_element(MSG1,SUBSORT1,MC1s-MS1s-MSPS1s),
	preprocess_inknw_element(MSG2,SUBSORT2,MC2s-MS2s-MSPS2s),
	append(MC1s,MC2s,MCs),
	append(MS1s,MS2s,MSs),
	append(MSPS1s,MSPS2s,MSPSs).


preprocess_inknw_element(rcrypt(MSG1,MSG2),rcrypt,
	       [constant(rcrypt(SUBSORT1,SUBSORT2),rcrypt),
	        constant(rcrypt(SUBSORT1,SUBSORT2),inknw_el),
	        constant(rcrypt(SUBSORT1,SUBSORT2),knw_el)|MCs]-MSs-MSPSs) :- 
	preprocess_inknw_element(MSG1,SUBSORT1,MC1s-MS1s-MSPS1s),
	preprocess_inknw_element(MSG2,SUBSORT2,MC2s-MS2s-MSPS2s),
	append(MC1s,MC2s,MCs),
	append(MS1s,MS2s,MSs),
	append(MSPS1s,MSPS2s,MSPSs).


% TODO: MAYBE USELESS
preprocess_inknw_element(nonce(c(NC,xTime)),nonce,
	[constant(NC,fresh_nonce_id)]-[]-[]).

preprocess_inknw_element(sk(c(SKC,xTime)),sk,
	[constant(SKC,fresh_symmetric_id)]-[]-[]).

preprocess_inknw_element(pk(c(PKC,xTime)),pk,
	[constant(PKC,fresh_public_id)]-[]-[]).

preprocess_inknw_element(primed(pk(c(PKC,xTime))),pk,
	[constant(PKC,fresh_private_id)]-[]-[]).

% TODO: MANAGE THE TYPED VERSION: add case for 'mr',etc

preprocess_inknw_element(mr(C),mr,[constant(C,user)]-[]-[super_sort(inknw_el,mr),super_sort(knw_el,mr)]) :- 
	atom(C),
	\+is_var(C).

preprocess_inknw_element(pk(C),pk,[constant(C,public_key)]-[]-[super_sort(inknw_el,pk),super_sort(knw_el,pk)]) :- 
	atom(C),
	\+is_var(C).

preprocess_inknw_element(primed(pk(C)),pk,[constant(C,private_key)]-[]-[super_sort(inknw_el,pk),super_sort(knw_el,pk)]) :- 
	atom(C),
	\+is_var(C).

preprocess_inknw_element(sk(C),sk,[constant(C,symmetric_key)]-[]-[super_sort(inknw_el,sk),super_sort(knw_el,sk)]) :- 
	atom(C),
	\+is_var(C).


preprocess_inknw_element(fu(C),fu,[constant(C,fu_symbol)]-[]-[super_sort(inknw_el,fu),super_sort(knw_el,fu)]) :- 
	atom(C),
	\+is_var(C).

preprocess_inknw_element(MSG,_,atom,[]-[]-[super_sort(inknw_el,atom),super_sort(knw_el,atom)]) :- 
	is_var(MSG).

%
%          END: PREPROCESS INITIAL KNOWLEDGE
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS ELEMENTs
%

preprocess_elements([],[]).
preprocess_elements([E|Es],Cs) :-
	preprocess_element(E,C1s),
	preprocess_elements(Es,C2s),
	append(C1s,C2s,Cs).

preprocess_element(E,[constant(E,atom)]) :-
	atom(E),!.
preprocess_element(mr(E),[constant(E,user)]) :-
	atom(E),!.
preprocess_element(pk(E),[constant(E,public_key)]) :-
	atom(E),!.
preprocess_element(primed(pk(E)),[constant(E,private_key)]) :-
	atom(E),!.
preprocess_element(sk(E),[constant(E,symmetric_key)]) :-
	atom(E),!.
preprocess_element(fu(E),[constant(E,fu_symbol)]) :-
	atom(E),!.
preprocess_element(nonce(c(N,xTime)),[constant(N,fresh_nonce_id)]) :-
	atom(N),!.
preprocess_element(nonce(c(N,N)),[constant(N,intruder_const)]) :-
	atom(N),!.
preprocess_element(primed(pk(c(N,N))),[constant(N,intruder_const)]) :-
	atom(N),!.
preprocess_element(sk(c(N,N)),[constant(N,intruder_const)]) :-
	atom(N),!.
preprocess_element(pk(c(N,N)),[constant(N,intruder_const)]) :-
	atom(N),!.
preprocess_element(E,Cs) :-
	\+atom(E),
	E=..[_|Es],
	preprocess_elements(Es,Cs).

%
%          END: PREPROCESS INITIAL STATE
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS MESSAGE TERMs
%

preprocess_msg_terms([],[]-[]-[]).
preprocess_msg_terms([m(STEP,_,_,_,MSG,_)|Ms],
	             Cs-Ss-SPSs) :-
	preprocess_msg(MSG,STEP,SORT,MCs-MSs-MSPSs),	

	build_sort('mstep',STEP,SSTEP),
	build_sort('msg',STEP,SMSG),

	append([constant(STEP,SSTEP),
	        constant(m(SSTEP,mr,mr,mr,SMSG,session),fluent)],
		MCs,C1s),
	append([sort(SSTEP),sort(SMSG)], MSs, S1s),
	append([super_sort(SMSG,SORT)],MSPSs,SPS1s),
	preprocess_msg_terms(Ms,C2s-S2s-SPS2s),
	append(C1s,C2s,Cs),
	append(S1s, S2s, Ss),
	append(SPS1s,SPS2s,SPSs).

%
%          END: PREPROCESS MESSAGE TERMs
%-----------------------------------------------------------------------

%-----------------------------------------------------------------------
%        BEGIN: PREPROCESS MESSAGE
%

preprocess_msg(crypt(_,MSG),STEP,SORT,
	       [constant(crypt(pk,SUBSORT),SORT),
	        constant(crypt(pk,SUBSORT),knw_el)|MCs]-[sort(SORT)|MSs]-MSPSs) :- 
	build_sort(crypt,STEP,SORT),
	preprocess_msg(MSG,STEP,SUBSORT,MCs-MSs-MSPSs).

preprocess_msg(scrypt(_,MSG),STEP,SORT,
	       [constant(scrypt(sk,SUBSORT),SORT),
	        constant(scrypt(sk,SUBSORT),knw_el)|MCs]-[sort(SORT)|MSs]-MSPSs) :- 
	build_sort(scrypt,STEP,SORT),
	preprocess_msg(MSG,STEP,SUBSORT,MCs-MSs-MSPSs).

preprocess_msg(funct(_,MSG),STEP,SORT,
	       [constant(funct(fu,SUBSORT),SORT),
	        constant(funct(fu,SUBSORT),knw_el)|MCs]-[sort(SORT)|MSs]-MSPSs) :- 
	build_sort(funct,STEP,SORT),
	preprocess_msg(MSG,STEP,SUBSORT,MCs-MSs-MSPSs).

preprocess_msg(c(MSG1,MSG2),STEP,SORT,
	       [constant(c(SUBSORT1,SUBSORT2),SORT),
	        constant(c(SUBSORT1,SUBSORT2),knw_el)|MCs]-[sort(SORT)|MSs]-MSPSs) :- 
	build_sort(pair,STEP,SORT),
	preprocess_msg(MSG1,STEP,SUBSORT1,MC1s-MS1s-MSPS1s),
	preprocess_msg(MSG2,STEP,SUBSORT2,MC2s-MS2s-MSPS2s),
	append(MC1s,MC2s,MCs),
	append(MS1s,MS2s,MSs),
	append(MSPS1s,MSPS2s,MSPSs).

preprocess_msg(rcrypt(MSG1,MSG2),STEP,SORT,
	       [constant(rcrypt(SUBSORT1,SUBSORT2),SORT),
	        constant(rcrypt(SUBSORT1,SUBSORT2),knw_el)|MCs]-[sort(SORT)|MSs]-MSPSs) :- 
	build_sort(rcrypt,STEP,SORT),
	preprocess_msg(MSG1,STEP,SUBSORT1,MC1s-MS1s-MSPS1s),
	preprocess_msg(MSG2,STEP,SUBSORT2,MC2s-MS2s-MSPS2s),
	append(MC1s,MC2s,MCs),
	append(MS1s,MS2s,MSs),
	append(MSPS1s,MSPS2s,MSPSs).

preprocess_msg(nonce(c(NC,xTime)),_,nonce,
	[constant(NC,fresh_nonce_id)]-[]-[]).

preprocess_msg(sk(c(SKC,xTime)),_,sk,
	[constant(SKC,fresh_symmetric_id)]-[]-[]).

preprocess_msg(pk(c(PKC,xTime)),_,pk,
	[constant(PKC,fresh_public_id)]-[]-[]).

preprocess_msg(primed(pk(c(PKC,xTime))),_,pk,
	[constant(PKC,fresh_private_id)]-[]-[]).

preprocess_msg(nonce(c(NC,NC)),_,nonce,
	[constant(NC,intruder_const)]-[]-[]).

preprocess_msg(sk(c(SKC,SKC)),_,sk,
	[constant(SKC,intruder_const)]-[]-[]).

preprocess_msg(pk(c(PKC,PKC)),_,pk,
	[constant(PKC,intruder_const)]-[]-[]).

preprocess_msg(primed(pk(c(PKC,PKC))),_,pk,
	[constant(PKC,intruder_const)]-[]-[]).

% TODO: MANAGE THE TYPED VERSION: add case for 'mr',etc

preprocess_msg(mr(C),_,mr,[]-[]-[super_sort(knw_el,mr)]) :- 
	atom(C).

preprocess_msg(pk(_),_,pk,[]-[]-[super_sort(knw_el,pk)]).

preprocess_msg(primed(pk(_)),_,pk,[]-[]-[super_sort(knw_el,pk)]).

preprocess_msg(sk(_),_,sk,[]-[]-[super_sort(knw_el,sk)]).

preprocess_msg(fu(_),_,fu,[]-[]-[super_sort(knw_el,fu)]).

preprocess_msg(nonce(_),_,nonce,[]-[]-[super_sort(knw_el,nonce)]).

preprocess_msg(MSG,_,atom,[]-[]-[super_sort(knw_el,atom)]) :- 
	is_var(MSG).

%
%          END: PREPROCESS MESSAGE
%-----------------------------------------------------------------------

is_var(MSG) :-
	atom(MSG),
	atom_concat('x',_,MSG).

build_constants(N-TOT,_,[]) :-
	N > TOT.

build_constants(TOT-TOT,SORT,[constant(TOT,SORT)]).
build_constants(N-TOT,SORT,[constant(N,SORT)|Cs]) :-
	N < TOT,
	M is N + 1,
	build_constants(M-TOT,SORT,Cs).

% SORT is LB1_LB2
build_sort(LB1,LB2,SORT) :-
	\+number(LB2),
	atom_chars(LB2,CLB2),
	atom_chars(LB1,CLB1),
	atom_chars('_',[UNDER]),
	append(CLB1,[UNDER|CLB2],CSORT),
	atom_chars(SORT,CSORT).
% SORT is LB_N
build_sort(LB,N,SORT) :-
	number(N),
	number_chars(N,CN),
	atom_chars(LB,CLB),
	atom_chars('_',[UNDER]),
	append(CLB,[UNDER|CN],CSORT),
	atom_chars(SORT,CSORT).

% write_facts(Ls) :-  
%       Write the list of facts Ls on the output stream
write_facts([]).
write_facts([L]):-
	write(L),
	put_code(46).
write_facts([L|Ls]) :-  
	write(L),
	put_code(46), 
	put_code(10), 
	write_facts(Ls).

%%%% ALE

pif2sate_initial_state(lrr(_,_,IS,[])) :-
	pifterms2lits_initial_state(IS,[],_,ISX),
	format('%%% INITIAL STATE\nfacts(~p).\n\n',[lits(ISX)]).

pif2sate_rules([]).
pif2sate_rules([R|Rs]) :-
	pif2sate_rule(R), nl,
	pif2sate_rules(Rs).

pif2sate_rule(lrr(Label,_,L,R)) :-
	pifterms2lits(L,[],M,Pre),
	pifterms2lits(R,M,M1,Add),
	append(L,R,LR),
	% For each action we have to specify 
	% a constant with the sort of each 
	% variable involved
	build_action_constant(Label,LR,M1,CA),
%	setof(V,ID^member(ID-V,M1),Vs),
	bagof(V,ID^member(ID-V,M1),Vs),
	ActionName=..[Label|Vs],
	format('~w.\n\n',[CA]),
	format('action(~w,\n\t~p,\n\t~p,\n\t~p,\n\t~p).\n',
	       [ActionName,true,lits(Pre),lits(Add),lits(Pre)]).

pif2sate_goals([]).
pif2sate_goals([G|Gs]) :-
	pif2sate_goal(G),
	pif2sate_goals(Gs).

pif2sate_goal(lrr(_,_,G,[])) :-
	pifterms2lits(G,[],_,GX),
	format('%%% GOAL STATE\ngoal(~p).\n\n',[lits(GX)]).

build_action_constant(Label,LR,M,CA) :-
	build_action_constant(Label,LR,M,CA,DOMs),
	ACT=..[Label|DOMs],
	CA=constant(ACT,action).

build_action_constant(_,_,[],_,[]).
build_action_constant(_,LR,[V-_|M],CA,[DOM|DOMs]) :-
	minimum_domain(LR,V,DOM),
	build_action_constant(_,LR,M,CA,DOMs).

minimum_domain(_,xTime,time) :- !.
minimum_domain(LR,V,session) :-
	(
	    member(m(_,_,_,_,_,S),LR);
	    member(w(_,_,_,_,_,_,S),LR);
	    member(secret(_,f(S)),LR)
	),
	make_var(S,[],[V-_],_),!.

minimum_domain(LR,V,bool) :-
	member(w(_,_,_,_,_,B,_),LR),
	make_var(B,[],[V-_],_),!.

minimum_domain(LR,V,mr) :-
	(
	    member(m(_,V,_,_,_,_),LR)
	;
	    member(m(_,_,V,_,_,_),LR)
	;
	    member(m(_,_,_,V,_,_),LR)
	;
	    member(w(_,V,_,_,_,_,_),LR)
	;
	    member(w(_,_,V,_,_,_,_),LR)
	),!.


% TYPED VERSION
minimum_domain(LR,V,user) :-
	(
	    member(m(_,mr(V),_,_,_,_),LR)
	;
	    member(m(_,_,mr(V),_,_,_),LR)
	;
	    member(m(_,_,_,mr(V),_,_),LR)
	;
	    member(w(_,mr(V),_,_,_,_,_),LR)
	;
	    member(w(_,_,mr(V),_,_,_,_),LR)
	),!.

minimum_domain(LR,V,DOM) :-
%	member(m(STEP,_,_,_,MSG,_),LR),
	member(m(_,_,_,_,MSG,_),LR),
	minimum_domain_msg(MSG,V,DOM),
	!.

minimum_domain(LR,V,inknw_el) :-
	member(w(_,_,_,_,InKnw,_,_),LR),
	member(V,InKnw),!.

minimum_domain(LR,V,DOM) :-
	member(w(_,_,_,_,InKnw,_,_),LR),
	member(IK,InKnw),
	minimum_domain_msg(IK,V,DOM),!.

% TODO: clever heuristic
% If the other predicates fail then we suppose V 
% of know's sort
minimum_domain(_,_,knw_el).

% DOMAIN OF THE VARIABLE OCCURRING IN A MESSAGE
% TYPED VERSION
minimum_domain_msg(crypt(pk(K),MSG),V,DOM) :- 
	(K = V -> 
	    DOM = public_key
	;
	    minimum_domain_msg(MSG,V,DOM)
	),!.

minimum_domain_msg(crypt(primed(pk(K)),MSG),V,DOM) :- 
	(K = V -> 
	    DOM = private_key
	;
	    minimum_domain_msg(MSG,V,DOM)
	),!.

minimum_domain_msg(scrypt(sk(K),MSG),V,DOM) :- 
	(K = V -> 
	    DOM = symmetric_key
	;
	    minimum_domain_msg(MSG,V,DOM)
	),!.

minimum_domain_msg(funct(fu(K),MSG),V,DOM) :- 
	(K = V -> 
	    DOM = fu_symbol
	;
	    minimum_domain_msg(MSG,V,DOM)
	),!.

minimum_domain_msg(c(MSG1,MSG2),V,DOM) :- 
	( 
	    minimum_domain_msg(MSG1,V,DOM)
	;
	    minimum_domain_msg(MSG2,V,DOM)
	),!.

minimum_domain_msg(rcrypt(MSG1,MSG2),V,DOM) :- 
	( 
	    minimum_domain_msg(MSG1,V,DOM)
	;
	    minimum_domain_msg(MSG2,V,DOM)
	),!.

minimum_domain_msg(nonce(c(V,xTime)),V,fresh_nonce_id) :- !.
minimum_domain_msg(pk(c(V,xTime)),V,fresh_public_id) :- !.
minimum_domain_msg(primed(pk(c(V,xTime))),V,fresh_private_id) :- !.
minimum_domain_msg(sk(c(V,xTime)),V,fresh_symmetric_id) :- !.

minimum_domain_msg(MSG,V,intruder_const) :- 
	MSG=..[_,c(V,V)], 
	!.

minimum_domain_msg(pk(V),V,public_key) :- !.
minimum_domain_msg(primed(pk(V)),V,private_key) :- !.
minimum_domain_msg(sk(V),V,symmetric_key) :- !.
minimum_domain_msg(fu(V),V,fu_symbol) :- !.
minimum_domain_msg(nonce(V),V,fresh_nonce) :- !.

%%%

% UNTYPED VERSION
minimum_domain_msg(crypt(K,MSG),V,DOM) :- 
	(K = V -> 
	    DOM = pk
	;
	    minimum_domain_msg(MSG,V,DOM)
	),!.

minimum_domain_msg(scrypt(K,MSG),V,DOM) :- 
	(K = V -> 
	    DOM = sk
	;
	    minimum_domain_msg(MSG,V,DOM)
	),!.

minimum_domain_msg(funct(K,MSG),V,DOM) :- 
	(K = V -> 
	    DOM = fu
	;
	    minimum_domain_msg(MSG,V,DOM)
	),!.

minimum_domain_msg(c(MSG1,MSG2),V,DOM) :- 
	( (MSG1 = V; MSG2 = V) -> 
	    DOM = atom
	;
	    ( 
		minimum_domain_msg(MSG1,V,DOM);
		minimum_domain_msg(MSG2,V,DOM)
	    )
	),!.

minimum_domain_msg(rcrypt(MSG1,MSG2),V,DOM) :- 
	( (MSG1 = V; MSG2 = V) -> 
	    DOM = atom
	;
	    ( 
		minimum_domain_msg(MSG1,V,DOM);
		minimum_domain_msg(MSG2,V,DOM)
	    )
	),!.
%%%

portray(lits(Ls)) :- print_lits(Ls).

print_lits([]) :- !, format('[]',[]).
print_lits([L]) :- !, format('[~w]',[L]).
print_lits([L|Ls]) :- !,
	format('[~w',[L]),
	print_lits_rest(Ls).

print_lits_rest([]) :- format(']',[]).
print_lits_rest([L|Ls]) :-
	format(',\n\t ~w',[L]),
	print_lits_rest(Ls).

% Usefull to instanciate the time in the initial state
pifterms2lits_initial_state([],M,M,[]).
pifterms2lits_initial_state([T|Ts],M,M2,TTsLs) :-
	pifterm2lits_initial_state(T,M,M1,TLs),
	pifterms2lits_initial_state(Ts,M1,M2,TsLs),
	append(TLs,TsLs,TTsLs).

pifterm2lits_initial_state(T,M,M1,TLs) :-
	T\=h(_),
	pifterm2lits(T,M,M1,TLs).
	    
% TODO: could be useful to instanciate the time
pifterm2lits_initial_state(h(xTime),M,[xTime-'XTime'|M],[h('XTime')]).

pifterms2lits([],M,M,[]).
pifterms2lits([T|Ts],M,M2,TTsLs) :-
	pifterm2lits(T,M,M1,TLs),
	pifterms2lits(Ts,M1,M2,TsLs),
	append(TLs,TsLs,TTsLs).

pifterm2lits(h(T),M,M1,[h(TX)]) :-
	make_var(T,M,M1,TX).
pifterm2lits(i(T),M,M1,[i(TX)]) :-
	make_var(T,M,M1,TX).
pifterm2lits(m(Step,RealSender,OfficialSender,Receiver,Content,Session),
	    M,
	    M6,
	    [m(StepX,RealSenderX,OfficialSenderX,ReceiverX,ContentX,SessionX)]) :-
	make_var(Step,M,M1,StepX),
	make_var(RealSender,M1,M2,RealSenderX),
	make_var(OfficialSender,M2,M3,OfficialSenderX),
	make_var(Receiver,M3,M4,ReceiverX),
	make_var(Content,M4,M5,ContentX),
	make_var(Session,M5,M6,SessionX).

% % TODO: CASE WHERE AcqKns OR InitKns AREN'T VARIABLES
% pifterm2lits(w(Step,Sender,Receiver,AcqKns,InitKns,Bool,Session),
% 	    M,
% 	    M7,
% 	    FLs) :-
% 	make_var(Step,M,M1,StepX),
% 	make_var(Sender,M1,M2,SenderX),
% 	make_var(Receiver,M2,M3,ReceiverX),

% 	make_var_multi(InitKns,M3,M4,InitKnsX),
% 	make_var_multi(AcqKns,M4,M5,AcqKnsX),
% 	make_var(Bool,M5,M6,BoolX),
% 	make_var(Session,M6,M7,SessionX),
% 	(InitKnsX=[] -> 
% 	    IKs=[inknw(ReceiverX,etc,1,SessionX)];
% 	    findall(inknw(ReceiverX,InitKnX,InIndex,SessionX),
% 		    nth(InIndex,InitKnsX,InitKnX),
% 		    IKs)
% 	),
% 	(AcqKnsX=[] -> 
% 	    WKs=[wk(StepX,SenderX,ReceiverX,etc,1,BoolX,SessionX)];
% 	    findall(wk(StepX,SenderX,ReceiverX,AcqKnX,AcqIndex,BoolX,SessionX),
% 		    nth(AcqIndex,AcqKnsX,AcqKnX),
% 		    WKs)
% 	),
% 	append(IKs,WKs,FLs).

% TODO: CASE WHERE AcqKns OR InitKns ARE VARIABLES
pifterm2lits(w(Step,Sender,Receiver,AcqKns,InitKns,Bool,Session),
	    M,
	    M7,
	    FLs) :-
	make_var(Step,M,M1,StepX),
	make_var(Sender,M1,M2,SenderX),
	make_var(Receiver,M2,M3,ReceiverX),

	(is_var(InitKns) -> 
	    InitKnsX = [],
	    M4 = M3;
	    make_var_multi(InitKns,M3,M4,InitKnsX)
	),
	(is_var(AcqKns) -> 
	    AcqKnsX = [],
	    M5 = M4;
	    make_var_multi(AcqKns,M4,M5,AcqKnsX)
	),
	make_var(Bool,M5,M6,BoolX),
	make_var(Session,M6,M7,SessionX),
	(InitKnsX=[] -> 
	    IKs=[inknw(ReceiverX,etc,1,SessionX)];
	    findall(inknw(ReceiverX,InitKnX,InIndex,SessionX),
		    nth(InIndex,InitKnsX,InitKnX),
		    IKs)
	),
	(AcqKnsX=[] -> 
	    WKs=[wk(StepX,SenderX,ReceiverX,etc,1,BoolX,SessionX)];
	    findall(wk(StepX,SenderX,ReceiverX,AcqKnX,AcqIndex,BoolX,SessionX),
		    nth(AcqIndex,AcqKnsX,AcqKnX),
		    WKs)
	),
	append(IKs,WKs,FLs).

pifterm2lits(secret(MSG,f(SES)),
	    M,
	    M2,
	    [secret(MSGX,f(SESX))]) :-
	make_var(MSG,M,M1,MSGX),
	make_var(SES,M1,M2,SESX).

make_var(ID,M,M1,V1) :-
	atom(ID),
	atom_concat('x',ID0,ID), !,
	( member(ID-V,M) ->
	    V1=V,
	    M1=M;
	    atom_concat('X',ID0,V1),
	    M1=[ID-V1|M] ).
make_var(T,M,M1,T1) :-
	T=..[F|Ts],
	make_var_multi(Ts,M,M1,Ts1),
	T1=..[F|Ts1].

make_var_multi([],M,M,[]).
make_var_multi([T|Ts],M,M2,[T1|Ts1]) :-
	make_var(T,M,M1,T1),
	make_var_multi(Ts,M1,M2,Ts1).

% split_knowledge(etc,[]).
% split_knowledge(xetc,[]).
% split_knowledge(etc2,[]).
% split_knowledge(c(Kn,KnRest),[Kn|Kns]) :-
% 	split_knowledge(KnRest,Kns).

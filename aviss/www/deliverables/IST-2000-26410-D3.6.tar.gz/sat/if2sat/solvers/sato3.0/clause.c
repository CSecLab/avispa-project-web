/*********************************************************************
; Copyright 1992-97, The University of Iowa (UI).  All rights reserved. 
; By using this software the USER indicates that he or she has read, 
; understood and will comply with the following:
;
; --- UI hereby grants USER nonexclusive permission to use, copy and/or
; modify this software for internal, noncommercial, research purposes only.
; Any distribution, including commercial sale or license, of this software,
; copies of the software, its associated documentation and/or modifications
; of either is strictly prohibited without the prior consent of UI.  Title
; to copyright to this software and its associated documentation shall at
; all times remain with UI.  Appropriate copyright notice shall be placed
; on all software copies, and a complete copy of this notice shall be
; included in all copies of the associated documentation.  No right is
; granted to use in advertising, publicity or otherwise any trademark,
; service mark, or the name of UI.  Software and/or its associated
; documentation identified as "confidential," if any, will be protected
; from unauthorized use/disclosure with the same degree of care USER
; regularly employs to safeguard its own such information.
;
; --- This software and any associated documentation is provided "as is," and
; UI MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
; THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
; USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL
; NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL
; PROPERTY RIGHTS OF A THIRD PARTY.  UI, the University of Iowa,
; its Regents, officers, and employees shall not be liable under any
; circumstances for any direct, indirect, special, incidental, or
; consequential damages with respect to any claim by USER or any third
; party on account of or arising from the use, or inability to use, this
; software or its associated documentation, even if UI has been advised
; of the possibility of those damages.
*********************************************************************/
#include "main.h"

int Act_max_atom = 0;

void print_clause (arr, sign, total)
     SATOINT arr[], sign[], total;
{
  fprint_clause (Sato_fp, arr, sign, total);
}

void fprint_clause (f, arr, sign, total)
     FILE *f;
     SATOINT arr[], sign[], total;
{
  Printed_clause++;
  if (OUTPUT == 6) {
    fprintf (f, "( " );
    total--;
    while ( total >= 0 ) {
      if (sign[arr[total]] == 0) fprintf(f, "~");
      fprintf (f, "%d ", arr[total] );
      if (total--) fprintf(f, " | ");
    }
    fprintf(f, ")&\n"); 
  } else {

    if (OUTPUT <= 3) fprintf (f, "( " );
    total--;
    while ( total >= 0 ) {
      if (sign[arr[total]] == 0) fprintf(f, "-");
      fprintf (f, "%d ", arr[total--] );
    }
    if (OUTPUT <= 3) fprintf(f, ")\n"); else fprintf(f, "0\n");
  }
}

void print_unit_clause (fp, sign, i)
     FILE *fp; int sign, i;
{ 
  Printed_clause++;
  if (OUTPUT == 6)
    fprintf(fp, (sign == TT)? "( %d )&\n" : "( ~%d )&\n", i);
  else if (OUTPUT > 3 ) 
    fprintf(fp, (sign == TT)? "%d 0\n" : "-%d 0\n", i);
  else 
    fprintf(fp, (sign == TT)? "( %d )\n" : "( -%d )\n", i);
}

int insert_cl_1 (i, sign) 
     int i, sign;
{
  if (OUTPUT) print_unit_clause(Sato_fp, sign, i);

  Clause_num++;
  Unit_num++;

  /*if(i==194) bug(i);*/

  if (Value[i] == sign) {
    Subsume_num++;

#ifdef MORETRACE
    if (TRACE > 7) printf("   [C%d] is subsumed\n", Clause_num);
#endif

    return 0;
  }

  if (Value[i] != DC) {

#ifdef MORETRACE
    if (TRACE > 4) printf("   [C%d] becomes empty!\n", Clause_num);
#endif
    bug(4);
    return 1;
  }

  assign_value(i, sign);

  return 0;
}

#ifdef BENCHMARK

int insert_cl_2 (a, b, sign, cl_arr, sign_arr) 
     int a, b, sign, cl_arr[], sign_arr[];
{
  int total;

  Clause_num++;
  cl_arr[0] = a; sign_arr[cl_arr[0]] = 0;
  if ((total = insert_one_key(b, sign, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
    return 1;
  return 0;
}

int insert_cl_all_3 (a, b, c, all, cl_arr, sign_arr) 
     int a, b, c, all, cl_arr[], sign_arr[];
{
  int total;

  total = 0;
  if (total) {
    if (all == 0) return 0;
    Clause_num++;
    cl_arr[0] = a; sign_arr[cl_arr[0]] = 0;
    if ((total = insert_one_key(b, 0, cl_arr, sign_arr, 1)) == 0)
      Subsume_num++;
    else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
      return 1;
    return 0;
  }

  Clause_num++;
  cl_arr[0] = c;
  sign_arr[cl_arr[0]] = (all)? 1: 0;
  if ((total = insert_one_key(a, 0, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(b, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
    return 1;

  if (all < 2 || PIGEON == 1) return 0;

  Clause_num++;
  cl_arr[0] = a;
  sign_arr[cl_arr[0]] = 0;
  if ((total = insert_one_key(b, 1, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(c, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
    return 1;

  Clause_num++;
  cl_arr[0] = a;
  sign_arr[cl_arr[0]] = 1;
  if ((total = insert_one_key(b, 0, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(c, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
    return 1;

  return 0;
}

int insert_cl_4(a, b, c, d, all, cl_arr, sign_arr) 
     int a, b, c, d, all, cl_arr[], sign_arr[];
{
  int total;

  total = 0;
  
  if (total) {
    if (all == 0) return 0;
    Clause_num++;
    cl_arr[0] = a; sign_arr[cl_arr[0]] = 0;
    if ((total = insert_one_key(b, 0, cl_arr, sign_arr, 1)) == 0)
      Subsume_num++;
    else if ((total = insert_one_key(c, 0, cl_arr, sign_arr, total)) == 0)
      Subsume_num++;
    else if (qg_insert_clause( cl_arr, sign_arr, total)) return 1;
    return 0;
  }

  Clause_num++;
  cl_arr[0] = d;
  sign_arr[cl_arr[0]] = (all)? 1 : 0;
  if ((total = insert_one_key(a, 0, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(b, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(c, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1) return 1;

  if (all < 2) return 0;

  Clause_num++;
  cl_arr[0] = a;
  sign_arr[cl_arr[0]] = 0;
  if ((total = insert_one_key(b, 0, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(c, 1, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(d, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
    return 1;

  Clause_num++;
  cl_arr[0] = a;
  sign_arr[cl_arr[0]] = 0;
  if ((total = insert_one_key(b, 1, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(c, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(d, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
    return 1;

  Clause_num++;
  cl_arr[0] = a;
  sign_arr[cl_arr[0]] = 1;
  if ((total = insert_one_key(b, 0, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(c, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(d, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1)
    return 1;

  return 0;
}

int insert_cl_5(a, b, c, d, e, sign, cl_arr, sign_arr) 
     int a, b, c, d, e, sign, cl_arr[], sign_arr[];
{
  int total;

  total = 0;

  Clause_num++;
  cl_arr[0] = e;
  sign_arr[cl_arr[0]] = (sign)? 1 : 0;
  if ((total = insert_one_key(a, 0, cl_arr, sign_arr, 1)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(b, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(c, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if ((total = insert_one_key(d, 0, cl_arr, sign_arr, total)) == 0)
    Subsume_num++;
  else if (qg_insert_clause( cl_arr, sign_arr, total) == 1) return 1;

  return 0;
}
#endif

int insert_clause ( cl_arr, sign_arr, total )             
     SATOINT cl_arr[], sign_arr[], total;
{
  int j, i, k;

  if (cl_arr[0] > Max_atom) bug(10);
  if (OUTPUT % 2) print_clause(cl_arr, sign_arr, total);

  /* check for literals and clauses subsumed by unit clauses */
  j = 0;
  for (i = 0; i < total; i++) {
    k = cl_arr[i];
    if (Value[k] == DC) 
      cl_arr[j++] = k;
    else if (Value[k] == sign_arr[k]) { /* the clause is subsumed */
      Subsume_num++;

#ifdef MORETRACE
      if (TRACE > 7)
	fprintf(Sato_fp, "      [C%ld] is subsumed by unit clause (%d).\n",
		Clause_num, (Value[k])? k : -k);
#endif
      return 0;

    } else { /* the literal is subsumed */

#ifdef MORETRACE
      if (TRACE > 7)
	fprintf(Sato_fp, "    %d in [C%ld] is skipped due to a unit clause.\n",
		k, Clause_num);
#endif
    }
  }
  total = j;

  if (total == 0) {

#ifdef MORETRACE
    if (TRACE > 6)
      fprintf(Sato_fp, "    [C%ld] becomes empty.\n", Clause_num);
#endif

    bug(4);
    return 1;
  }

  if (OUTPUT == 2 || OUTPUT == 4 || OUTPUT == 6) 
    print_clause(cl_arr, sign_arr, total);

  if (total == 1) { /* a unit clause is found */

    j = cl_arr[0];
    assign_value(j, sign_arr[j]);
    Unit_num++;

#ifdef MORETRACE
    if (TRACE > 7 || TRACE == 4)
      fprintf (Sato_fp, "    x%d is set to %d by unit clause.\n",
	       j, Value[j]);
#endif

    return 0;
  }

  if (DATA == 1) 
    return list_insert_clause(cl_arr, sign_arr, total);
  else 
    return trie_insert_clause(cl_arr, sign_arr, total);
}


int read_one_clause ( f, cl_arr, sign_arr, tautology, mark )
     FILE *f; 
     SATOINT cl_arr[], sign_arr[], *tautology;
     long mark[];
{
  SATOINT total, sign, i;
  
  total = 0;
  sign = read_int ( f, &i );

  while ( sign != 2 && sign != 3 ) { 

    if (i > Act_max_atom && (Act_max_atom = i) > Max_atom) {
      fprintf ( stderr, "Atom %d > Max_atom(=%d).\n",
	       i, Max_atom);
      exit(0);
    } 

    if (mark == NULL) {
      cl_arr [ total++ ] = i;
      sign_arr [ i ] = sign;
      sign = read_int ( f, &i );
    } else if (PREP == 1) {
      if ((total = insert_one_key(i, sign, cl_arr, sign_arr, total)) == 0) {
	*tautology = 1;
	sign = 2;
      } else {
	sign = read_int ( f, &i );
      }
    } else if (mark[i] == Clause_num) { /* duplicate atoms */
      if (sign_arr[i] != sign) { /* a tautology is found */
	*tautology = 1;
	sign = 2;
      } else { /* skip the same literal */
	sign = read_int ( f, &i );
      }
    } else { /* new atom */
      cl_arr [ total++ ] = i;
      sign_arr [ i ] = sign;
      mark[i] = Clause_num;
      sign = read_int ( f, &i );
    }
  }

  if (FORMAT == 1) {
    if (*tautology || sign == 2) {
      skip_chars_until(f, ')');
      return 0;
    }    
  } else if (*tautology) {
    while (read_int( f, &i ) != 2);
    return 0;
  }
  return total;
}

int input_clauses ( f )
     /* return 1 if an empty clause is found; otherwise, 0 */
     FILE *f; 
{
  if (f == NULL) {
    fprintf(stderr, "the input file is null\n");
  } else {
    SATOINT total_lits, ch, i, tautology;
    long mark[MAX_ATOM];
  
    for (i = 0; i <= Max_atom; i++) mark[i] = MAX_ATOM;
    ch = getc ( f );  

    while ( ch != EOF ) {
      SATOINT cl_arr [ MAX_ATOM ], sign_arr [ MAX_ATOM ];

      if (FORMAT == 0 && (ch <= 'z' && ch >= 'a')) 
	ch = skip_chars_until( f, '\n' ); 

      if ( FORMAT == 0 || ch == '(' ) {
	tautology = 0;
	Clause_num++;
	total_lits = read_one_clause( f, cl_arr, sign_arr, &tautology, mark );

	if (tautology == 1) {
	  Subsume_num++;
#ifdef MORETRACE
	  if (TRACE > 6) 
	    fprintf(Sato_fp, "      [C%ld] is a tautology.\n", Clause_num);
#endif
	  
	} else if (total_lits > 0) {

	  if (FORMAT == 1 && (ch = getc(f)) != ')') {
#ifdef MORETRACE
	    if (TRACE > 6) 
	      fprintf(Sato_fp, "      [C%ld] is a bad clause and is ignored.\n", Clause_num);
#endif
	  } else {

	    if (PREP != 1) reverse(cl_arr, total_lits);
	    if (insert_clause ( cl_arr, sign_arr, total_lits)) {
	      Max_atom = Act_max_atom;
  	      return 1;
	    }
	  }
	} else {
	  Clause_num--; /* empty clause means bad clause */
	}
      }

      ch = getc ( f );                /* skip it */
    }
  }

  Max_atom = Act_max_atom;
  return 0;
}



int insert_one_key (key, sign, cl_arr, sign_arr, total)
     SATOINT key, sign, cl_arr[], sign_arr[], total;
     /* insert a literal into the current clause.
	return 0 if a tautology is found.
	ignore duplicate literals.
	return the length of the current clause. */
{
  SATOINT i, j;

  for (j = 0; j < total; j++)
    if (key > cl_arr[j]) {
      for (i = total; i > j; i--)
	cl_arr[i] = cl_arr[i-1];
      cl_arr[j] = key;
      sign_arr[key] = sign;
      return total+1;
    } else if (key == cl_arr[j]) {
      if (sign == sign_arr[key])
	return total;
      else 
	return 0;
    }
  
  cl_arr[total] = key;
  sign_arr[key] = sign;
  return total+1;
}


int read_int(f, temp)
     FILE *f; 
     SATOINT *temp;
{
  SATOINT sign, nn, ch, good;

  *temp = nn = good = 0;
  sign = 1;

  while ((ch = getc ( f )) != EOF && (ch == ' ' || ch == '\n' || ch == '\t'));

  if (ch == '-') { sign = 0; ch = getc ( f );}

  while (ch >= '0' && ch <= '9') {
    nn = nn * 10 + ch - '0';
    good = 1;
    ch = getc ( f );
  }

  ungetc(ch, f);
  *temp = nn; 
  if (good == 0) { /* printf("!!!%c!!!", ch); */ return 3; }
  if (nn == 0) return 2;
  return sign;
}

int skip_chars_until ( f, c )
     FILE *f; 
     char c;
{ 
  int ch;

  while ((ch = getc ( f )) != EOF && ch != c);
  return ch;
}

/******** functions on integer arrays and strings **********/

void reverse (arr, x)
     SATOINT arr[], x;
{
  SATOINT i = 0;
  SATOINT j = x-1;

  while (i < j) {
    x = arr[i];
    arr[i++] = arr[j];
    arr[j--] = x;
  }
}

void insert_sorter (arr, last)
     SATOINT arr[], last;
{
  SATOINT x, y, i, j;

  for (i = 1; i < last; i++) {
    x = arr[i];
    y = arr[i-1];
    j = i;
    while (y < x) {
      arr[j--] = y;
      y = (j > 0)? arr[j-1] : MAX_SHORT;
    }
    arr[j] = x;
  }
}

int str_int(s, i)
     char s[];
     int i;
{
  int n = 0;
  for( ; s[i] >= '0' && s[i] <= '9'; i++)
    n = n * 10 + s[i] - '0';

  return n;
} 

void str_cat(s1,s2,s3)
     char *s1;
     char *s2;
     char *s3;
{
  SATOINT i, j;

  for (i = 0; s1[i] != '\0'; i++)
    s3[i] = s1[i];
  for (j = 0; s2[j] != '\0'; j++, i++)
    s3[i] = s2[j];
  s3[i] = '\0';
}
    
void str_copy(s, t)
     char *s;
     char *t;
{
  while (*t++ = *s++);
}

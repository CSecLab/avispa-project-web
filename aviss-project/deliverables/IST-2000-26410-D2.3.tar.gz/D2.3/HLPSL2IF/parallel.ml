(***********************************************************************)
(*                                                                     *)
(*                                 Casrul                              *)
(*                                                                     *)
(*                              Protheo, LORIA                         *)
(*                                                                     *)
(*  Copyright 2001 Laboratoire lorrain de recherche en informatique    *)
(*                       et ses applications                           *)
(***********************************************************************)
(* handling --para command line option *)
open Types;;
open Globals;;
open Rules;;
open Utilities;;
let leftMemberTerms = ref ([] : term list);;
let rightMemberTerms = ref ([] : term list);;
let currentSession =  ref ([] : (int * string) list);;
let get_para_instance identifierNumber =
  try
    List.assoc identifierNumber !currentSession;
  with 
      Not_found ->  Utilities.get_identifier_name identifierNumber
;;
let rec replace_by_instance = function
    Op(operand,[term]) -> Op(operand,[(replace_by_instance term)])
  | Cons(consName) -> Cons(get_para_instance (get_identifier_number consName !Globals.ident_list))
  | Var(varName) -> Var(get_para_instance (get_identifier_number varName !Globals.ident_list)) 
  | x -> x;
;;
let check_secret instance =
  let isHidden = ref false in
    List.iter(fun identifierName -> if (instance = identifierName ) then isHidden:=true)!Globals.secret_ident_list;
    !isHidden;
;;
let check_hidden_rule leftTermList rightTermList =
  let isHidden = ref false in
    (* test for the atomic terms of the LHS *)
    List.iter (fun leftTerm ->
		 match leftTerm with
		     (Op("v",[Op(operator,[t])]))-> if (not (List.mem (Op("i",[Op(operator,[t])])) rightTermList)) then isHidden:=true;
		   |_->ignore();
	      ) leftTermList;
    (* test for the atomic terms of the RHS *)
    List.iter (fun rightTerm ->
		 match rightTerm with
		     (Op("v",[Op(operator,[t])]))-> if (not (List.mem (Op("i",[Op(operator,[t])])) rightTermList)) then isHidden:=true;
		   |_->ignore();
	      ) leftTermList;
    (* test for secret terms in LHS *)
    List.iter (fun leftTerm -> 
		 if (not !isHidden) then (
		   match leftTerm with
		       Op("v",[Op("mr",[Cons(consName)])])-> isHidden:=check_secret consName;
		     |Op("v",[Op("nonce",[Cons(consName)])])->   isHidden:=check_secret consName;
		     |Op("v",[Op("sk",[Cons(consName)])])->   isHidden:=check_secret consName;
		     |Op("v",[Op("pk",[Cons(consName)])])->  isHidden:=check_secret consName;
		     |Op("prim",[Op("pk",[Cons (consName)])])->  isHidden:=check_secret (consName ^ "'");
		     |Op("v",[Op("fu",[Cons(consName)])])->  isHidden:=check_secret consName;
		     |Op("v",[Op("tb",[Cons(consName)])])-> isHidden:=check_secret consName;
		     |Op("v",[Op("prim",[Op("pk",[Cons (consName)])])])-> isHidden:=check_secret ( consName ^ "'");
		     |_-> ignore();
		 )) leftTermList;
    (* test for secret terms in RHS *)
    List.iter (fun rightTerm ->
		 if (not !isHidden) then
		   (match rightTerm with
			Op("i",[Op("mr",[Cons(consName)])])-> isHidden:=check_secret consName;
		      |Op("i",[Op("nonce",[Cons(consName)])])->   isHidden:=check_secret consName;
		      |Op("i",[Op("sk",[Cons(consName)])])->   isHidden:=check_secret consName;
		      |Op("i",[Op("pk",[Cons(consName)])])->  isHidden:=check_secret consName;
		      |Op("prim",[Op("pk",[Cons (consName)])])-> isHidden:=check_secret (consName ^ "'");
		      |Op("i",[Op("fu",[Cons(consName)])])->  isHidden:=check_secret consName;
		      |Op("i",[Op("tb",[Cons(consName)])])-> isHidden:=check_secret consName;
		      |Op("i",[Op("prim",[Op("pk",[Cons (consName)])])])->  isHidden:=check_secret ( consName ^ "'");
		      |_-> ignore();
		   )
	      ) rightTermList;
    !isHidden
;;
let rec add_type_para  = function
    Op(operator,[term]) -> Op(operator,[term])
  | Op(operator,termList) -> Op(operator, (List.map (add_type_para ) termList))
  | Var(varName) -> let varType = findtype varName !Globals.ident_list true in
      op_of_type varType (Var(varName));
  | Cons(consName) ->
      let varType = findtype consName !Globals.ident_list true in
        op_of_type varType (Cons(consName));
  | x -> x
;;
let rec compose_para userNumber message step   =
  match message with
      Pair(couplePart1,couplePart2) -> oppair (compose_para userNumber couplePart1 step) (compose_para userNumber couplePart2 step)
    | Crypt(3,key,m) -> opscrypt (compose_para userNumber key step) (compose_para userNumber m step)
    | Crypt(_,key,m) -> opcrypt (compose_para userNumber key step) (compose_para userNumber m step)
    | Arith (a,operand1,operand2) -> (oparith_of_nb a) (compose_para userNumber operand1 step) (compose_para userNumber operand2 step)
    | Logic (a,operand1,operand2) -> (oplogic_of_nb a) (compose_para userNumber operand1 step) (compose_para userNumber operand2 step)
    | Func(f,m) -> opfunct (compose_para userNumber (Id(f)) step) (compose_para userNumber m step)
    | Int(number) -> Cons(string_of_int number)
    | Id(identifierNumber) ->if ((Rules.know message userNumber 0) or (List.mem identifierNumber (fresh_var step)))
      then	 
	replace_by_instance (add_type_para (Cons(Utilities.get_identifier_name identifierNumber)))
      else 
	replace_by_instance (add_type_para (Var(Utilities.get_identifier_name identifierNumber)))
;;
let rec build_para_function leftTermList rightTermList=
  (* local variables *)
  let tail = ref[] in (* to store the remaining member terms after removing those which will be replaced while applying build_para_function *)
  let matchFound=ref 0 in
    (* rules for matching the RHS rules *)
    List.iter (fun x -> 
		 tail:= remove x rightTermList;
		 match (!matchFound,leftTermList,[x]@(!tail)) with
		   |(0,xu,(Op("d",[Cons(t)]))::xd)->build_para_function xu ([Op("i",[Cons(t)])]@xd);matchFound:=1;
		   |(0,xu,(Op("d",[Var(t)]))::xd)->build_para_function xu ([Op("i",[Var(t)])]@xd);matchFound:=1;
		   |(0,xu,(Op("d",[Op(operator,[t])]))::xd)->build_para_function xu ([Op("i",[Op(operator,[t])])]@xd);matchFound:=1;
		   |(0,xu,(Op("d",[Op("c",[t1;t2])]))::xd)->build_para_function xu ([Op("d",[t1])]@[Op("d",[t2])]@xd) ;matchFound:=1
		   |(0,xu,(Op("d",[Op("crypt",[t1;t2])])::xd))->build_para_function (xu@[Op("u",[(Op("prim",[t1]))])]) ([Op("d",[t2])]@xd);build_para_function xu ([Op("i",[Op("crypt",[t1;t2])])]@xd);matchFound:=1;
		   |(0,xu,(Op("d",[Op("scrypt",[t1;t2])])::xd))->matchFound:=1;build_para_function (xu@[Op("u",[t1])]) ([Op("d",[t2])]@xd);matchFound:=1;build_para_function xu ([Op("i",[Op("scrypt",[t1;t2])])]@xd);
		   |_->ignore();
	      )rightTermList;
    (* rules for the LHS matching *)
    List.iter (fun x -> 
		 tail:= remove x leftTermList;
		 match (!matchFound,[x]@(!tail),rightTermList) with
		   |(0,(Op("u",[Cons(t)]))::xu,xd)->build_para_function ([Op("v",[Cons(t)])]@xu) xd;matchFound:=1
		   |(0,(Op("u",[Var(t)]))::xu,xd)->build_para_function ([Op("v",[Var(t)])]@xu) xd;matchFound:=1
		   |(0,(Op("u",[Op(operator,[t])]))::xu,xd)->build_para_function ([Op("v",[Op(operator,[t])])]@xu) xd;matchFound:=1
		   |(0,(Op("u",[Op("c",[t1;t2])])::xu),xd)->build_para_function ([Op("u",[t1])]@[Op("u",[t2])]@xu) xd;matchFound:=1
		   |(0,(Op("u",[Op("crypt",[t1;t2])]))::xu,xd)->build_para_function (xu@[Op("u",[t1])]@[Op("u",[t2])]) xd;build_para_function ([Op("v",[Op("crypt",[t1;t2])])]@ xu) xd;matchFound:=1;
		   |(0,(Op("u",[Op("scrypt",[t1;t2])]))::xu,xd)->build_para_function ([Op("u",[t1])]@[Op("u",[t2])]@xu) xd;build_para_function ([Op("v",[Op("scrypt",[t1;t2])])]@ xu) xd;matchFound:=1;
		   |_->ignore();
	      ) leftTermList;
    (* add the rule to the list *)
    if (!matchFound=0 && ((check_hidden_rule leftTermList rightTermList)=false)) then Globals.para_res:=!Globals.para_res@[([Cons("ii")]@leftTermList,[Cons("ii")]@rightTermList)];
;;
let  build_para_rules () =  
  (* local variable for the list of users for who we will generate parallel rules *)
  let currentUser= ref 0 in
    for sessionCounter=0 to (List.length !Globals.para_ident_list -1 )do
      currentUser:=List.nth !Globals.para_ident_list sessionCounter;
      currentSession:= List.nth !Globals.para_session_instances (sessionCounter+1);
      for step=0 to (!Globals.nbMsgs-1) do
	rightMemberTerms:=[];
	leftMemberTerms:=[];
	if (step=0 && (!currentUser=get_sender 1))
	then
	  rightMemberTerms:=[Op("d",[compose_para !currentUser (get_msg 1) 1])]
	else
	  (
	    if ((step+1) = !Globals.nbMsgs && !currentUser=get_receiver (step+1))
	    then 
	      leftMemberTerms:=[Op("u",[compose_para !currentUser (get_msg (step+1)) step  ])]
	    else
	      (
		if(!currentUser=get_sender (step+1))
		then
		  (
		    leftMemberTerms:=[Op("u",[compose_para !currentUser (get_msg step) (step-1)])];
		    rightMemberTerms:=[Op("d",[compose_para !currentUser (get_msg (step+1)) (step+1)])]
		  )
	      );
	  );
	if ((!leftMemberTerms <> []) or (!rightMemberTerms <> []))
	then
	  build_para_function !leftMemberTerms !rightMemberTerms;
      done;
    done;
    !Globals.para_res;
;;
